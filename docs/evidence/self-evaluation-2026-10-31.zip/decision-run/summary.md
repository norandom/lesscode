# Evaluation summary

Report format version: 1
Run: `351b6574f76c4a0487697c4e9b7ab27f`; plan: `cbda8d5205caca385d21e9b42023f9202fa7965754dfbd05e4c8b700611e8b36`
Decision: `accepted`

## Decision reasons

- `Candidate accepted under the frozen profile; required declared checks passed`
- `Results cover only declared checks; unchecked behavior remains; not proof of equivalence`
- `Protection: local_detection; provider evidence: None`

## Declared checks

Passing results mean passing the declared checks; this is not proof of equivalence. Unchecked behavior remains unverified.

### Baseline

- `self.unit_suite`: `passed`; kind `invariant`; required; diagnostics `baseline/checks/0/1be249a3084944e390222494cf6a0f2e.check.xml`
- `self.threshold_oracle`: `passed`; kind `invariant`; required; diagnostics `baseline/checks/0/1be249a3084944e390222494cf6a0f2e.check.xml`
- Execution `self`: `completed`; exit `0`; elapsed `0.9839999997057021` seconds; stdout `baseline/checks/0/26fae77f0c714b22b8cff479cdd8f5c4.stdout.log`; stderr `baseline/checks/0/26fae77f0c714b22b8cff479cdd8f5c4.stderr.log`

### Candidate

- `self.unit_suite`: `passed`; kind `invariant`; required; diagnostics `candidate/checks/0/b372198ea3ee42368e3600b4451a8ec7.check.xml`
- `self.threshold_oracle`: `passed`; kind `invariant`; required; diagnostics `candidate/checks/0/b372198ea3ee42368e3600b4451a8ec7.check.xml`
- Execution `self`: `completed`; exit `0`; elapsed `0.625` seconds; stdout `candidate/checks/0/43002bdfd26740b1b968cb1b19788278.stdout.log`; stderr `candidate/checks/0/43002bdfd26740b1b968cb1b19788278.stderr.log`

## Integrity and protections

Status: `unchanged`; protection: `local_detection`.
Local change detection does not isolate malicious workloads or prevent privileged writes.

## Structural and other metrics

Each producer and definition is separate. Structured payloads are retained as recorded; no combined quality score is calculated.

### `complexity`

- Before: `available`; value `{&quot;count&quot;: 7, &quot;files&quot;: [{&quot;nloc&quot;: 260, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;}], &quot;functions&quot;: [{&quot;ccn&quot;: 53, &quot;end_line&quot;: 127, &quot;long_name&quot;: &quot;compare( baseline : Observation , candidate : Observation , profile : FrozenProfile , integrity : IntegrityResult )&quot;, &quot;name&quot;: &quot;compare&quot;, &quot;nloc&quot;: 106, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 15, &quot;token_count&quot;: 823}, {&quot;ccn&quot;: 41, &quot;end_line&quot;: 242, &quot;long_name&quot;: &quot;compare_metric( before : MetricEvidence | None , after : MetricEvidence | None )&quot;, &quot;name&quot;: &quot;compare_metric&quot;, &quot;nloc&quot;: 80, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 162, &quot;token_count&quot;: 634}, {&quot;ccn&quot;: 13, &quot;end_line&quot;: 288, &quot;long_name&quot;: &quot;evaluate_threshold( comparison : MetricComparison , threshold : Threshold )&quot;, &quot;name&quot;: &quot;evaluate_threshold&quot;, &quot;nloc&quot;: 28, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 260, &quot;token_count&quot;: 194}, {&quot;ccn&quot;: 4, &quot;end_line&quot;: 159, &quot;long_name&quot;: &quot;_scalar( evidence : MetricEvidence | None )&quot;, &quot;name&quot;: &quot;_scalar&quot;, &quot;nloc&quot;: 4, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 156, &quot;token_count&quot;: 34}, {&quot;ccn&quot;: 3, &quot;end_line&quot;: 153, &quot;long_name&quot;: &quot;_finite_number( value )&quot;, &quot;name&quot;: &quot;_finite_number&quot;, &quot;nloc&quot;: 7, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 147, &quot;token_count&quot;: 36}, {&quot;ccn&quot;: 3, &quot;end_line&quot;: 253, &quot;long_name&quot;: &quot;compare_metrics.index( records )&quot;, &quot;name&quot;: &quot;compare_metrics.index&quot;, &quot;nloc&quot;: 7, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 247, &quot;token_count&quot;: 37}, {&quot;ccn&quot;: 2, &quot;end_line&quot;: 257, &quot;long_name&quot;: &quot;compare_metrics( before : tuple [ MetricEvidence , ... ] , after : tuple [ MetricEvidence , ... ] )&quot;, &quot;name&quot;: &quot;compare_metrics&quot;, &quot;nloc&quot;: 6, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 245, &quot;token_count&quot;: 82}], &quot;kind&quot;: &quot;complexity&quot;, &quot;maximum&quot;: 53, &quot;median&quot;: 4, &quot;minimum&quot;: 2, &quot;p95&quot;: 53}`; unit `CCN`; producer `lizard` version `1.17.31`; definition `lizard-python-ccn-files-functions-median-nearest-rank-p95-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `baseline/metrics/complexity/69a4bcb8495a4cb9b843401dc45b51a9.stdout.log`
- After: `available`; value `{&quot;count&quot;: 7, &quot;files&quot;: [{&quot;nloc&quot;: 257, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;}], &quot;functions&quot;: [{&quot;ccn&quot;: 53, &quot;end_line&quot;: 127, &quot;long_name&quot;: &quot;compare( baseline : Observation , candidate : Observation , profile : FrozenProfile , integrity : IntegrityResult )&quot;, &quot;name&quot;: &quot;compare&quot;, &quot;nloc&quot;: 106, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 15, &quot;token_count&quot;: 823}, {&quot;ccn&quot;: 41, &quot;end_line&quot;: 242, &quot;long_name&quot;: &quot;compare_metric( before : MetricEvidence | None , after : MetricEvidence | None )&quot;, &quot;name&quot;: &quot;compare_metric&quot;, &quot;nloc&quot;: 80, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 162, &quot;token_count&quot;: 634}, {&quot;ccn&quot;: 9, &quot;end_line&quot;: 285, &quot;long_name&quot;: &quot;evaluate_threshold( comparison : MetricComparison , threshold : Threshold )&quot;, &quot;name&quot;: &quot;evaluate_threshold&quot;, &quot;nloc&quot;: 25, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 260, &quot;token_count&quot;: 185}, {&quot;ccn&quot;: 4, &quot;end_line&quot;: 159, &quot;long_name&quot;: &quot;_scalar( evidence : MetricEvidence | None )&quot;, &quot;name&quot;: &quot;_scalar&quot;, &quot;nloc&quot;: 4, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 156, &quot;token_count&quot;: 34}, {&quot;ccn&quot;: 3, &quot;end_line&quot;: 153, &quot;long_name&quot;: &quot;_finite_number( value )&quot;, &quot;name&quot;: &quot;_finite_number&quot;, &quot;nloc&quot;: 7, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 147, &quot;token_count&quot;: 36}, {&quot;ccn&quot;: 3, &quot;end_line&quot;: 253, &quot;long_name&quot;: &quot;compare_metrics.index( records )&quot;, &quot;name&quot;: &quot;compare_metrics.index&quot;, &quot;nloc&quot;: 7, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 247, &quot;token_count&quot;: 37}, {&quot;ccn&quot;: 2, &quot;end_line&quot;: 257, &quot;long_name&quot;: &quot;compare_metrics( before : tuple [ MetricEvidence , ... ] , after : tuple [ MetricEvidence , ... ] )&quot;, &quot;name&quot;: &quot;compare_metrics&quot;, &quot;nloc&quot;: 6, &quot;path&quot;: &quot;src/lesscode_baseline/decision.py&quot;, &quot;start_line&quot;: 245, &quot;token_count&quot;: 82}], &quot;kind&quot;: &quot;complexity&quot;, &quot;maximum&quot;: 53, &quot;median&quot;: 4, &quot;minimum&quot;: 2, &quot;p95&quot;: 53}`; unit `CCN`; producer `lizard` version `1.17.31`; definition `lizard-python-ccn-files-functions-median-nearest-rank-p95-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `candidate/metrics/complexity/cb393a47ee5c4cf699cb5892b9361e52.stdout.log`
- Comparison: `unavailable`; before unavailable; after unavailable; absolute delta unavailable `CCN`; percentage delta unavailable percent; reason `structured measurement has no declared scalar projection`; percentage reason `structured measurement has no declared scalar projection`

### `duplication`

- Before: `available`; value `{&quot;clones&quot;: [], &quot;duplicated_tokens&quot;: 0, &quot;kind&quot;: &quot;duplication&quot;, &quot;mode&quot;: &quot;weak&quot;, &quot;ratio&quot;: 0.0, &quot;ratio_reason&quot;: null, &quot;scanned_paths&quot;: [&quot;src/lesscode_baseline/decision.py&quot;], &quot;total_tokens&quot;: 3468, &quot;upstream_percentage&quot;: 0, &quot;zero_token_paths&quot;: []}`; unit `ratio`; producer `jscpd` version `4.0.5`; definition `jscpd-python-weak-minlines5-mintokens50-aggregate-pair-span-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `baseline/metrics/duplication/duplication-wqpg4k6s/jscpd-report.json`
- After: `available`; value `{&quot;clones&quot;: [], &quot;duplicated_tokens&quot;: 0, &quot;kind&quot;: &quot;duplication&quot;, &quot;mode&quot;: &quot;weak&quot;, &quot;ratio&quot;: 0.0, &quot;ratio_reason&quot;: null, &quot;scanned_paths&quot;: [&quot;src/lesscode_baseline/decision.py&quot;], &quot;total_tokens&quot;: 3429, &quot;upstream_percentage&quot;: 0, &quot;zero_token_paths&quot;: []}`; unit `ratio`; producer `jscpd` version `4.0.5`; definition `jscpd-python-weak-minlines5-mintokens50-aggregate-pair-span-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `candidate/metrics/duplication/duplication-02pq_h8s/jscpd-report.json`
- Comparison: `unavailable`; before unavailable; after unavailable; absolute delta unavailable `ratio`; percentage delta unavailable percent; reason `structured measurement has no declared scalar projection`; percentage reason `structured measurement has no declared scalar projection`

### `compressed_source_bytes`

- Before: `available`; value `4022`; unit `bytes`; producer `lesscode-size` version `CPython 3.12.10; zlib 1.3.1/1.3.1; syntax Python 3.12.10`; definition `product-sorted-utf8-path-bytes-u64be-lengths-gzip-level9-mtime0-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `baseline/metrics/sizes/9c84f45a145c46439bdb06ec2d352774.stderr.log`
- After: `available`; value `4024`; unit `bytes`; producer `lesscode-size` version `CPython 3.12.10; zlib 1.3.1/1.3.1; syntax Python 3.12.10`; definition `product-sorted-utf8-path-bytes-u64be-lengths-gzip-level9-mtime0-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `candidate/metrics/sizes/8ed351afd6274d15903e388a9a913b8a.stderr.log`
- Comparison: `available`; before `4022`; after `4024`; absolute delta `2` `bytes`; percentage delta `0.04972650422675286` percent; reason unavailable; percentage reason unavailable

### `physical_lines`

- Before: `available`; value `288`; unit `lines`; producer `lesscode-size` version `CPython 3.12.10; zlib 1.3.1/1.3.1; syntax Python 3.12.10`; definition `product-bytes-splitlines-final-unterminated-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `baseline/metrics/sizes/9c84f45a145c46439bdb06ec2d352774.stderr.log`
- After: `available`; value `285`; unit `lines`; producer `lesscode-size` version `CPython 3.12.10; zlib 1.3.1/1.3.1; syntax Python 3.12.10`; definition `product-bytes-splitlines-final-unterminated-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `candidate/metrics/sizes/8ed351afd6274d15903e388a9a913b8a.stderr.log`
- Comparison: `available`; before `288`; after `285`; absolute delta `-3` `lines`; percentage delta `-1.0416666666666667` percent; reason unavailable; percentage reason unavailable

### `source_bytes`

- Before: `available`; value `14944`; unit `bytes`; producer `lesscode-size` version `CPython 3.12.10; zlib 1.3.1/1.3.1; syntax Python 3.12.10`; definition `product-original-bytes-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `baseline/metrics/sizes/9c84f45a145c46439bdb06ec2d352774.stderr.log`
- After: `available`; value `14846`; unit `bytes`; producer `lesscode-size` version `CPython 3.12.10; zlib 1.3.1/1.3.1; syntax Python 3.12.10`; definition `product-original-bytes-v1`; scope `b7ff35d891d7a0b462726752ac0a91bf10ccdb6d879133eb3fc1f6047d6de45d`; reason unavailable; raw `candidate/metrics/sizes/8ed351afd6274d15903e388a9a913b8a.stderr.log`
- Comparison: `available`; before `14944`; after `14846`; absolute delta `-98` `bytes`; percentage delta `-0.6557815845824411` percent; reason unavailable; percentage reason unavailable

## File changes

- Product files:
  - added: none
  - removed: none
  - modified: `src/lesscode_baseline/decision.py`
- Test files:
  - added: none
  - modified: none
  - removed: none

## Time and cost

Evaluation elapsed: `48.688000000081956` seconds.
Agent execution time: unavailable (not supplied in RunReport).
Agent token usage and provider cost: unavailable (not supplied in RunReport).

## Limitations

- `Local change detection is not adversarial isolation; unchecked behavior remains.`

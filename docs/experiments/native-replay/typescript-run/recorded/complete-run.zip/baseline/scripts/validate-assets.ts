import { existsSync, readdirSync, readFileSync } from "node:fs"
import { basename, join } from "node:path"

export interface AssetValidationResult {
  readonly ok: boolean
  readonly errors: readonly string[]
}

interface FrontmatterDocument {
  readonly frontmatter: ReadonlyMap<string, string>
  readonly frontmatterSource: string
  readonly body: string
}

const requiredScaffoldPaths = [
  "package.json",
  "opencode.json",
  "pnpm-workspace.yaml",
  "tsconfig.json",
  "install.sh",
  "install-dev.sh",
  "install.ps1",
  "install-dev.ps1",
  "SECURITY.md",
  ".github/dependabot.yml",
  ".github/workflows/release.yml",
  ".github/workflows/plugin-security-scan.yml",
  "src",
  ".opencode/plugins",
  ".opencode/plugins/open-ultracode",
  ".opencode/plugins/open-ultracode/index.ts",
  ".opencode/tools",
  ".opencode/tools/open_ultracode_configure_fusion.ts",
  ".opencode/lib",
  ".opencode/lib/fusion-config.ts",
  ".opencode/skills/open-ultracode",
  ".opencode/agents",
  ".opencode/commands",
  "docs",
  "tests",
  "scripts/validate-assets.ts"
] as const

const requiredCommandAssets = [
  "ultracode.md",
  "ultracode-debug.md",
  "ultracode-fusion.md",
  "ultracode-fusion-models.md",
  "ultracode-spec-audit.md",
  "ultracode-research.md",
  "ultracode-verify.md",
  "ultrathink.md",
  "ultrathink-fusion.md"
] as const

const requiredAgentAssets = [
  "open-ultracode.md",
  "open-ultracode-planner.md",
  "open-ultracode-implementer.md",
  "open-ultracode-adversary.md",
  "open-ultracode-reconciler.md",
  "open-ultracode-verifier.md",
  "open-ultracode-researcher.md",
  "ultracode-fusion-panel-a.md",
  "ultracode-fusion-panel-b.md",
  "ultracode-fusion-arbiter.md"
] as const

const fusionAgentPattern = /^ultracode-fusion-[\w-]+\.md$/u

export function validateAssets(root = process.cwd()): AssetValidationResult {
  const errors: string[] = []

  for (const relativePath of requiredScaffoldPaths) {
    if (!existsSync(join(root, relativePath))) {
      errors.push(`${relativePath} is missing`)
    }
  }

  validatePlugin(root, errors)
  validateFusionConfigTool(root, errors)
  validateOpenCodeConfig(root, errors)
  validateComplianceControls(root, errors)
  validateSkill(root, errors)
  validateCommands(root, errors)
  validateAgents(root, errors)

  return { ok: errors.length === 0, errors }
}

function validateOpenCodeConfig(root: string, errors: string[]): void {
  const relativePath = "opencode.json"
  const content = readAsset(root, relativePath, errors)
  if (content === undefined) return

  const config = readJsonObject(relativePath, content, errors)
  if (config === undefined) return

  if (config.$schema !== "https://opencode.ai/config.json") {
    errors.push(`${relativePath} must declare https://opencode.ai/config.json schema`)
  }
  const plugins = Array.isArray(config.plugins) ? config.plugins : []
  const registersPlugin = plugins.some(
    (entry) => isRecord(entry) && entry.package === "./.opencode/plugins/open-ultracode"
  )
  if (!registersPlugin) {
    errors.push(`${relativePath} must register ./.opencode/plugins/open-ultracode as a plugins package entry`)
  }
  if (config.plugin !== undefined) {
    errors.push(`${relativePath} must use the OpenCode 2 plugins array, not the V1 plugin key`)
  }
  if (!arrayEquals(config.skills, [".opencode/skills"])) {
    errors.push(`${relativePath} must register .opencode/skills in the skills array`)
  }
  const permissions = Array.isArray(config.permissions) ? config.permissions : []
  const asksBeforeFusionMutation = permissions.some(
    (entry) => isRecord(entry) && entry.action === "open_ultracode_configure_fusion" && entry.effect === "ask"
  )
  if (!asksBeforeFusionMutation) {
    errors.push(`${relativePath} must ask before open_ultracode_configure_fusion mutations via the permissions array`)
  }
  if ("model" in config || "provider" in config) {
    errors.push(`${relativePath} must not configure model or provider routing`)
  }
}

function validatePlugin(root: string, errors: string[]): void {
  const relativePath = ".opencode/plugins/open-ultracode/index.ts"
  const content = readAsset(root, relativePath, errors)
  if (content === undefined) return
  if (!/export\s+\{[^}]*default[^}]*\}|export\s+default/.test(content)) {
    errors.push(`${relativePath} must export an opencode plugin entry point`)
  }
  if (/\b(model|provider)\s*:/.test(content)) {
    errors.push(`${relativePath} must not configure model or provider routing`)
  }
}

function validateSkill(root: string, errors: string[]): void {
  const relativePath = ".opencode/skills/open-ultracode/SKILL.md"
  const document = readFrontmatter(root, relativePath, errors)
  if (document === undefined) return

  if (document.frontmatter.get("name") !== "open-ultracode") {
    errors.push(`${relativePath} frontmatter must set name: open-ultracode`)
  }
  if (!document.frontmatter.has("description")) {
    errors.push(`${relativePath} frontmatter must include description`)
  }
  requireBody(relativePath, document.body, [/selected model/i, /verification/i, /missing task context|incomplete spec/i], errors)
  rejectModelOverride(relativePath, document, errors)
}

function validateCommands(root: string, errors: string[]): void {
  for (const fileName of requiredCommandAssets) {
    const relativePath = `.opencode/commands/${fileName}`
    const document = readFrontmatter(root, relativePath, errors)
    if (document === undefined) continue

    if (!document.frontmatter.has("description")) {
      errors.push(`${relativePath} frontmatter must include description`)
    }
    if (document.frontmatter.has("name")) {
      errors.push(`${relativePath} frontmatter must not include name; OpenCode derives command names from filenames`)
    }
    rejectModelOverride(relativePath, document, errors)
    if (fileName === "ultracode-fusion-models.md") {
      requireBody(relativePath, document.body, [/\$ARGUMENTS/, /open_ultracode_configure_fusion/i, /provider\/model/i, /selected model/i], errors)
      continue
    }
    requireBody(relativePath, document.body, [/\$ARGUMENTS/, /selected model/i, /Workflow mode:/i], errors)
    if (!/missing task context|not provide enough task context/i.test(document.body)) {
      errors.push(`${relativePath} must ask focused questions when task context is missing`)
    }
  }
}

function validateComplianceControls(root: string, errors: string[]): void {
  const releasePath = ".github/workflows/release.yml"
  const releaseWorkflow = readAsset(root, releasePath, errors)
  if (releaseWorkflow !== undefined) {
    validateImmutableActionReferences(releasePath, releaseWorkflow, errors)
  }

  const scannerPath = ".github/workflows/plugin-security-scan.yml"
  const scannerWorkflow = readAsset(root, scannerPath, errors)
  if (scannerWorkflow !== undefined) {
    validateImmutableActionReferences(scannerPath, scannerWorkflow, errors)
    for (const [pattern, message] of [
      [/^permissions:\s*\n {2}contents: read\s*$/mu, "must grant only read access to contents"],
      [/persist-credentials:\s*false/u, "must disable persisted checkout credentials"],
      [/hashgraph-online\/ai-plugin-scanner-action@[0-9a-f]{40}/u, "must use the pinned Hashgraph Online scanner action"],
      [/min_score:\s*["']?75["']?/u, "must enforce a minimum scanner score of 75"],
      [/fail_on_severity:\s*none/u, "must report findings without changing the catalog score gate"]
    ] as const) {
      if (!pattern.test(scannerWorkflow)) errors.push(`${scannerPath} ${message}`)
    }
    if (/\bsecrets\s*:/u.test(scannerWorkflow)) {
      errors.push(`${scannerPath} must not pass repository secrets to the scanner`)
    }
  }

  const dependabotPath = ".github/dependabot.yml"
  const dependabot = readAsset(root, dependabotPath, errors)
  if (dependabot !== undefined) {
    for (const ecosystem of ["npm", "github-actions"] as const) {
      if (!new RegExp(`package-ecosystem:\\s*["']${ecosystem}["']`, "u").test(dependabot)) {
        errors.push(`${dependabotPath} must monitor ${ecosystem}`)
      }
    }
  }

  const securityPath = "SECURITY.md"
  const securityPolicy = readAsset(root, securityPath, errors)
  if (securityPolicy !== undefined) {
    for (const pattern of [/supported versions/i, /security\/advisories\/new/i, /do not open a public issue/i]) {
      if (!pattern.test(securityPolicy)) errors.push(`${securityPath} is missing required disclosure guidance matching ${pattern}`)
    }
  }
}

function validateImmutableActionReferences(relativePath: string, content: string, errors: string[]): void {
  for (const match of content.matchAll(/^\s*(?:-\s*)?uses:\s*([^\s#]+).*$/gmu)) {
    const reference = match[1]
    if (reference !== undefined && !/@[0-9a-f]{40}$/u.test(reference)) {
      errors.push(`${relativePath} action ${reference} must be pinned to a full commit SHA`)
    }
  }
}

function validateAgents(root: string, errors: string[]): void {
  for (const fileName of requiredAgentAssets) {
    const relativePath = `.opencode/agents/${fileName}`
    const document = readFrontmatter(root, relativePath, errors)
    if (document === undefined) continue

    if (!document.frontmatter.has("description")) {
      errors.push(`${relativePath} frontmatter must include description`)
    }
    if (document.frontmatter.get("mode") !== "subagent") {
      errors.push(`${relativePath} frontmatter must set mode: subagent`)
    }
    if (!fusionAgentPattern.test(fileName)) {
      rejectModelOverride(relativePath, document, errors)
    }
    validateAgentPermissions(relativePath, document, errors)
    if (fusionAgentPattern.test(fileName)) {
      requireBody(relativePath, document.body, [/fusion/i, /supplied context/i, /structured round output/i], errors)
      validateFusionAgentOptions(relativePath, document, errors)
    } else {
      requireBody(relativePath, document.body, [/inherit the active selected model/i, /do not change provider/i, /structured output/i], errors)
    }
  }

  for (const fileName of listAgentMarkdownFiles(root, errors)) {
    if (requiredAgentAssets.includes(fileName as (typeof requiredAgentAssets)[number]) || fusionAgentPattern.test(fileName)) {
      continue
    }
    const relativePath = `.opencode/agents/${fileName}`
    const document = readFrontmatter(root, relativePath, errors)
    if (document !== undefined) {
      rejectModelOverride(relativePath, document, errors)
    }
  }
}

function validateFusionConfigTool(root: string, errors: string[]): void {
  const relativePath = ".opencode/tools/open_ultracode_configure_fusion.ts"
  const content = readAsset(root, relativePath, errors)
  if (content === undefined) return

  for (const pattern of [
    /from\s+["']@opencode-ai\/plugin["']/,
    /export\s+default\s+tool\s*\(/,
    /args\s*:/,
    /panelA\s*:/,
    /panelB\s*:/,
    /decider\s*:/,
    /\.optional\s*\(\s*\)/,
    /configureFusionModels\s*\(/,
    /context\.worktree/
  ]) {
    if (!pattern.test(content)) {
      errors.push(`${relativePath} is missing required OpenCode tool structure: ${pattern.source}`)
    }
  }
}

function validateFusionAgentOptions(relativePath: string, document: FrontmatterDocument, errors: string[]): void {
  const model = document.frontmatter.get("model")
  if (model === undefined || !/^[A-Za-z0-9][A-Za-z0-9._-]*\/[^\s#]+$/u.test(model)) {
    errors.push(`${relativePath} model must be a provider/model reference without an inline variant`)
  }
  if (document.frontmatter.get("variant") !== "max") {
    errors.push(`${relativePath} frontmatter must set variant: max`)
  }
  if (document.frontmatter.get("reasoningEffort") !== "max") {
    errors.push(`${relativePath} frontmatter must set reasoningEffort: max`)
  }
  if (!/^ {2}open_ultracode_configure_fusion:\s*deny\s*$/mu.test(document.frontmatterSource)) {
    errors.push(`${relativePath} must deny open_ultracode_configure_fusion`)
  }
}

function listAgentMarkdownFiles(root: string, errors: string[]): readonly string[] {
  const agentsPath = join(root, ".opencode/agents")
  if (!existsSync(agentsPath)) return []
  try {
    return readdirSync(agentsPath).filter((fileName) => fileName.endsWith(".md"))
  } catch (error) {
    errors.push(`.opencode/agents could not be read: ${error instanceof Error ? error.message : String(error)}`)
    return []
  }
}

function validateAgentPermissions(relativePath: string, document: FrontmatterDocument, errors: string[]): void {
  if (!document.frontmatter.has("permission")) {
    errors.push(`${relativePath} frontmatter must include permission constraints`)
    return
  }
  if (document.frontmatter.get("permission") === "allow") {
    errors.push(`${relativePath} permission must not allow all tools`)
  }

  const permissionBlock = readFrontmatterBlock(document, "permission")
  if (/\bedit\s*:\s*allow\b/i.test(permissionBlock)) {
    errors.push(`${relativePath} permission must not set edit: allow`)
  }
  if (/\bbash\s*:\s*allow\b/i.test(permissionBlock)) {
    errors.push(`${relativePath} permission must not set bash: allow`)
  }
  if (/\bpermission\s*:\s*allow\b/i.test(permissionBlock)) {
    errors.push(`${relativePath} permission must not allow all tools`)
  }
}

function readAsset(root: string, relativePath: string, errors: string[]): string | undefined {
  const fullPath = join(root, relativePath)
  if (!existsSync(fullPath)) {
    errors.push(`${relativePath} is missing`)
    return undefined
  }
  return readFileSync(fullPath, "utf8")
}

function readFrontmatter(root: string, relativePath: string, errors: string[]): FrontmatterDocument | undefined {
  const content = readAsset(root, relativePath, errors)
  if (content === undefined) return undefined

  const normalizedContent = content.replace(/\r\n/gu, "\n")
  const match = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/u.exec(normalizedContent)
  if (match === null) {
    errors.push(`${relativePath} must include YAML frontmatter`)
    return undefined
  }
  const frontmatterSource = match[1]
  const body = match[2]
  if (frontmatterSource === undefined || body === undefined) {
    errors.push(`${relativePath} frontmatter could not be parsed`)
    return undefined
  }

  return {
    frontmatter: parseFrontmatter(frontmatterSource),
    frontmatterSource,
    body
  }
}

function parseFrontmatter(frontmatter: string): ReadonlyMap<string, string> {
  const values = new Map<string, string>()
  for (const line of frontmatter.split("\n")) {
    const match = /^(\w[\w-]*)\s*:\s*(.*)$/u.exec(line)
    if (match !== null) {
      const key = match[1]
      const value = match[2]
      if (key !== undefined && value !== undefined) {
        values.set(key, value)
      }
    }
  }
  return values
}

function readFrontmatterBlock(document: FrontmatterDocument, key: string): string {
  if (document.frontmatter.has(key)) {
    const match = new RegExp(`(^|\\n)${key}:([\\s\\S]*?)(\\n\\w[\\w-]*\\s*:|$)`, "u").exec(
      document.frontmatterSource
    )
    return match?.[2] ?? document.frontmatter.get(key) ?? ""
  }
  return ""
}

function rejectModelOverride(relativePath: string, document: FrontmatterDocument, errors: string[]): void {
  if (document.frontmatter.has("model")) {
    errors.push(`${relativePath} frontmatter must not include model overrides`)
  }
  if (/override the selected model/i.test(document.body)) {
    errors.push(`${relativePath} must not instruct users to override the selected model`)
  }
}

function requireBody(relativePath: string, body: string, patterns: readonly RegExp[], errors: string[]): void {
  for (const pattern of patterns) {
    if (!pattern.test(body)) {
      errors.push(`${relativePath} body is missing required guidance matching ${pattern}`)
    }
  }
}

function readJsonObject(relativePath: string, content: string, errors: string[]): Record<string, unknown> | undefined {
  try {
    const parsed = JSON.parse(content) as unknown
    if (isRecord(parsed)) {
      return parsed
    }
    errors.push(`${relativePath} must contain a JSON object`)
  } catch (error) {
    errors.push(`${relativePath} must contain valid JSON: ${error instanceof Error ? error.message : String(error)}`)
  }
  return undefined
}

function arrayEquals(value: unknown, expected: readonly string[]): boolean {
  return Array.isArray(value) && value.length === expected.length && value.every((item, index) => item === expected[index])
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
}

if (isDirectExecution()) {
  const result = validateAssets()
  if (result.ok) {
    console.log("OpenUltraCode assets are valid")
  } else {
    console.error(`OpenUltraCode asset validation failed:\n${result.errors.join("\n")}`)
    process.exitCode = 1
  }
}

function isDirectExecution(): boolean {
  const scriptPath = process.argv[1]
  return scriptPath !== undefined && basename(scriptPath) === basename(new URL(import.meta.url).pathname)
}

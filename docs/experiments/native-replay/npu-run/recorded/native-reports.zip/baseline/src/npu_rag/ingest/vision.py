"""Resolve image references through an injected image-to-text interface.

Apply size thresholds, native chart metadata, cache lookup and backend calls
in that order. Return a FigureSegment or a typed omission. This interface
does not yet accept multimodal embeddings; NPU vision requires a separate
pixel-input contract after Windows qualification.
"""

from __future__ import annotations

import concurrent.futures
import hashlib
from collections.abc import Sequence
from pathlib import Path
from typing import Protocol

from npu_rag.ingest.config import IngestConfig
from npu_rag.ingest.errors import VisionError, VisionUnavailable
from npu_rag.ingest.state import StateStore
from npu_rag.ingest.types import (
    ChartRanges,
    FigureSegment,
    ImageRef,
    Omission,
    OmissionCategory,
    Provenance,
    Resolved,
)

__all__ = [
    "PIPELINE_VERSION",
    "VisionDescriber",
    "format_chart_ranges",
    "resolve",
    "resolve_all",
]

# Version the image-to-text cache independently of the embedding model.
PIPELINE_VERSION = "image-text:v2"


class VisionDescriber(Protocol):
    """Protocol for image-to-text conversion (design.md, Service Interface)."""

    def describe(self, image: ImageRef) -> str:
        """Transcribe visible text from image locally.

        Raises VisionError on failure; raises VisionUnavailable if model files
        or required external binaries are absent.
        """
        ...












def format_chart_ranges(ranges: ChartRanges) -> str:
    """Format native Excel chart series ranges into figure text."""
    parts: list[str] = []
    if ranges.value_ranges:
        parts.append(f"values: {', '.join(ranges.value_ranges)}")
    if ranges.category_ranges:
        parts.append(f"categories: {', '.join(ranges.category_ranges)}")
    return "; ".join(parts)


def _recognizer_id(describer: VisionDescriber | None, config: IngestConfig) -> str:
    if describer is not None:
        rec_id = getattr(describer, "recognizer_id", None) or getattr(describer, "model_id", None)
        if rec_id:
            return str(rec_id)
    return config.vision_model or "unconfigured"


def resolve(
    ref: ImageRef,
    *,
    store: StateStore,
    describer: VisionDescriber | None,
    config: IngestConfig,
    source_path: Path | None = None,
) -> Resolved:
    """Resolve a single ImageRef in strict gate order.

    Order: threshold -> chart_ranges -> cache -> models present -> describe -> store.
    """
    path = source_path if source_path is not None else Path("")
    rec_id = _recognizer_id(describer, config)

    # Gate 1: Threshold
    shorter_side = min(ref.width, ref.height)
    if shorter_side < config.min_image_pixels:
        return Resolved(
            figure=None,
            omission=Omission(
                category=OmissionCategory.BELOW_THRESHOLD,
                path=path,
                reason=(
                    f"image dimensions ({ref.width}x{ref.height}) shorter side "
                    f"{shorter_side}px is below minimum {config.min_image_pixels}px"
                ),
            ),
        )

    # Gate 2: Native chart ranges short-circuit
    if ref.chart_ranges is not None:
        text = format_chart_ranges(ref.chart_ranges)
        figure = FigureSegment(
            text=text,
            locator=ref.locator,
            provenance=Provenance(
                vision_model=rec_id,
                prompt_version=PIPELINE_VERSION,
            ),
        )
        return Resolved(figure=figure, omission=None)

    # Gate 3: Cache lookup (requirements 5.4, 5.5)
    image_hash = hashlib.sha256(ref.data).hexdigest()
    cached = store.cached_description(
        image_sha256=image_hash,
        model_id=rec_id,
        prompt_version=PIPELINE_VERSION,
    )
    if cached is not None:
        figure = FigureSegment(
            text=cached,
            locator=ref.locator,
            provenance=Provenance(
                vision_model=rec_id,
                prompt_version=PIPELINE_VERSION,
            ),
        )
        return Resolved(figure=figure, omission=None)

    # Gate 4: Models present / describer configured (requirements 5.2, 9.4)
    if describer is None:
        return Resolved(
            figure=None,
            omission=Omission(
                category=OmissionCategory.VISION_UNAVAILABLE,
                path=path,
                reason="Windows NPU vision backend is not configured",
                missing_capability="windows_npu_vision",
            ),
        )

    # Gate 5: Describe (one image per call; requirements 5.1, 5.6, 5.9)
    try:
        text = describer.describe(ref)
    except VisionUnavailable as exc:
        missing_cap = (
            getattr(exc, "missing_capability", None)
            or exc.message
            or "windows_npu_vision"
        )
        return Resolved(
            figure=None,
            omission=Omission(
                category=OmissionCategory.VISION_UNAVAILABLE,
                path=path,
                reason=exc.message,
                missing_capability=missing_cap,
            ),
        )
    except VisionError as exc:
        return Resolved(
            figure=None,
            omission=Omission(
                category=OmissionCategory.VISION_FAILED,
                path=path,
                reason=exc.message,
            ),
        )
    except Exception as exc:
        return Resolved(
            figure=None,
            omission=Omission(
                category=OmissionCategory.VISION_FAILED,
                path=path,
                reason=str(exc),
            ),
        )

    # Gate 6: Cache store
    store.store_description(
        image_sha256=image_hash,
        model_id=rec_id,
        prompt_version=PIPELINE_VERSION,
        text=text,
    )
    figure = FigureSegment(
        text=text,
        locator=ref.locator,
        provenance=Provenance(
            vision_model=rec_id,
            prompt_version=PIPELINE_VERSION,
        ),
    )
    return Resolved(figure=figure, omission=None)


def resolve_all(
    refs: Sequence[ImageRef],
    *,
    store: StateStore,
    describer: VisionDescriber | None,
    config: IngestConfig,
    source_path: Path | None = None,
) -> tuple[Resolved, ...]:
    """Resolve a sequence of ImageRefs preserving input order.

    Cache misses that require description are executed with bounded concurrency
    via a thread pool whose maximum worker count is config.vision_concurrency.
    """
    if not refs:
        return ()

    path = source_path if source_path is not None else Path("")
    rec_id = _recognizer_id(describer, config)
    results: list[Resolved | None] = [None] * len(refs)

    # Track indices that need calling describer.describe()
    miss_indices: list[int] = []

    for idx, ref in enumerate(refs):
        # Gate 1: Threshold
        shorter_side = min(ref.width, ref.height)
        if shorter_side < config.min_image_pixels:
            results[idx] = Resolved(
                figure=None,
                omission=Omission(
                    category=OmissionCategory.BELOW_THRESHOLD,
                    path=path,
                    reason=(
                        f"image dimensions ({ref.width}x{ref.height}) shorter side "
                        f"{shorter_side}px is below minimum {config.min_image_pixels}px"
                    ),
                ),
            )
            continue

        # Gate 2: Chart ranges
        if ref.chart_ranges is not None:
            text = format_chart_ranges(ref.chart_ranges)
            results[idx] = Resolved(
                figure=FigureSegment(
                    text=text,
                    locator=ref.locator,
                    provenance=Provenance(
                        vision_model=rec_id,
                        prompt_version=PIPELINE_VERSION,
                    ),
                ),
                omission=None,
            )
            continue

        # Gate 3: Cache lookup
        image_hash = hashlib.sha256(ref.data).hexdigest()
        cached = store.cached_description(
            image_sha256=image_hash,
            model_id=rec_id,
            prompt_version=PIPELINE_VERSION,
        )
        if cached is not None:
            results[idx] = Resolved(
                figure=FigureSegment(
                    text=cached,
                    locator=ref.locator,
                    provenance=Provenance(
                        vision_model=rec_id,
                        prompt_version=PIPELINE_VERSION,
                    ),
                ),
                omission=None,
            )
            continue

        # Gate 4: Models present / describer configured
        if describer is None:
            results[idx] = Resolved(
                figure=None,
                omission=Omission(
                    category=OmissionCategory.VISION_UNAVAILABLE,
                    path=path,
                    reason="Windows NPU vision backend is not configured",
                    missing_capability="windows_npu_vision",
                ),
            )
            continue

        miss_indices.append(idx)

    # If no misses require execution, return immediately
    if not miss_indices:
        return tuple(res for res in results if res is not None)

    # Process misses with bounded concurrency
    def _execute_miss(idx: int) -> tuple[int, Resolved]:
        ref = refs[idx]
        resolved = resolve(
            ref,
            store=store,
            describer=describer,
            config=config,
            source_path=source_path,
        )
        return idx, resolved

    max_workers = max(1, config.vision_concurrency)
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(_execute_miss, idx) for idx in miss_indices]
        for future in concurrent.futures.as_completed(futures):
            idx, res = future.result()
            results[idx] = res

    return tuple(res for res in results if res is not None)

"""Download model files at a resolved Hugging Face revision.

Resolve metadata before downloading weights. Gated repositories produce a
license-acceptance error with the model URL. Credentials come from the process
environment or nearest .env, and are redacted from diagnostics.
"""

from __future__ import annotations

import os
import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final, Protocol

from huggingface_hub import HfApi, snapshot_download
from huggingface_hub.errors import GatedRepoError
from huggingface_hub.utils.tqdm import tqdm as hub_tqdm

from npu_rag.embedding.errors import (
    EmbeddingRuntimeError,
    LicenseAcceptanceRequired,
    PreparationError,
)
from npu_rag.embedding.profiles import ModelProfile
from npu_rag.embedding.reporting import ProgressCallback, ProgressUpdate

__all__ = [
    "ACQUISITION_STAGE",
    "DEFAULT_REVISION",
    "DISCOVER",
    "DOTENV_FILENAME",
    "REDACTED",
    "TOKEN_KEYS",
    "AcquiredModel",
    "HfCredential",
    "HubRepositoryClient",
    "ModelRepositoryClient",
    "acquire_model",
    "discover_credential",
    "find_dotenv",
    "parse_dotenv",
]

#: The stage every failure here reports (8.1, 4.6). It matches
#: ``LicenseAcceptanceRequired.default_stage`` deliberately: the licensing
#: failure and the honest transport failure happen at the same point in the
#: flow, and only their *type* distinguishes them.
ACQUISITION_STAGE: Final = "acquisition"

#: What is asked for when no revision is named. It is a branch, which is exactly
#: why it is resolved to a commit before anything is downloaded or recorded.
DEFAULT_REVISION: Final = "main"

#: What stands in for a credential wherever text is rendered.
REDACTED: Final = "<redacted>"

#: Where a Hugging Face credential is looked for, in order. The second name is
#: ``huggingface_hub``'s own older variable, honoured so a machine already set up
#: for the Hub does not have to be set up twice.
TOKEN_KEYS: Final = ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN")

#: The project's gitignored credential file.
DOTENV_FILENAME: Final = ".env"

#: Acquisition's two steps, for progress reporting: resolve, then download.
_STEPS: Final = 2

#: A resolved Hub revision: the forty-character commit hash ``ModelInfo.sha``
#: carries. Anything else - a branch, a tag, ``refs/pr/3``, an empty string - is
#: a moving target and is refused.
_RESOLVED_REVISION: Final = re.compile(r"\A[0-9a-f]{40}\Z")


# --------------------------------------------------------------------------
# The credential
# --------------------------------------------------------------------------


class HfCredential:
    """A Hugging Face token with redacted repr and str output.
    Use reveal only where authentication needs the token; source records
    where it was found.
    """

    __slots__ = ("_value", "source")

    def __init__(self, value: str, *, source: str) -> None:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError(
                "a credential cannot be blank: an empty token is an absent one, "
                "and absence is spelled None so the two cannot be confused"
            )
        self._value = cleaned
        self.source = source

    def reveal(self) -> str:
        """Return the token for authentication."""
        return self._value

    def redact(self, text: str) -> str:
        """``text`` with every occurrence of the token replaced."""
        return text.replace(self._value, REDACTED)

    def __repr__(self) -> str:
        return f"HfCredential(source={self.source!r}, value={REDACTED})"

    __str__ = __repr__


def parse_dotenv(text: str) -> dict[str, str]:
    """Parse supported key/value .env syntax without interpolation.
    Ignore comments and malformed unrelated lines; retain quoted token values.
    """
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].lstrip()
        key, separator, value = line.partition("=")
        key = key.strip()
        if not separator or not key:
            continue
        values[key] = _unquoted(value.strip())
    return values


def _unquoted(value: str) -> str:
    """One layer of matching quotes removed, if present."""
    for quote in ('"', "'"):
        if len(value) >= 2 and value.startswith(quote) and value.endswith(quote):
            return value[1:-1]
    return value


def find_dotenv(start: Path | None = None) -> Path | None:
    """The nearest ``.env`` at or above ``start`` (default: the process's cwd).

    Walking upward rather than assuming a fixed location is what lets the file
    be found from a test's temporary directory, from a nested working directory,
    and from an installed package that has no idea where the project root is.
    """
    origin = (start if start is not None else Path.cwd()).resolve()
    for directory in (origin, *origin.parents):
        candidate = directory / DOTENV_FILENAME
        if candidate.is_file():
            return candidate
    return None


def discover_credential(
    *,
    env: Mapping[str, str] | None = None,
    start: Path | None = None,
) -> HfCredential | None:
    """Find a Hub token in the environment, then the nearest .env.
    Return None when no token is available.
    """
    environment = env if env is not None else os.environ
    for key in TOKEN_KEYS:
        value = environment.get(key)
        if value is not None and value.strip():
            return HfCredential(value, source=f"the {key} environment variable")

    dotenv = find_dotenv(start)
    if dotenv is None:
        return None
    try:
        parsed = parse_dotenv(dotenv.read_text(encoding="utf-8"))
    except OSError:
        # An unreadable .env is an absent credential, not a crash: the caller's
        # next failure will be the licensing error, which names the file.
        return None
    for key in TOKEN_KEYS:
        value = parsed.get(key)
        if value is not None and value.strip():
            return HfCredential(value, source=f"{key} in {dotenv}")
    return None


class _Discover:
    """Sentinel: work out the credential rather than being handed one.

    A plain ``None`` default cannot express this, because ``None`` already means
    something specific and useful here - *make the request anonymously* - and
    the two must stay distinguishable, or a caller asking for an anonymous
    request would silently get whatever token the machine happens to hold.
    """

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return "DISCOVER"


DISCOVER: Final[_Discover] = _Discover()


# --------------------------------------------------------------------------
# What acquisition produces
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class AcquiredModel:
    """A local model directory at a resolved commit hash.
    The revision must be immutable because artifact reuse depends on it.
    """

    model_id: str
    revision: str
    local_path: Path

    def __post_init__(self) -> None:
        if not _RESOLVED_REVISION.match(self.revision):
            raise ValueError(
                f"revision {self.revision!r} is not a resolved commit hash; a "
                "branch or tag cannot identify the artifact that was actually "
                "downloaded"
            )
        if not self.local_path.is_dir():
            raise ValueError(
                f"local_path {self.local_path} is not a directory: acquisition "
                "reports where the files are, so a path with nothing at it is a "
                "failed acquisition wearing a success"
            )


# --------------------------------------------------------------------------
# The repository seam
# --------------------------------------------------------------------------


class ModelRepositoryClient(Protocol):
    """The two things acquisition needs from a model repository.

    Kept to two methods on purpose. This is the boundary at which the gated
    path is simulated, and a wide protocol would make the simulation less like
    the thing it stands in for.
    """

    def resolve_revision(
        self, *, repo_id: str, revision: str, credential: HfCredential | None
    ) -> str:
        """The concrete commit hash ``revision`` currently points at."""
        ...

    def download(
        self,
        *,
        repo_id: str,
        revision: str,
        credential: HfCredential | None,
        allow_patterns: Sequence[str] | None,
        cache_dir: Path | None,
    ) -> Path:
        """Fetch the repository at ``revision`` and return the local directory."""
        ...


def _token_argument(credential: HfCredential | None) -> str | bool:
    """Return the token value or False for anonymous Hub access.
    None would permit the Hub client to reuse cached credentials.
    """
    return credential.reveal() if credential is not None else False


class _SilentTqdm(hub_tqdm):
    """Disable only this Hub progress bar.
    Keep the caller callback interface without changing process-wide progress state.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs["disable"] = True
        # ``tqdm`` ships no annotations, so strict mode sees an untyped call
        # here. The ignore is scoped to this one line rather than widened to a
        # per-module override, which would also hide real type errors in this
        # file.
        super().__init__(*args, **kwargs)  # type: ignore[no-untyped-call]


class HubRepositoryClient:
    """`ModelRepositoryClient` backed by ``huggingface_hub``."""

    def __init__(self, *, api: HfApi | None = None) -> None:
        self._api = api if api is not None else HfApi()

    def resolve_revision(
        self, *, repo_id: str, revision: str, credential: HfCredential | None
    ) -> str:
        info = self._api.model_info(
            repo_id, revision=revision, token=_token_argument(credential)
        )
        # A metadata call only: no weights move here, and this is where a closed
        # gate is met - before a byte of a gigabyte-sized repository is fetched.
        return info.sha or ""

    def download(
        self,
        *,
        repo_id: str,
        revision: str,
        credential: HfCredential | None,
        allow_patterns: Sequence[str] | None,
        cache_dir: Path | None,
    ) -> Path:
        local = snapshot_download(
            repo_id=repo_id,
            revision=revision,
            token=_token_argument(credential),
            allow_patterns=list(allow_patterns) if allow_patterns else None,
            cache_dir=cache_dir,
            tqdm_class=_SilentTqdm,
        )
        if not isinstance(local, str):
            raise PreparationError(
                f"the model repository returned {type(local).__name__} instead "
                "of a local path",
                model_id=repo_id,
                stage=ACQUISITION_STAGE,
            )
        return Path(local)


# --------------------------------------------------------------------------
# Failure mapping
# --------------------------------------------------------------------------


def _status_code(error: Exception) -> int | None:
    """The HTTP status behind ``error``, when there is one.

    Read defensively through ``getattr`` because the attribute belongs to the
    Hub's exception hierarchy, not to ours, and an acquisition failure is a bad
    moment to raise a second, unrelated error while diagnosing the first.
    """
    status = getattr(getattr(error, "response", None), "status_code", None)
    return status if isinstance(status, int) else None


def _acceptance_url(profile: ModelProfile) -> str:
    """Use the profile license URL, falling back to its model card."""
    return (
        profile.license_acceptance_url
        or f"https://huggingface.co/{profile.model_id}"
    )


def _credential_state(credential: HfCredential | None) -> str:
    if credential is None:
        return (
            "no credential was found (looked for "
            f"{' and '.join(TOKEN_KEYS)} in the environment and in the nearest "
            f"{DOTENV_FILENAME})"
        )
    return f"the credential from {credential.source} was not accepted"


def _acquisition_failure(
    error: Exception,
    *,
    profile: ModelProfile,
    credential: HfCredential | None,
    step: str,
) -> EmbeddingRuntimeError:
    """Map upstream failures to acquisition errors and redact credentials.
    Include upstream detail as text without exposing it through exception chaining.
    """
    detail = f"{type(error).__name__}: {error}"
    if credential is not None:
        detail = credential.redact(detail)
    status = _status_code(error)

    gated = isinstance(error, GatedRepoError)
    if profile.license_gated and status in (401, 403):
        gated = True

    if gated:
        if status == 401:
            message = (
                f"{profile.model_id} is gated, and the request was not "
                f"authenticated (HTTP 401): {_credential_state(credential)}. "
                f"Authenticate with a Hugging Face token that has read access, "
                f"then accept the terms for this repository. "
                f"[{step}] {detail}"
            )
        else:
            message = (
                f"{profile.model_id} is gated and its terms have not been "
                f"accepted for the account in use"
                f"{'' if status is None else f' (HTTP {status})'}. This is a "
                f"one-time acceptance, not a transient failure, so retrying "
                f"the download will not resolve it. [{step}] {detail}"
            )
        return LicenseAcceptanceRequired(
            message,
            acceptance_url=_acceptance_url(profile),
            model_id=profile.model_id,
            stage=ACQUISITION_STAGE,
        )

    return PreparationError(
        f"could not acquire {profile.model_id} at the {step} step"
        f"{'' if status is None else f' (HTTP {status})'}: {detail}",
        model_id=profile.model_id,
        stage=ACQUISITION_STAGE,
    )


def _guarded[T](
    action: Callable[[], T],
    *,
    step: str,
    profile: ModelProfile,
    credential: HfCredential | None,
) -> T:
    """Map repository exceptions to redacted acquisition errors.
    Suppress exception chaining because upstream messages may contain credentials.
    """
    try:
        return action()
    except EmbeddingRuntimeError:
        # Already diagnosed in this feature's vocabulary; re-diagnosing it would
        # bury the specific stage under a generic one.
        raise
    except Exception as error:
        raise _acquisition_failure(
            error, profile=profile, credential=credential, step=step
        ) from None


# --------------------------------------------------------------------------
# Acquisition
# --------------------------------------------------------------------------


def _emit(
    progress: ProgressCallback | None, operation: str, completed: int
) -> None:
    if progress is None:
        return
    progress(
        ProgressUpdate(operation=operation, completed=completed, total=_STEPS)
    )


def acquire_model(
    profile: ModelProfile,
    *,
    client: ModelRepositoryClient | None = None,
    credential: HfCredential | None | _Discover = DISCOVER,
    revision: str = DEFAULT_REVISION,
    cache_dir: Path | None = None,
    allow_patterns: Sequence[str] | None = None,
    progress: ProgressCallback | None = None,
) -> AcquiredModel:
    """Resolve the requested revision before downloading selected model files.
    An omitted credential triggers discovery; None forces anonymous access.
    Return the local directory and immutable commit hash.
    """
    repository = client if client is not None else HubRepositoryClient()
    resolved_credential = (
        discover_credential() if isinstance(credential, _Discover) else credential
    )
    operation = f"acquire:{profile.name}"

    _emit(progress, operation, 0)

    resolved_revision = _guarded(
        lambda: repository.resolve_revision(
            repo_id=profile.model_id,
            revision=revision,
            credential=resolved_credential,
        ),
        step="revision resolution",
        profile=profile,
        credential=resolved_credential,
    )
    if not _RESOLVED_REVISION.match(resolved_revision):
        raise PreparationError(
            f"the model repository resolved {revision!r} to "
            f"{resolved_revision!r}, which is not a commit hash; the artifact "
            "manifest records a revision so a silently changed upstream model "
            "is detectable, and a moving reference cannot do that",
            model_id=profile.model_id,
            stage=ACQUISITION_STAGE,
        )
    _emit(progress, operation, 1)

    local_path = _guarded(
        lambda: repository.download(
            repo_id=profile.model_id,
            revision=resolved_revision,
            credential=resolved_credential,
            allow_patterns=allow_patterns,
            cache_dir=cache_dir,
        ),
        step="download",
        profile=profile,
        credential=resolved_credential,
    )

    try:
        acquired = AcquiredModel(
            model_id=profile.model_id,
            revision=resolved_revision,
            local_path=local_path,
        )
    except ValueError as error:
        raise PreparationError(
            f"acquisition of {profile.model_id} did not produce a usable "
            f"result: {error}",
            model_id=profile.model_id,
            stage=ACQUISITION_STAGE,
        ) from None

    _emit(progress, operation, _STEPS)
    return acquired

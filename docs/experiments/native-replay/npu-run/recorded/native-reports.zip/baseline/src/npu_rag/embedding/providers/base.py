"""Define the backend protocol and resolve provider selection.

Backends return token embeddings. Explicit npu selection fails on unavailable
hardware; cpu selects the reference backend; auto prefers NPU and records
its fallback reason. Only in-process NPU execution has an implementation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Protocol, runtime_checkable

import numpy as np
import numpy.typing as npt

from npu_rag.embedding.errors import NpuUnavailableError
from npu_rag.embedding.profiles import ModelProfile
from npu_rag.embedding.types import (
    CapabilityReport,
    Condition,
    ExecutionMode,
    ProviderChoice,
)

__all__ = [
    "SERVABLE_EXECUTION_MODES",
    "BackendFactories",
    "BackendFactory",
    "BoundBackend",
    "TransformerBackend",
    "npu_unavailable_reason",
    "resolve_backend",
]

#: Only the in-process NPU adapter is implemented. ISOLATED reports
#: remain unservable until a worker adapter exists.
SERVABLE_EXECUTION_MODES: Final = frozenset({ExecutionMode.IN_PROCESS})

#: Said before the unmet conditions, because no condition mentions it. The
#: conditions explain why the provider is missing *here*; only this says that
#: being reachable elsewhere is of no use to a build with no way to get there.
_NO_ISOLATED_BACKEND = (
    f"NPU execution is reachable only in isolation "
    f"(execution_mode={ExecutionMode.ISOLATED.value}) and no isolated backend "
    "is built, so nothing in this process can reach the hardware"
)


# --------------------------------------------------------------------------
# The contract
# --------------------------------------------------------------------------


@runtime_checkable
class TransformerBackend(Protocol):
    """Run a prepared graph and return (batch, sequence, hidden) token embeddings.
    Expose provider, execution mode and partition share. Sentence pooling and
    normalization belong to the service.
    """

    @property
    def provider(self) -> ProviderChoice:
        """Which provider this adapter actually runs on: ``npu`` or ``cpu``.

        Never ``auto``. ``auto`` is a request, and this is an outcome - the
        distinction requirement 2.6 rests on.
        """
        ...

    @property
    def execution_mode(self) -> ExecutionMode:
        """Whether the work happens in this interpreter or in a separate one.

        Requirement 5.3: isolated execution is reported for every operation it
        serves, and the adapter is the only thing that knows.
        """
        ...

    @property
    def npu_partition_share(self) -> float | None:
        """How much of the graph the NPU took, or ``None`` if not established.

        ``None`` is *unverified*, never "assume it was fine": design.md requires
        an explicit ``npu`` selection to distinguish "verified on NPU" from
        "assumed on NPU". A CPU adapter reports ``None`` because the question
        does not apply to it. Task 4.3 fills this in.
        """
        ...

    def run(
        self,
        token_ids: npt.NDArray[np.int64],
        attention_mask: npt.NDArray[np.int64],
    ) -> npt.NDArray[np.float32]:
        """Token embeddings for one padded batch. No pooling, no normalization."""
        ...


class BackendFactory(Protocol):
    """Construct one adapter using the profile and the capability report that
    provider resolution already checked.
    """

    def __call__(
        self, profile: ModelProfile, capability: CapabilityReport, /
    ) -> TransformerBackend: ...


@dataclass(frozen=True)
class BackendFactories:
    """How `resolve_backend` builds whichever adapter the policy chose.

    Required rather than defaulted. A default pair would have to import the
    concrete adapters, which import this module back, and - worse - a caller who
    forgot to supply them would silently get whatever the default was, which is
    the shape of every substitution requirement 2 forbids.
    """

    npu: BackendFactory
    cpu: BackendFactory


# --------------------------------------------------------------------------
# The binding
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class BoundBackend:
    """Bind one adapter to a frozen provider decision for the operation.
    Report served provider, execution mode and fallback reason consistently
    across batches.
    """

    backend: TransformerBackend
    requested: ProviderChoice
    fallback_reason: str | None

    def __post_init__(self) -> None:
        # Normalizing both choices is not decoration. ``ProviderChoice`` is a
        # ``StrEnum``, so a raw ``"npu"`` compares equal to the member but is
        # not identical to it, and every branch below is written with ``is``.
        # An unconverted string would slip past each one in turn and land on
        # whatever the last case happens to be.
        object.__setattr__(self, "requested", ProviderChoice(self.requested))
        served = self.provider
        if served is ProviderChoice.AUTO:
            raise ValueError(
                "a backend reports the provider that actually ran; 'auto' is a "
                "request, not an outcome (requirement 2.6) - report npu or cpu"
            )
        if self.fallback_reason is not None and not self.fallback_reason.strip():
            raise ValueError(
                "fallback_reason must say specifically why the NPU was not "
                f"used, got {self.fallback_reason!r}: a blank reason reports a "
                "fallback and explains nothing (requirement 2.5)"
            )
        if self.requested is ProviderChoice.AUTO:
            self._check_auto(served)
            return
        if served is not self.requested:
            raise ValueError(
                f"provider {self.requested.value!r} was requested explicitly "
                f"and a {served.value!r} backend was produced; an explicit "
                "choice is honoured or it fails, never substituted "
                "(requirement 2.2)"
            )
        if self.fallback_reason is not None:
            raise ValueError(
                f"provider {self.requested.value!r} was requested explicitly "
                "and served, so nothing fell back; a fallback reason belongs "
                "to an 'auto' selection only (requirement 2.5)"
            )

    def _check_auto(self, served: ProviderChoice) -> None:
        """Under ``auto``: a reason exactly when the CPU served instead."""
        if served is ProviderChoice.CPU and self.fallback_reason is None:
            raise ValueError(
                "automatic selection used the CPU without saying why the NPU "
                "was not used; requirement 2.5 requires the specific reason to "
                "be reported before embedding on the CPU"
            )
        if served is ProviderChoice.NPU and self.fallback_reason is not None:
            raise ValueError(
                "automatic selection used the NPU, so nothing fell back, but a "
                f"fallback reason was recorded: {self.fallback_reason!r} "
                "(requirement 2.4)"
            )

    @property
    def provider(self) -> ProviderChoice:
        """The provider that will serve this operation (2.6)."""
        return ProviderChoice(self.backend.provider)

    @property
    def execution_mode(self) -> ExecutionMode:
        return self.backend.execution_mode

    @property
    def npu_partition_share(self) -> float | None:
        return self.backend.npu_partition_share

    @property
    def fell_back(self) -> bool:
        """Whether the CPU served because the NPU could not (2.5)."""
        return self.fallback_reason is not None

    def run(
        self,
        token_ids: npt.NDArray[np.int64],
        attention_mask: npt.NDArray[np.int64],
    ) -> npt.NDArray[np.float32]:
        """Delegate to the bound adapter, unchanged in both directions."""
        return self.backend.run(token_ids, attention_mask)


# --------------------------------------------------------------------------
# The policy
# --------------------------------------------------------------------------


def npu_unavailable_reason(capability: CapabilityReport) -> str | None:
    """Return None for a supported in-process NPU route, otherwise describe
    unmet conditions. Include an explicit unsupported-backend reason for
    ISOLATED reports even when all other conditions are satisfied.
    """
    mode = capability.execution_mode
    if mode in SERVABLE_EXECUTION_MODES:
        return None
    parts = [
        _describe(condition)
        for condition in capability.conditions
        if not condition.satisfied
    ]
    if not parts:
        parts = [
            f"NPU execution reported as {mode.value} with no unsatisfied "
            "condition to explain it; the capability report names no route to "
            "the hardware"
        ]
    if mode is ExecutionMode.ISOLATED:
        parts.insert(0, _NO_ISOLATED_BACKEND)
    return " | ".join(parts)


def _describe(condition: Condition) -> str:
    """One unmet condition as a line an operator can act on (1.3, 8.1)."""
    detail = f"{condition.name}: {condition.observed}"
    extras = [
        f"{label}: {value}"
        for label, value in (
            ("required", condition.required),
            ("remediation", condition.remediation),
        )
        if value
    ]
    return f"{detail} ({'; '.join(extras)})" if extras else detail


def resolve_backend(
    choice: ProviderChoice,
    profile: ModelProfile,
    capability: CapabilityReport,
    *,
    factories: BackendFactories,
) -> tuple[TransformerBackend, str | None]:
    """Bind one backend before preparation or inference.
    Explicit NPU requests raise when unavailable. AUTO prefers NPU and returns
    a specific CPU fallback reason. CPU selects the reference backend.
    """
    # A ``StrEnum`` member is equal to its value but not identical to it, and
    # the branches below compare by identity. Converting first means a caller
    # handing over a plain ``"npu"`` - from a CLI flag, a config file, a JSON
    # frame - gets the NPU or a clear rejection, never a silent slide into the
    # ``auto`` branch. Requirement 2.1 accepts the three spellings; nothing else.
    choice = ProviderChoice(choice)
    reason = npu_unavailable_reason(capability)

    if choice is ProviderChoice.CPU:
        return _bind(factories.cpu, profile, capability, choice, None), None

    if choice is ProviderChoice.NPU:
        if reason is not None:
            raise NpuUnavailableError(
                f"provider 'npu' was requested explicitly and the NPU is not "
                f"usable: {reason}. No other provider will be substituted",
                provider=ProviderChoice.NPU,
                model_id=profile.model_id,
            )
        return _bind(factories.npu, profile, capability, choice, None), None

    if reason is None:
        return _bind(factories.npu, profile, capability, choice, None), None
    return _bind(factories.cpu, profile, capability, choice, reason), reason


def _bind(
    factory: BackendFactory,
    profile: ModelProfile,
    capability: CapabilityReport,
    requested: ProviderChoice,
    fallback_reason: str | None,
) -> BoundBackend:
    """Construct the selected adapter and verify that it serves the requested
    provider before returning a frozen binding.
    """
    backend = factory(profile, capability)
    served = ProviderChoice(backend.provider)
    if requested is ProviderChoice.NPU and served is not ProviderChoice.NPU:
        raise NpuUnavailableError(
            f"provider 'npu' was requested explicitly and resolution produced a "
            f"{served.value!r} backend; an explicit NPU request is never served "
            "by another provider",
            provider=ProviderChoice.NPU,
            model_id=profile.model_id,
        )
    return BoundBackend(
        backend=backend, requested=requested, fallback_reason=fallback_reason
    )

"""Group search hits by archive folder and order documents naturally.

Document keys recognize dates, numbered sessions and session words. Group order
follows the best hit in each folder; chunks within a document use chunk_index.
Windows paths are parsed independently of the host platform.
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from npu_rag.index.types import SearchResult

__all__ = [
    "ROOT_FOLDER",
    "SESSION_KEYWORDS",
    "folder_of",
    "group_and_order_results",
    "natural_sort_key",
]

#: The group key for a document sitting directly in the archive root, and the
#: fallback for a path with no parent at all. `discover._author` spells the
#: same case as `""`, which is a poor label for a caller rendering
#: `[Folder: ...]`; `"."` names the root the way a shell does.
ROOT_FOLDER: Final = "."

#: Words that mark a token as a position in a series rather than a quantity.
#: Chosen from what requirement 4.2 names (`Day`, `Part`) plus what the real
#: archive uses; see the module test for the survey. A number word is only read
#: as a sequence number when it sits directly beside one of these, so
#: `the-three-layers-of-ai` keeps its `three` as prose while `ai-moats-part-one`
#: becomes `part 1`.
SESSION_KEYWORDS: Final[tuple[str, ...]] = (
    "day",
    "part",
    "volume",
    "vol",
    "session",
    "episode",
    "chapter",
    "lesson",
    "week",
    "module",
)

# Kind discriminators. A digit run sorts before text at the same position,
# which puts a dated or numbered document ahead of an untitled sibling.
_NUMBER: Final = 0
_TEXT: Final = 1

_Atom = tuple[int, int, str]
_Component = tuple[_Atom, ...]

#: What `natural_sort_key` returns: the per-component atoms, then the
#: normalized path as the total-order tiebreak.
SortKey = tuple[tuple[_Component, ...], str]

# Windows long-path prefixes. `npu_rag.ingest.discover` stamps every discovered
# file with `\\?\`, and `file_path` is `str(Path)` of that, so the prefix can
# reach this module. Splitting it naively would leave a bogus `?` component.
_LONG_PREFIX: Final = "\\\\?\\"
_UNC_LONG_PREFIX: Final = "\\\\?\\UNC\\"

#: Both separator spellings, always. Implementation note 2.1: `file_path` is
#: backslash-separated on Windows, and no test on this platform can naturally
#: exercise the `/` branch, so the tests construct POSIX values by hand.
_SEPARATORS: Final = re.compile(r"[\\/]+")

_DIGIT_RUN: Final = re.compile(r"\d+")

_NUMBER_WORDS: Final[dict[str, int]] = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "eleven": 11,
    "twelve": 12,
    "thirteen": 13,
    "fourteen": 14,
    "fifteen": 15,
    "sixteen": 16,
    "seventeen": 17,
    "eighteen": 18,
    "nineteen": 19,
    "twenty": 20,
    "first": 1,
    "second": 2,
    "third": 3,
    "fourth": 4,
    "fifth": 5,
    "sixth": 6,
    "seventh": 7,
    "eighth": 8,
    "ninth": 9,
    "tenth": 10,
    "eleventh": 11,
    "twelfth": 12,
    "thirteenth": 13,
    "fourteenth": 14,
    "fifteenth": 15,
    "sixteenth": 16,
    "seventeenth": 17,
    "eighteenth": 18,
    "nineteenth": 19,
    "twentieth": 20,
}

# Longest alternative first. This is belt-and-braces and is *not* what makes
# `nineteen` read as 19 rather than 9 - the trailing `(?![a-z0-9])` below is,
# by refusing the short alternative and forcing the alternation to backtrack.
# Verified by mutation: reversing both sort orders changes no observable
# behaviour. The ordering is kept because it saves the backtracking and because
# a future edit that relaxed the lookahead would otherwise silently regress.
_KEYWORD_ALT: Final = "|".join(sorted(SESSION_KEYWORDS, key=len, reverse=True))
_WORD_ALT: Final = "|".join(sorted(_NUMBER_WORDS, key=len, reverse=True))

# What separates two words inside one path component: a space, and the three
# characters this archive's slugs actually use.
_WORD_GAP: Final = r"[\s._\-]+"

# `Part One`, `Day-two`, `volumes_three`.
_KEYWORD_THEN_WORD: Final = re.compile(
    rf"(?<![a-z0-9])((?:{_KEYWORD_ALT})s?{_WORD_GAP})({_WORD_ALT})(?![a-z0-9])"
)
# `First Day`, `second-part` - design §3.4's own sample file is
# `Savarni Nath - First Day.md`, so this order has to work too.
_WORD_THEN_KEYWORD: Final = re.compile(
    rf"(?<![a-z0-9])({_WORD_ALT})({_WORD_GAP}(?:{_KEYWORD_ALT})s?)(?![a-z0-9])"
)


# --------------------------------------------------------------------------- #
# Path decomposition
# --------------------------------------------------------------------------- #


def _strip_long_prefix(text: str) -> str:
    """Normalize Windows extended-length and UNC prefixes for path parsing.
    Keep path parsing local to the CLI to avoid importing ingestion dependencies.
    """
    if text.startswith(_UNC_LONG_PREFIX):
        return "\\\\" + text[len(_UNC_LONG_PREFIX) :]
    if text.startswith(_LONG_PREFIX):
        return text[len(_LONG_PREFIX) :]
    return text


def _components(file_path: str) -> tuple[str, ...]:
    """Split a path into non-empty components, either separator spelling."""
    return tuple(part for part in _SEPARATORS.split(_strip_long_prefix(file_path)) if part)


def _normalized(file_path: str) -> str:
    """The path with separators unified, case preserved - the tiebreak value."""
    return "/".join(_components(file_path))


# --------------------------------------------------------------------------- #
# Sequence tokens
# --------------------------------------------------------------------------- #


def _keyword_then_word_digits(match: re.Match[str]) -> str:
    """`part one` -> `part 1`; the keyword and its gap are kept verbatim."""
    return f"{match.group(1)}{_NUMBER_WORDS[match.group(2)]}"


def _word_then_keyword_digits(match: re.Match[str]) -> str:
    """`first day` -> `1 day`; the keyword and its gap are kept verbatim."""
    return f"{_NUMBER_WORDS[match.group(1)]}{match.group(2)}"


def _digits_for_session_words(text: str) -> str:
    """Convert spelled-out numbers after session words to digits.
    For example, part one becomes part 1; three layers stays unchanged.
    """
    text = _KEYWORD_THEN_WORD.sub(_keyword_then_word_digits, text)
    return _WORD_THEN_KEYWORD.sub(_word_then_keyword_digits, text)


def _atoms(component: str) -> _Component:
    """Tokenize one path component into same-shaped `(kind, number, text)` atoms.

    Digit runs become numbers, so `Day 2` precedes `Day 10`; everything between
    them stays text. No separate date parser is needed: `20240310_182951_x.md`
    yields `20240310`, `182951` and the slug, and `2026-03-29` yields year,
    month and day, and both already sort chronologically as integers.
    """
    text = _digits_for_session_words(component.casefold())
    atoms: list[_Atom] = []
    position = 0
    for match in _DIGIT_RUN.finditer(text):
        if match.start() > position:
            atoms.append((_TEXT, 0, text[position : match.start()]))
        atoms.append((_NUMBER, int(match[0]), ""))
        position = match.end()
    if position < len(text):
        atoms.append((_TEXT, 0, text[position:]))
    return tuple(atoms)


def natural_sort_key(file_path: str) -> SortKey:
    """Build a type-stable key from date, session and filename tokens.
    Support Day 1, Part 2, ISO dates and YYYYMMDD_HHMMSS prefixes.
    Tagged key components avoid comparing strings directly with integers.
    """
    components = _components(file_path)
    return tuple(_atoms(component) for component in components), _normalized(file_path)


# --------------------------------------------------------------------------- #
# Folder identity
# --------------------------------------------------------------------------- #


def _is_beneath(root: tuple[str, ...], parts: tuple[str, ...]) -> bool:
    """Whether `parts` starts with `root`, under the platform's casing rule.

    `os.path.normcase` and not `str.casefold`: on Windows two spellings of one
    directory are one directory, on POSIX they are two, and grouping must not
    invent a merge the filesystem does not have. Same call
    `discover._dedup_key` uses.
    """
    if len(parts) <= len(root):
        return False
    return all(os.path.normcase(a) == os.path.normcase(b) for a, b in zip(root, parts))


def _fallback_folder(parts: tuple[str, ...]) -> str:
    """Use the full parent directory path when no archive root is supplied."""
    if len(parts) <= 1:
        return ROOT_FOLDER
    return "/".join(parts[:-1])


def folder_of(file_path: str, *, archive_root: str | Path | None = None) -> str:
    """Return the first path component below archive_root.
    Without a root, use the document parent folder. Parse Windows separators
    consistently on every host.
    """
    parts = _components(file_path)
    if archive_root is not None:
        root = _components(str(archive_root))
        if root and _is_beneath(root, parts):
            below = parts[len(root) :]
            return below[0] if len(below) > 1 else ROOT_FOLDER
    return _fallback_folder(parts)


# --------------------------------------------------------------------------- #
# Grouping
# --------------------------------------------------------------------------- #


def group_and_order_results(
    results: Sequence[SearchResult],
    *,
    archive_root: str | Path | None = None,
) -> dict[str, list[SearchResult]]:
    """Group by folder, then order documents by natural sequence and chunks by
    chunk_index. Order folders by their best hit. The caller owns result limits.
    """
    grouped: dict[str, list[SearchResult]] = {}
    for result in results:
        folder = folder_of(result.file_path, archive_root=archive_root)
        grouped.setdefault(folder, []).append(result)

    for items in grouped.values():
        items.sort(key=lambda r: (natural_sort_key(r.file_path), r.chunk_index))

    return {
        folder: items
        for folder, items in sorted(
            grouped.items(),
            key=lambda entry: (-max(item.score for item in entry[1]), entry[0]),
        )
    }

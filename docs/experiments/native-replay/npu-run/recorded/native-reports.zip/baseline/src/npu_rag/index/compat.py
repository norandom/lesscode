"""Check embedding model identity before index writes or queries.

Equal vector dimensions do not imply a shared embedding space. Mixed identities
and mismatched models require rebuilding the index.
"""

from __future__ import annotations

from npu_rag.index.errors import ConfigurationError
from npu_rag.index.schema import UNSTAMPED_MODEL_IDENTITY
from npu_rag.index.store import LanceIndexStore

#: How an absent identity is rendered inside a diagnostic. Never ``""``, which
#: would leave the operator reading an empty gap in a sentence.
UNSTAMPED_LABEL: str = "(no identity recorded)"


def _describe(identity: str) -> str:
    """Render one stored identity for a human reading an error message."""
    return UNSTAMPED_LABEL if identity == UNSTAMPED_MODEL_IDENTITY else identity


def _chunks(count: int) -> str:
    """``"1 chunk"`` / ``"2 chunks"`` - the message is read by an operator."""
    return f"{count} chunk" if count == 1 else f"{count} chunks"


def _inventory(counts: dict[str, int]) -> str:
    """Render ``identity (N chunks)`` pairs in a stable order."""
    return ", ".join(
        f"{_describe(identity)} ({_chunks(counts[identity])})"
        for identity in sorted(counts)
    )


def verify_model_identity(
    store: LanceIndexStore,
    configured_identity: str,
) -> None:
    """Validate a caller model identity against the stored row identities.

    Empty tables accept an initial identity. Reject mixed rows and model
    mismatches. Unstamped rows accept only an unstamped caller; stamped rows
    require the same supplied identity. Raise ConfigurationError otherwise.
    """
    counts = store.model_identity_counts()
    if not counts:
        return

    stored = tuple(sorted(counts))
    location = store.db_path

    if len(stored) > 1:
        raise ConfigurationError(
            f"The index at {location} already holds vectors from more than one "
            # "vector space", not "embedding model": the partially stamped case
            # may name only one model, and unstamped rows are a second space
            # whether or not they came from a second model.
            f"vector space: {_inventory(counts)}. Similarity scores that "
            "cross that boundary are meaningless, so no model can be declared "
            "compatible with it. Delete the index and rebuild it with a single "
            f"model (the configured one is {_describe(configured_identity)})."
        )

    only = stored[0]
    if only == configured_identity:
        return

    total = counts[only]
    if only == UNSTAMPED_MODEL_IDENTITY:
        raise ConfigurationError(
            f"The index at {location} holds {_chunks(total)} with no recorded "
            "embedding model, so there is no way to tell whether they came "
            f"from {_describe(configured_identity)}. The index predates "
            "embedding-model stamping or was written by a caller that supplied "
            "none. Delete the index and rebuild it so every row is stamped."
        )

    if configured_identity == UNSTAMPED_MODEL_IDENTITY:
        raise ConfigurationError(
            f"The index at {location} was built with {only} "
            f"({_chunks(total)}), but this run supplied no embedding-model "
            "identity. Writing unstamped rows into it would make the table "
            "permanently ambiguous. Pass the identity of the model being "
            "used, or delete the index and rebuild it."
        )

    raise ConfigurationError(
        f"Embedding model mismatch: the index at {location} was built with "
        f"{only} ({_chunks(total)}), but the configured model is "
        f"{configured_identity}. Vectors from different models are not "
        "comparable even at the same width, so mixing them would produce "
        f"plausible but meaningless scores. Either set the model back to "
        f"{only}, or delete the index and rebuild it with "
        f"{configured_identity}."
    )

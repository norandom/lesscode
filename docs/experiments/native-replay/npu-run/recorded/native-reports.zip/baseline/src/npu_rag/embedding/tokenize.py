"""Render model templates and encode fixed-shape token batches.

Token counts include prefixes and special tokens before truncation. Chunking
and inference use the same count. An input of exactly max_input_tokens fits;
longer inputs are reported as truncated.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Final, Protocol

import numpy as np
import numpy.typing as npt
from transformers import AutoTokenizer, PreTrainedTokenizerBase

from npu_rag.embedding.errors import ExecutionError, PreparationError
from npu_rag.embedding.models.acquire import (
    DEFAULT_REVISION,
    AcquiredModel,
    acquire_model,
)
from npu_rag.embedding.profiles import ModelProfile
from npu_rag.embedding.reporting import ProgressCallback
from npu_rag.embedding.types import DocumentText, TextKind

__all__ = [
    "TOKENIZATION_STAGE",
    "TOKENIZER_FILE_PATTERNS",
    "TOKENIZER_STAGE",
    "EncodedBatch",
    "ModelAcquirer",
    "ModelTokenizer",
    "TokenizerLoader",
    "load_tokenizer",
]

#: The stage a failure to obtain or load a tokenizer reports (8.1, 4.6). It is a
#: preparation stage: the model has not been made ready.
TOKENIZER_STAGE: Final = "tokenizer"

#: The stage a failure *while measuring or encoding* reports. Distinct from
#: `TOKENIZER_STAGE` because the tokenizer loaded fine and the failure belongs
#: to the embedding operation in flight, which is what 8.2 separates.
TOKENIZATION_STAGE: Final = "tokenize"

#: Download tokenizer assets without model weights. config.json supplies
#: a fallback model type when tokenizer_config.json has no class.
TOKENIZER_FILE_PATTERNS: Final[tuple[str, ...]] = (
    "added_tokens.json",
    "config.json",
    "merges.txt",
    "special_tokens_map.json",
    "tokenizer.json",
    "tokenizer.model",
    "tokenizer_config.json",
    "vocab.json",
    "vocab.txt",
)

#: What pads a short sequence when the tokenizer declares no pad token. The
#: padded positions are masked out, so the value is never attended to; a
#: concrete number is still needed because the array has a fixed width.
_FALLBACK_PAD_ID: Final = 0


# --------------------------------------------------------------------------
# The boundary, in one place
# --------------------------------------------------------------------------


def _over_limit(counts: Iterable[int], max_input_tokens: int) -> tuple[int, ...]:
    """Return positions whose measured count is strictly above the input limit."""
    return tuple(
        index for index, count in enumerate(counts) if count > max_input_tokens
    )


# --------------------------------------------------------------------------
# What encoding produces
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class EncodedBatch:
    """Fixed-shape int64 token IDs and attention masks.
    Keep pre-truncation token counts separately and validate truncated_indices
    against them.
    """

    token_ids: npt.NDArray[np.int64]
    attention_mask: npt.NDArray[np.int64]
    #: The untruncated length of each input, in input order.
    token_counts: tuple[int, ...]
    #: The published maximum these counts were judged against (3.6).
    max_input_tokens: int
    #: Which inputs were shortened, in input order (3.9's carrier).
    truncated_indices: tuple[int, ...]

    def __post_init__(self) -> None:
        if self.max_input_tokens <= 0:
            raise ValueError(
                f"max_input_tokens must be positive, got {self.max_input_tokens}"
            )
        for name in ("token_ids", "attention_mask"):
            array: npt.NDArray[np.int64] = getattr(self, name)
            if array.ndim != 2 or array.shape[1] != self.max_input_tokens:
                raise ValueError(
                    f"{name} is shaped {array.shape}; the backends require "
                    f"(batch, {self.max_input_tokens}) because the graph is "
                    "compiled at a static length"
                )
            if array.dtype != np.int64:
                raise ValueError(
                    f"{name} has dtype {array.dtype}; the exported graph "
                    "declares int64 inputs"
                )
        if self.token_ids.shape != self.attention_mask.shape:
            raise ValueError(
                f"token_ids {self.token_ids.shape} and attention_mask "
                f"{self.attention_mask.shape} describe different batches"
            )
        rows = int(self.token_ids.shape[0])
        if len(self.token_counts) != rows:
            raise ValueError(
                f"{len(self.token_counts)} token counts for {rows} rows: every "
                "input is measured, so the two cannot differ"
            )
        if any(count < 0 for count in self.token_counts):
            raise ValueError(f"negative token count in {self.token_counts}")

        expected = _over_limit(self.token_counts, self.max_input_tokens)
        if self.truncated_indices != expected:
            raise ValueError(
                f"truncated_indices {self.truncated_indices} disagrees with the "
                f"measurement {expected} at a maximum of {self.max_input_tokens}"
                " tokens; requirement 3.8 makes the consumer's measurement and "
                "this runtime's truncation decision the same decision, so a "
                "batch that reported otherwise would be the exact silent "
                "shortening that requirement exists to prevent"
            )

        for row, count in enumerate(self.token_counts):
            kept = min(count, self.max_input_tokens)
            mask = self.attention_mask[row]
            if int(mask.sum()) != kept:
                raise ValueError(
                    f"row {row} masks {int(mask.sum())} tokens but measured "
                    f"{count} against a maximum of {self.max_input_tokens}"
                )
            if not bool(mask[:kept].all()) or bool(mask[kept:].any()):
                raise ValueError(
                    f"row {row}'s attention mask is not a run of real tokens "
                    "followed by padding; masked mean pooling reads this mask "
                    "and would average over padding"
                )

    @property
    def batch_size(self) -> int:
        """How many inputs this batch carries."""
        return int(self.token_ids.shape[0])

    @property
    def any_truncated(self) -> bool:
        """Whether requirement 3.9 has anything to report for this batch."""
        return bool(self.truncated_indices)


# --------------------------------------------------------------------------
# The seams
# --------------------------------------------------------------------------


class TokenizerLoader(Protocol):
    """Turns a directory of tokenizer files into a tokenizer."""

    def __call__(self, path: Path, /) -> PreTrainedTokenizerBase: ...


class ModelAcquirer(Protocol):
    """The part of `acquire_model` this module uses.

    Narrow on purpose. Acquisition, its credential handling and its
    gated-repository diagnosis are `models.acquire`'s, not this module's; this
    protocol exists so a test can supply a directory without a network, not so
    an alternative acquisition can be written.
    """

    def __call__(
        self,
        profile: ModelProfile,
        /,
        *,
        allow_patterns: Sequence[str] | None = ...,
        cache_dir: Path | None = ...,
        revision: str = ...,
        progress: ProgressCallback | None = ...,
    ) -> AcquiredModel: ...


def _load_pretrained(path: Path) -> PreTrainedTokenizerBase:
    tokenizer = AutoTokenizer.from_pretrained(str(path))  # type: ignore[no-untyped-call]
    if not isinstance(tokenizer, PreTrainedTokenizerBase):  # pragma: no cover
        raise TypeError(
            f"{type(tokenizer).__name__} is not a tokenizer this runtime can "
            "measure with"
        )
    return tokenizer


# --------------------------------------------------------------------------
# The tokenizer, and measurement by its rule
# --------------------------------------------------------------------------


class ModelTokenizer:
    """The active model's tokenizer, plus the rules the runtime measures by.

    Requirement 3.7's exposure is `tokenizer`; requirement 3.8's guarantee is
    that `count_tokens`, `exceeds_limit` and `encode` are one computation seen
    from three angles.
    """

    __slots__ = ("_profile", "_tokenizer", "_tokenizer_id")

    def __init__(
        self,
        *,
        profile: ModelProfile,
        tokenizer: PreTrainedTokenizerBase,
        tokenizer_id: str,
    ) -> None:
        if not tokenizer_id.strip():
            raise ValueError(
                "a tokenizer must be identifiable: design.md makes the "
                "tokenizer identity a revalidation trigger for downstream "
                "specs, and a blank one can never trigger it"
            )
        self._profile = profile
        self._tokenizer = tokenizer
        self._tokenizer_id = tokenizer_id

    @property
    def profile(self) -> ModelProfile:
        """The active model's profile."""
        return self._profile

    @property
    def model_id(self) -> str:
        """The active model's repository id."""
        return self._profile.model_id

    @property
    def tokenizer(self) -> PreTrainedTokenizerBase:
        """The active model's tokenizer itself (requirement 3.7)."""
        return self._tokenizer

    @property
    def tokenizer_id(self) -> str:
        """Identify the tokenizer by repository and resolved commit."""
        return self._tokenizer_id

    @property
    def max_input_tokens(self) -> int:
        """The published maximum input length (requirement 3.6).

        The compiled sequence length. Reading it through
        `ModelProfile.max_input_tokens` rather than off ``compiled_seq_len``
        keeps the choice of *which number is the contract* in the one place
        profiles.py made it.
        """
        return self._profile.max_input_tokens

    # -- measuring ---------------------------------------------------------

    def render(self, text: str | DocumentText, kind: TextKind) -> str:
        """Apply the document or query template.
        Untitled document strings use the model absence sentinel. Reject a
        DocumentText supplied as a query rather than discarding its title.
        """
        if kind is TextKind.QUERY:
            if isinstance(text, DocumentText):
                raise ValueError(
                    "a DocumentText cannot be measured or embedded as a query: "
                    "the query convention has no title slot, and dropping the "
                    "title silently would change the text being embedded"
                )
            return self._profile.render_query(text)
        document = DocumentText(text) if isinstance(text, str) else text
        return self._profile.render_document(document)

    def count_tokens(self, text: str | DocumentText, kind: TextKind) -> int:
        """Count rendered text, including model prefixes and special tokens.
        Use the same pre-truncation measurement as encode.
        """
        return len(self._measure(self.render(text, kind)))

    def exceeds_limit(self, text: str | DocumentText, kind: TextKind) -> bool:
        """Whether this input will be shortened (requirements 3.8, 3.9)."""
        return bool(
            _over_limit([self.count_tokens(text, kind)], self.max_input_tokens)
        )

    def _measure(self, rendered: str) -> list[int]:
        """Tokenize rendered text without truncation or library console warnings."""
        return [
            int(token)
            for token in self._tokenizer.encode(
                rendered,
                add_special_tokens=True,
                truncation=False,
                verbose=False,
            )
        ]

    def _fit(self, rendered: str) -> list[int]:
        """The rendered text shortened to the compiled length by the model's
        own truncation rule, which keeps the closing special token."""
        return [
            int(token)
            for token in self._tokenizer.encode(
                rendered,
                add_special_tokens=True,
                truncation=True,
                max_length=self.max_input_tokens,
                verbose=False,
            )
        ]

    # -- encoding ----------------------------------------------------------

    def encode_documents(
        self, texts: Sequence[str | DocumentText]
    ) -> EncodedBatch:
        """Model inputs for corpus content, under the document convention."""
        return self.encode(texts, TextKind.DOCUMENT)

    def encode_queries(self, texts: Sequence[str]) -> EncodedBatch:
        """Model inputs for search queries, under the query convention."""
        return self.encode(list(texts), TextKind.QUERY)

    def encode(
        self, texts: Sequence[str | DocumentText], kind: TextKind
    ) -> EncodedBatch:
        """Render, measure, shorten what does not fit, and pad to the graph.

        One row per input in input order (requirement 3.1), each row exactly
        ``compiled_seq_len`` wide. Truncation is decided from the measurement
        `count_tokens` returns and from nothing else, so the two cannot drift.
        """
        limit = self.max_input_tokens
        counts: list[int] = []
        rows: list[list[int]] = []
        for text in texts:
            rendered = self.render(text, kind)
            measured = self._measure(rendered)
            counts.append(len(measured))
            rows.append(
                self._fit(rendered)
                if _over_limit([len(measured)], limit)
                else measured
            )

        token_ids = np.full((len(rows), limit), self._pad_id(), dtype=np.int64)
        attention_mask = np.zeros((len(rows), limit), dtype=np.int64)
        for index, ids in enumerate(rows):
            if len(ids) > limit:
                raise ExecutionError(
                    f"the tokenizer returned {len(ids)} tokens for input "
                    f"{index} after being asked to truncate to {limit}; the "
                    "graph has no more slots, and quietly trimming here would "
                    "move the truncation decision away from the one place that "
                    "reports it",
                    model_id=self.model_id,
                    stage=TOKENIZATION_STAGE,
                )
            token_ids[index, : len(ids)] = ids
            attention_mask[index, : len(ids)] = 1

        return EncodedBatch(
            token_ids=token_ids,
            attention_mask=attention_mask,
            token_counts=tuple(counts),
            max_input_tokens=limit,
            truncated_indices=_over_limit(counts, limit),
        )

    def _pad_id(self) -> int:
        pad = self._tokenizer.pad_token_id
        return _FALLBACK_PAD_ID if pad is None else int(pad)


# --------------------------------------------------------------------------
# Obtaining the tokenizer
# --------------------------------------------------------------------------


def load_tokenizer(
    profile: ModelProfile,
    *,
    acquire: ModelAcquirer = acquire_model,
    loader: TokenizerLoader = _load_pretrained,
    revision: str = DEFAULT_REVISION,
    cache_dir: Path | None = None,
    progress: ProgressCallback | None = None,
) -> ModelTokenizer:
    """Acquire only tokenizer files through the shared download path.
    Preserve license-acceptance errors; report invalid tokenizer files as
    PreparationError at the tokenizer stage.
    """
    acquired = acquire(
        profile,
        allow_patterns=TOKENIZER_FILE_PATTERNS,
        cache_dir=cache_dir,
        revision=revision,
        progress=progress,
    )
    try:
        tokenizer = loader(acquired.local_path)
    except Exception as error:
        raise PreparationError(
            f"the tokenizer for {profile.model_id} could not be loaded from "
            f"{acquired.local_path}: {type(error).__name__}: {error}",
            model_id=profile.model_id,
            stage=TOKENIZER_STAGE,
        ) from None
    return ModelTokenizer(
        profile=profile,
        tokenizer=tokenizer,
        tokenizer_id=f"{profile.model_id}@{acquired.revision}",
    )

"""Render search results as terminal text or JSON.

Terminal output escapes data-derived ANSI sequences, applies optional styling,
and truncates snippets. JSON preserves source text and paths. Both formats
include source locators and the provider that served the query.
"""

from __future__ import annotations

import io
import json
import os
import re
import sys
from typing import TYPE_CHECKING, Final

from npu_rag.cli.order import _components, folder_of, group_and_order_results

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence
    from pathlib import Path
    from typing import IO

    from npu_rag.index.types import SearchResponse, SearchResult

__all__ = [
    "BREADCRUMB_SEPARATOR",
    "CPU_PROVIDER",
    "HIT_MARKER",
    "JSON_INDENT",
    "LOCATOR_FORMATTERS",
    "NO_COLOR_VARIABLE",
    "NO_RESULTS_LINE",
    "NPU_PROVIDER",
    "RULE_WIDTH",
    "SGR",
    "SNIPPET_LIMIT",
    "UNKNOWN_DOCUMENT",
    "UNKNOWN_LOCATOR",
    "emit",
    "ensure_utf8_stdout",
    "format_breadcrumb",
    "format_locator",
    "format_provider",
    "render_search",
    "render_search_json",
    "render_search_text",
    "should_colorize",
    "strip_ansi",
    "style",
]

# --------------------------------------------------------------------------- #
# Vocabulary
# --------------------------------------------------------------------------- #

#: The active ONNX Runtime provider names requirement 6.3 cites verbatim.
#: Spelled here rather than imported: `npu_rag.embedding.providers.*` and
#: `environment.capability` own these constants, and importing either would put
#: numpy and the onnxruntime probe on the `search` path against requirement
#: 1.2. A test cross-checks both spellings against the owning modules, so the
#: duplication cannot drift unnoticed.
NPU_PROVIDER: Final = "VitisAIExecutionProvider"
CPU_PROVIDER: Final = "CPUExecutionProvider"

#: The environment variable of the `NO_COLOR` convention (https://no-color.org).
NO_COLOR_VARIABLE: Final = "NO_COLOR"

#: Requirement 4.4's arrow between breadcrumb segments.
BREADCRUMB_SEPARATOR: Final = " -> "

#: Design §3.4's banner rule and hit marker.
RULE_WIDTH: Final = 80
HIT_MARKER: Final = "\u25b6"  # BLACK RIGHT-POINTING TRIANGLE

#: Snippet budget in characters. Counted in characters and never in bytes:
#: Devanagari and CJK cost 3 bytes a character here, and a byte budget would
#: silently shrink the preview to a third for exactly the content this archive
#: is made of.
SNIPPET_LIMIT: Final = 200
SNIPPET_ELLIPSIS: Final = "..."

#: Fixed decimal places. Pinned as constants because a score's precision is
#: how a user compares two hits, and drifting it changes every line.
SCORE_DIGITS: Final = 3
ELAPSED_DIGITS: Final = 3

UNKNOWN_LOCATOR: Final = "Unknown location"
UNKNOWN_DOCUMENT: Final = "(unknown document)"
NO_RESULTS_LINE: Final = "No results."

#: Default `json.dumps` indent. `--json` output is read by `jq` and by people.
JSON_INDENT: Final = 2

#: The SGR sequences this module emits, by name. A closed, named table rather
#: than inline escapes: `strip_ansi` has to be able to remove exactly what
#: `style` adds, and a test pins every entry against a hand-written literal
#:.
SGR: Final[dict[str, str]] = {
    "reset": "\x1b[0m",
    "bold": "\x1b[1m",
    "dim": "\x1b[2m",
    "green": "\x1b[32m",
    "yellow": "\x1b[33m",
    "magenta": "\x1b[35m",
    "cyan": "\x1b[36m",
}

# An ANSI escape in any of the three forms that reach a terminal: a CSI
# sequence (`\x1b[` parameters intermediates final), an OSC string (`\x1b]`
# ... BEL or ST - window titles and hyperlinks), and a two-character Fe/Fp
# escape. The OSC alternative must precede the two-character one, because `]`
# falls inside the latter's character range and would otherwise swallow the
# introducer and leave the payload text behind.
_ANSI_ESCAPE: Final = re.compile(
    "\x1b(?:"
    r"\[[0-?]*[ -/]*[@-~]"
    r"|\][^\x07\x1b]*(?:\x07|\x1b\\)"
    r"|[0-?@-Z\\-_]"
    ")"
)


# --------------------------------------------------------------------------- #
# Requirement 8.2 - styling, stripping, and when colour is allowed
# --------------------------------------------------------------------------- #


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from output or untrusted source fields."""
    return _ANSI_ESCAPE.sub("", text)


def style(text: str, *names: str, enabled: bool = True) -> str:
    """Apply named SGR codes and a reset, or return text unchanged when disabled."""
    if not enabled or not names:
        return text
    try:
        prefix = "".join(SGR[name] for name in names)
    except KeyError as exc:
        raise ValueError(
            f"unknown style {exc.args[0]!r}; available: {sorted(SGR)}"
        ) from exc
    return f"{prefix}{text}{SGR['reset']}"


def should_colorize(
    *,
    prefer_color: bool = True,
    stream: IO[str] | None = None,
    env: Mapping[str, str] | None = None,
) -> bool:
    """Enable styling only when requested, NO_COLOR is absent and the stream
    is a terminal. Stream inspection failures disable styling.
    """
    if not prefer_color:
        return False
    variables = os.environ if env is None else env
    if (variables.get(NO_COLOR_VARIABLE) or "").strip():
        return False
    target = sys.stdout if stream is None else stream
    isatty = getattr(target, "isatty", None)
    if not callable(isatty):
        return False
    try:
        # `bool()` is not decoration. `getattr` yields `Any`, so a stream whose
        # `isatty()` returns a truthy non-bool - `1`, or any object - would make
        # this `-> bool` function return that object, and mypy cannot see it.
        # A test asserts identity with `True`, not truthiness.
        return bool(isatty())
    except (OSError, ValueError):
        return False


# --------------------------------------------------------------------------- #
# Requirement 8.4 - UTF-8 stdout on Windows
# --------------------------------------------------------------------------- #


def ensure_utf8_stdout(stream: IO[str] | None = None) -> str | None:
    """Reconfigure stdout as UTF-8 when the stream supports it.
    Return the effective encoding. Leave streams without reconfigure unchanged.
    """
    target = sys.stdout if stream is None else stream
    if not isinstance(target, io.TextIOWrapper):
        return None
    target.reconfigure(encoding="utf-8")
    return target.encoding


def emit(text: str, *, stream: IO[str] | None = None) -> None:
    """Set the stream encoding to UTF-8 where supported, then write one output line."""
    target = sys.stdout if stream is None else stream
    ensure_utf8_stdout(target)
    target.write(text if text.endswith("\n") else f"{text}\n")
    target.flush()


# --------------------------------------------------------------------------- #
# Requirement 4.4 - locators
# --------------------------------------------------------------------------- #


def _as_int(value: object) -> int:
    """Narrow a parsed JSON value to `int`, rejecting `bool`."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"expected an int, got {type(value).__name__}")
    return value


def _as_text(value: object) -> str:
    if not isinstance(value, str):
        raise TypeError(f"expected a str, got {type(value).__name__}")
    return value


def _markdown_locator(payload: Mapping[str, object]) -> str:
    """`Lines 45-80`, or `Line 7` for a single-line block.

    `MarkdownLocator.ordinal` - the image ordinal inside the block - is not in
    the label: it disambiguates figures within one line range and would be
    noise on every prose hit. It survives in `--json` under `locator`.
    """
    raw = payload["line_range"]
    if not isinstance(raw, list) or len(raw) != 2:
        raise TypeError("markdown locator line_range must be a pair")
    start = _as_int(raw[0])
    end = _as_int(raw[1])
    if start == end:
        return f"Line {start}"
    return f"Lines {start}-{end}"


def _page_locator(payload: Mapping[str, object]) -> str:
    """`Page 3`."""
    return f"Page {_as_int(payload['page'])}"


def _sheet_locator(payload: Mapping[str, object]) -> str:
    """`Sheet 'Summary'!A1:C9` - the workbook convention, quoted.

    Quoted because sheet names contain spaces ("Bilanz Übersicht"), and
    prefixed with the noun so the segment reads the same way as `Page 3` and
    `Lines 45-80` do.
    """
    sheet = _as_text(payload["sheet"])
    cell_range = _as_text(payload["cell_range"])
    if not cell_range:
        return f"Sheet '{sheet}'"
    return f"Sheet '{sheet}'!{cell_range}"


def _image_file_locator(payload: Mapping[str, object]) -> str:
    """`Image file` - `ImageFileLocator` carries no position; the file is one."""
    return "Image file"


#: Format every persisted locator kind. Tests compare these keys with the
#: ingestion locator registry.
LOCATOR_FORMATTERS: Final[dict[str, Callable[[Mapping[str, object]], str]]] = {
    "markdown": _markdown_locator,
    "page": _page_locator,
    "sheet": _sheet_locator,
    "image_file": _image_file_locator,
}


def _parse_locator(locator_json: str) -> dict[str, object] | None:
    """The locator object, or `None` for anything that is not one."""
    try:
        loaded: object = json.loads(locator_json)
    except (TypeError, ValueError):
        return None
    if not isinstance(loaded, dict):
        return None
    return loaded


def format_locator(locator_type: str, locator_json: str) -> str:
    """Render the stored locator as a source breadcrumb.
    Malformed or incomplete metadata yields a partial locator rather than
    a rendering exception.
    """
    payload = _parse_locator(locator_json)
    formatter = LOCATOR_FORMATTERS.get(locator_type)
    if formatter is not None and payload is not None:
        try:
            return formatter(payload)
        except (KeyError, TypeError, ValueError):
            pass
    return locator_type.strip() or UNKNOWN_LOCATOR


# --------------------------------------------------------------------------- #
# Paths, documents, snippets
# --------------------------------------------------------------------------- #


def _path_parts(file_path: str) -> tuple[str, ...]:
    """Split a path using the shared Windows-aware ordering helpers."""
    return _components(file_path)


def _display_path(file_path: str) -> str:
    """Normalize extended-length prefixes and separators for display.
    Use the archive root for relative paths when supplied; retain the path
    when it is outside the root.
    """
    return "/".join(_path_parts(file_path))


def _document_name(file_path: str) -> str:
    """Use the source filename in terminal attribution.
    The extracted title is a separate JSON field.
    """
    parts = _path_parts(file_path)
    return parts[-1] if parts else UNKNOWN_DOCUMENT


def _snippet(text: str, *, limit: int = SNIPPET_LIMIT) -> str:
    """One line of preview: escapes removed, whitespace collapsed, truncated.

    Sanitised *before* truncation, so a cut can never land inside an escape
    sequence and leave its tail as visible junk.
    """
    collapsed = " ".join(strip_ansi(text).split())
    if len(collapsed) <= limit:
        return collapsed
    head = collapsed[:limit]
    boundary = head.rfind(" ")
    if boundary >= limit // 2:
        head = head[:boundary]
    return f"{head.rstrip()}{SNIPPET_ELLIPSIS}"


# --------------------------------------------------------------------------- #
# Requirement 6.3 - provider attribution
# --------------------------------------------------------------------------- #


def _require_provider(provider: str) -> str:
    """The provider name, or a `ValueError` - never a blank attribution.

    Requirement 6.3 says *every* execution reports its provider. A blank string
    would render `[Provider: ]`, which is attribution that has silently gone
    missing - the exact shape requirement 6.2 forbids one layer down.
    """
    if not provider.strip():
        raise ValueError(
            "provider must name the execution provider that ran this query "
            f"(e.g. {NPU_PROVIDER!r} or {CPU_PROVIDER!r}); got {provider!r}"
        )
    return provider


def format_provider(provider: str, *, color: bool = False) -> str:
    """Render the provider name and append (NPU) for VitisAIExecutionProvider."""
    name = strip_ansi(_require_provider(provider))
    suffix = " (NPU)" if name == NPU_PROVIDER else ""
    return style(f"[Provider: {name}{suffix}]", "bold", "magenta", enabled=color)


# --------------------------------------------------------------------------- #
# Requirement 4.4 - the breadcrumb
# --------------------------------------------------------------------------- #


def format_breadcrumb(
    *,
    folder: str,
    document: str,
    document_index: int,
    document_total: int,
    chunk_index: int,
    locator: str,
    color: bool = False,
) -> str:
    """Render folder, document position, chunk index and source locator.
    Strip embedded ANSI sequences from every data-derived component.
    """
    segments = (
        style(f"[Folder: {strip_ansi(folder)}]", "cyan", enabled=color),
        style(
            f"[Doc {document_index}/{document_total}: {strip_ansi(document)}]",
            "bold",
            enabled=color,
        ),
        style(
            f"[Chunk #{chunk_index} | {strip_ansi(locator)}]",
            "yellow",
            enabled=color,
        ),
    )
    return style(BREADCRUMB_SEPARATOR, "dim", enabled=color).join(segments)


# --------------------------------------------------------------------------- #
# The rendered sequence
# --------------------------------------------------------------------------- #


class _Hit:
    """One result in render order, with the context a breadcrumb needs.

    A hand-written class and not a dataclass: `dataclasses` is not otherwise on
    this import path and requirement 1.2 is measured in modules loaded.
    """

    __slots__ = (
        "document",
        "document_index",
        "document_total",
        "folder",
        "result",
        "tags",
    )

    def __init__(
        self,
        *,
        folder: str,
        tags: tuple[str, ...],
        document: str,
        document_index: int,
        document_total: int,
        result: SearchResult,
    ) -> None:
        self.folder = folder
        self.tags = tags
        self.document = document
        self.document_index = document_index
        self.document_total = document_total
        self.result = result


def _folder_tags(
    folder: str, folder_tags: Mapping[str, Sequence[str]] | None
) -> tuple[str, ...]:
    """The tags the caller attributes to `folder`, sanitised, order preserved."""
    if folder_tags is None:
        return ()
    return tuple(strip_ansi(str(tag)) for tag in folder_tags.get(folder, ()))


def _sequence(
    response: SearchResponse,
    *,
    archive_root: str | Path | None,
    group_by_folder: bool,
) -> list[tuple[str, SearchResult]]:
    """Pair each result with its folder in render order.
    Grouped output flattens the ordered folder mapping.
    """
    if group_by_folder:
        grouped = group_and_order_results(response.results, archive_root=archive_root)
        return [(folder, result) for folder, items in grouped.items() for result in items]
    return [
        (folder_of(result.file_path, archive_root=archive_root), result)
        for result in response.results
    ]


def _hits(
    response: SearchResponse,
    *,
    archive_root: str | Path | None,
    folder_tags: Mapping[str, Sequence[str]] | None,
    group_by_folder: bool,
) -> list[_Hit]:
    """Add document positions to the render sequence.
    Count distinct full paths so equal filenames in different folders remain separate.
    """
    sequence = _sequence(
        response, archive_root=archive_root, group_by_folder=group_by_folder
    )

    positions: dict[str, dict[str, int]] = {}
    for folder, result in sequence:
        documents = positions.setdefault(folder, {})
        key = _display_path(result.file_path)
        if key not in documents:
            documents[key] = len(documents) + 1

    hits: list[_Hit] = []
    for folder, result in sequence:
        documents = positions[folder]
        hits.append(
            _Hit(
                folder=folder,
                tags=_folder_tags(folder, folder_tags),
                document=_document_name(result.file_path),
                document_index=documents[_display_path(result.file_path)],
                document_total=len(documents),
                result=result,
            )
        )
    return hits


def _folder_rows(hits: Sequence[_Hit]) -> list[dict[str, object]]:
    """Return tags, hit count and distinct document count for each folder in render order."""
    counts: dict[str, int] = {}
    tags: dict[str, tuple[str, ...]] = {}
    totals: dict[str, int] = {}
    for hit in hits:
        counts[hit.folder] = counts.get(hit.folder, 0) + 1
        tags[hit.folder] = hit.tags
        totals[hit.folder] = hit.document_total
    return [
        {
            "folder": folder,
            "tags": list(tags[folder]),
            "result_count": count,
            "document_count": totals[folder],
        }
        for folder, count in counts.items()
    ]


def _tags_label(tags: Sequence[str]) -> str:
    """`(Tag: siddha)` for one, `(Tags: a, b)` for several - design §3.4's form."""
    if len(tags) == 1:
        return f"(Tag: {tags[0]})"
    return f"(Tags: {', '.join(tags)})"


# --------------------------------------------------------------------------- #
# Requirement 8.1 - the terminal rendering
# --------------------------------------------------------------------------- #


def _header_lines(response: SearchResponse, provider: str) -> list[str]:
    """Render query, search mode, provider and result/candidate counts."""
    query = strip_ansi(response.query)
    mode = strip_ansi(str(response.mode))
    elapsed = f"{response.elapsed_seconds:.{ELAPSED_DIGITS}f}"
    return [
        " ".join(
            [
                style(f"[Query: {query}]", "dim"),
                style(f"[Mode: {mode}]", "dim"),
                format_provider(provider, color=True),
            ]
        ),
        style(
            f"[Results: {len(response.results)}] "
            f"[Candidates: {response.total_candidates}] "
            f"[Elapsed: {elapsed}s]",
            "dim",
        ),
    ]


def _banner_lines(hit: _Hit) -> list[str]:
    """Design §3.4's folder banner: a rule, the folder with its tag, a rule."""
    rule = style("=" * RULE_WIDTH, "dim")
    label = style(f"[Folder: {strip_ansi(hit.folder)}]", "bold", "cyan")
    if hit.tags:
        label = f"{label} {style(_tags_label(hit.tags), 'magenta')}"
    return [rule, label, rule]


def _hit_lines(hit: _Hit) -> list[str]:
    """Render a hit with source breadcrumb, score, snippet and optional context.
    Keep folder attribution on each hit so copied lines remain identifiable.
    """
    result = hit.result
    breadcrumb = format_breadcrumb(
        folder=hit.folder,
        document=hit.document,
        document_index=hit.document_index,
        document_total=hit.document_total,
        chunk_index=result.chunk_index,
        locator=format_locator(result.locator_type, result.locator_json),
        color=True,
    )
    score = style(f"[Score: {result.score:.{SCORE_DIGITS}f}]", "green")
    lines = [
        f"  {style(HIT_MARKER, 'cyan')} {breadcrumb} {score}",
        f'      "{_snippet(result.text)}"',
    ]
    context = result.expanded_context
    if context is not None and context != result.text:
        lines.append(f'      {style("[Context]", "dim")} "{_snippet(context)}"')
    return lines


def render_search_text(
    response: SearchResponse,
    *,
    provider: str,
    archive_root: str | Path | None = None,
    group_by_folder: bool = False,
    folder_tags: Mapping[str, Sequence[str]] | None = None,
    color: bool = False,
) -> str:
    """Render grouped or flat terminal results with provider attribution.
    Apply styling, then strip all ANSI sequences when color is disabled.
    Escape source fields, truncate snippets and include optional context.
    """
    _require_provider(provider)
    hits = _hits(
        response,
        archive_root=archive_root,
        folder_tags=folder_tags,
        group_by_folder=group_by_folder,
    )

    lines = [*_header_lines(response, provider), ""]
    if not hits:
        lines.append(NO_RESULTS_LINE)
    else:
        current: str | None = None
        for hit in hits:
            if group_by_folder and hit.folder != current:
                current = hit.folder
                lines.extend(_banner_lines(hit))
            lines.extend(_hit_lines(hit))
            lines.append("")

    text = "\n".join(lines).rstrip()
    return text if color else strip_ansi(text)


# --------------------------------------------------------------------------- #
# Requirement 8.3 - the JSON rendering
# --------------------------------------------------------------------------- #


def _result_payload(hit: _Hit) -> dict[str, object]:
    """Serialize one result in schema order.
    Preserve source text without terminal truncation or ANSI cleanup.
    Normalize path separators for JSON consumers.
    """
    result = hit.result
    locator_label = format_locator(result.locator_type, result.locator_json)
    return {
        "folder": hit.folder,
        "tags": list(hit.tags),
        "document": hit.document,
        "document_index": hit.document_index,
        "document_total": hit.document_total,
        "file_path": _display_path(result.file_path),
        "source_path": result.file_path,
        "title": result.title,
        "chunk_id": result.chunk_id,
        "chunk_index": result.chunk_index,
        "chunk_kind": result.chunk_kind,
        "headings": list(result.headings),
        "locator_type": result.locator_type,
        "locator": _parse_locator(result.locator_json),
        "locator_label": locator_label,
        "score": result.score,
        "text": result.text,
        "expanded_context": result.expanded_context,
        "token_count": result.token_count,
        "dense_distance": result.dense_distance,
        "dense_rank": result.dense_rank,
        "lexical_score": result.lexical_score,
        "lexical_rank": result.lexical_rank,
        "breadcrumb": format_breadcrumb(
            folder=hit.folder,
            document=hit.document,
            document_index=hit.document_index,
            document_total=hit.document_total,
            chunk_index=result.chunk_index,
            locator=locator_label,
        ),
    }


def render_search_json(
    response: SearchResponse,
    *,
    provider: str,
    archive_root: str | Path | None = None,
    group_by_folder: bool = False,
    folder_tags: Mapping[str, Sequence[str]] | None = None,
    indent: int | None = JSON_INDENT,
) -> str:
    """Serialize results, folder metadata and provider attribution.
    Keep each result folder explicit so flat consumers can recover grouping.
    """
    _require_provider(provider)
    hits = _hits(
        response,
        archive_root=archive_root,
        folder_tags=folder_tags,
        group_by_folder=group_by_folder,
    )
    payload: dict[str, object] = {
        "query": response.query,
        "mode": str(response.mode),
        "provider": provider,
        "grouped": group_by_folder,
        "total_candidates": response.total_candidates,
        "elapsed_seconds": response.elapsed_seconds,
        "folders": _folder_rows(hits),
        "results": [_result_payload(hit) for hit in hits],
    }
    return json.dumps(payload, ensure_ascii=False, indent=indent)


def render_search(
    response: SearchResponse,
    *,
    provider: str,
    as_json: bool,
    archive_root: str | Path | None = None,
    group_by_folder: bool = False,
    folder_tags: Mapping[str, Sequence[str]] | None = None,
    color: bool = False,
    indent: int | None = JSON_INDENT,
) -> str:
    """Dispatch to terminal or JSON rendering with explicit provider attribution."""
    if as_json:
        return render_search_json(
            response,
            provider=provider,
            archive_root=archive_root,
            group_by_folder=group_by_folder,
            folder_tags=folder_tags,
            indent=indent,
        )
    return render_search_text(
        response,
        provider=provider,
        archive_root=archive_root,
        group_by_folder=group_by_folder,
        folder_tags=folder_tags,
        color=color,
    )

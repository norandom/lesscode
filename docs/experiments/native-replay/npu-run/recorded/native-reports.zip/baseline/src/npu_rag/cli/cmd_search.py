"""Search the local index and render results.

Validate filters and index presence before model preparation. Explicit NPU
requests fail when the provider is unavailable; auto mode reports CPU fallback.
Lexical search runs without an embedding session.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Final, Protocol

from npu_rag.cli import render
from npu_rag.cli.config import (
    MODE_CHOICES,
    PROVIDER_CHOICES,
    CliConfig,
    ConfigError,
    emit_config_error,
    load_config,
)
from npu_rag.cli.main import EXIT_OK, EXIT_RUNTIME, EXIT_USAGE, PROGRAM_NAME
from npu_rag.cli.order import folder_of
from npu_rag.cli.tags import PATH_SEPARATORS, TagRegistry

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Mapping, Sequence

    from npu_rag.embedding.service import EmbeddingService
    from npu_rag.embedding.types import ProviderChoice
    from npu_rag.index.types import SearchOptions, SearchResponse

__all__ = [
    "ARTIFACTS_DIRNAME",
    "CPU_ORT_PROVIDER",
    "EXIT_CODES",
    "FALLBACK_NOTICE_PREFIX",
    "FUSION_CHOICES",
    "LEXICAL_MODE",
    "METRIC_CHOICES",
    "NO_EMBEDDING_PROVIDER",
    "NPU_ORT_PROVIDER",
    "SEARCH_MODES",
    "ProviderAttributionError",
    "add_arguments",
    "artifacts_root",
    "folder_tag_map",
    "missing_index_message",
    "open_index_at",
    "open_query_embedder",
    "run",
]

# --------------------------------------------------------------------------- #
# Vocabulary
# --------------------------------------------------------------------------- #

#: Requirement 5.1's `--mode` spelling -> the `SearchMode` value it selects.
#: See ruling 2; the key set is `config.MODE_CHOICES` and a test pins both
#: sides against literals and against the enum.
SEARCH_MODES: Final[dict[str, str]] = {
    "dense": "dense_only",
    "fts": "lexical_only",
    "hybrid": "hybrid",
}

#: The one mode that embeds nothing, in the user's spelling.
LEXICAL_MODE: Final = "fts"

#: Requirement 5.1's `--metric` and `--fusion` vocabularies, which coincide
#: with `DistanceMetric` and `FusionMethod`. Spelled as literals so that
#: `search --help` does not import lancedb; a test compares them
#: with the enums.
METRIC_CHOICES: Final[tuple[str, ...]] = ("cosine", "dot", "l2")
FUSION_CHOICES: Final[tuple[str, ...]] = ("rrf", "linear")

#: The ONNX Runtime provider names requirement 6.3 reports. Taken from
#: `render`, which already cross-checks both spellings against the modules that
#: own them, so there is one spelling in the CLI and not three.
NPU_ORT_PROVIDER: Final = render.NPU_PROVIDER
CPU_ORT_PROVIDER: Final = render.CPU_PROVIDER

#: What a lexical-only search reports. Non-blank, because `render`
#: refuses a blank attribution, and deliberately not an ONNX Runtime name,
#: because no session ran.
NO_EMBEDDING_PROVIDER: Final = "none (lexical-only search ran no embedding model)"

#: Requirement 6.2's audible half of an `auto` fallback.
FALLBACK_NOTICE_PREFIX: Final = (
    "the NPU was not used; this query ran on the CPU. Reason: "
)

#: Where prepared model artifacts live, relative to the index's parent. The
#: index is the only user-configured location the search command has, and
#: `CliConfig` carries no artifacts field, so the two sit side by side:
#: `.npu_rag/lancedb` and `.npu_rag/artifacts` under the default configuration.
#: Tasks 5.1 and 5.2 must use `artifacts_root()` rather than re-deriving this.
ARTIFACTS_DIRNAME: Final = "artifacts"

#: Requirement 5.1's defaults, as design §3.5 and the requirement spell them.
DEFAULT_METRIC: Final = "cosine"
DEFAULT_FUSION: Final = "rrf"
DEFAULT_RRF_K: Final = 60
DEFAULT_LINEAR_ALPHA: Final = 0.5
DEFAULT_CONTEXT: Final = 0

#: LanceDB writes one `<table>.lance` directory per table inside the database
#: directory, so the presence of any of them is what distinguishes a real index
#: from an empty folder. Matched as a glob rather than by table name, so this
#: check does not silently depend on `LanceIndexStore`'s default table.
_TABLE_GLOB: Final = "*.lance"

#: `tags.py`'s glob vocabulary (`GLOB_CHARS`), as regular-expression fragments.
_GLOB_REGEX: Final[dict[str, str]] = {"*": ".*", "?": "."}


class ProviderAttributionError(Exception):
    """A query completed without recording which provider served it.

    Requirement 6.3 reports the active provider for *every* execution, so an
    unattributable run is a runtime failure (exit 2) and not output with a
    plausible guess. It is its own type so that the diagnostic cannot be
    confused with an embedding or storage failure.
    """


# --------------------------------------------------------------------------- #
# Seams
# --------------------------------------------------------------------------- #


class QueryEmbedder(Protocol):
    """Query embedding interface with served-provider and fallback metadata.
    Metadata remains None until a query has been embedded.
    """

    provider_served: str | None
    fallback_reason: str | None

    def embed_query(self, query: str) -> list[float]: ...


class IndexSearcher(Protocol):
    """The one method this command uses on `VectorIndex`."""

    def search(
        self,
        query: str,
        options: SearchOptions | None = ...,
        embed_service: object | None = ...,
    ) -> SearchResponse: ...


if TYPE_CHECKING:
    ConfigLoader = Callable[..., CliConfig]
    IndexOpener = Callable[[Path], IndexSearcher]
    EmbedderOpener = Callable[[CliConfig], QueryEmbedder]


# --------------------------------------------------------------------------- #
# Requirement 5.2 - parse-time numeric validation
# --------------------------------------------------------------------------- #


def _positive_int(raw: str) -> int:
    """An integer of 1 or more."""
    return _bounded_int(raw, minimum=1, described="a positive integer (1 or greater)")


def _non_negative_int(raw: str) -> int:
    """An integer of 0 or more."""
    return _bounded_int(raw, minimum=0, described="a whole number (0 or greater)")


def _bounded_int(raw: str, *, minimum: int, described: str) -> int:
    try:
        value = int(raw)
    except ValueError:
        raise argparse.ArgumentTypeError(f"must be {described}; got {raw!r}") from None
    if value < minimum:
        raise argparse.ArgumentTypeError(f"must be {described}; got {value}")
    return value


def _unit_interval(raw: str) -> float:
    """A float in `[0.0, 1.0]`, both ends included.

    `nan` parses as a float and then fails the comparison, which is the
    intended outcome: a diversity factor that compares false against every
    bound would otherwise flow into the engine and silently disable MMR.
    """
    try:
        value = float(raw)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"must be a number between 0.0 and 1.0; got {raw!r}"
        ) from None
    if not 0.0 <= value <= 1.0:
        raise argparse.ArgumentTypeError(
            f"must be between 0.0 and 1.0 inclusive; got {raw}"
        )
    return value


# --------------------------------------------------------------------------- #
# Registration (design §3.5)
# --------------------------------------------------------------------------- #


def add_arguments(parser: argparse.ArgumentParser) -> None:
    """Register search flags when this subcommand is selected."""
    parser.add_argument(
        "query",
        help="The text to search for. Quote it if it contains spaces.",
    )

    scope = parser.add_argument_group("folder scoping and tag taxonomy")
    scope.add_argument(
        "--folder",
        metavar="<name|glob>",
        help=(
            "Restrict the search to one folder, relative subfolder, or glob "
            "(for example 'Bhagwan Garuda*'). Requirement 3.1."
        ),
    )
    scope.add_argument(
        "--tag",
        action="append",
        metavar="<name[,name]>",
        help=(
            "Restrict the search to the folders a configured tag names. "
            "Repeatable, and accepts a comma-separated list. Requirement 3.3."
        ),
    )
    scope.add_argument(
        "--filter",
        metavar="<sql>",
        help="An additional SQL WHERE predicate, ANDed with the scope above.",
    )

    presentation = parser.add_argument_group("presentation")
    presentation.add_argument(
        "--group-by-folder",
        action="store_true",
        help=(
            "Group hits under their folder and restore each folder's narrative "
            "order (session numbers, dates) instead of score order."
        ),
    )
    presentation.add_argument(
        "--context",
        type=_non_negative_int,
        default=DEFAULT_CONTEXT,
        metavar="<n>",
        help=(
            "Attach N preceding and N succeeding chunks to each hit "
            f"(default {DEFAULT_CONTEXT})."
        ),
    )
    presentation.add_argument(
        "--json",
        action="store_true",
        help="Emit structured JSON on stdout instead of formatted text.",
    )
    presentation.add_argument(
        "--no-color",
        action="store_true",
        help="Never emit ANSI styling, even on a terminal that supports it.",
    )

    retrieval = parser.add_argument_group("retrieval controls")
    retrieval.add_argument(
        "--mode",
        choices=MODE_CHOICES,
        help=(
            "Retrieval mode: 'dense' vectors only, 'fts' full-text only, or "
            "'hybrid' (the default, and whatever the configuration says)."
        ),
    )
    retrieval.add_argument(
        "--metric",
        choices=METRIC_CHOICES,
        default=DEFAULT_METRIC,
        help=f"Dense distance metric (default {DEFAULT_METRIC}).",
    )
    retrieval.add_argument(
        "--fusion",
        choices=FUSION_CHOICES,
        default=DEFAULT_FUSION,
        help=f"How hybrid rankings are combined (default {DEFAULT_FUSION}).",
    )
    retrieval.add_argument(
        "--rrf-k",
        type=_positive_int,
        default=DEFAULT_RRF_K,
        metavar="<k>",
        help=f"Reciprocal-rank-fusion smoothing constant (default {DEFAULT_RRF_K}).",
    )
    retrieval.add_argument(
        "--linear-alpha",
        type=_unit_interval,
        default=DEFAULT_LINEAR_ALPHA,
        metavar="<alpha>",
        help=(
            "Dense weight for linear fusion, between 0.0 and 1.0 "
            f"(default {DEFAULT_LINEAR_ALPHA}). Only used with --fusion linear."
        ),
    )
    retrieval.add_argument(
        "--mmr",
        type=_unit_interval,
        metavar="<lambda>",
        help=(
            "Maximal-marginal-relevance diversity between 0.0 and 1.0. "
            "Opt-in: omitted, no diversity re-ranking is applied."
        ),
    )
    retrieval.add_argument(
        "--max-chunks-per-doc",
        type=_positive_int,
        metavar="<n>",
        help="Keep at most N chunks from any one document.",
    )
    retrieval.add_argument(
        "--rollup",
        action="store_true",
        help="Aggregate chunk scores to document level before truncating.",
    )
    retrieval.add_argument(
        "--top-k",
        type=_positive_int,
        metavar="<n>",
        help=(
            "How many results to return. Defaults to the configured "
            "default_limit, which is 10 unless set."
        ),
    )
    retrieval.add_argument(
        "--fetch-k",
        type=_positive_int,
        metavar="<n>",
        help=(
            "How many candidates to retrieve before fusion, diversity and "
            "truncation. Defaults to max(top-k * 4, 30). Raise it when a "
            "relevant chunk is being squeezed out of the candidate pool; "
            "lower it to trade recall for speed on a large index."
        ),
    )

    execution = parser.add_argument_group("execution")
    execution.add_argument(
        "--provider",
        choices=PROVIDER_CHOICES,
        help=(
            "Where the query is embedded: 'npu' (fail if the NPU is "
            "unavailable), 'cpu', or 'auto' (prefer the NPU, and say so when "
            "it cannot be used). Defaults to the configured provider."
        ),
    )


# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #


def artifacts_root(config: CliConfig) -> Path:
    """Where prepared model artifacts live for this configuration.

    A sibling of the index directory, so one configured location puts the
    database and the compiled graphs together: `.npu_rag/lancedb` and
    `.npu_rag/artifacts` by default, and both move when `index_path` does.
    """
    return config.index_path.expanduser().resolve().parent / ARTIFACTS_DIRNAME


def missing_index_message(index_path: Path) -> str | None:
    """Check for existing table files or table metadata before opening the store.
    A missing index returns a diagnostic directing the caller to index first.
    """
    if index_path.is_dir():
        if any(index_path.glob(_TABLE_GLOB)):
            return None
        # Namespace-backed LanceDB versions can store table metadata without
        # a root *.lance directory. List existing tables only after checking
        # the root, so a first search still cannot create a database.
        import lancedb

        if "chunks" in lancedb.connect(str(index_path)).list_tables().tables:
            return None
    return (
        f"no search index found at {index_path}. "
        f"Run `{PROGRAM_NAME} index` first to build one, or point "
        f"NPU_RAG_INDEX_PATH (or index_path in npu-rag.toml) at an existing index."
    )


# --------------------------------------------------------------------------- #
# Ruling 6 - folder -> tags, keyed as `order.folder_of` labels
# --------------------------------------------------------------------------- #


def _first_component(spec: str) -> str:
    """The first path component of a folder spec, either separator spelling."""
    text = spec
    for separator in PATH_SEPARATORS:
        text = text.replace(separator, "\x00")
    for part in text.split("\x00"):
        if part.strip():
            return part.strip()
    return ""


def _spec_pattern(spec: str) -> re.Pattern[str]:
    """Match folder globs over the full label.
    Only * and ? are wildcards; %, _, [ and other characters are literal.
    """
    out = [_GLOB_REGEX.get(char, re.escape(char)) for char in os.path.normcase(spec)]
    return re.compile("".join(out) + r"\Z")


def folder_tag_map(
    folders: Iterable[str], tags: Mapping[str, Sequence[str]]
) -> dict[str, tuple[str, ...]]:
    """Map first-level archive folder labels to matching tag names.
    Match both separator spellings. Ignore empty or unmatched annotations;
    explicit tag selection is validated separately.
    """
    labels = list(folders)
    mapping: dict[str, list[str]] = {}
    for tag in sorted(tags):
        for spec in tags[tag]:
            component = _first_component(spec)
            if not component:
                continue
            pattern = _spec_pattern(component)
            for label in labels:
                if pattern.match(os.path.normcase(label)):
                    carried = mapping.setdefault(label, [])
                    if tag not in carried:
                        carried.append(tag)
    return {label: tuple(names) for label, names in mapping.items()}


# --------------------------------------------------------------------------- #
# The default seams
# --------------------------------------------------------------------------- #


class _ServiceQueryEmbedder:
    """Adapt EmbeddingService to the index query interface.
    Retain the served provider and fallback metadata for output attribution.
    """

    __slots__ = ("_provider", "_service", "fallback_reason", "provider_served")

    def __init__(self, service: EmbeddingService, provider: ProviderChoice) -> None:
        self._service = service
        self._provider = provider
        self.provider_served: str | None = None
        self.fallback_reason: str | None = None

    def embed_query(self, query: str) -> list[float]:
        result = self._service.embed_queries([query], self._provider)
        self.provider_served = str(result.provider_served)
        self.fallback_reason = result.fallback_reason
        return [float(value) for value in result.vectors[0]]


def open_index_at(index_path: Path) -> IndexSearcher:
    """Open the vector index at `index_path` (lancedb enters the process here)."""
    from npu_rag.index.service import VectorIndex

    return VectorIndex(index_path)


def open_query_embedder(config: CliConfig) -> QueryEmbedder:
    """Build the query embedder after checking explicit NPU availability.
    Preserve an AUTO request even when preparation selects CPU, so the result
    can report the reason for fallback.
    """
    from npu_rag.embedding.environment.capability import check_capability
    from npu_rag.embedding.errors import NpuUnavailableError
    from npu_rag.embedding.profiles import PROFILES, profile_for
    from npu_rag.embedding.providers.base import npu_unavailable_reason
    from npu_rag.embedding.service import build_service
    from npu_rag.embedding.types import ProviderChoice

    requested = ProviderChoice(config.provider)
    try:
        profile = profile_for(config.model_name)
    except KeyError:
        declared = ", ".join(repr(name) for name in sorted(PROFILES))
        raise ConfigError(
            f"unknown model {config.model_name!r}. Declared models: {declared}."
        ) from None

    capability = check_capability()
    reason = npu_unavailable_reason(capability)
    if requested is ProviderChoice.NPU and reason is not None:
        raise NpuUnavailableError(
            f"provider 'npu' was requested explicitly and the NPU is not usable: "
            f"{reason}. No other provider will be substituted; re-run with "
            f"--provider cpu to search on the CPU, or repair the NPU "
            f"provisioning (uv run python -m tools.provision_npu).",
            provider=requested,
            model_id=profile.model_id,
        )

    if requested is ProviderChoice.CPU or reason is not None:
        artifact_provider = ProviderChoice.CPU
    else:
        artifact_provider = ProviderChoice.NPU
    service = build_service(
        profile, capability, artifacts_root(config), provider=artifact_provider
    )
    return _ServiceQueryEmbedder(service, requested)


# --------------------------------------------------------------------------- #
# Execution
# --------------------------------------------------------------------------- #


def _fail(message: str, code: int) -> int:
    """A diagnostic on stderr and nothing on stdout - `main._fail`'s format.

    Spelled here rather than imported: `main._fail` is private to the
    dispatcher, and `config.emit_config_error` already duplicates the same
    single line for the same reason. A test pins all three to one shape.
    """
    sys.stderr.write(f"{PROGRAM_NAME}: error: {message}\n")
    return code


def _notice(message: str) -> None:
    """A non-error remark on stderr, so `--json` stdout stays parseable."""
    sys.stderr.write(f"{PROGRAM_NAME}: notice: {message}\n")


def _tag_names(raw: Sequence[str] | None) -> list[str]:
    """`--tag a,b --tag c` as one list, splitting on commas (requirement 3.3).

    Blanks are **kept**, not dropped: `--tag ""` and a trailing comma both
    reach `TagRegistry.resolve_tag`, which diagnoses them. Dropping them here
    would make a flag whose only job is to narrow do nothing at all, which is
    the failure mode `tags._require_value` exists to prevent.
    """
    if not raw:
        return []
    return [name for entry in raw for name in entry.split(",")]


def _resolved_mode(args: argparse.Namespace, config: CliConfig) -> str:
    """The effective `--mode`, in requirement 5.1's spelling.

    Note 1.2: a `CliConfig` built outside `load_config()` is unvalidated, so
    `default_mode` is checked here rather than assumed - the message names
    where the value came from, as requirement 2.3 asks.
    """
    mode: str | None = args.mode
    if mode is None:
        mode = config.default_mode
    if mode not in SEARCH_MODES:
        listed = ", ".join(repr(name) for name in MODE_CHOICES)
        raise ConfigError(
            f"configured default_mode must be one of {listed}; got {mode!r}."
        )
    return mode


def _build_options(
    args: argparse.Namespace, config: CliConfig, *, mode: str, filter_sql: str | None
) -> SearchOptions:
    """Every flag of requirement 5.1, on the `SearchOptions` field it controls."""
    from npu_rag.index.types import (
        DistanceMetric,
        FusionMethod,
        SearchMode,
        SearchOptions,
    )

    limit = config.default_limit if args.top_k is None else args.top_k
    return SearchOptions(
        limit=limit,
        mode=SearchMode(SEARCH_MODES[mode]),
        metric=DistanceMetric(args.metric),
        filter_sql=filter_sql,
        fusion_method=FusionMethod(args.fusion),
        rrf_k=args.rrf_k,
        linear_alpha=args.linear_alpha,
        mmr_diversity=args.mmr,
        max_chunks_per_document=args.max_chunks_per_doc,
        document_rollup=args.rollup,
        context_window=args.context,
        # `None` is meaningful, not a missing value: it asks the index to keep
        # its derived default (`max(limit * 4, 30)`) rather than naming a depth.
        fetch_k=args.fetch_k,
    )


def _provider_label(embedder: QueryEmbedder | None) -> str:
    """Return the served ONNX Runtime provider name or raise if attribution is absent."""
    if embedder is None:
        return NO_EMBEDDING_PROVIDER
    served = embedder.provider_served
    if served is None:
        raise ProviderAttributionError(
            "the query completed without recording which execution provider "
            "served it, so the result cannot be attributed (requirement 6.3)."
        )
    if served == "npu":
        return NPU_ORT_PROVIDER
    if served == "cpu":
        return CPU_ORT_PROVIDER
    raise ProviderAttributionError(
        f"the embedding runtime reported an unknown execution provider "
        f"{served!r}; expected 'npu' or 'cpu' (requirement 6.3)."
    )


def _render(
    response: SearchResponse,
    args: argparse.Namespace,
    config: CliConfig,
    *,
    provider: str,
    archive_root: Path,
) -> None:
    """Format and print, through `render.emit` (note 3.1, requirement 8.4)."""
    folders = {
        folder_of(result.file_path, archive_root=archive_root)
        for result in response.results
    }
    color = render.should_colorize(
        prefer_color=config.ansi_colors and not args.no_color
    )
    render.emit(
        render.render_search(
            response,
            provider=provider,
            as_json=args.json,
            archive_root=archive_root,
            group_by_folder=args.group_by_folder,
            folder_tags=folder_tag_map(folders, config.tags),
            color=color,
        )
    )


def run(
    args: argparse.Namespace,
    *,
    load: ConfigLoader = load_config,
    open_index: IndexOpener = open_index_at,
    open_embedder: EmbedderOpener = open_query_embedder,
) -> int:
    """Validate configuration and filters, check index presence, execute search
    and render results. Diagnose user errors before model preparation.
    """
    try:
        config = load(cli_args=vars(args))
        query = str(args.query)
        if not query.strip():
            raise ConfigError(
                "the search query is empty; name the text to search for."
            )
        mode = _resolved_mode(args, config)
        filter_sql = TagRegistry(config.tags).build_filter_sql(
            folder=args.folder,
            tags=_tag_names(args.tag),
            custom_filter=args.filter,
        )
        options = _build_options(args, config, mode=mode, filter_sql=filter_sql)
    except ConfigError as error:
        return emit_config_error(error)

    from npu_rag.embedding.errors import EmbeddingRuntimeError
    from npu_rag.index.errors import VectorIndexError

    try:
        index_path = config.index_path.expanduser().resolve()
        absent = missing_index_message(index_path)
        if absent is not None:
            return _fail(absent, EXIT_RUNTIME)
        embedder = None if mode == LEXICAL_MODE else open_embedder(config)
        index = open_index(index_path)
        response = index.search(query, options, embedder)
        provider = _provider_label(embedder)
        if embedder is not None and embedder.fallback_reason is not None:
            _notice(f"{FALLBACK_NOTICE_PREFIX}{embedder.fallback_reason}")
        _render(
            response,
            args,
            config,
            provider=provider,
            archive_root=config.archive_path.expanduser().resolve(),
        )
    except ConfigError as error:
        return emit_config_error(error)
    except ProviderAttributionError as error:
        return _fail(str(error), EXIT_RUNTIME)
    except (EmbeddingRuntimeError, VectorIndexError, OSError) as error:
        return _fail(str(error), EXIT_RUNTIME)
    return EXIT_OK


EXIT_CODES: Final[tuple[int, int, int]] = (EXIT_OK, EXIT_USAGE, EXIT_RUNTIME)
"""Design §4's taxonomy, re-exported so a test can pin this module to it."""

"""Assemble tokenization, provider execution and sentence postprocessing.

Resolve one provider per operation, pad to the static batch shape, run token
inference and return normalized vectors with execution metadata. Dense stages
are mandatory when the model profile declares them.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Final, Protocol

import numpy as np
import numpy.typing as npt
from transformers import PreTrainedTokenizerBase

from npu_rag.embedding.errors import ExecutionError
from npu_rag.embedding.models.artifacts import PreparedArtifact, ensure_prepared
from npu_rag.embedding.models.export import (
    ACTIVATION_PREFIX,
    BIAS_PREFIX,
    DENSE_ORDER_KEY,
    WEIGHT_PREFIX,
)
from npu_rag.embedding.postprocess import (
    DenseLayer,
    dense_layers_from_arrays,
    finalize,
)
from npu_rag.embedding.profiles import ModelProfile
from npu_rag.embedding.providers.base import (
    BackendFactories,
    TransformerBackend,
    resolve_backend,
)
from npu_rag.embedding.providers.cpu import CpuBackend
from npu_rag.embedding.providers.vitisai import (
    MINIMUM_PARTITION_SHARE,
    VitisAIBackend,
)
from npu_rag.embedding.reporting import (
    ProgressCallback,
    RunTracker,
    SummaryCallback,
)
from npu_rag.embedding.tokenize import EncodedBatch, ModelTokenizer, load_tokenizer
from npu_rag.embedding.types import (
    CapabilityReport,
    DocumentText,
    ExecutionMode,
    ProviderChoice,
    TextKind,
)

__all__ = [
    "EMBED_STAGE",
    "ArtifactPreparer",
    "BackendBuilder",
    "EmbedResult",
    "EmbeddingContract",
    "EmbeddingService",
    "build_service",
    "default_backend_builder",
    "load_dense_layers",
]

#: The stage a failure inside an embedding operation belongs to (8.1, 8.2).
#: Distinct from the preparation stages ``acquire``/``export``/``compile`` and
#: from ``session``, so requirement 8.2's three categories stay separable.
EMBED_STAGE: Final = "embed"

#: What `RunSummary.operation` is called for each entry point. Requirement 8.3's
#: progress and 8.6's completion report name the operation, and a consumer that
#: renders documents and queries differently needs to tell them apart.
_OPERATION: Final[dict[TextKind, str]] = {
    TextKind.DOCUMENT: "embed_documents",
    TextKind.QUERY: "embed_queries",
}


# --------------------------------------------------------------------------
# What the service publishes
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class EmbeddingContract:
    """Consumer limits and tokenizer identity.
    max_input_tokens is the compiled sequence length, not the architectural
    context limit.
    """

    model_id: str
    dimension: int
    max_input_tokens: int
    tokenizer_id: str


@dataclass(frozen=True)
class EmbedResult:
    """Normalized vectors and metadata for a completed embedding operation.
    Validate dimensions, provider information and fallback metadata.
    """

    vectors: npt.NDArray[np.float32]
    provider_served: ProviderChoice
    execution_mode: ExecutionMode
    #: ``None`` when the CPU served, because the question does not apply to it.
    #: ``False`` on an NPU run means *assumed, not verified* - either no share
    #: was established or the measured share was below threshold - which is a
    #: different statement from ``True`` and must not collapse into it.
    partition_verified: bool | None
    fallback_reason: str | None
    truncated_indices: tuple[int, ...]
    elapsed_seconds: float
    input_count: int

    def __post_init__(self) -> None:
        if self.vectors.ndim != 2 or self.vectors.shape[0] != self.input_count:
            raise ValueError(
                f"requirement 3.1 is one vector per input: {self.input_count} "
                f"inputs produced an array shaped {self.vectors.shape}"
            )
        if self.provider_served is ProviderChoice.AUTO:
            raise ValueError(
                "provider_served names what actually ran; 'auto' is a "
                "request, not an outcome (requirement 2.6)"
            )
        self._check_partition()
        self._check_fallback()
        self._check_truncated()

    def _check_partition(self) -> None:
        served_on_cpu = self.provider_served is ProviderChoice.CPU
        if served_on_cpu and self.partition_verified is not None:
            raise ValueError(
                "graph partitioning does not apply to the cpu, so "
                f"partition_verified must be None, got "
                f"{self.partition_verified!r}"
            )
        if not served_on_cpu and self.partition_verified is None:
            raise ValueError(
                "an npu run must state whether its partition was verified; "
                "partition_verified=None would leave 'measured and below "
                "threshold' indistinguishable from 'never checked'"
            )

    def _check_fallback(self) -> None:
        if self.fallback_reason is None:
            return
        if not self.fallback_reason.strip():
            raise ValueError(
                "fallback_reason must say specifically why the NPU was not "
                f"used, got {self.fallback_reason!r}: a blank reason reports a "
                "fallback and explains nothing (requirement 2.5)"
            )
        if self.provider_served is not ProviderChoice.CPU:
            raise ValueError(
                "fallback_reason explains why the NPU was not used, so the cpu "
                f"must be what served; got provider_served="
                f"{self.provider_served.value!r} (requirement 2.5)"
            )

    def _check_truncated(self) -> None:
        previous = -1
        for index in self.truncated_indices:
            if not 0 <= index < self.input_count:
                raise ValueError(
                    f"truncated_indices names input {index}, which is outside "
                    f"a batch of {self.input_count} (requirement 3.9)"
                )
            if index <= previous:
                raise ValueError(
                    "truncated_indices must be strictly increasing so each "
                    f"shortened input is named once, got "
                    f"{self.truncated_indices!r}"
                )
            previous = index

    @property
    def truncated_count(self) -> int:
        """How many inputs were shortened to fit (3.9)."""
        return len(self.truncated_indices)


# --------------------------------------------------------------------------
# The seams
# --------------------------------------------------------------------------


class BackendBuilder(Protocol):
    """Build provider factories for the explicitly requested selection.
    The NPU factory captures that selection so partition verification can
    distinguish strict NPU requests from AUTO requests.
    """

    def __call__(self, requested: ProviderChoice, /) -> BackendFactories: ...


class DefaultingBackendBuilder(Protocol):
    """A backend builder that accepts an omitted selection.
    The implementation default is tested separately from this callable type.
    """

    def __call__(
        self, requested: ProviderChoice = ..., /
    ) -> BackendFactories: ...


class ArtifactPreparer(Protocol):
    """`ensure_prepared`, narrowed to what the default builder uses."""

    def __call__(
        self, profile: ModelProfile, provider: ProviderChoice, root: Path, /
    ) -> PreparedArtifact: ...


def load_dense_layers(
    artifact: PreparedArtifact,
    profile: ModelProfile,
    provider: ProviderChoice | None = None,
) -> tuple[DenseLayer, ...]:
    """Load declared dense projections in pipeline order using exporter keys.
    A required dense.npz file must exist; omitting a projection changes the
    embedding space even when dimensions and norms still look valid.
    """
    if not profile.has_dense_stage:
        return ()
    if artifact.dense_path is None:
        raise ExecutionError(
            f"{profile.model_id} has a Dense stage between pooling and "
            "normalization, but the prepared artifact carries no dense "
            "weights. Embedding without it would produce correctly shaped, "
            "correctly normalized vectors that are semantically wrong",
            provider=provider,
            model_id=profile.model_id,
            stage=EMBED_STAGE,
        )
    with np.load(artifact.dense_path) as arrays:
        return dense_layers_from_arrays(
            arrays,
            order_key=DENSE_ORDER_KEY,
            weight_prefix=WEIGHT_PREFIX,
            bias_prefix=BIAS_PREFIX,
            activation_prefix=ACTIVATION_PREFIX,
            provider=provider,
            model_id=profile.model_id,
        )


def default_backend_builder(
    root: Path,
    *,
    prepare: ArtifactPreparer = ensure_prepared,
) -> DefaultingBackendBuilder:
    """Build CPU and NPU factories with provider-specific prepared artifacts.
    An omitted request defaults to strict NPU selection.
    """

    def build(
        requested: ProviderChoice = ProviderChoice.NPU, /
    ) -> BackendFactories:
        def npu(
            profile: ModelProfile, capability: CapabilityReport, /
        ) -> TransformerBackend:
            artifact = prepare(profile, ProviderChoice.NPU, root)
            return VitisAIBackend(artifact, profile, requested)

        def cpu(
            profile: ModelProfile, capability: CapabilityReport, /
        ) -> TransformerBackend:
            artifact = prepare(profile, ProviderChoice.CPU, root)
            return CpuBackend(artifact, profile)

        return BackendFactories(npu=npu, cpu=cpu)

    return build


# --------------------------------------------------------------------------
# The service
# --------------------------------------------------------------------------


class EmbeddingService:
    """Embed text batches and report the served provider.
    Require dense weights whenever the profile declares a dense stage.
    """

    def __init__(
        self,
        profile: ModelProfile,
        capability: CapabilityReport,
        tokenizer: ModelTokenizer,
        *,
        backends: BackendBuilder,
        dense: Sequence[DenseLayer] = (),
        clock: Callable[[], float] = time.perf_counter,
    ) -> None:
        if profile.has_dense_stage and not dense:
            raise ValueError(
                f"{profile.model_id} applies a Dense stage between pooling and "
                "normalization and no layers were supplied. Embedding without "
                "it produces vectors of the right width, the right dtype and "
                "unit norm that mean something else - the trunk's hidden width "
                "equals the published dimension, so not even a dimension check "
                "can see it, and only a retrieval-quality measurement ever "
                "would. Pass dense=load_dense_layers(artifact, profile), or "
                "use build_service, which does it"
            )
        self._profile = profile
        self._capability = capability
        self._tokens = tokenizer
        self._backends = backends
        self._dense = tuple(dense)
        self._clock = clock

    # -- the published contract (3.6, 3.7) ---------------------------------

    def contract(self) -> EmbeddingContract:
        """The model's dimension, its maximum input length, and its tokenizer."""
        return EmbeddingContract(
            model_id=self._profile.model_id,
            dimension=self._profile.dimension,
            max_input_tokens=self._profile.max_input_tokens,
            tokenizer_id=self._tokens.tokenizer_id,
        )

    def tokenizer(self) -> PreTrainedTokenizerBase:
        """The tokenizer this runtime measures with (3.7).

        Exposed so a consumer can measure by the same rule rather than a similar
        one; requirement 3.8 is the promise that the two agree.
        """
        return self._tokens.tokenizer

    def count_tokens(
        self, text: str | DocumentText, kind: TextKind
    ) -> int:
        """The token length of ``text`` under ``kind``'s convention (3.8).

        Accepts `DocumentText` as well as a bare string, because a document's
        length includes the rendered title slot. Measuring the content alone
        would disagree with the truncation decision for exactly the documents
        that carry a title, which is the drift requirement 3.8 forbids.
        """
        return self._tokens.count_tokens(text, kind)

    # -- embedding (3.1-3.5, 3.9, 3.10) ------------------------------------

    def embed_documents(
        self,
        texts: Sequence[DocumentText],
        provider: ProviderChoice,
        progress: ProgressCallback | None = None,
        *,
        on_finish: SummaryCallback | None = None,
    ) -> EmbedResult:
        """Embed corpus content under the document-side convention (3.4)."""
        return self._embed(texts, TextKind.DOCUMENT, provider, progress, on_finish)

    def embed_queries(
        self,
        texts: Sequence[str],
        provider: ProviderChoice,
        progress: ProgressCallback | None = None,
        *,
        on_finish: SummaryCallback | None = None,
    ) -> EmbedResult:
        """Embed search queries under the query-side convention (3.4)."""
        return self._embed(texts, TextKind.QUERY, provider, progress, on_finish)

    def _embed(
        self,
        texts: Sequence[str | DocumentText],
        kind: TextKind,
        provider: ProviderChoice,
        progress: ProgressCallback | None,
        on_finish: SummaryCallback | None,
    ) -> EmbedResult:
        """Tokenize inputs, resolve one backend and execute fixed-shape batches.
        Deliver on_finish metadata on completion or interruption, even when
        no EmbedResult is returned.
        """
        if len(texts) == 0:
            raise ValueError(
                "an embedding request must carry at least one input: an empty "
                "batch has no provider to report and no vectors to return"
            )
        choice = ProviderChoice(provider)
        encoded = self._tokens.encode(list(texts), kind)
        # Bound once, before any work, and never rebound inside the loop below:
        # requirement 2.7 is that the provider cannot change part-way through an
        # operation, and `BoundBackend` is frozen so it structurally cannot.
        bound, reason = resolve_backend(
            choice, self._profile, self._capability, factories=self._backends(choice)
        )
        tracker = RunTracker(
            operation=_OPERATION[kind],
            provider_served=ProviderChoice(bound.provider),
            execution_mode=bound.execution_mode,
            input_count=len(texts),
            progress=progress,
            on_finish=on_finish,
            fallback_reason=reason,
            clock=self._clock,
        )
        with tracker:
            tracker.record_truncated(len(encoded.truncated_indices))
            vectors = self._forward(bound, encoded, tracker)
        summary = tracker.result
        if summary is None:
            # `RunTracker.__exit__` stores the summary before it returns, so
            # this is unreachable today. It is a raise rather than an `assert`
            # because `python -O` strips assertions, and the stripped build
            # would reach the attribute access below and report requirement
            # 8.6's missing elapsed time as an AttributeError on None.
            raise ExecutionError(
                "the run tracker produced no summary for a completed "
                "operation, so there is no elapsed time to report",
                provider=ProviderChoice(bound.provider),
                model_id=self._profile.model_id,
                stage=EMBED_STAGE,
            )
        # Copy shared metrics from the final RunSummary to keep one source
        # for provider, elapsed time and completion counts.
        return EmbedResult(
            vectors=vectors,
            provider_served=summary.provider_served,
            execution_mode=summary.execution_mode,
            partition_verified=self._partition_verified(bound),
            fallback_reason=summary.fallback_reason,
            truncated_indices=encoded.truncated_indices,
            elapsed_seconds=summary.elapsed_seconds,
            input_count=summary.input_count,
        )

    def _forward(
        self,
        bound: TransformerBackend,
        encoded: EncodedBatch,
        tracker: RunTracker,
    ) -> npt.NDArray[np.float32]:
        """Run every batch at the compiled shape and post-process the real rows."""
        size = self._profile.batch_size
        total = encoded.token_ids.shape[0]
        provider = ProviderChoice(bound.provider)
        chunks: list[npt.NDArray[np.float32]] = []
        for start in range(0, total, size):
            stop = min(start + size, total)
            actual = stop - start
            token_ids = encoded.token_ids[start:stop]
            attention_mask = encoded.attention_mask[start:stop]
            if actual < size:
                token_ids, attention_mask = _pad_to(token_ids, attention_mask, size)
            embeddings = bound.run(token_ids, attention_mask)
            # Slice before post-processing, never after: the filler rows carry
            # an all-zero mask, which masked mean pooling refuses rather than
            # averaging over nothing.
            chunks.append(
                finalize(
                    embeddings[:actual],
                    attention_mask[:actual],
                    # The active model's own rule, never a default: two
                    # candidates pool by masked mean and one by CLS, and the
                    # wrong choice is the right width and the right norm
                    # carrying a different meaning.
                    pooling=self._profile.pooling,
                    dense=self._dense,
                    provider=provider,
                    model_id=self._profile.model_id,
                )
            )
            tracker.advance(actual)
        return np.concatenate(chunks) if len(chunks) > 1 else chunks[0]

    def _partition_verified(self, bound: TransformerBackend) -> bool | None:
        """Whether the NPU demonstrably took the graph (design.md, 2026-09-06).

        ``None`` for the CPU: the question does not apply. Otherwise a share is
        verified only if one was established *and* it reaches the threshold, so
        an unestablished share reads as ``False`` - assumed, not verified -
        rather than as a passing check.
        """
        if ProviderChoice(bound.provider) is ProviderChoice.CPU:
            return None
        share = bound.npu_partition_share
        return share is not None and share >= MINIMUM_PARTITION_SHARE


def _pad_to(
    token_ids: npt.NDArray[np.int64],
    attention_mask: npt.NDArray[np.int64],
    size: int,
) -> tuple[npt.NDArray[np.int64], npt.NDArray[np.int64]]:
    """Fill a short batch out to the compiled batch size.

    The filler repeats the last real row with its attention zeroed. The ids are
    then certainly inside this model's vocabulary, and the zero mask means the
    row's output is discarded before post-processing and cannot reach a result.
    """
    missing = size - token_ids.shape[0]
    filler = np.repeat(token_ids[-1:], missing, axis=0)
    return (
        np.concatenate([token_ids, filler]),
        np.concatenate(
            [attention_mask, np.zeros_like(filler, dtype=np.int64)]
        ),
    )


def build_service(
    profile: ModelProfile,
    capability: CapabilityReport,
    root: Path,
    *,
    provider: ProviderChoice = ProviderChoice.NPU,
    prepare: ArtifactPreparer = ensure_prepared,
    progress: ProgressCallback | None = None,
) -> EmbeddingService:
    """Assemble tokenization, dense weights and provider factories from artifacts
    under root. Read weights from the artifact for the selected provider.
    """
    artifact = prepare(profile, ProviderChoice(provider), root)
    return EmbeddingService(
        profile=profile,
        capability=capability,
        tokenizer=load_tokenizer(profile, progress=progress),
        backends=default_backend_builder(root, prepare=prepare),
        dense=load_dense_layers(artifact, profile, ProviderChoice(provider)),
    )

"""Compile folder and tag filters for LanceDB.

Folder and tag values are escaped as SQL literals. Folder globs recognize
both path separators. A raw filter remains caller-supplied SQL. Clauses
combine with AND; folder alternatives within one tag combine with OR.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from npu_rag.cli.config import CONFIG_FILENAME, ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

__all__ = [
    "AUTHOR_COLUMN",
    "GLOB_CHARS",
    "LIKE_ESCAPE_CHAR",
    "PATH_COLUMN",
    "PATH_SEPARATORS",
    "EmptyTagError",
    "TagRegistry",
    "UnknownTagError",
]

#: The indexed folder name. `npu_rag.ingest.discover._author` derives it as the
#: first directory component beneath the archive root, so for this folder-first
#: product `author` *is* the folder (design §1 principle 1).
AUTHOR_COLUMN: Final = "author"

#: The absolute source path, stored as `str(Path)` - backslash-separated on
#: Windows. Matching it as a substring is what reaches files in nested
#: subfolders, which an `author` equality cannot.
PATH_COLUMN: Final = "file_path"

# Both column names are spelled as literals rather than imported from
# `npu_rag.index.schema`, which would put `lancedb` and `pydantic` on the
# startup path of every `--help`. A test pins both against `ChunkSchema`.

#: The user's wildcards, translated to SQL's `%` and `_`.
GLOB_CHARS: Final[frozenset[str]] = frozenset("*?")

#: lancedb 0.38.0 supports no other escape character.
LIKE_ESCAPE_CHAR: Final = "\\"

#: Both spellings of a path separator. A user types `Sub/Folder`; Windows
#: stored `Sub\Folder`.
PATH_SEPARATORS: Final[tuple[str, str]] = ("/", "\\")

_DEFAULT_SOURCE: Final = CONFIG_FILENAME


class UnknownTagError(ConfigError):
    """An undefined tag selection. The message lists available tags.
    This is a ConfigError so the CLI reports a usage error.
    """


class EmptyTagError(ConfigError):
    """A `[tags]` entry that names no folder, or a blank one.

    `config._resolve_tags` accepts `alpha = []` as `()` and `alpha = ""` as
    `('',)` without complaint; see `TagRegistry.resolve_tag` for why this is an
    error here rather than a silently-compiled filter.
    """


# --------------------------------------------------------------------------- #
# SQL emission
# --------------------------------------------------------------------------- #


def _sql_literal(text: str) -> str:
    """Quote `text` as an SQL string literal.

    Doubling the quote is not a stylistic choice: probed against lancedb
    0.38.0, `author = 'O\\'Brien'` is rejected by the parser with "Unterminated
    string literal", while `author = 'O''Brien'` selects the row. This is the
    same escape `LanceIndexStore.delete_by_chunk_ids` already uses.
    """
    return "'" + text.replace("'", "''") + "'"


def _like_pattern(spec: str) -> str:
    """Translate a user glob into a SQL `LIKE` pattern.

    One pass, because the two halves interact: `*` and `?` become the SQL
    wildcards, while a `%`, `_` or `\\` the user actually typed becomes a
    literal. Escaping after translating would re-escape the wildcards just
    produced; escaping before would hide the glob characters.
    """
    out: list[str] = []
    for char in spec:
        if char == "*":
            out.append("%")
        elif char == "?":
            out.append("_")
        elif char in ("%", "_", LIKE_ESCAPE_CHAR):
            out.append(LIKE_ESCAPE_CHAR + char)
        else:
            out.append(char)
    return "".join(out)


def _like_clause(column: str, pattern: str) -> str:
    return (
        f"{column} LIKE {_sql_literal(pattern)} "
        f"ESCAPE {_sql_literal(LIKE_ESCAPE_CHAR)}"
    )


def _has_separator(spec: str) -> bool:
    return any(separator in spec for separator in PATH_SEPARATORS)


def _path_clauses(spec: str) -> list[str]:
    """Build escaped file_path predicates for both separator spellings.
    Translate folder globs to LIKE patterns while escaping literal SQL
    wildcards and matching path-component boundaries.
    """
    clauses: list[str] = []
    for separator in PATH_SEPARATORS:
        normalized = spec.replace("\\", separator).replace("/", separator)
        pattern = f"%{_like_pattern(normalized)}{_like_pattern(separator)}%"
        clauses.append(_like_clause(PATH_COLUMN, pattern))
    return clauses


def _folder_clause(spec: str) -> str:
    """Select a folder label, nested path or glob.
    Bare names can match author; nested paths use file_path because author
    contains only the first component below the archive root.
    """
    terms: list[str] = []
    if not _has_separator(spec):
        if GLOB_CHARS & set(spec):
            terms.append(_like_clause(AUTHOR_COLUMN, _like_pattern(spec)))
        else:
            terms.append(f"{AUTHOR_COLUMN} = {_sql_literal(spec)}")
    terms.extend(_path_clauses(spec))
    return "(" + " OR ".join(terms) + ")"


def _require_value(raw: str, *, origin: str, expected: str) -> str:
    """Reject a blank value instead of silently dropping the flag.

    Design §3.2 guards with `if folder:`, which makes `--folder ""` a no-op:
    the user asked for a scope, got none, and nothing said so. `config.py`'s
    coercers already take the opposite line ("is empty; expected a filesystem
    path"), and this follows them.
    """
    text = raw.strip()
    if not text:
        raise ConfigError(f"{origin} is empty; expected {expected}.")
    return text


# --------------------------------------------------------------------------- #
# The registry
# --------------------------------------------------------------------------- #


class TagRegistry:
    """Copy a tag-to-folder mapping and compile its pushdown filters."""

    def __init__(
        self, tags: Mapping[str, Sequence[str]], *, source: str = _DEFAULT_SOURCE
    ) -> None:
        self._tags: dict[str, tuple[str, ...]] = {
            str(name): tuple(folders) for name, folders in tags.items()
        }
        self._source = source

    @property
    def tags(self) -> dict[str, tuple[str, ...]]:
        """Return all configured tag entries, including invalid entries for diagnostics."""
        return dict(self._tags)

    def tag_names(self) -> tuple[str, ...]:
        """Every configured tag, sorted.

        Sorted rather than in TOML order: the order of keys in a hand-written
        table carries no meaning, and a listing the user has to scan should be
        scannable. Folder order *inside* a tag is the author's and is preserved.
        """
        return tuple(sorted(self._tags))

    def resolve_tag(self, tag_name: str) -> tuple[str, ...]:
        """Return folder alternatives for a defined, nonempty tag.
        Raise UnknownTagError for missing tags and EmptyTagError for unusable
        expansions.
        """
        name = tag_name.strip()
        if not name:
            raise ConfigError(
                f"command-line option --tag is empty; expected a tag name. "
                f"{self._available_sentence()}"
            )
        if name not in self._tags:
            raise UnknownTagError(
                f"{self._source}: unknown tag {name!r}. {self._available_sentence()}"
            )

        folders = self._tags[name]
        if not folders:
            raise EmptyTagError(
                f"{self._source}: [tags] entry {name!r} lists no folders; a tag "
                f"must name at least one folder, or be removed."
            )
        for position, folder in enumerate(folders, start=1):
            if not folder.strip():
                raise EmptyTagError(
                    f"{self._source}: [tags] entry {name!r} has a blank folder "
                    f"name at position {position}; every entry must name a "
                    f"folder. A blank name would scope the search to every "
                    f"document instead of narrowing it."
                )
        return tuple(folder.strip() for folder in folders)

    def resolve_tags(self, tag_names: Sequence[str]) -> tuple[str, ...]:
        """The union of several tags' folders, de-duplicated.

        First-seen order is kept, so the expansion of `--tag a,b` reads in the
        order the user asked for. De-duplication matters because requirement
        3.2 is explicitly many-to-many: two tags sharing a folder would
        otherwise emit that folder's clause twice.
        """
        seen: dict[str, None] = {}
        for name in tag_names:
            for folder in self.resolve_tag(name):
                seen.setdefault(folder, None)
        return tuple(seen)

    def build_filter_sql(
        self,
        *,
        folder: str | None = None,
        tags: Sequence[str] | None = None,
        custom_filter: str | None = None,
    ) -> str | None:
        """Combine folder, tag and raw predicates with AND.
        Combine alternatives within a tag with OR. Escape folder/tag values;
        retain the caller raw predicate as SQL.
        """
        predicates: list[str] = []

        if folder is not None:
            predicates.append(
                _folder_clause(
                    _require_value(
                        folder,
                        origin="command-line option --folder",
                        expected="a folder name, relative subfolder, or glob pattern",
                    )
                )
            )

        if tags:
            expansion = " OR ".join(_folder_clause(spec) for spec in self.resolve_tags(tags))
            predicates.append(f"({expansion})")

        if custom_filter is not None:
            predicates.append(
                "("
                + _require_value(
                    custom_filter,
                    origin="command-line option --filter",
                    expected="an SQL WHERE expression",
                )
                + ")"
            )

        if not predicates:
            return None
        return " AND ".join(predicates)

    def _available_sentence(self) -> str:
        """Requirement 3.4's "listing all available tags", or why there are none."""
        if not self._tags:
            return (
                f"No tags are configured: add a [tags] table to {self._source}, "
                f'for example  research = ["Folder A", "Folder B"].'
            )
        listed = ", ".join(repr(name) for name in self.tag_names())
        return f"Available tags: {listed}."

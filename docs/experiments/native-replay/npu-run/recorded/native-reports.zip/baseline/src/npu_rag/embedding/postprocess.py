"""Convert token embeddings to normalized sentence vectors.

Apply the profile pooling rule, ordered dense projections and L2 normalization
in float32. Matryoshka truncation requires a second normalization. All backends
share this implementation.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Final

import numpy as np
import numpy.typing as npt

from npu_rag.embedding.errors import ExecutionError
from npu_rag.embedding.types import ProviderChoice

__all__ = [
    "POOLING_RULES",
    "POSTPROCESS_STAGE",
    "SUPPORTED_ACTIVATIONS",
    "DenseLayer",
    "apply_dense_stages",
    "cls_pool",
    "dense_layers_from_arrays",
    "finalize",
    "l2_normalize",
    "masked_mean_pool",
    "pool",
]

#: The stage every failure here reports (8.1). Named for the phase of the
#: embedding flow rather than for this file, because that is what an operator
#: reading a traceback is trying to locate.
POSTPROCESS_STAGE: Final = "postprocess"

#: Supported pooling rules; tests keep this set consistent with ModelProfile.
POOLING_RULES: Final[frozenset[str]] = frozenset({"mean", "cls"})


def _identity(values: npt.NDArray[np.float32]) -> npt.NDArray[np.float32]:
    return values


def _relu(values: npt.NDArray[np.float32]) -> npt.NDArray[np.float32]:
    return np.maximum(values, np.zeros((), dtype=np.float32))


def _tanh(values: npt.NDArray[np.float32]) -> npt.NDArray[np.float32]:
    return np.tanh(values, dtype=np.float32)


#: Exact dense activations keyed by lowercase class name. Unsupported
#: activations raise rather than using an approximation or identity.
SUPPORTED_ACTIVATIONS: Final[
    Mapping[str, Callable[[npt.NDArray[np.float32]], npt.NDArray[np.float32]]]
] = {
    "identity": _identity,
    "linear": _identity,
    "relu": _relu,
    "tanh": _tanh,
}


@dataclass(frozen=True)
class DenseLayer:
    """One ordered dense projection.
    Weights use (out_features, in_features); the postprocessor accepts arrays
    without importing the model exporter.
    """

    name: str
    weight: npt.NDArray[np.float32]
    bias: npt.NDArray[np.float32] | None
    activation: str


def _fail(
    message: str,
    *,
    provider: ProviderChoice | None,
    model_id: str | None,
) -> ExecutionError:
    return ExecutionError(
        message,
        provider=provider,
        model_id=model_id,
        stage=POSTPROCESS_STAGE,
    )


def _float32_matrix(
    values: npt.NDArray[Any],
    *,
    what: str,
    provider: ProviderChoice | None,
    model_id: str | None,
) -> npt.NDArray[np.float32]:
    """A two-dimensional float32 array, or a diagnosed failure."""
    if values.ndim != 2:
        raise _fail(
            f"{what} is {values.ndim}-dimensional; post-processing works on "
            f"(batch, width) matrices",
            provider=provider,
            model_id=model_id,
        )
    if values.dtype != np.float32:
        raise _fail(
            f"{what} carries {values.dtype} values, not float32. The backends "
            "return float32 and the whole post-processing path stays there, so "
            "a different precision here would be a cast nobody asked for",
            provider=provider,
            model_id=model_id,
        )
    return values


def masked_mean_pool(
    token_embeddings: npt.NDArray[np.float32],
    attention_mask: npt.NDArray[Any],
    *,
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> npt.NDArray[np.float32]:
    """Mean-pool attended tokens from (batch, sequence, hidden) embeddings.
    Validate mask shape and nonempty rows. Exclude masked positions before
    reduction so padding NaNs cannot contaminate the result.
    """
    if token_embeddings.ndim != 3:
        raise _fail(
            f"token embeddings are {token_embeddings.ndim}-dimensional; the "
            "backend contract is (batch, sequence, hidden)",
            provider=provider,
            model_id=model_id,
        )
    if token_embeddings.dtype != np.float32:
        raise _fail(
            f"token embeddings carry {token_embeddings.dtype} values, not "
            "float32, which is what every backend returns",
            provider=provider,
            model_id=model_id,
        )
    mask = np.asarray(attention_mask)
    if mask.ndim != 2:
        raise _fail(
            f"the attention mask is {mask.ndim}-dimensional; it is "
            "(batch, sequence), one flag per position",
            provider=provider,
            model_id=model_id,
        )
    if mask.shape != token_embeddings.shape[:2]:
        raise _fail(
            f"the attention mask is shaped {tuple(mask.shape)} but the token "
            f"embeddings are {tuple(token_embeddings.shape)}; a mask that does "
            "not line up would pool the wrong positions rather than fail",
            provider=provider,
            model_id=model_id,
        )
    if not bool(np.all((mask == 0) | (mask == 1))):
        raise _fail(
            "the attention mask carries values other than 0 and 1, so it is "
            "not a statement about which positions were attended; a weighted "
            "mask would change the pooling rule without changing any shape",
            provider=provider,
            model_id=model_id,
        )

    attended = mask.astype(bool)
    counts = attended.sum(axis=1)
    empty = np.flatnonzero(counts == 0)
    if empty.size:
        raise _fail(
            f"rows {empty.tolist()} attend no positions at all, so they have "
            "no mean. Dividing by zero would put NaN in the index and "
            "substituting a zero vector would put a direction there that no "
            "text produced",
            provider=provider,
            model_id=model_id,
        )

    selected = np.where(
        attended[:, :, None], token_embeddings, np.zeros((), dtype=np.float32)
    )
    totals = selected.sum(axis=1, dtype=np.float32)
    pooled: npt.NDArray[np.float32] = (
        totals / counts[:, None].astype(np.float32)
    ).astype(np.float32, copy=False)
    return pooled


def cls_pool(
    token_embeddings: npt.NDArray[np.float32],
    *,
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> npt.NDArray[np.float32]:
    """Select the first token vector in each row.
    Validate the corresponding mask entry; ignored padding positions must
    not affect the selected output.
    """
    if token_embeddings.ndim != 3:
        raise _fail(
            f"token embeddings are {token_embeddings.ndim}-dimensional; the "
            "backend contract is (batch, sequence, hidden)",
            provider=provider,
            model_id=model_id,
        )
    if token_embeddings.dtype != np.float32:
        raise _fail(
            f"token embeddings carry {token_embeddings.dtype} values, not "
            "float32, which is what every backend returns",
            provider=provider,
            model_id=model_id,
        )
    if token_embeddings.shape[1] == 0:
        raise _fail(
            "the sequence dimension is empty, so there is no first position to "
            "pool. A CLS model's vector is that position and nothing else, so "
            "there is no fallback that would mean anything",
            provider=provider,
            model_id=model_id,
        )

    # A copy, not the view ``token_embeddings[:, 0, :]`` would be: every other
    # function here hands back an array the caller does not already own, and a
    # view would alias the backend's output buffer.
    pooled: npt.NDArray[np.float32] = np.array(
        token_embeddings[:, 0, :], dtype=np.float32, copy=True
    )
    return pooled


def pool(
    token_embeddings: npt.NDArray[np.float32],
    attention_mask: npt.NDArray[Any],
    *,
    rule: str,
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> npt.NDArray[np.float32]:
    """Apply the declared pooling rule and return one vector per batch row."""
    if rule == "mean":
        return masked_mean_pool(
            token_embeddings,
            attention_mask,
            provider=provider,
            model_id=model_id,
        )
    if rule == "cls":
        return cls_pool(
            token_embeddings, provider=provider, model_id=model_id
        )
    raise _fail(
        f"the active model declares {rule!r} pooling, which this runtime does "
        "not implement. It is refused rather than pooled by some other rule: "
        "every rule here produces a vector of the same width carrying the same "
        "norm, so a substituted one would be undetectable downstream and would "
        f"only ever surface as poor retrieval. Known: {sorted(POOLING_RULES)}",
        provider=provider,
        model_id=model_id,
    )


def _activation_of(
    layer: DenseLayer,
    *,
    provider: ProviderChoice | None,
    model_id: str | None,
) -> Callable[[npt.NDArray[np.float32]], npt.NDArray[np.float32]]:
    key = layer.activation.rsplit(".", 1)[-1].strip().lower()
    function = SUPPORTED_ACTIVATIONS.get(key)
    if function is None:
        raise _fail(
            f"dense stage {layer.name!r} declares the activation "
            f"{layer.activation!r}, which this runtime does not compute. It is "
            "refused rather than treated as the identity or approximated: "
            "either would produce vectors of the right width and the right "
            f"norm that mean something else. Known: "
            f"{sorted(SUPPORTED_ACTIVATIONS)}",
            provider=provider,
            model_id=model_id,
        )
    return function


def apply_dense_stages(
    vectors: npt.NDArray[np.float32],
    stages: Sequence[DenseLayer],
    *,
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> npt.NDArray[np.float32]:
    """Apply dense projections and activations in the supplied pipeline order."""
    current = np.array(
        _float32_matrix(
            vectors,
            what="the pooled vectors",
            provider=provider,
            model_id=model_id,
        ),
        dtype=np.float32,
        copy=True,
    )

    for layer in stages:
        weight = _float32_matrix(
            layer.weight,
            what=f"the weight of dense stage {layer.name!r}",
            provider=provider,
            model_id=model_id,
        )
        if weight.shape[1] != current.shape[1]:
            raise _fail(
                f"dense stage {layer.name!r} consumes {weight.shape[1]} "
                f"features but is being given {current.shape[1]}. The stages "
                "must be applied in the recorded pipeline order; two "
                "projections that chain in both directions each look plausible "
                "alone, and the wrong order is the same shape and the same norm "
                "carrying a different meaning",
                provider=provider,
                model_id=model_id,
            )

        projected = current @ weight.T
        if layer.bias is not None:
            bias = layer.bias
            if bias.dtype != np.float32:
                raise _fail(
                    f"the bias of dense stage {layer.name!r} carries "
                    f"{bias.dtype} values, not float32",
                    provider=provider,
                    model_id=model_id,
                )
            if bias.shape != (weight.shape[0],):
                raise _fail(
                    f"the bias of dense stage {layer.name!r} is shaped "
                    f"{tuple(bias.shape)}, which does not match its "
                    f"{weight.shape[0]} outputs",
                    provider=provider,
                    model_id=model_id,
                )
            projected = projected + bias

        activation = _activation_of(
            layer, provider=provider, model_id=model_id
        )
        current = activation(projected.astype(np.float32, copy=False)).astype(
            np.float32, copy=False
        )

    return current


def l2_normalize(
    vectors: npt.NDArray[np.float32],
    *,
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> npt.NDArray[np.float32]:
    """Normalize each finite, nonzero row to unit length in float32.
    Reject invalid rows so cosine similarity remains equivalent to dot product.
    """
    matrix = _float32_matrix(
        vectors,
        what="the vectors to normalize",
        provider=provider,
        model_id=model_id,
    )
    lengths = np.sqrt(np.square(matrix, dtype=np.float64).sum(axis=1))
    unusable = np.flatnonzero(~(lengths > 0.0))
    if unusable.size:
        raise _fail(
            f"rows {unusable.tolist()} have no length to normalize by, so they "
            "have no direction either. A zero or non-finite vector cannot be "
            "made unit-norm, and passing it on would break the equivalence of "
            "cosine and dot-product similarity that requirement 3.5 exists to "
            "guarantee",
            provider=provider,
            model_id=model_id,
        )
    scaled: npt.NDArray[np.float32] = (matrix / lengths[:, None]).astype(
        np.float32, copy=False
    )
    return scaled


def finalize(
    token_embeddings: npt.NDArray[np.float32],
    attention_mask: npt.NDArray[Any],
    *,
    pooling: str,
    dense: Sequence[DenseLayer] = (),
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> npt.NDArray[np.float32]:
    """Pool token embeddings, apply ordered dense stages and normalize.
    If dimension truncation is requested, slice after projection and normalize
    again. Return one float32 unit vector per input row.
    """
    pooled = pool(
        token_embeddings,
        attention_mask,
        rule=pooling,
        provider=provider,
        model_id=model_id,
    )
    projected = apply_dense_stages(
        pooled, dense, provider=provider, model_id=model_id
    )
    return l2_normalize(projected, provider=provider, model_id=model_id)


def _one_string(
    value: npt.NDArray[Any],
    *,
    what: str,
    provider: ProviderChoice | None,
    model_id: str | None,
) -> str:
    flat = np.asarray(value).ravel()
    if flat.size != 1:
        raise _fail(
            f"{what} holds {flat.size} values where exactly one was expected",
            provider=provider,
            model_id=model_id,
        )
    return str(flat[0])


def dense_layers_from_arrays(
    arrays: Mapping[str, npt.NDArray[Any]],
    *,
    order_key: str,
    weight_prefix: str,
    bias_prefix: str,
    activation_prefix: str,
    provider: ProviderChoice | None = None,
    model_id: str | None = None,
) -> tuple[DenseLayer, ...]:
    """Read ordered dense stages from NPZ arrays.
    The caller supplies exporter key names to keep serialization details
    outside the postprocessing layer.
    """
    if order_key not in arrays:
        raise _fail(
            f"the dense weights carry no {order_key!r} entry, so the pipeline "
            "order is unknown. It is not recoverable by sorting the weight "
            "names: the stages chain in both directions, and applying them "
            "backwards changes neither the width nor the norm of the result",
            provider=provider,
            model_id=model_id,
        )

    order = [
        str(name) for name in np.asarray(arrays[order_key]).ravel().tolist()
    ]
    layers: list[DenseLayer] = []
    for name in order:
        weight_key = f"{weight_prefix}{name}"
        if weight_key not in arrays:
            raise _fail(
                f"the pipeline order names a dense stage {name!r} whose "
                f"weights ({weight_key!r}) are not in the file",
                provider=provider,
                model_id=model_id,
            )
        activation_key = f"{activation_prefix}{name}"
        if activation_key not in arrays:
            raise _fail(
                f"dense stage {name!r} records no activation. It is refused "
                "rather than assumed to be the identity, because a stage whose "
                "activation is guessed wrong produces the right width and the "
                "right norm and the wrong meaning",
                provider=provider,
                model_id=model_id,
            )
        bias = arrays.get(f"{bias_prefix}{name}")
        layers.append(
            DenseLayer(
                name=name,
                weight=np.asarray(arrays[weight_key], dtype=np.float32),
                bias=(
                    None if bias is None else np.asarray(bias, dtype=np.float32)
                ),
                activation=_one_string(
                    arrays[activation_key],
                    what=f"the activation of dense stage {name!r}",
                    provider=provider,
                    model_id=model_id,
                ),
            )
        )

    named = set(order)
    unlisted = sorted(
        key[len(weight_prefix) :]
        for key in arrays
        if key.startswith(weight_prefix)
        and key[len(weight_prefix) :] not in named
    )
    if unlisted:
        raise _fail(
            f"the dense weights carry projections {unlisted} that the recorded "
            f"pipeline order does not name. Applying only the listed ones would "
            "drop a stage of the sentence pipeline, which is invisible in the "
            "shape and in the norm of every vector that follows",
            provider=provider,
            model_id=model_id,
        )

    return tuple(layers)

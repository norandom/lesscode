"""Progress callbacks and run summaries for embedding operations.

The library emits data through callbacks and does not configure logging.
A run summary records completed inputs, elapsed time, provider, truncation
and interruption status.
"""

from __future__ import annotations

import math
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from types import TracebackType
from typing import Protocol, Self

from npu_rag.embedding.types import ExecutionMode, ProviderChoice

__all__ = [
    "ProgressCallback",
    "ProgressUpdate",
    "RunSummary",
    "RunTracker",
    "SummaryCallback",
]


# Validate labels before starting a run or building a summary.


def _checked_label(value: str, field: str) -> str:
    """A non-blank label. A blank one renders as an anonymous progress bar."""
    if not value.strip():
        raise ValueError(f"{field} must be a non-blank label, got {value!r}")
    return value


def _checked_count(value: int, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field} must be an int, got {value!r}")
    if value < 0:
        raise ValueError(f"{field} cannot be negative, got {value}")
    return value


def _checked_served(provider: ProviderChoice) -> ProviderChoice:
    """The provider that *actually* served, which is never ``auto``.

    Requirement 2.6 reports the provider that served an operation, and
    ``ProviderChoice.AUTO`` is a request rather than an outcome (types.py). A
    summary saying ``auto`` would report the question back instead of the answer
    - exactly the ambiguity requirement 2 exists to remove.
    """
    if provider is ProviderChoice.AUTO:
        raise ValueError(
            "provider_served names the provider that actually ran; 'auto' is a "
            "request, not an outcome (requirement 2.6) - report npu or cpu"
        )
    return provider


def _require_keys(mapping: Mapping[str, object], *keys: str) -> None:
    missing = [key for key in keys if key not in mapping]
    if missing:
        raise ValueError(f"missing keys: {', '.join(missing)}")


def _int_from(mapping: Mapping[str, object], key: str) -> int:
    value = mapping[key]
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{key} must be an int, got {value!r}")
    return value


def _str_from(mapping: Mapping[str, object], key: str) -> str:
    value = mapping[key]
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a str, got {value!r}")
    return value


def _optional_str_from(mapping: Mapping[str, object], key: str) -> str | None:
    value = mapping[key]
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a str or null, got {value!r}")
    return value


def _float_from(mapping: Mapping[str, object], key: str) -> float:
    value = mapping[key]
    # JSON writes 0.0 back as an int, so an int is a valid float here.
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ValueError(f"{key} must be a number, got {value!r}")
    return float(value)


# --------------------------------------------------------------------------
# Progress
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class ProgressUpdate:
    """Completed and total input counts for one operation.
    Remaining inputs are derived from those counts.
    """

    operation: str
    completed: int
    total: int

    def __post_init__(self) -> None:
        _checked_label(self.operation, "operation")
        _checked_count(self.completed, "completed")
        _checked_count(self.total, "total")
        if self.completed > self.total:
            raise ValueError(
                f"completed ({self.completed}) cannot exceed total "
                f"({self.total}): progress past the end of the batch is a "
                "miscount, not a milestone"
            )

    @property
    def remaining(self) -> int:
        """Inputs still to do (requirement 8.3's second half)."""
        return self.total - self.completed

    def as_mapping(self) -> dict[str, object]:
        """A JSON-serialisable view, for crossing a process boundary (5.6)."""
        return {
            "operation": str(self.operation),
            "completed": int(self.completed),
            "total": int(self.total),
        }

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, object]) -> Self:
        """Rebuild an update received as plain data. Inverse of `as_mapping`."""
        _require_keys(mapping, "operation", "completed", "total")
        return cls(
            operation=_str_from(mapping, "operation"),
            completed=_int_from(mapping, "completed"),
            total=_int_from(mapping, "total"),
        )


class ProgressCallback(Protocol):
    """A positional-only callback accepting one progress observation."""

    def __call__(self, update: ProgressUpdate, /) -> None: ...


# --------------------------------------------------------------------------
# Run summary
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class RunSummary:
    """Completed-run metrics and an optional interruption reason.
    Exactly one summary covers each run, including partial completion.
    """

    operation: str
    provider_served: ProviderChoice
    execution_mode: ExecutionMode
    input_count: int
    completed_count: int
    truncated_count: int
    elapsed_seconds: float
    interruption: str | None
    fallback_reason: str | None = None

    def __post_init__(self) -> None:
        _checked_label(self.operation, "operation")
        _checked_served(self.provider_served)
        _checked_count(self.input_count, "input_count")
        _checked_count(self.completed_count, "completed_count")
        _checked_count(self.truncated_count, "truncated_count")
        if self.elapsed_seconds < 0 or not math.isfinite(self.elapsed_seconds):
            raise ValueError(
                f"elapsed_seconds must be a finite, non-negative number of "
                f"seconds, got {self.elapsed_seconds!r}"
            )
        if self.completed_count > self.input_count:
            raise ValueError(
                f"completed_count ({self.completed_count}) cannot exceed "
                f"input_count ({self.input_count})"
            )
        if self.truncated_count > self.input_count:
            raise ValueError(
                f"truncated_count ({self.truncated_count}) cannot exceed "
                f"input_count ({self.input_count})"
            )
        if self.interruption is None:
            if self.completed_count != self.input_count:
                raise ValueError(
                    f"a run reported as complete must have finished every "
                    f"input, but {self.completed_count} of {self.input_count} "
                    "did: set interruption to say why it stopped (8.4)"
                )
        else:
            _checked_label(self.interruption, "interruption")
        if self.fallback_reason is not None:
            _checked_label(self.fallback_reason, "fallback_reason")
            if self.provider_served is not ProviderChoice.CPU:
                raise ValueError(
                    "fallback_reason explains why the NPU was not used, so the "
                    f"CPU must be what served; got provider_served="
                    f"{self.provider_served.value!r} (requirement 2.5)"
                )

    @property
    def interrupted(self) -> bool:
        """Whether the run stopped before finishing (8.4)."""
        return self.interruption is not None

    def as_mapping(self) -> dict[str, object]:
        """A JSON-serialisable view, symmetric with `ProgressUpdate`."""
        return {
            "operation": str(self.operation),
            "provider_served": self.provider_served.value,
            "execution_mode": self.execution_mode.value,
            "input_count": int(self.input_count),
            "completed_count": int(self.completed_count),
            "truncated_count": int(self.truncated_count),
            "elapsed_seconds": float(self.elapsed_seconds),
            "interruption": self.interruption,
            "fallback_reason": self.fallback_reason,
        }

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, object]) -> Self:
        """Rebuild a summary received as plain data. Inverse of `as_mapping`."""
        _require_keys(
            mapping,
            "operation",
            "provider_served",
            "execution_mode",
            "input_count",
            "completed_count",
            "truncated_count",
            "elapsed_seconds",
            "interruption",
            "fallback_reason",
        )
        return cls(
            operation=_str_from(mapping, "operation"),
            provider_served=ProviderChoice(_str_from(mapping, "provider_served")),
            execution_mode=ExecutionMode(_str_from(mapping, "execution_mode")),
            input_count=_int_from(mapping, "input_count"),
            completed_count=_int_from(mapping, "completed_count"),
            truncated_count=_int_from(mapping, "truncated_count"),
            elapsed_seconds=_float_from(mapping, "elapsed_seconds"),
            interruption=_optional_str_from(mapping, "interruption"),
            fallback_reason=_optional_str_from(mapping, "fallback_reason"),
        )


class SummaryCallback(Protocol):
    """How a caller receives the run summary, however the run ended.

    This is what makes requirement 8.4 reachable: an interrupted run's summary
    has to reach someone who never held the tracker, and the callback the caller
    supplied is the only reference that survives the stack unwinding.
    """

    def __call__(self, summary: RunSummary, /) -> None: ...


# --------------------------------------------------------------------------
# The tracker
# --------------------------------------------------------------------------


def _describe(exc_type: type[BaseException], exc: BaseException | None) -> str:
    """Why the run stopped, in one line, never blank.

    The exception type leads because 8.2's category distinction is carried by
    the type; the message follows when there is one. ``KeyboardInterrupt``
    usually has none, which is why the type alone must already be a valid
    reason.
    """
    detail = str(exc) if exc is not None else ""
    if detail.strip():
        return f"{exc_type.__qualname__}: {detail}"
    return exc_type.__qualname__


class RunTracker:
    """Track a single operation as a context manager.
    Emit progress after completed batches and deliver a final summary on
    normal completion or interruption.
    """

    def __init__(
        self,
        *,
        operation: str,
        provider_served: ProviderChoice,
        execution_mode: ExecutionMode,
        input_count: int,
        progress: ProgressCallback | None = None,
        on_finish: SummaryCallback | None = None,
        fallback_reason: str | None = None,
        clock: Callable[[], float] = time.perf_counter,
    ) -> None:
        self._operation = _checked_label(operation, "operation")
        self._provider_served = _checked_served(provider_served)
        self._execution_mode = execution_mode
        self._input_count = _checked_count(input_count, "input_count")
        # Validate fallback metadata before inference so summary construction
        # cannot replace an exception already propagating from the workload.
        if fallback_reason is not None:
            _checked_label(fallback_reason, "fallback_reason")
            if self._provider_served is not ProviderChoice.CPU:
                raise ValueError(
                    "fallback_reason explains why the NPU was not used, so the "
                    f"CPU must be what served; got provider_served="
                    f"{self._provider_served.value!r} (requirement 2.5)"
                )
        self._fallback_reason = fallback_reason
        self._progress = progress
        self._on_finish = on_finish
        self._clock = clock
        self._completed = 0
        self._truncated = 0
        self._started = clock()
        self._entered = False
        self._result: RunSummary | None = None

    @property
    def completed(self) -> int:
        """Inputs finished so far. Never decreases (the task's Observable)."""
        return self._completed

    @property
    def input_count(self) -> int:
        return self._input_count

    @property
    def result(self) -> RunSummary | None:
        """The summary, once the run has ended; ``None`` while it is running.

        Set before ``on_finish`` is called, so a hostile presentation callback
        cannot cost the caller the record.
        """
        return self._result

    def __enter__(self) -> Self:
        """Start a single-use tracker. Reject re-entry rather than combining runs."""
        if self._entered:
            raise RuntimeError(
                "this RunTracker has already been entered and records a single "
                "run; build a new one per operation rather than reusing it"
            )
        self._entered = True
        self._started = self._clock()
        self._emit()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Deliver the final summary and propagate the original exception.
        Include KeyboardInterrupt and SystemExit in interruption reporting.
        """
        self._result = RunSummary(
            operation=self._operation,
            provider_served=self._provider_served,
            execution_mode=self._execution_mode,
            input_count=self._input_count,
            completed_count=self._completed,
            truncated_count=self._truncated,
            elapsed_seconds=max(0.0, self._clock() - self._started),
            interruption=self._interruption(exc_type, exc),
            fallback_reason=self._fallback_reason,
        )
        if self._on_finish is not None:
            self._on_finish(self._result)
        return None

    def _interruption(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
    ) -> str | None:
        """``None`` only when the run both raised nothing and finished."""
        if exc_type is not None:
            return _describe(exc_type, exc)
        if self._completed != self._input_count:
            return (
                f"ended without an error after {self._completed} of "
                f"{self._input_count} inputs"
            )
        return None

    def advance(self, count: int = 1) -> ProgressUpdate:
        """Record a positive number of completed inputs and emit progress.
        Reject counts that exceed the declared input total.
        """
        if isinstance(count, bool) or not isinstance(count, int):
            raise ValueError(f"count must be an int, got {count!r}")
        if count < 1:
            raise ValueError(
                f"advance must move forward by at least one input, got {count}: "
                "progress never stalls or reverses (requirement 8.3)"
            )
        if self._completed + count > self._input_count:
            raise ValueError(
                f"advancing by {count} would report "
                f"{self._completed + count} of {self._input_count} inputs "
                "completed; a run cannot finish more inputs than it was given"
            )
        self._completed += count
        return self._emit()

    def record_truncated(self, count: int = 1) -> None:
        """Note that ``count`` more inputs were shortened to fit (3.9, 8.6).

                The count is the run-level fact design.md's Monitoring note lists.
                *Which* inputs were truncated is `EmbedResult.truncated_indices`, owned
                by the service, because only the service knows the ordering.

        """
        _checked_count(count, "count")
        if self._truncated + count > self._input_count:
            raise ValueError(
                f"truncating {count} more would report "
                f"{self._truncated + count} of {self._input_count} inputs "
                "truncated; a run cannot truncate more inputs than it was given"
            )
        self._truncated += count

    def _emit(self) -> ProgressUpdate:
        update = ProgressUpdate(
            operation=self._operation,
            completed=self._completed,
            total=self._input_count,
        )
        if self._progress is not None:
            self._progress(update)
        return update

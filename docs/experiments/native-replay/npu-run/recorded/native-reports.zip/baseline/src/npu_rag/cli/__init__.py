"""CLI package. Import commands from their modules to preserve lazy startup."""

from __future__ import annotations

__all__: list[str] = []

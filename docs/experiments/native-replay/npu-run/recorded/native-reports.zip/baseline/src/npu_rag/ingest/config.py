"""Immutable ingestion settings. The caller supplies roots and token budget.

An empty vision_model means no backend is configured. The pipeline does not
select a hosted service or load an implicit OCR model.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

__all__ = ["IngestConfig"]

_DEFAULT_VISION_MODEL = ""
_DEFAULT_STATE_PATH = Path(".npu_rag") / "ingest.sqlite"


@dataclass(frozen=True)
class IngestConfig:
    """Every ingest tunable, validated at construction.

    ``min_image_pixels`` is applied to an image's shorter side. An empty
    ``include`` tuple means include-all; an empty ``exclude`` tuple means
    exclude-none. Discovery interprets those; this object only stores them.
    """

    roots: tuple[Path, ...]
    token_budget: int
    include: tuple[str, ...] = ()
    exclude: tuple[str, ...] = ()
    prose_overlap_tokens: int = 64
    min_page_chars: int = 50
    min_image_pixels: int = 200
    vision_model: str = _DEFAULT_VISION_MODEL
    vision_concurrency: int = 4
    state_path: Path = _DEFAULT_STATE_PATH

    def __post_init__(self) -> None:
        if not self.roots:
            raise ValueError("roots must contain at least one source root")
        if self.token_budget <= 0:
            raise ValueError("token_budget must be positive")
        if self.prose_overlap_tokens >= self.token_budget:
            raise ValueError(
                "prose_overlap_tokens must be less than token_budget"
            )

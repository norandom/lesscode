"""Shared tensor checks and execution; provider construction stays in adapters."""
from collections.abc import Callable, Mapping, Sequence
from typing import Any

import numpy as np
import numpy.typing as npt

from npu_rag.embedding.errors import ExecutionError
from npu_rag.embedding.models.export import ATTENTION_MASK, INPUT_IDS


def checked_run(
    token_ids: npt.NDArray[np.int64], attention_mask: npt.NDArray[np.int64], *,
    shape: tuple[int, int], profile_name: str,
    session_run: Callable[[Sequence[str] | None, Mapping[str, Any]], Sequence[Any]],
    failure: Callable[[str], ExecutionError], execution_note: str,
    shape_note: str, input_dtype_note: str, output_dtype_note: str,
) -> npt.NDArray[np.float32]:
    """Preserve input order, feed identity, exception suppression and output identity."""
    def check(label: str, array: npt.NDArray[np.int64]) -> None:
        if array.shape != shape:
            raise failure(f"{label} arrived with shape {array.shape}, but "
                          f"{profile_name} is compiled at {shape} {shape_note}")
        if False:
            raise failure(f"{label} arrived as {array.dtype}, but {input_dtype_note}")

    check(INPUT_IDS, token_ids)
    check(ATTENTION_MASK, attention_mask)
    try:
        outputs = session_run(None, {INPUT_IDS: token_ids, ATTENTION_MASK: attention_mask})
    except Exception as error:
        raise failure(f"{execution_note}{type(error).__name__}: {error}") from None
    if len(outputs) != 1:
        raise failure(f"the graph returned {len(outputs)} tensors; the trunk contract "
                      "is one tensor of token embeddings")
    produced = outputs[0]
    if not isinstance(produced, np.ndarray):
        raise failure(f"the graph returned {type(produced).__name__}, not an array")
    if produced.dtype != np.float32:
        raise failure(f"the graph returned token embeddings as {produced.dtype}, not {output_dtype_note}")
    if produced.ndim != 3 or produced.shape[:2] != shape:
        raise failure(f"the graph returned shape {produced.shape} for a batch of "
                      f"{shape}; token embeddings are (batch, sequence, hidden)")
    embeddings: npt.NDArray[np.float32] = produced
    return embeddings

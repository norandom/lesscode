"""Run the prepared FP32 ONNX trunk through CPUExecutionProvider.

This backend is the numerical reference for reduced-precision NPU inference.
It validates session inputs and returns token embeddings without pooling.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Final, Protocol

import numpy as np
import numpy.typing as npt

from npu_rag.embedding.providers.checked_run import checked_run
from npu_rag.embedding.errors import EnvironmentError_, ExecutionError
from npu_rag.embedding.models.artifacts import PreparedArtifact
from npu_rag.embedding.models.export import ATTENTION_MASK, INPUT_IDS
from npu_rag.embedding.profiles import ModelProfile
from npu_rag.embedding.types import ExecutionMode, ProviderChoice

__all__ = [
    "CPU_PROVIDER",
    "SESSION_STAGE",
    "CpuBackend",
    "Session",
    "SessionFactory",
    "available_providers",
    "build_session",
]

#: ONNX Runtime's built-in provider - the one every installation has, and the
#: one the runtime silently falls back to when a requested provider is absent.
CPU_PROVIDER: Final = "CPUExecutionProvider"

#: The stage a failure to obtain a usable session belongs to. errors.py
#: documents four preparation stages and leaves ``stage`` a free-form string;
#: this one is on the execution side of that line - the artifact is already
#: prepared - but it is not a failure *of the graph*, and telling an operator
#: which of the two happened is the whole point of requirement 8.1.
SESSION_STAGE: Final = "session"


# --------------------------------------------------------------------------
# The seam
# --------------------------------------------------------------------------


class Session(Protocol):
    """An ONNX Runtime session, narrowed to what this adapter is allowed to use.

    Two members, and the absence of a third matters: there is no hook here for
    session options, so no code path through this module can set one. The
    default session is a full-precision session, and that is the property
    requirement 6.3 rests on.
    """

    def get_providers(self) -> Sequence[str]:
        """The providers this session actually holds, best first."""
        ...

    def run(
        self,
        output_names: Sequence[str] | None,
        input_feed: Mapping[str, Any],
        /,
    ) -> Sequence[Any]:
        """Execute the graph over one feed."""
        ...


class SessionFactory(Protocol):
    """Builds one session for one graph on one provider list.

    A seam for the same reason acquisition, export and compilation have one: the
    refusal branches below - a session that came back on another provider, a
    session that will not build at all - cannot be reached with a real runtime,
    because a real runtime cannot be asked to misbehave on demand.
    """

    def __call__(
        self, model_path: Path, providers: Sequence[str], /
    ) -> Session: ...


def available_providers() -> tuple[str, ...]:
    """Which execution providers this interpreter's runtime actually offers.

    design.md's guard one. It is a module-level function rather than an inline
    import so a test can substitute it, which is the only way to reach the
    branch below on a machine whose runtime is intact.
    """
    # ``onnxruntime`` ships no annotations, so strict mode sees an untyped
    # import; the ignore is scoped to this line. The import is inside the
    # function so this module - and therefore the package - imports in an
    # environment that has never seen the vendor wheels.
    import onnxruntime as ort  # type: ignore[import-untyped]

    return tuple(str(name) for name in ort.get_available_providers())


def build_session(model_path: Path, providers: Sequence[str], /) -> Session:
    """The real `SessionFactory`: a default, full-precision session.

    No ``SessionOptions`` is constructed and no session configuration entry is
    set. That is not an omission - it is the reference path, and every knob that
    exists here would change the numbers requirement 6.3 compares against.
    """
    # The untyped-import ignore sits on the first of these two imports, in
    # `available_providers`; mypy reports one per module, so repeating it here
    # would itself be an error under `warn_unused_ignores`.
    import onnxruntime as ort

    session: Session = ort.InferenceSession(
        str(model_path), providers=list(providers)
    )
    return session


# --------------------------------------------------------------------------
# The adapter
# --------------------------------------------------------------------------


class CpuBackend:
    """Runs a prepared graph on the CPU at full precision (2.3, 6.3).

    The graph is the artifact's ``model.onnx`` - the FP32 trunk - never the
    compiled snapshot beside it in an NPU artifact, which is a different
    provider's build of a different thing.
    """

    def __init__(
        self,
        artifact: PreparedArtifact,
        profile: ModelProfile,
        *,
        session_factory: SessionFactory | None = None,
    ) -> None:
        self._profile = profile
        self._graph = artifact.onnx_path
        self._shape = (profile.batch_size, profile.compiled_seq_len)
        self._session = self._open(
            session_factory if session_factory is not None else build_session
        )

    # -- the contract ------------------------------------------------------

    @property
    def provider(self) -> ProviderChoice:
        """The CPU - and it is reported because the CPU served, not because it
        was requested; the constructor read the session back to find out."""
        return ProviderChoice.CPU

    @property
    def execution_mode(self) -> ExecutionMode:
        """This interpreter. The isolated worker exists for the vendor runtime
        (requirement 5.1); the CPU provider is here in every environment."""
        return ExecutionMode.IN_PROCESS

    @property
    def npu_partition_share(self) -> float | None:
        """Return None because CPU inference has no NPU partition."""
        return None

    def run(
        self, token_ids: npt.NDArray[np.int64], attention_mask: npt.NDArray[np.int64],
    ) -> npt.NDArray[np.float32]:
        """Validate and execute one batch through the provider-neutral operation."""
        return checked_run(
            token_ids, attention_mask, shape=self._shape, profile_name=self._profile.name,
            session_run=self._session.run, failure=self._failed,
            execution_note=(f"running {self._profile.name} over a batch of "
                            f"{self._shape[0]} x {self._shape[1]} failed: "),
            shape_note=(
                '(batch x sequence). A partial batch is padded by the caller, because static shapes'
                ' are what make the same batch runnable on either provider'),
            input_dtype_note=(
                'the graph declares it as int64. Casting it here would hide a tokenizer that is '
                'producing the wrong type'),
            output_dtype_note=(
                'float32. This backend is the full-precision reference the benchmark compares '
                'reduced-precision execution against, so a narrower type here would leave that '
                'comparison measuring nothing'),
        )

    # -- getting a session, and proving it is the right one -----------------

    def _open(self, build: SessionFactory) -> Session:
        """Guard one, then build, then guard two. In that order, for a reason:
        a session built on an unregistered provider comes back looking healthy,
        so the pre-check must happen while there is still nothing to inspect."""
        registered = available_providers()
        if CPU_PROVIDER not in registered:
            raise EnvironmentError_(
                f"{CPU_PROVIDER} is not registered in this interpreter, so "
                f"nothing here can execute {self._profile.model_id}. Available "
                f"providers: {', '.join(registered) or 'none'}. That provider "
                "is built into every ONNX Runtime build, so its absence means "
                "the installed runtime is incomplete rather than that this "
                "model cannot run",
                provider=ProviderChoice.CPU,
                model_id=self._profile.model_id,
            )

        try:
            session = build(self._graph, (CPU_PROVIDER,))
        except Exception as error:
            raise ExecutionError(
                f"opening {self._graph.name} for {self._profile.model_id} on "
                f"{CPU_PROVIDER} failed: {type(error).__name__}: {error}",
                provider=ProviderChoice.CPU,
                model_id=self._profile.model_id,
                stage=SESSION_STAGE,
            ) from None

        served = tuple(str(name) for name in session.get_providers())
        if not served or served[0] != CPU_PROVIDER:
            raise ExecutionError(
                f"a session was requested on {CPU_PROVIDER} and came back on "
                f"{', '.join(served) or 'no provider at all'}. Requesting a "
                "provider the runtime does not have succeeds and runs the graph "
                "somewhere else, so what came back is read rather than assumed: "
                "this backend reports the provider that ran",
                provider=ProviderChoice.CPU,
                model_id=self._profile.model_id,
                stage=SESSION_STAGE,
            )
        return session

    # -- what goes in, and what comes back ----------------------------------



    def _failed(self, message: str, *, stage: str | None = None) -> ExecutionError:
        """One execution failure, carrying requirement 8.1's three facts."""
        return ExecutionError(
            message,
            provider=ProviderChoice.CPU,
            model_id=self._profile.model_id,
            stage=stage,
        )

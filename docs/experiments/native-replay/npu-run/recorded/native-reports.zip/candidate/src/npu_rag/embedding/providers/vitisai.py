"""Run a compiled EP context through VitisAIExecutionProvider.

Check provider registration, session provider selection and graph partition
share. The node count cannot detect CPU fallback inside the EP context;
independent timing and hardware telemetry are required to establish offload.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any, Final, Protocol

import numpy as np
import numpy.typing as npt

from npu_rag.embedding.environment.capability import (
    VITISAI_PROVIDER,
    probe_onnx_runtime,
)
from npu_rag.embedding.providers.checked_run import checked_run
from npu_rag.embedding.errors import (
    EnvironmentError_,
    ExecutionError,
    PartitionShareTooLow,
)
from npu_rag.embedding.models.artifacts import CONTEXT_FILENAME, PreparedArtifact
from npu_rag.embedding.models.export import ATTENTION_MASK, INPUT_IDS
from npu_rag.embedding.profiles import ModelProfile
from npu_rag.embedding.types import ExecutionMode, ProviderChoice

__all__ = [
    "EP_CONTEXT_OP",
    "MINIMUM_PARTITION_SHARE",
    "SESSION_STAGE",
    "VITISAI_PROVIDER",
    "NpuSession",
    "NpuSessionFactory",
    "PartitionReader",
    "VitisAIBackend",
    "build_npu_session",
    "npu_provider_registered",
    "read_node_partition_share",
]

#: The op type ONNX Runtime writes into an EP-context snapshot for the subgraph
#: the compiler offloaded. Its presence - at least one such node - is the
#: minimum evidence that anything was compiled to the NPU at all.
EP_CONTEXT_OP: Final = "EPContext"

#: Require at least half the original nodes to be offloaded.
#: Shape and indexing glue may remain on CPU. The node estimate cannot
#: detect CPU work hidden inside an EPContext.
MINIMUM_PARTITION_SHARE: Final = 0.5

#: The stage a failure to obtain a usable NPU session belongs to (8.1). The
#: artifact is already prepared, so this is on the execution side of the line;
#: partition verification proper reports errors.py's ``verify`` stage through
#: `PartitionShareTooLow`.
SESSION_STAGE: Final = "session"

#: ONNX Runtime's built-in provider, the one a session silently falls back to
#: when the requested provider is absent. Named so guard two can tell "the NPU
#: served" from "the CPU served while the session claimed the NPU".
_CPU_PROVIDER: Final = "CPUExecutionProvider"

#: The Vitis AI ``config_file`` provider option resolves here on a provisioned
#: machine. It is what switches the device data type to
#: bfloat16, so a session built without it does not engage the NLP flow this
#: feature needs.
_VAIP_CONFIG_RELATIVE: Final = ("capi", "vaip_config.json")


# --------------------------------------------------------------------------
# The session seam
# --------------------------------------------------------------------------


class NpuSession(Protocol):
    """An ONNX Runtime session, narrowed to what this adapter uses.

    Two members, the same pair the CPU adapter's `Session` exposes. The
    difference is entirely in the *factory* below, which - unlike the CPU one -
    can express ``provider_options``, because that is where reduced-precision
    targeting is supplied.
    """

    def get_providers(self) -> Sequence[str]:
        """The providers this session actually holds, best first."""
        ...

    def run(
        self,
        output_names: Sequence[str] | None,
        input_feed: Mapping[str, Any],
        /,
    ) -> Sequence[Any]:
        """Execute the graph over one feed."""
        ...


class NpuSessionFactory(Protocol):
    """Construct a VitisAI session over a compiled context with an optional
    BF16 configuration path.
    """

    def __call__(
        self, model_path: Path, *, config_file: Path | None
    ) -> NpuSession: ...


def npu_provider_registered() -> bool:
    """Guard one, reusing ``environment/capability.py``'s probe.

    A module-level function so a test can substitute it - the only way to reach
    the guard's failure branch on a machine whose runtime is intact. The probe
    imports ONNX Runtime lazily and never raises, so this module stays importable
    where the vendor wheels are absent.
    """
    return probe_onnx_runtime().registers


def build_npu_session(
    model_path: Path, *, config_file: Path | None
) -> NpuSession:
    """Open an EP context with its matching BF16 config.
    Pass no cache_key: contexts embed their compilation key, and a mismatched
    key can abort the process. ORT resolves the binary sidecar relative to
    the context file.
    """
    # ``onnxruntime`` ships no annotations, so strict mode sees an untyped
    # import; the ignore is scoped to this line. The import is inside the
    # function so this module - and the package - imports where the vendor wheels
    # have never been installed.
    import onnxruntime as ort  # type: ignore[import-untyped]

    resolved = (
        config_file
        if config_file is not None
        else Path(ort.__file__).parent.joinpath(*_VAIP_CONFIG_RELATIVE)
    )
    if not resolved.is_file():
        raise FileNotFoundError(
            f"the Vitis AI configuration file {resolved} is missing; it is the "
            "config_file provider option that switches the device data type to "
            "bfloat16"
        )
    session: NpuSession = ort.InferenceSession(
        str(model_path),
        providers=[VITISAI_PROVIDER],
        provider_options=[{"config_file": str(resolved)}],
    )
    return session


# --------------------------------------------------------------------------
# The node-mix partition metric
# --------------------------------------------------------------------------


class PartitionReader(Protocol):
    """Reads the offload share from a compiled snapshot and its trunk."""

    def __call__(
        self, *, context_path: Path, model_path: Path
    ) -> float | None: ...


def read_node_partition_share(
    *, context_path: Path, model_path: Path
) -> float | None:
    """Estimate offload as clamp01((original_nodes - residue_nodes) / original_nodes).
    Return None for unreadable graphs or missing EPContext nodes. This estimate
    cannot detect CPU work inside the compiled context.
    """
    context_ops = _op_counts(context_path)
    if context_ops is None:
        return None
    if context_ops.get(EP_CONTEXT_OP, 0) < 1:
        # No EPContext node means the compiler offloaded nothing - the snapshot
        # is not a verified NPU build, whatever else it contains. This is the
        # unverifiable case, never "100% offloaded".
        return None
    residue = sum(
        count for op, count in context_ops.items() if op != EP_CONTEXT_OP
    )
    original = _node_total(model_path)
    if original is None or original <= 0:
        return None
    share = (original - residue) / original
    if share < 0.0:
        return 0.0
    if share > 1.0:
        return 1.0
    return share


def _op_counts(path: Path) -> dict[str, int] | None:
    """Every op type in the graph at ``path`` and how often it occurs, or `None`."""
    graph = _load_graph(path)
    if graph is None:
        return None
    counts: dict[str, int] = {}
    for node in graph.node:
        counts[node.op_type] = counts.get(node.op_type, 0) + 1
    return counts


def _node_total(path: Path) -> int | None:
    """The number of nodes in the graph at ``path``, or `None` if unreadable."""
    graph = _load_graph(path)
    return None if graph is None else len(graph.node)


def _load_graph(path: Path) -> Any | None:
    """Load graph metadata without external weights.
    Inline weights still count toward protobuf parsing cost, including the
    1.22 GB EmbeddingGemma 300m export.
    """
    # ``onnx`` is a default dependency and safe at module scope; it is imported
    # here to keep the graph-reading concern in one place.
    import onnx

    try:
        return onnx.load(str(path), load_external_data=False).graph
    except Exception:  # noqa: BLE001 - an absent or corrupt graph is data, not a raise
        return None


# --------------------------------------------------------------------------
# The adapter
# --------------------------------------------------------------------------


class VitisAIBackend:
    """Runs a compiled snapshot on the NPU, with partition verification (2.2, 2.6).

    Constructed once per operation with the selection that produced it: an
    explicit ``npu`` request makes below-threshold or unverifiable partitioning a
    failure, while ``auto`` records the weakness and proceeds. The two verdicts
    on the identical graph are what make the provider-choice policy observable.
    """

    def __init__(
        self,
        artifact: PreparedArtifact,
        profile: ModelProfile,
        requested: ProviderChoice,
        *,
        session_factory: NpuSessionFactory | None = None,
        config_file: Path | None = None,
        partition_reader: PartitionReader | None = None,
        provider_probe: Callable[[], bool] | None = None,
    ) -> None:
        self._profile = profile
        self._requested = _npu_or_auto(requested, profile)
        self._config_file = config_file
        self._context = _require_context(artifact, profile)
        self._model = artifact.onnx_path
        self._shape = (profile.batch_size, profile.compiled_seq_len)
        probe = provider_probe if provider_probe is not None else npu_provider_registered
        build = session_factory if session_factory is not None else build_npu_session
        read = (
            partition_reader
            if partition_reader is not None
            else read_node_partition_share
        )
        self._session = self._open(probe, build)
        self._share = self._verify(read)

    # -- the contract ------------------------------------------------------

    @property
    def provider(self) -> ProviderChoice:
        """The NPU - reported because the session came back on it (guard two)."""
        return ProviderChoice.NPU

    @property
    def execution_mode(self) -> ExecutionMode:
        """This interpreter. The isolated worker reports ISOLATED."""
        return ExecutionMode.IN_PROCESS

    @property
    def npu_partition_share(self) -> float | None:
        """The verified offload fraction, or `None` when unverifiable.

        Under explicit ``npu`` this is always a float at or above
        `MINIMUM_PARTITION_SHARE` - construction raised otherwise. Under ``auto``
        it may be `None` or a low number: the recorded warning that the caller,
        or the benchmark, reads to tell "verified on NPU" from "assumed on NPU".
        """
        return self._share

    def run(
        self, token_ids: npt.NDArray[np.int64], attention_mask: npt.NDArray[np.int64],
    ) -> npt.NDArray[np.float32]:
        """Validate and execute one batch through the provider-neutral operation."""
        return checked_run(
            token_ids, attention_mask, shape=self._shape, profile_name=self._profile.name,
            session_run=self._session.run, failure=self._failed,
            execution_note=(f"running {self._profile.name} on the NPU over a batch of "
                            f"{self._shape[0]} x {self._shape[1]} failed: "),
            shape_note=(
                '(batch x sequence). A partial batch is padded by the caller, because static shapes'
                ' are what the NPU compilation fixed'),
            input_dtype_note=(
                'the graph declares it as int64. Casting it here would hide a tokenizer producing '
                'the wrong type'),
            output_dtype_note=(
                'float32. The EP casts to bfloat16 internally for compute, but the output tensor is'
                ' float32; a narrower type here is a defect'),
        )

    # -- getting a session, and proving it is the right one -----------------

    def _open(
        self, probe: Callable[[], bool], build: NpuSessionFactory
    ) -> NpuSession:
        """Guard one, then build, then guard two - in that order, because a
        session built on an unregistered provider comes back looking healthy."""
        if not probe():
            raise EnvironmentError_(
                f"{VITISAI_PROVIDER} is not registered in this interpreter, so "
                f"nothing here can run {self._profile.model_id} on the NPU. "
                "Requesting an absent provider from ONNX Runtime succeeds and "
                "runs the graph on the CPU, so this is checked before a session "
                "is built rather than after",
                provider=ProviderChoice.NPU,
                model_id=self._profile.model_id,
            )

        try:
            session = build(self._context, config_file=self._config_file)
        except Exception as error:
            raise ExecutionError(
                f"opening {self._context.name} for {self._profile.model_id} on "
                f"{VITISAI_PROVIDER} failed: {type(error).__name__}: {error}",
                provider=ProviderChoice.NPU,
                model_id=self._profile.model_id,
                stage=SESSION_STAGE,
            ) from None

        served = tuple(str(name) for name in session.get_providers())
        if not served or served[0] != VITISAI_PROVIDER:
            raise ExecutionError(
                f"a session was requested on {VITISAI_PROVIDER} and came back on "
                f"{', '.join(served) or 'no provider at all'}. Requesting a "
                "provider the runtime does not have succeeds and runs the graph "
                "somewhere else, so a session that is not NPU-first ran on the "
                f"{_CPU_PROVIDER} and is not this backend's session",
                provider=ProviderChoice.NPU,
                model_id=self._profile.model_id,
                stage=SESSION_STAGE,
            )
        return session

    def _verify(self, read: PartitionReader) -> float | None:
        """Apply the provider-choice policy to the node-mix share.

        Under explicit ``npu`` an unverifiable or below-threshold share is a
        failure; under ``auto`` it is recorded and returned so execution
        proceeds.
        """
        share = read(context_path=self._context, model_path=self._model)
        if self._requested is not ProviderChoice.NPU:
            return share
        if share is None:
            raise PartitionShareTooLow(
                f"the NPU partition of {self._profile.model_id} could not be "
                f"verified: {self._context.name}'s node mix carries no "
                f"{EP_CONTEXT_OP} node, or could not be read. Under an explicit "
                "'npu' selection an unverified partition is a failure - "
                "proceeding without evidence is the silent CPU degradation "
                "requirement 2 exists to prevent",
                observed_share=None,
                minimum_share=MINIMUM_PARTITION_SHARE,
                provider=ProviderChoice.NPU,
                model_id=self._profile.model_id,
            )
        if share < MINIMUM_PARTITION_SHARE:
            raise PartitionShareTooLow(
                f"only {share:.1%} of {self._profile.model_id} was offloaded to "
                f"the NPU, below the {MINIMUM_PARTITION_SHARE:.0%} threshold: the "
                "graph is running mostly on the CPU. Under an explicit 'npu' "
                "selection that is a failure, not a silent fallback",
                observed_share=share,
                minimum_share=MINIMUM_PARTITION_SHARE,
                provider=ProviderChoice.NPU,
                model_id=self._profile.model_id,
            )
        return share

    # -- what goes in, and what comes back ----------------------------------



    def _failed(self, message: str) -> ExecutionError:
        """One execution failure, carrying requirement 8.1's three facts."""
        return ExecutionError(
            message,
            provider=ProviderChoice.NPU,
            model_id=self._profile.model_id,
        )


def _npu_or_auto(requested: ProviderChoice, profile: ModelProfile) -> ProviderChoice:
    """Only ``npu`` or ``auto`` reach this backend; ``cpu`` is a category error.

    ``ProviderChoice(requested)`` first, because a raw ``"npu"`` string compares
    equal to the member but is not identical to it, and the policy branches on
    identity.
    """
    choice = ProviderChoice(requested)
    if choice not in (ProviderChoice.NPU, ProviderChoice.AUTO):
        raise ValueError(
            f"the NPU backend serves 'npu' and 'auto' selections; {choice.value!r} "
            f"belongs to another provider and resolution never builds this "
            f"backend for it (model {profile.model_id})"
        )
    return choice


def _require_context(artifact: PreparedArtifact, profile: ModelProfile) -> Path:
    """The compiled snapshot to run, or an execution error if there is none.

    A CPU artifact has no ``context.onnx``; the NPU backend cannot run one that
    is not there, and refuses rather than reaching for ``model.onnx`` - which
    would run the FP32 trunk on the NPU with no compiled binary behind it.
    """
    context = artifact.context_path
    if context is None or not context.is_file():
        raise ExecutionError(
            f"the artifact for {profile.model_id} carries no {CONTEXT_FILENAME} "
            "snapshot, so there is nothing compiled for the NPU to run. A CPU "
            "artifact has only the FP32 trunk; running that on the NPU is not "
            "what this backend does",
            provider=ProviderChoice.NPU,
            model_id=profile.model_id,
            stage=SESSION_STAGE,
        )
    return context

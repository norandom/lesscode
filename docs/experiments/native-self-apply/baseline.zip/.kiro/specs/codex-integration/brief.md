# Brief: codex-integration

> Retired from active delivery scope by owner decision, 2026-11-01.
> The proposal below is historical, not queued work or a dependency of the core.
> Reintroduction requires a concrete unmet need and a new scope decision.

## Problem
Developers need convenient Codex access to proven local measurement and rewriting capabilities.

## Current State
No product MCP server or plugin package exists.

2026-11-01 amendment: dropped from delivery; reconsider only if a native CLI plus skill demonstrates an unmet
integration need. Reuse the proposed capability-compression-core library; do not
build a separate analysis platform. Hardware/performance is outside product scope.

## Desired Outcome
Optional stdio MCP tools expose analysis, planning and mutation through separate schema-defined calls.

## Approach
Wrap existing local capabilities. Verify current official Codex packaging and lifecycle contracts during design rather than relying on supplied research snippets.

## Scope
- **In**: MCP facade, local data lifecycle, installation and cross-platform smoke validation.
- **Out**: duplicated analyzers, mandatory hooks and unverified manifest assumptions.

## Boundary Candidates
Own delivery and transport; reuse measurement and transaction contracts.

## Out of Boundary
Do not make the CLI evaluator depend on Codex, cloud accounts or commercial analyzers.

## Upstream / Downstream
- **Upstream**: capability-compression-core and deconvolute-skill. Transactional-rewrites is needed only for future mutation tools, not read-only comparison transport.
- **Downstream**: future language adapters.

## Existing Spec Touchpoints
- **Extends**: none.
- **Adjacent**: upstream features retain policy and engine ownership.

## Constraints
English. Discovery draft; phase approvals pending. Packaging work follows evidence that the skill and deterministic tools add value.

# Brief: transactional-rewrites

> Retired from active delivery scope by owner decision, 2026-11-01.
> The proposal below is historical, not queued work or a dependency of the core.
> Reintroduction requires a concrete unmet need and a new scope decision.

## Problem
Structural edits need repeatable mechanics that preserve concurrent changes and distinguish syntax from semantics.

## Current State
No engine or transformation rules exist.

2026-11-01 amendment: dropped from the delivery plan. The next slice compares isolated supplied
capability replacements; it does not require a general transaction engine or
codemod catalogue. Preserve this brief as future scope, not an implementation queue.

## Desired Outcome
A small tested rule set supports preview, scoped application, validation and conflict-aware rollback.

## Approach
Evaluate ast-grep for deterministic rules with explicit semantic preconditions. Journal owned changes; reject stale file hashes and stop rollback when concurrent edits conflict.

## Scope
- **In**: plans, file preconditions, diffs, transactions, rule fixtures and validator integration.
- **Out**: universal semantic equivalence and three specialized language backends at launch.

## Boundary Candidates
Own mechanical mutation and journal; consume policy and independent measurement.

## Out of Boundary
Do not own evaluator configuration or discard unrelated changes during rollback.

## Upstream / Downstream
- **Upstream**: demonstrated capability-compression-core and deconvolute-skill workflow; efficiency-baseline supplies historical evidence contracts.
- **Downstream**: codex-integration.

## Existing Spec Touchpoints
- **Extends**: none.
- **Adjacent**: skill selects candidates; evaluator decides acceptance.

## Constraints
English. Discovery draft; phase approvals pending. Introduce only rules whose benefit and validation justify maintenance.

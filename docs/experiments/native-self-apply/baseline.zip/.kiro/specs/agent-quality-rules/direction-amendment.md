# Direction amendment — 2026-11-01

Owner decision: drop this broad platform from the active delivery scope, rather
than keep it as a queued extension. The existing implementation is retained as
reference; no public command or uncommitted work is deleted by this scope change.

The existing phase approvals describe the historical policy-engine plan; they do
not approve a native port or expanded implementation. Its task list marks 9/25
tasks complete. Remaining implementation is retired from the current delivery plan;
preserve uncommitted changes and all reviewed work.

The next proposed work is [capability-compression-core](../capability-compression-core/requirements.md).
Derive prevention from a complete capability boundary and demonstrated replacement
benefit. Per-function budgets cannot establish whole-capability compression.
Hardware/performance and bytes/gzip benefit scores are excluded from this direction.
Existing metric fields retain historical compatibility; no runtime contract is
removed by this amendment. Revisit this feature's requirements/design/tasks before
resuming, rather than treating the prior approvals as approval of the new direction.

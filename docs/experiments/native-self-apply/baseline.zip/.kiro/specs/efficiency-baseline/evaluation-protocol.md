# Evaluation Protocol — Discovery Proposal

## Questions
Does the skill reduce complexity and duplication while preserving behavior? Do deterministic tools add benefit beyond instructions? What time, tokens and runtime costs accompany accepted changes?

## Corpus
Start with a small proposed Python pilot: synthetic overengineering, licensed real repositories with stable tests and adversarial fixtures. Record provenance from known generation history rather than inferring AI authorship. Store repo URL, commit, license, fixture hashes, environment and commands. Declare sample size and repetitions before comparison trials.

Adversarial cases include truthy versus nullish fallback in JS, dynamic imports, reflection, resource cleanup, permission checks, transaction boundaries, side effects and public extension points. In the supplied research, replacing a truthiness condition with `??` changes results for empty strings, zero and false; retain this as a regression fixture when JS support is added.

## Experiment arms
A: plain Codex. B: Codex plus skill. C: same skill plus deterministic tooling when available. Optionally compare Ponytail after verifying its exact source, release and license; supplied opaque citation tokens do not establish provenance.

Use identical fresh input workspaces, fixed tasks, model/version/settings and budgets. Record prompt/configuration hashes, tool versions, environment, repetitions and randomized arm order. Tool access differs only for the intended intervention. Include failures and exhausted budgets; do not cherry-pick successful patches. Record seeds when supported without promising deterministic LLM execution.

## Measurements
- Behavior: baseline passing checks retained, independent outputs and API checks, zero unexplained regressions. A failing baseline is separately reported and ineligible for success claims.
- Test strength: available branch coverage and optional changed-scope mutation testing. Explain changed mutant denominators and equivalent mutants.
- Maintainability: per-function complexity distributions and hotspots, duplicate tokens and ratio, supported nesting and architecture checks. Keep Lizard and Radon measurements separate.
- Size: source bytes, line counts using explicit analyzer definitions and deterministic compressed source size. Report tests separately; exclude generated/vendor files through a fixed scope manifest.
- Cost: wall time, observed agent tokens and provider spend where available. Runtime performance requires controlled workloads; fewer lines do not establish faster execution.

Store raw outputs, exit codes, tool versions, configuration and evaluator hashes, source revisions, scope, exclusions and machine description. Missing tools, unsupported syntax, parse failures and timeouts yield explicit incomplete results, never zero or pass.

Absolute delta is after minus before. Percentage delta is 100 * (after-before) / before; mark unavailable when before is zero. Report correctness over all eligible attempts, accepted/rejected counts, paired improvements for accepted patches and uncertainty across repetitions. Do not mix analyzer definitions into one aggregate metric.

## Acceptance and independence
Rank behavior/invariants first, then test strength, API stability, complexity/duplication, size and cost. Set exact tolerances during requirements review. Avoid a universal score that rewards breaking behavior for fewer lines.

Keep evaluation tests outside the rewrite workspace. Freeze and hash evaluator configuration, exclusions and test inventory. Separate processes and hashes detect accidental changes; strong enforcement needs externally controlled CI or filesystem permissions. The rewrite agent may not weaken its own gate.

Passing checks supplies bounded evidence, not a proof of equivalence. Reject behavior-breaking patches and preserve their evidence. Roll back only owned edits; stop if concurrent changes prevent safe rollback.

## Harness acceptance demonstrations
Unchanged input yields stable structural metrics. Known duplication is detected. A shorter behavior-breaking fixture is rejected. Missing metrics stay unavailable. Evaluator tampering is detected. A second developer can rerun a paired comparison from its recorded artifacts.

## Upstream sources checked during discovery
- [ast-grep](https://github.com/ast-grep/ast-grep): structural search and rewrite candidate.
- [Lizard](https://github.com/terryyin/lizard): complexity candidate.
- [jscpd](https://github.com/kucherenko/jscpd): duplication candidate.
- [Radon](https://github.com/rubik/radon): optional Python metrics candidate.

Discovery date: 2026-10-30. Exact release licenses, install behavior, compatibility and metric accuracy still require executable validation. No benchmarks have run. Supplied reduction percentages and effort estimates remain unverified claims, not acceptance targets.

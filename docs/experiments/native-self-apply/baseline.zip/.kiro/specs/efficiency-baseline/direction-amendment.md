# Direction amendment — 2026-11-01

This completed specification and its validation remain records of the delivered
Python evaluator. They are not retroactively changed into a Rust specification.
Preserve its public contracts, frozen evidence and historical metric fields.

The proposed successor slice is [capability-compression-core](../capability-compression-core/requirements.md):
whole-capability accounting with existing behavior checks. Hardware/performance
measurement is excluded; byte/gzip fields are not compression-benefit targets.
Reuse selected adverse fixtures and evidence contracts, not the entire platform.
Replacing the existing CLI would require an explicit compatibility/migration plan.

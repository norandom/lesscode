# Research & Design Decisions

## Summary
- **Feature:** efficiency-baseline
- **Discovery Scope:** New Feature; full discovery on 2026-10-30.
- **Key Findings:** A skill can invoke the local harness without MCP. Analyzer success exits do not establish complete evidence. Duplication counts and source suppression must be handled explicitly.
- **Review:** Inline design review, with one repair pass for analyzer contracts; no independent design approval claimed.
- **Consulted guidance:** kiro-spec-design, its full-discovery/synthesis/review rules and templates; core steering; skill-creator guidance already loaded; OpenAI Docs for the user's skill-versus-MCP question. No UI or accessibility workflow applies to this command-line feature.

## Research Log

### Existing project and runtime
- **Context:** Determine reusable implementation and executable prerequisites.
- **Sources consulted:** Repository inventory, steering, requirements and local runtime commands.
- **Findings:** No product implementation exists. The Windows python command is a Store alias and does not run Python. The py launcher provides Python 3.12.10; Node reports 24.22.1. This is a launcher distinction, not evidence that Python is absent.
- **Implications:** Resolve real interpreters explicitly. Select CPython 3.12.10 and Node 24.22.1 as the initial reproducibility targets, subject to exact dependency locks. Three-platform runtime behavior still needs implementation CI.

### Skill versus MCP
- **Context:** User asked whether a skill is sufficient.
- **Source:** [Official OpenAI skill documentation](https://learn.chatgpt.com/docs/build-skills).
- **Findings:** Skills support instructions, resources and optional scripts. MCP connections can be bundled separately; they are not required to author a skill.
- **Implications:** This feature exposes a CLI. The subsequent product skill invokes it through local execution. MCP remains optional delivery work and is not an independence or correctness mechanism.

### Lizard contract
- **Sources:** [Pinned metadata](https://pypi.org/pypi/lizard/1.17.31/json), [versioned README](https://raw.githubusercontent.com/terryyin/lizard/1.17.31/README.rst), [CSV implementation](https://raw.githubusercontent.com/terryyin/lizard/1.17.31/lizard_ext/csvoutput.py).
- **Findings:** Pin 1.17.31. Metadata/root license is MIT; source contains an Apache-2.0 header, so retain applicable notices rather than claiming uniform licensing. Both are open-source licenses. Python support and direct analyze_file records fit the first slice. CSV is function-oriented and cannot alone show that a zero-function file was analyzed.
- **Implications:** A bounded worker emits normalized file and function records using the library. Validate parsing independently. Source controls including GENERATED CODE comments can suppress metrics; disallow controls in this initial measured profile. Resolve transitive dependencies into a hash-locked environment.

### jscpd contract and version drift
- **Sources:** [4.0.5 registry metadata](https://registry.npmjs.org/jscpd/4.0.5), [pinned CLI README](https://raw.githubusercontent.com/kucherenko/jscpd/87a118f80343288c0099a4e3e47ccd875476bf6c/packages/jscpd/README.md), [statistics](https://raw.githubusercontent.com/kucherenko/jscpd/87a118f80343288c0099a4e3e47ccd875476bf6c/packages/core/src/statistic.ts), [JSON reporter](https://raw.githubusercontent.com/kucherenko/jscpd/87a118f80343288c0099a4e3e47ccd875476bf6c/packages/finder/src/reporters/json.ts), [token positions](https://raw.githubusercontent.com/kucherenko/jscpd/87a118f80343288c0099a4e3e47ccd875476bf6c/packages/tokenizer/src/token-map.ts).
- **Findings:** Select MIT-licensed 4.0.5, not current master, which describes a newer engine. The package uses core/finder/tokenizer 4.0.1; lock the entire tree. Source-level ignore markers remain active despite external configuration. CLI defaults can omit large files.
- **Output semantics:** Aggregate duplicatedTokens counts one span per emitted clone pair; total.tokens reflects token-position spans. It is not unique duplicate coverage. Per-clone tokens is hardcoded zero. Clone line lengths are inclusive while aggregate duplicatedLines uses a different span calculation.
- **Implications:** Expose a versioned pair-span ratio, preserve original statistics, reconcile files, set size limits explicitly and reject suppression controls. Do not generalize one tool's percentage into universal duplication quality.

### Executable contract probes
A research subagent ran local Windows probes in C:/Users/mariu/AppData/Local/Temp/lesscode-analyzer-contract-probe without editing the project.
- Lizard 1.17.31 on Python 3.12.10: each of two sample functions reported CCN 3, NLOC 8 and tokens 28.
- jscpd 4.0.5 on Node 24.22.1: two identical eight-line Python files, using weak mode and a probe threshold of 20 tokens, yielded total tokens 112, duplicated tokens 56 and percentageTokens 50. Clone tokens was zero; clone lines 8 versus aggregate duplicatedLines 7.
- A Windows backslash input directory exited zero with no JSON; normalized forward-slash input produced the report.
- Limits: these are tool-contract probes, not product tests or a simplification benchmark. Production detection uses a declared 50-token/5-line profile. Linux/macOS and full harness integration have not run. Exact lockfiles are implementation deliverables.

### Process lifecycle and deterministic size
- **Sources:** [Python subprocess](https://docs.python.org/3.13/library/subprocess.html), [Windows Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects), [Python gzip](https://docs.python.org/3/library/gzip.html).
- **Findings:** A subprocess timeout alone does not establish that all descendants stopped. OS process-group/job management is needed for the chosen lifecycle contract. gzip supports explicit timestamp and level; defaults can change between runtime versions.
- **Implications:** Separate platform-specific process lifecycle code, use argv rather than shell strings, and test descendant termination on every supported OS. Freeze gzip settings and record Python/zlib versions. No assertion of hostile-code isolation follows from process management.

## Architecture Pattern Evaluation
| Option | Strengths | Risks / Limitations | Decision |
|---|---|---|---|
| Skill with local functional CLI | Small install surface, human/agent reuse, deterministic evidence | Requires local tools and project runtimes | Selected |
| MCP-first server | Structured agent transport | Adds lifecycle and transport work without improving measurements | Deferred |
| Generic plugin/adapter framework | Broad extensibility | Premature abstraction for two analyzers | Rejected |
| Reuse analyzers and normalize evidence | Avoids custom complexity/clone algorithms | Must retain tool-specific semantics | Selected |

## Design Decisions

### Decision: Generalize evidence, not execution platforms
- **Context:** Native tests, independent checks and optional coverage/mutation/architecture results share provenance and availability needs.
- **Alternatives:** Separate subsystem per metric versus one typed evidence envelope.
- **Selected approach:** Typed metric/check records with status, scope, producer, raw artifact and source/plan identities. Keep the actual implementations limited to the initial tools and supplied evidence.
- **Trade-offs:** Input validation is project code; vendor algorithms remain upstream.
- **Follow-up:** Contract fixtures for malformed, missing, stale and non-comparable evidence.

### Decision: Build comparison semantics; adopt measurement
- **Context:** Existing analyzers do not implement the project's acceptance order, evaluator integrity or experiment accounting.
- **Selected approach:** Build scope manifests, comparison rules and reports; adopt Lizard/jscpd and standard-library storage/process functions.
- **Alternatives:** SciTools excluded by user preference; Radon duplicates part of the initial complexity surface; ast-grep addresses later structural transformations.
- **Trade-offs:** New code remains limited to orchestration and evidence interpretation.
- **Follow-up:** End-to-end unchanged/shorter-but-broken fixtures before product effectiveness claims.

### Decision: Explicit profiles and conservative statuses
- **Context:** Requirements avoid fixed global reduction targets and require unavailable evidence to remain visible.
- **Selected approach:** Freeze check inventory, required metrics and threshold rules before execution. Distinguish accepted, rejected, incomplete, baseline_ineligible and invalid. A passing behavior check does not imply semantic equivalence.
- **Trade-offs:** Users must provide runnable checks and meaningful profiles; no automatic oracle inference.
- **Follow-up:** Verify every status transition and denominator with adversarial tests.

### Decision: Simplify experiment reporting
- **Context:** The evaluator must compare externally produced trials without becoming an agent scheduler.
- **Selected approach:** Import records, reconcile planned trials and report paired descriptive statistics. No LLM calls, queue or inferential confidence interval in version 1.
- **Trade-offs:** Experiment producers remain responsible for randomization and identical starting environments; the evaluator records and flags discrepancies.
- **Follow-up:** Validate missing and exhausted-budget trials, confounding and separate correctness/acceptance rates.

### Decision: Local detection is not independent enforcement
- **Context:** An agent with identical OS permissions could alter both checks and hashes.
- **Selected approach:** Freeze and verify evaluator resources locally and disclose protection level; externally controlled CI provides stronger isolation.
- **Trade-offs:** Local convenience does not justify claims of tamper-proof evaluation.
- **Follow-up:** Tamper tests prove detection within the stated boundary only.

### Decision: All baseline behavior checks establish eligibility
- **Context:** Task planning found that the design's required-only baseline rule narrowed requirement 4.2.
- **Selected approach:** The user confirmed that any failed or incomplete declared baseline behavior check makes the trial baseline-ineligible, including optional behavior checks. Optional metrics can remain unavailable unless required by the profile.
- **Follow-up:** Cover failed, skipped, missing and errored optional baseline checks in decision and integrated evaluation tests. The required flag still controls candidate missing-evidence handling as specified elsewhere.

## Risks & Mitigations
- Analyzer omissions or suppressions: file reconciliation, explicit bounds, suppression rejection and syntax validation.
- Runtime/tool drift: immutable pins, transitive locks and per-run identities.
- Tests writing outside copies: trusted local commands only; untrusted corpora require external isolation.
- Flaky tests or stochastic generation: no hidden retries; retain repeated outcomes and controlled-condition metadata.
- Metric gaming: frozen checks and criteria, separate metrics, no compensating universal score.
- Source access or copy races: fail capture and retain input diagnostics rather than compare mismatched bytes.
- License/notice ambiguity: preserve Lizard source notices and review resolved dependency inventory before distribution.

## References
Canonical sources are linked within the corresponding investigation above. Internal basis: requirements.md, evaluation-protocol.md and core steering. The design is supported by upstream contracts and limited Windows probes; no benchmark effectiveness, cross-platform implementation readiness or security-audit claim is made.

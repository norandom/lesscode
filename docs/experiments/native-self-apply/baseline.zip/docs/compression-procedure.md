# Reusable logic for finding less code

**Find a replaceable responsibility, explain its behavioral variations, compare complete implementations, and only then choose the verification tool.**

The repo-local [lesscode-discovery skill](../.agents/skills/lesscode-discovery/SKILL.md) makes this procedure reusable by coding agents. It includes a compact [experiment record](../.agents/skills/lesscode-discovery/references/experiment-record.md) for selection, behavior, whole-replacement cost and outcomes. It is an experimental workflow, not the completed proposed deconvolution product or an automatic enforcement engine.

The [reader-family plan and prototype](experiments/reader-family/README.md) demonstrate the concrete input and transformation loop on five actual Lesscode records. Source and tests are the inputs; ASTs are an internal tool. The prototype preserves the checked behavior but saves only three lines, so it is not adopted.

```mermaid
flowchart TD
    A[Trace a complete implementation responsibility] --> B{Concrete replacement opportunity?}
    B -->|No| C[Keep as observation; inspect another responsibility]
    B -->|Yes| D[Separate shared behavior, data variation and required differences]
    D --> E[Compare original, direct simplification, existing capability, justified sharing]
    E --> F[Freeze tests, accounting scope and candidate record]
    F --> G[Choose appropriate verification and run bounded trial]
    G --> H{Behavior established within declared boundary?}
    H -->|No| I[Retain failure or uncertainty; do not adopt]
    H -->|Yes| J{Complete replacement smaller and useful?}
    J -->|No| K[Keep original; record valid but unhelpful alternative]
    J -->|Yes| L[Adopt within authorized scope; report net change]
```

## Freeze a capability scope before scoring

A function is a location, not the acceptance unit. Name the externally observable
operation and include every owned implementation needed to deliver it: dispatch,
helpers, wrappers, tables, configuration and affected callers. Any support added
outside the original files joins the measured scope. Keep a wider module/project
total to detect code that was merely moved.

Compare aggregate implementation and decision structure. Report function count
and call depth as tradeoffs, not targets. Splitting one function into twenty may
improve individual complexity scores while increasing convolution. Conversely,
a useful shared renderer may add a helper while removing a duplicated algorithm.
Neither result can be judged by per-function caps alone.

The [ATS bilingual report trial](experiments/ats-report/README.md) measures the
complete language-dispatch/rendering capability, including translations and
compatibility wrappers. Its scope protocol supplements the experiment record;
these are research practices, not an implemented automatic gate.

## What this changes about candidate selection

| Example | Decision under this procedure |
| --- | --- |
| One already-direct 12-line classifier | No demonstrated shared-family opportunity. A table trial can be a rejection control, not primary evidence for compression efficacy. |
| Several readers repeating the same parsing operation | Candidate family if shared behavior and policy differences can be stated. Compare a concrete whole-boundary alternative, including validation and diagnostic compatibility. |
| One large handwritten operation supplied by an installed library | Candidate even without duplicate functions. Preserve semantic differences and count adapters. |
| Similar file-delta helpers with different definitions of “modified” | Investigate the difference before sharing: content-hash changes and full-record changes are not automatically equivalent. |
| Functions rejected because a solver requires `x: int -> int` | Record tool-interface limitations. Do not infer that the functions are incompressible. |

These are inline checks of the procedure against known cases, not independent forward-testing or evidence of an improved compression rate. The [earlier self-application results](reports/lesscode-self-application.md) remain available, but the isolated classifier is a control. It did not test the hypothesis that repeated grown implementations can share a smaller core.

## Use it on Lesscode

For the next trial, start with the public record conversion family. Inspect its members and error/validation policies, then state exactly which code a replacement would remove. The 524 reader-method lines locate a possible burden; they are not a promised saving. Reject a schema or library candidate if its adapters merely reproduce the same machinery elsewhere.

Example request for the repo-local skill:

```text
Use $lesscode-discovery on Lesscode's public record conversion boundary.
Inspect the complete family and its tests. Select a concrete compression
hypothesis before choosing a framework or solver. Trial the most promising
alternative in isolation, preserve the existing behavior boundary, and report
the full replacement cost. Do not change Facdrone.
```

Statistics follow the decisions: source population, candidates examined, families trialed, alternatives validated, replacements adopted, and accepted net reduction. Unsupported cases and failed attempts stay visible. Tool coverage, synthetic reductions and test counts remain distinct from real-project compression efficacy.

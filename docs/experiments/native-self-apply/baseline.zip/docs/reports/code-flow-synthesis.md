# Less code, same behavior: a synthesis experiment

**2026-11-01 — prototype evidence, not a production compressor.**

An agent maintaining a grown codebase needs a smaller implementation without losing its behavior. This experiment shows that solver-assisted simplification can help with a narrowly defined family of functions. It also shows why a shared kernel must compete against ordinary concise code: **the direct expressions were smaller than the synthesized kernel and table.**

The practical archetype is **propose alternatives → verify behavior → measure the complete replacement → retain the simplest useful result**. A solver supplies evidence for equivalence within its model. It does not decide what humans should maintain.

## What became smaller

Two synthetic Python fixtures were compared with two generated alternatives. The verbose fixture contains six integer functions with assignments, repeated branches and differing constants. The compact control already expresses three functions directly. Neither is a representative sample of AI-generated repositories.

![Complete Python alternatives: verbose source shrinks from 66 lines to 35 with a shared kernel or 22 with direct expressions; compact source grows from 10 to 23 with sharing.](../images/cegis-compression.svg)

| Fixture and representation | Physical lines | Logical lines | UTF-8 bytes | AST nodes |
| --- | ---: | ---: | ---: | ---: |
| Verbose original | 66 | 56 | 1,277 | 320 |
| Shared kernel, table and API wrappers | 35 | 17 | 839 | 213 |
| Direct expressions | **22** | **12** | **409** | **154** |
| Compact original | 10 | 6 | 187 | 65 |
| Shared kernel, table and API wrappers | 23 | 11 | 543 | 137 |
| Direct expressions | 10 | 6 | 187 | 65 |

The verbose fixture lost **44 physical lines (66.7%) and 868 bytes (68.0%)** with direct expressions. Sharing saved 31 lines, but introduced a table, helper and dispatch. On the compact control, sharing added 13 lines and 356 bytes: reject it as compression. Keeping the original is a valid outcome.

Counts cover entire emitted Python modules, including imports, tables and compatibility wrappers. Physical lines include blank lines; logical lines count Python tokenizer `NEWLINE` tokens. These are not interchangeable with every analyzer's LLOC. Byte and AST reductions support the conclusion that this is more than reformatting. No maintenance-hours, runtime or whole-repository improvement was measured.

The research machinery costs code too: `synthesis.py` and `trial.py` total **332 physical lines**, before the TypeScript verifier and plotting script. It is experimental tooling, accounted separately from application replacements. This tiny example does not demonstrate that building a compressor pays for itself.

Inspect the [raw measurements and source hashes](../experiments/cegis/results.json), [verbose-to-direct diff](../experiments/cegis/bloated_inline.diff), [verbose-to-shared diff](../experiments/cegis/bloated_shared.diff) and [rejected compact-to-shared diff](../experiments/cegis/compact_shared.diff). The [plot script](../experiments/cegis/plot_results.py) reads the same JSON; [PNG download](../images/cegis-compression.png) is available for sharing.

## What the prototype actually does

The class-free Python prototype extracts a restricted AST into guarded return expressions. It accepts exact integer arithmetic, local assignments and selected conditional forms. It checks path coverage and disjointness, then solves constants for a supplied sketch:

```text
K(x, threshold, multiplier, offset) =
    x * multiplier + offset if x > threshold else x + offset
```

A synthesis solver fits parameters to concrete samples. A separate verification query searches for an integer where the fixed candidate differs from the original expression. A counterexample becomes the next sample; verifier `unsat` establishes equality over the modeled integer domain. This is a bounded CEGIS loop, not automatic discovery of the best algorithm.

```mermaid
flowchart LR
    A[Restricted source AST] --> B[Guarded integer expressions]
    B --> C[Fit sketch parameters to samples]
    C --> D{Counterexample query}
    D -->|SAT: add sample| C
    D -->|UNSAT| E[Emit shared and direct alternatives]
    D -->|Unknown or budget exhausted| F[No proof; do not accept]
    E --> G[Verify emitted Python expressions]
    G --> H[Compare whole replacement cost]
    H --> I[Keep original or smaller verified candidate]
```

Each solver phase here uses quantifier-free linear integer arithmetic: inputs are concrete during fitting, and parameters are concrete during verification. This reasoning does not extend automatically to arbitrary nonlinear sketches. SMT algorithms depend on the selected theories; neither quantified solving nor CEGIS has a universal millisecond guarantee. See the solver authors' [Programming Z3](https://z3prover.github.io/papers/programmingz3.html).

The [standalone technical specification](../experiments/cegis/SPEC.md) defines the supported subset, statuses and reproduction commands. The [artifact index](../experiments/cegis/README.md) separates source, generated candidates and validation evidence. Python runs locally through uv; nothing was added to Lesscode's production dependencies.

## Verification and evidence against overclaiming

All nine function specializations reached verifier `unsat`. Emitted Python expressions were checked again, and **17,748 concrete comparisons** against original fixtures passed. Generated TypeScript `bigint` code compiled with TypeScript 5.9.3 strict checking and passed **8,874 comparisons**, with zero mismatches. Python used CPython 3.13.16 and z3-solver 4.15.4.0; Node was 24.22.1. See the [TypeScript receipt](../experiments/cegis/typescript-results.json).

This is a proof about an encoding of a restricted source subset, conditional on correct extraction and emission. It is not a proof about arbitrary Python objects, exceptions, resource limits or TypeScript `number`. TypeScript input extraction is not implemented; its generated output received compile and differential checks, not a source-level TypeScript equivalence proof.

The controls matter as much as the successful fixture:

- Floating-point literals, calls, side effects, implicit `None` and nonlinear `x * x` are refused.
- A three-region function cannot fit this sketch and returns `no_solution_in_sketch`.
- Iteration and time exhaustion are distinct outcomes. An injected solver `unknown` verifies fail-closed handling; it is not a naturally observed timeout.
- With only zero as the initial sample, a solvable example reached the 40-iteration limit. Boundary samples from source literals made the normal run much more effective. That is a sampling result, not a convergence theorem.
- A float identity rewrite changed negative zero to positive zero in both Python and JavaScript. Real-number algebra would miss this observable difference. [Z3's floating-point guide](https://microsoft.github.io/z3guide/docs/theories/IEEE%20Floats/) explains why ordinary algebraic identities do not transfer freely to floating point.

Two manually selected Facdrone definitions, `bar_sigma` and `stress_multiplier`, were read as applicability probes. Both were rejected by the integer-only interface. They were not executed or changed. This is evidence of a semantic coverage gap, not an estimate of how much Facdrone can be compressed.

CrossHair and property-based tests remain useful complementary tools. Absence of a discovered counterexample does not establish universal equivalence; CrossHair explicitly documents that limitation and its execution/proxy constraints. They cannot automatically lock all behavior of a dirty module. See [CrossHair limitations](https://crosshair.readthedocs.io/en/latest/limitations.html).

## What proof theory contributes—and what it does not

Curry–Howard relates proofs and programs in specified calculi. It gives a useful language for normalization, but does not make arbitrary Python or TypeScript refactoring literally cut elimination. The relevant correspondences and their computational limits are developed in Sørensen and Urzyczyn's [Lectures on the Curry–Howard Isomorphism](https://kwarc.info/teaching/sWuV/sorensen-urzyczyn_lectures-on-the-curry-howard-isomorphism.pdf), especially chapters 4–7.

| Proposed connection | Engineering interpretation |
| --- | --- |
| Hilbert proofs and SK combinators | A formal correspondence, not a source-size objective. Removing variable names need not make code smaller or clearer. Preserve names that explain roles. |
| Cut elimination and inlining | Normalization can duplicate terms and destroy sharing. It is not a guarantee of fewer operations or less source. |
| Subformula property and tractability | Restricting proof search does not imply cheap search or a minimal program. |
| Craig interpolation and a common kernel | An interpolant separates a valid implication using shared vocabulary. It need not be the weakest, smallest or executable description of either function. |
| SMT and parameter factoring | Useful when a faithful encoding and suitable sketch already exist. The solver does not infer those prerequisites from a repository. |

For a concrete counterexample to “inline everything,” replacing `t = expensive(x); return t + t` with `return expensive(x) + expensive(x)` repeats work. With effects, it can change behavior. Normalization and compression are different objectives.

McMillan's [Interpolants from Z3 proofs](https://www.cs.utexas.edu/~hunt/fmcad/FMCAD11/papers/81.pdf) studies interpolation for verification, abstraction refinement and invariant generation. Its common-vocabulary property does not promise a minimal shared implementation. Historical iZ3 work should not be treated as evidence that current SPACER exposes a general minimal-kernel synthesis operation.

A closer optimization analogy is to retain several equivalent representations and choose one using an explicit cost model. [egg: Fast and Extensible Equality Saturation](https://arxiv.org/abs/2004.03082) describes e-graphs for rewrite-driven optimization and synthesis. That supports the direction, not a need to build an e-graph now: this prototype already compares two alternatives directly. No global minimality or branch minimality has been proved.

## Next: measure Facdrone before extending the machinery

Facdrone is an example case for Lesscode's general question: **where does a smaller representation preserve the same code behavior?** The next deliverable is a measurement report and a ranked, inspectable sample of implementation opportunities. No application-specific redesign or upstream changes are required.

| Measurement | Evidence to retain | Decision it informs |
| --- | --- | --- |
| Population and scope | Revision, dirty-state record, exclusions; separate production, tests, generated code and experiment support | What denominator does any reduction claim use? |
| Implementation breadth | Module/function inventory, responsibilities, calls and forwarding layers; retain source locations | Where does one operation require excessive custom code or navigation? |
| Candidate families | Repeated branches, conversion pipelines, wrappers, custom library substitutes and verbose pure calculations | Which general compression hypothesis fits observed code? |
| Semantic eligibility | Integer/float/array/object operations, effects, exceptions, dependencies; supported and rejected counts with reasons | Is SMT applicable, or would a library replacement plus differential tests be more productive? |
| Whole replacement trials | Original, idiomatic direct version, existing-library version where relevant, shared version when justified | Which alternative actually removes maintained implementation? |
| Maintenance observations | Same small change exercise on original and candidate: touched files, navigation steps, agent retries, test outcomes and human review | Does less source also make work easier? |

Start with a disclosed manual sample across these families, including compact negative controls. Report coverage and refusals; do not extrapolate a selected success percentage to the repository. Preserve financial behavior, meaningful types, error handling and tests. Any local trial belongs in an isolated experimental copy; no Facdrone commit or push follows from this work.

The hypothesis fails for a candidate when behavior differs, the complete replacement is no smaller, or the reduction creates more difficult navigation or change work. A smaller AST is a useful observation, not a substitute for that review. Extend the extractor or sketch only when a real, worthwhile candidate demonstrates the need. Keep existing-library and idiomatic-code alternatives in the experiment: SMT is one instrument, not the definition of Lesscode.

Use those findings to reflect on this archetype and **then** amend the Kiro specification. This report does not change Kiro requirements, design or tasks. It also does not establish why any commercial coding agent lacks a particular synthesis feature; editing format alone does not explain additive code growth.

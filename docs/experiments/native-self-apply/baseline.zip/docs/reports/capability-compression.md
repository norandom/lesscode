# Capability-scoped compression: two positive trials

The ATS trial demonstrates useful compression of a real repeated responsibility.
It retains the observed behavior while reducing the complete bilingual report
implementation, including translations and wrappers. This is positive evidence
for selecting a compressible capability before choosing a transformation tool.

| ATS01 measure | Original | Candidate | Reduction |
| --- | ---: | ---: | ---: |
| Physical lines | 384 | 202 | 47.4% |
| LLOC | 298 | 135 | 54.7% |
| Aggregate decision points | 76 | 47 | 38.2% |

All 8,820 frozen cases match. A deliberate German-section omission fails 2,251
comparisons. Function count rises from three to five: the reduction is in the
whole responsibility, not its individual function scores. The full containing
module also shrinks, so the candidate does not export code outside the measured
scope. See the [report, chart and exact diff](../experiments/ats-report/README.md).

The legacy status of the ATS application limits product relevance, not the
validity of this result. No upstream adoption occurred. Finite tests do not prove
universal equivalence, and line savings do not measure maintenance hours.

## The mechanism also reduced an active backend family

The [NPU01 trial](../experiments/npu-backends/README.md) shares the CPU/NPU batch
execution and tensor-check operation. Provider-specific construction, partition
verification, fallback policy and precision safeguards remain intact. All 3,168
generated cases match, and both versions pass the same 339 existing tests.
Selected strict type checks pass. A deliberately omitted dtype check changes
572 outcomes, showing that the behavioral boundary catches that regression.

| NPU01 measure | Original | Candidate | Reduction |
| --- | ---: | ---: | ---: |
| Owned capability physical lines | 171 | 101 | 40.9% |
| LLOC | 68 | 47 | 30.9% |
| Aggregate decision points | 16 | 8 | 50.0% |

The full provider modules plus new shared module shrink by the same 70 physical
lines. Typed adapters and exact diagnostic text are included. This is evidence
of useful code compression on active code, with no upstream changes. Live
hardware behavior remains unmeasured; injected-session tests do not replace it.

The percentages are separate scoped results, not a pooled success rate or a
forecast for whole projects. ATS01 and NPU01 were manually selected because their
repetition was visible. Both preserve their checked behavior by maintaining a
common operation once, while leaving meaningful differences explicit. Neither
needed SMT, another framework or a per-function complexity cap.

Research overhead remains visible: ATS01 adds 223 script lines; NPU01 adds 253.
Those are experiment apparatus, not product implementation savings. The prior
negative Lesscode trials still matter: a graph or an attractive metric alone
does not establish a removable implementation.

## Record the discovery step for reuse

1. Name a capability and its observable boundary.
2. Find repeated operations across that boundary, including small functions.
3. Separate literal/data variations from genuine behavior differences.
4. Name the duplicated implementation that can disappear.
5. Freeze checks and count all replacement support before judging the result.

This is the practice maintainers and coding agents should repeat. A graph helps
trace the scope; a low per-function complexity score does not establish success.

## Composition and disproof notes

COBESY framing: the audience is Lesscode's maintainer and future trial-running
agents. The target behavior is capability-level selection and accounting. The
working assumption to challenge is that more small functions necessarily mean
less convolution. The maintainer is the initial adoption point; the documented
procedure carries the practice into subsequent agent runs. This is a learning
problem with explicit rejection conditions, not a requirement that every trial
succeed. No psychological-safety assessment of a wider organization is claimed.

The governing message is two positive scoped results; the supporting evidence
is behavior, whole-scope reduction and clear limits. Transfer to active code was
tested rather than assumed. Disproof remains a behavioral mismatch or no useful
saving after complete accounting. Prior failed trials remain visible and are
not reclassified as successes. The next discovery pass should apply the same
selection criteria to another complete responsibility, without assuming that
sharing is always the right replacement.

# From isolated compression trials to an SMT-augmented LLM loop

The next experiment builds on a real, smaller Lesscode implementation. The
current candidate reduces outcome classification from 72 to 60 physical lines,
62 to 41 Radon LLOC and 54 to 45 Lizard CCN. It preserves the tested behavior.
SMT verifies only its extracted final-decision boundary under explicit input
assumptions. Neither this result nor the earlier synthetic examples establishes
general repository compression.

The practical question is now whether an LLM can improve that implementation
further when it receives counterexamples and a complexity budget. This report
keeps the intermediate evidence visible so a later proposal cannot replace the
baseline, erase a failure or inherit a stronger proof claim than it earned.

## What changed between the trials

| Trial | Input and intervention | Observed result | What it establishes |
| --- | --- | --- | --- |
| [Synthetic synthesis](../experiments/cegis/) | Restricted integer functions; supplied kernel and solved parameters | Verbose six-function family: 66 physical lines to 35 shared or 22 inline. Compact three-function control: 10 to 23 shared | Representation can compress verbose inputs and expand compact ones. Not real-project efficacy. |
| [Self-application](lesscode-self-application.md) | Real-code applicability census and narrow classifier/glob trials | Unsupported interfaces dominate the restricted solver census; classifier table grew from 12 to 17 lines; glob replacement changed behavior | Tool acceptance is not compression potential. Keep rejected candidates. |
| [Reader family](../experiments/reader-family/README.md) | Five real record readers replaced by a shared factory | 63 to 60 lines including helper; 1,126 comparisons and 103 existing tests pass | Equivalence checks can pass while whole-replacement value remains weak. |
| [Outcome hotspot, stage 1](../experiments/outcome-hotspot/README.md) | Complete high-CCN classifier; repeated inventories and final decision representation simplified | 72 to 60 lines; LLOC 62 to 41; CCN 54 to 45; 20,258 matching cases and 65 tests per implementation | A useful local direction, not adopted production code. |
| [Outcome SMT boundary](../experiments/outcome-hotspot/logic-result.json) | AST-derived final decision precedence and invalidity normalization | Difference query UNSAT; removing invalidity precedence SAT | Equivalence inside this boundary, assuming equal incoming behavior and completeness. No proof of the full function. |
| [Stage 2, continued trial](../experiments/outcome-llm/README.md) | Two LLM proposals with source-derived SMT feedback | Proposal 1 changed six outcomes; revised proposal 2 passes and reaches CCN 43, still 60 lines / 41 LLOC | The loop catches an unsafe proposal; further code reduction and the CCN 36 cap were not achieved. |

These are different populations and interventions. Do not pool their test counts
or derive a success rate. Facdrone remains a read-only example, not a refactoring
deliverable. Bytes are excluded from the current assessment at the owner's
request. Production, tests and experiment apparatus are counted separately.

## Three identities must remain distinct

1. The unchanged production original: 72 lines, CCN 54.
2. The retained stage-1 candidate: 60 lines, CCN 45. Its source, diff, raw results,
   test logs and solver queries remain in `docs/experiments/outcome-hotspot/`.
3. Each stage-2 proposal: a new source artifact and result, compared against the
   production original for behavior and against stage 1 for additional savings.

Stage 1 originally used a provisional 20% physical-line cutoff. The owner later
accepted its 16.7% reduction as a useful direction. That amendment is recorded;
it is not presented as a predeclared success. No production adoption has occurred.

## Stage 2 protocol

Use at most three LLM-authored proposals. Keep the original contract and tests
fixed. The provisional cap is `floor(45 * 0.8) = 36` Lizard CCN for the complete
responsibility. Require fewer lines and LLOC than the original, no increase over
the current 60-line candidate, and readable names and control flow. Count helpers
and tables, including any relocated decisions. Missing the cap is evidence about
the search, not permission to obscure the code.

For each proposal: save source and hypothesis; extract supported logic; ask SMT
for a difference; retain SAT counterexamples or UNKNOWN results; revise only in a
new artifact. Then run exact outcome/diagnostic comparisons and unchanged tests
for viable proposals. A proof result applies only to the recorded source and
model boundary. Unsupported code remains unverified.

MCP is a later interface for these operations, not the compression mechanism.
The experiment currently uses local scripts via uv. There is no implemented
general AST-to-SMT compiler, autonomous synthesis service or MCP server.

## COBESY framing and composition record

| Element | Applied choice |
| --- | --- |
| Raw knowledge | Saved source, metrics, comparisons, test logs and solver queries from the linked trials. |
| Target behavior | The owner and future coding agents compare complete implementations and retain intermediate evidence before continuing. |
| Inferred assumption | A lower complexity score can tempt us to treat changed representation as solved convolution. |
| Anchor | The project owner and this indexed report; no organizational network or psychological-safety diagnosis is asserted. |
| Framing | Treat proposals as falsifiable experiments. A counterexample is useful feedback, not a failed contributor. |
| Disproof | Behavior changes, the cap is met only by moving decisions, or complete implementation/readability fails to improve. |
| Composition | Conclusion first; separate historical populations, proof boundaries and the next reproducible action. |
| Adoption aid | Link each claim to its artifact and give each proposal its own identity. No rollout campaign is needed. |

The writing pass keeps measured evidence separate from interpretation. There is
no claim of measured maintenance hours, universal equivalence or large-project
effectiveness. The next decision is whether this bounded feedback loop earns a
larger empirical trial.

## Continuation result, appended after the report update

This report was established before running stage 2. Both attempted sources and
their results remain in a separate directory. Previous experiment files and
production/test inputs are hash-checked and unchanged. The revised proposal
passes 20,258 comparisons and 65 existing tests, but saves no further physical
lines or LLOC. Production remains untouched.

The initial SAT model exposed the need to distinguish abstract counterexamples
from realizable inputs. Concrete comparison confirmed six defects in proposal 1;
the LLM restored the missing guard in proposal 2. This shows that feedback can
prevent regression. It does not yet show additional compression from that loop.
See the [attempt ledger and chart](../experiments/outcome-llm/README.md).

## Next design: global knowledge before local proposals

The next design adds a [repository-wide capability driver](../repository-capability-driver.md):
one discovery subagent reads build/runtime constraints, dependency roles and
existing implementations, then supplies a shared inventory to local agents.
Dependency changes remain centralized; local simplifications cannot introduce
competing frameworks independently. Refresh affected inventory entries when their
evidence changes, rather than rediscovering the stack for every function.

The [next experiment](../experiments/capability-guided/plan.md) compares local
discovery with that shared inventory on matched responsibilities, under the same
frozen dependency policy. It counts discovery cost and retains every attempt.
The [first pilot is now complete](../experiments/capability-guided/run-01/README.md).
One discovery agent and six fresh local sessions compared three responsibilities.
Both arms found the same 12-line / 9-LLOC evidence-admission replacement; storage
proposals were marginal and an analyzer proposal changed behavior. The shared
inventory did not produce additional verified removal in this small pilot.
Dependencies, production and earlier results remain unchanged. The report retains
all attempts, setup failures, validation limits and discovery/research costs.

## Graph trial: no additional compression

The [report-ingestion graph trial](../experiments/report-graph/README.md) compares
one local rewrite with a joint validator/reader rewrite. Both match 6,234 generated
cases and pass the same 18 existing integration tests. A deliberate variant that
discards simultaneous outcome markers fails 176 comparisons.

The original subgraph has 85 physical lines and 69 LLOC. The local proposal has
82/70; the joint proposal has 84/73. Both lower CCN from 44 to 42, but neither
meets the fixed requirement to reduce physical lines and LLOC. Production stays
unchanged. This is evidence for recording data and ordering obligations on graph
edges, not evidence that graph-guided rewriting compresses more code. All 339
frozen inputs remain protected; the separate research scripts add 193 lines.

## Feature-path hypothesis: two deletion premises rejected

[FP01](../experiments/feature-path/README.md) traces a real pinned Lizard result
through comparison, reporting and recovered storage. Evidence compatibility and
scalar availability cannot share one status: the probe changes an accepted
fixture to incomplete and fails five of 1,024 generated comparisons. Removing
the function inventory breaks report consistency and existing adapter tests.

The unchanged baseline runs 81 decision/contract/report tests (80 pass, one skip)
and eight adapter tests (all pass). The corresponding probes fail five tests each,
including two errors in the inventory arm. These are falsification probes, not
complete compression alternatives. The trial established no admissible rewrite,
so accepted savings remain zero. It adds 172 research-code lines and a seven-line
specimen, preserves 412 frozen inputs and leaves production untouched.

## ATS01: a repeated capability provides a stronger target

The [ATS bilingual report experiment](../experiments/ats-report/README.md) tests
one shared renderer against two existing English/German implementations. The
scope includes language dispatch, translation data and compatibility wrappers.
It shrinks from 384 to 202 physical lines and 298 to 135 LLOC; aggregate AST
decisions fall from 76 to 47. Function count rises from three to five, exposing
why a per-function goal is insufficient.

All 8,820 frozen cases match, and the original language-method override seam
remains observable. A deliberate German-only-section omission produces 2,251
mismatches. The full module drops from 815 to 634 physical lines; surrounding
class members are unchanged by AST comparison. This is tested finite behavior,
not a universal proof. It concerns ATS's legacy Python renderer, not its current
skill product. Neither specimen repository was edited. Research scripts add
223 lines; the source candidate is retained without upstream adoption.

## NPU01: the same mechanism works on an active typed family

The [CPU/NPU backend trial](../experiments/npu-backends/README.md) reduces the
complete execution/check family from 171 to 101 owned physical lines and 68 to
47 LLOC. Aggregate decisions fall from 16 to 8. Both versions pass the same
339 native tests; all 3,168 generated cases match. A deliberately omitted input
dtype check changes 572 outcomes. The full two provider modules plus the new
shared module also shrink by 70 physical lines, so code was not moved outside
the accounting scope.

The first physical count included extraction separators (178/106); the report
retains it and explains the correction to actual owned source spans. Selected
strict typing passes on both versions; the baseline required a retry after a
process exit with no diagnostics. No source was revised between attempts.

This is a positive active-code experiment, not a hardware numerical validation
or upstream adoption. Research scripts add 253 lines and all 545 frozen inputs
remain unchanged. The [COBESY synthesis](capability-compression.md) records ATS01
and NPU01 as two separate positive results and preserves the earlier failures.

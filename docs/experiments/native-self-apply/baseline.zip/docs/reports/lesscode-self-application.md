# Applying synthesis to Lesscode: coverage before compression claims

**Interpretation correction:** the isolated classifier below is a rejection control, not an efficacy trial for compressing a repeated implementation family. The interface census measures prototype restrictions, not compression potential. Use the [responsibility-first procedure](../compression-procedure.md) to select future candidates. The recorded observations remain valid within their stated limits.

2026-11-01. **The approach has now been exercised on Lesscode's actual source. No production reduction has earned adoption yet.** A complete production-function census exposes the original prototype's limited interface. A separate real-code CEGIS experiment produces a behaviorally valid decision table, but the complete replacement is larger than the original function.

These findings are useful precisely because they constrain the claim: the earlier synthetic reduction does not establish that Lesscode, or a grown project such as Facdrone, can be reduced by the same percentage.

![The unchanged pricing prototype accepts zero of 282 production definitions; the manually adapted real classifier grows from 12 to 17 lines.](../images/lesscode-synthesis-statistics.svg)

## Fixed population and explicit exclusions

The [census](../experiments/self-apply/applicability.json) records the Git revision, dirty working-tree state and raw SHA-256 of every production Python file. The actual working-tree bytes are authoritative: this includes the owner's pre-existing, uncommitted rule-evaluation implementation. No production files were edited during the experiment.

| Population at measurement time | Files | Physical lines | Logical lines |
| --- | ---: | ---: | ---: |
| Production Python, `src/**/*.py` | 17 | 6,589 | 4,852 |
| Automated tests, `tests/test_*.py` | 29 | 7,475 | 5,853 |
| Other test Python and fixtures | 16 | 388 | 237 |
| Experiment Python, `docs/experiments/**/*.py` | 21 | 1,257 | 875 |

Physical lines include blanks, comments and docstrings. Logical lines count tokenizer `NEWLINE` tokens; this is not a claim about another analyzer's LLOC. The experiment population includes drivers, synthetic examples and generated alternatives, not only new work from this pass. Non-Python assets, installed dependencies and documentation are outside these Python totals. Tests are a separate protection cost, not a deletion target.

All **282 lexical function definitions** in production source are inventoried individually with file, name, source line and disposition. Methods and nested definitions are counted once; their overlapping source spans are not summed into a fictional code total. Lambdas and functions embedded in worker-source strings are not separate definitions in this inventory, although their text remains in the module line counts.

| Current prototype disposition | Definitions | Explanation |
| --- | ---: | --- |
| Supported by unchanged pricing-prototype interface | **0** | No production definition passed its existing admission rules. |
| Unsupported module-level functions | 155 | 153 fail the required single argument `x: int -> int` shape; two have unsupported decorators. |
| Context excluded from standalone extraction | 127 | Methods and nested functions require object or enclosing-scope modeling. |

This is **zero interface applicability in this snapshot**, not zero potential compressibility. The refusal commonly occurs before inspecting the function body. In particular, an argument-name or annotation restriction is a prototype constraint, not a semantic impossibility. We did not silently remove these functions from the denominator or rename their arguments to manufacture coverage. [The runnable census](../experiments/self-apply/applicability.py) attempts the unchanged extractor on every module-level synchronous function and records its actual first refusal.

## A real-code synthesis trial beyond that interface

We manually selected `_debt_disposition` from `src/lesscode_baseline/rules/evaluate.py`. It is an existing pure classifier whose result depends on relative order and whether a maximum is present. Its definition already contains all eight outcome labels, without filesystem access or a dependency on financial behavior.

The [trial](../experiments/self-apply/debt_trial.py) lowers the actual source AST's supported comparisons, conditional returns and string labels into a symbolic expression. It then fits a fixed decision-table sketch using a two-solver CEGIS loop. Its features are:

1. Whether the reference exceeds the maximum.
2. Whether the candidate exceeds the maximum.
3. Whether the candidate is lower than, equal to, or higher than the reference.

The three features have twelve Cartesian combinations, of which eight are reachable. The solver chooses an output label for each table cell; a counterexample query challenges each proposal. This is parameter synthesis for a manually supplied representation, not automatic discovery of the function or its best representation.

| Observation | Measured result |
| --- | --- |
| CEGIS iterations, including final verification | 8 |
| Reachable table cells | 8 |
| Final symbolic counterexample query | `unsat` |
| Concrete original/candidate comparisons | 810; zero mismatches |
| Same existing rule-evaluation tests, original | 44 run, zero failures/errors/skips |
| Same existing rule-evaluation tests, generated candidate | 44 run, zero failures/errors/skips |
| Complete original function | 12 lines; 530 UTF-8 bytes |
| Complete table plus replacement function | **17 lines; 656 bytes** |
| Adoption | **Rejected as compression; keep original** |

The replacement adds five lines (**41.7%**) and 126 bytes (**23.8%**). Counting only its five-line lookup function would conceal the table and wrongly report success. The numeric trend encoding also makes the outcome rules less direct to read. The same behavior was expressed in another form; it was not expressed more economically.

Inspect the [before source](../experiments/self-apply/debt-before.py), [generated table and function](../experiments/self-apply/debt-after.py), [complete diff](../experiments/self-apply/debt.diff) and [raw result with source/test hashes](../experiments/self-apply/debt-result.json). The final [SMT query](../experiments/self-apply/debt-verification.smt2) is retained for replay.

### What is proved and what is tested

The `unsat` result concerns the AST-derived expression and solved symbolic table over real-number ordering plus a Boolean flag for an optional maximum. For this comparison-only function, finite built-in integer/float values have the corresponding ordering; signed zero compares equal. There is no real-arithmetic replacement of floating-point multiplication or rounding here.

The proof remains conditional on the extractor and model. NaN, infinities, overloaded comparisons, arbitrary objects, effects and allocation/resource behavior are outside its declared domain. The emitted Python code has concrete differential and existing-test evidence; we do not claim an independently verified Python compiler or a universal source-level proof. Replaying the SMT query checks the modeled claim, not that the model faithfully captures every Python behavior.

The 810 comparisons enumerate a fixed input grid including negative values, zero, fractional values, large integers and absent thresholds. They are not 810 independent randomized trials; some values compare equal. Likewise, the two 44-test runs reuse the same tests and are not 88 distinct tests or independent observations of repository-wide success.

## Retain unsuccessful attempts in the evidence

| Local attempt | Behavioral evidence | Compression/adoption result |
| --- | --- | --- |
| Standard-library path matching | Existing snapshot suite detects changed scope semantics: 11 failures and 2 errors | Reject despite a shorter function. [Receipt](../experiments/self-apply/glob-result.json). |
| Debt decision table, this pass | Symbolic equivalence within the model; matching concrete cases and existing tests | Reject because the complete candidate grows. |
| Earlier five-record library conversion | 5,404 acceptance/value comparisons; exact diagnostics and full API compatibility not established | Four-line marginal saving insufficient for adoption. [Earlier report](../experiments/leaf-contracts/README.md). |

These are different, manually selected exploratory trials. Do not combine their case counts into a success rate, confidence interval or claim about general agent performance. Selection was not randomized or preregistered. The census is complete for its stated source population; the replacement experiments are not a representative sample of that population.

**Accepted production-line reduction in these attempts: zero.** No product feature, source file, validation rule or existing test was removed. The research apparatus grew; its separate footprint is disclosed above. A solver experiment must justify that support cost through useful subsequent applications rather than claiming the tooling itself as less code.

## What this changes about the next experiment

The original integer sketch is too narrow to serve as Lesscode's general compressor. A local semantic adapter can verify a real classifier, but that does not make a table preferable. This supports keeping at least three alternatives: retain the original, simplify directly, or factor common behavior only when the shared representation amortizes its cost across actual duplication.

The next substantial Lesscode boundary remains record conversion: the earlier [selected-boundary measurements](../experiments/facdrone/selected-parts.md) located 524 `from_dict` method lines in the 1,376-line public contract module. That is an opportunity estimate, not predicted removable code. Compare one whole-boundary candidate with the original, including its schema, adapters and dependencies. Freeze error paths, JSON behavior, invalid-input rejection, constructors and cross-record invariants before editing. Add missing behavioral tests before changing implementation, and retain them regardless of which alternative wins.

For future statistics, retain the full candidate register: admitted, unsupported, solver unknown, test failed, equivalent but larger, and adopted. Report both local and whole-production deltas with unchanged scope. Keep tests separate and disclose any changes to them. Measure readability and maintenance through review or comparable change exercises; do not infer them from line count.

Facdrone was not modified or used as the implementation target. Kiro specifications remain unchanged. This is a credible starting result for empirical development, not evidence that the desired substantial compression has already been achieved.

## Reproduce locally with uv

From Lesscode's root, use the existing Python 3.12 environment (or an installed equivalent through uv):

```powershell
$env:PYTHONPATH=(Resolve-Path src).Path + ';' + (Get-Location).Path
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with z3-solver==4.15.4.0 python docs/experiments/self-apply/debt_trial.py
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with z3-solver==4.15.4.0 python docs/experiments/self-apply/applicability.py
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with matplotlib==3.10.7 python docs/experiments/self-apply/plot_statistics.py
```

Check each exit code. The scripts regenerate their experiment artifacts and perform no production rewrite. Model choices and counterexample order may vary; semantic outcomes and whole-replacement cost are the relevant results. The earlier [515-test full baseline](../experiments/self-apply/baseline-tests.txt) is retained as earlier evidence, not presented as a newly executed full-suite run. This pass reran the 44 relevant tests on both alternatives; the production source was unchanged.

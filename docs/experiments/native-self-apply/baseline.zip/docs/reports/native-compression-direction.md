# From successful trials to a native compression tool

Status: implementation proposal, 2026-11-01. The owner requested a compiled
implementation and excluded hardware and performance from Lesscode's scope.
Rust is recommended below; implementation has not begun and the new Kiro
requirements remain unapproved.

Owner scope decision: **drop first, extend later**. The deferred layers discussed
in the original proposal below are now removed from active delivery, not queued
milestones. Keep the skill, native scope/comparison core and existing project
checks. Retain Python and solver experiments as reference evidence. No generic
policy platform, rewrite engine, solver adapter, pattern-adviser component, MCP,
plugin hooks or specialized backend framework will be built in this slice.
The [current roadmap](../../.kiro/steering/roadmap.md) supersedes extension sequencing
below. Existing implementation and frozen results remain preserved.

## What the experiments justify

The useful hypothesis is **select a complete capability, identify repeated
behavior, replace it with a smaller shared implementation, and count the entire
replacement under unchanged behavior checks**. Function-level minimization is
insufficient: additional small helpers can hide more maintained implementation.

| Frozen trial | Capability LLOC | Decisions | Behavioral evidence | Structural tradeoff |
| --- | --- | --- | --- | --- |
| [ATS01](../experiments/ats-report/README.md) | 298 → 135 (−54.7%) | 76 → 47 | 8,820 matching cases; negative control detected | Functions 3 → 5; internal call depth 1 → 3 |
| [NPU01](../experiments/npu-backends/README.md) | 68 → 47 (−30.9%) | 16 → 8 | 3,168 matching cases; 339 existing tests pass on each version; negative control detected | Functions 8 → 6; error call depth 2 → 3 |

These are two manually selected positive cases, not a discovery success rate,
universal equivalence proof or measured reduction in maintenance effort. The
[two-trial synthesis](capability-compression.md) and earlier rejected experiments
remain the evidence. Do not pool unlike capabilities into a product efficacy
score. Hardware execution and throughput are not missing Lesscode acceptance
gates; they are outside this research question. Preserve software-visible
behavior at the declared boundary, including errors and interaction contracts.

## Ecosystem recommendation

**Use Rust for one native library and CLI, with the agent skill as its workflow
interface.** This is an integration and distribution choice, not a performance
claim. Rust can directly reuse ast-grep's parsing, traversal and structural
matching APIs over tree-sitter. Start with that existing parser stack rather
than implementing an AST compiler or running competing parser frameworks.
[ast-grep core documentation](https://docs.rs/ast-grep-core/latest/ast_grep_core/)

| Option | Fit for this project | Decision |
| --- | --- | --- |
| Rust | Direct reuse of the structural-search library; native CLI with typed records | Recommended; prove integration in the first slice |
| Go | Viable native CLI; official tree-sitter bindings introduce a C interoperability boundary | Alternative if team familiarity outweighs direct Rust library reuse |
| C# Native AOT | Viable native delivery; does not by itself supply the Python/TS analysis substrate | Alternative, not a reason to rebuild the parser/tool integrations |
| Python | Existing tested reference, experiment scripts and solver ecosystem | Retain for research and reference runs through uv; do not port the entire harness |
| TypeScript | Target-language validation and existing project compiler knowledge | Use target-project tools when needed; not the requested native core |

The Go binding documents CGO-related lifetime requirements.
[Official Go binding](https://github.com/tree-sitter/go-tree-sitter)
Microsoft documents native AOT publishing and target-specific deployment.
[Native AOT overview](https://learn.microsoft.com/en-us/dotnet/core/deploying/native-aot/)
These sources establish available integration paths, not a comparative benchmark.
Rust is a judgment about this stack. It still brings compiler/toolchain and
dependency maintenance costs; pin and review its selected dependencies during
design. Native core distribution does not remove a target project's Python,
Node, compiler or test-runner requirements.

## Keep, defer and drop from the new delivery path

| Element | Disposition | Reason |
| --- | --- | --- |
| Frozen trial artifacts, adverse fixtures, behavior checks | Keep | Existing evidence is the starting contract |
| Experimental lesscode-discovery skill | Evolve | Agent selects responsibilities and proposes idiomatic replacements |
| Existing Python evaluator | Keep as reference | No wholesale Rust translation or immediate public CLI replacement |
| Scope, metric identity, evidence completeness and decision precedence | Reuse contracts selectively | Missing evidence must not turn into success |
| ast-grep/tree-sitter | Native structural substrate | Candidate locations and syntax; not semantic proof |
| Lizard/Radon/jscpd | Reference or optional tools | Preserve recorded definitions; avoid mandatory multi-runtime analyzer installation in the new core |
| Repository capability inventory | Keep, once per snapshot | Reuse installed frameworks without per-function dependency proliferation |
| General agent-quality-rules platform | Pause | Derive a small scope policy from trials before resuming the broad engine |
| Codemod orchestration, dedicated language rewrite backends | Defer | Avoid duplicate orchestration until a concrete rewrite needs it |
| Z3/CEGIS/CrossHair | Optional specialist experiments | No demonstrated need as the primary discovery or acceptance engine |
| MCP, plugin hooks, daemon, agent swarm | Defer | CLI plus skill can validate the next hypothesis |
| Per-function compression targets, byte/gzip improvement scores | Drop as decision targets | Easy to improve without removing maintained capability implementation |
| Hardware, latency, throughput, memory-use benchmarking | Exclude | This project studies code compression with preserved software behavior |

“Drop” concerns the new product direction, not deleting historical artifacts or
breaking the current evaluator's contracts. Integrity hashes remain useful;
byte size is not a compression benefit metric. Execution timeouts are operational
bounds, not performance objectives. Windows/Linux/macOS correctness remains a
delivery concern, distinct from hardware benchmarking.

## Small implementation boundary

Proposed layout: a single `native/Cargo.toml` package with a library and thin CLI.
Use ordinary modules and typed data; no plugin registry, generic analyzer trait
hierarchy, database or service framework without demonstrated need.

```mermaid
flowchart LR
  R[Repository snapshot and installed capabilities] --> S[Skill selects complete capability]
  S --> M[Frozen scope and check manifest]
  M --> C[Native inventory and measurements]
  S --> P[Agent proposes isolated candidate]
  P --> C
  C --> V[Existing project checks and differential evidence]
  V --> D[Scoped comparison and review report]
```

The manifest names entry points, owned implementation, wider accounting boundary,
source identities, exclusions and fixed checks. The skill explains the proposed
replacement and what becomes unnecessary. Native code resolves source locations,
reports syntactic relationships and unresolved edges, and accounts for the whole
replacement, including new helpers, tables and changed callers. An unresolved
dynamic call is not evidence that its target is dead.

Report physical lines, versioned logical-statement counts and aggregate decision
counts; show functions, internal call layers and dependency changes as context.
Do not rename a new tree-sitter count “Radon LLOC” or “Lizard CCN.” Either reproduce
the documented definition with fixtures or publish a distinct metric ID and
remeasure both versions. Never compare incompatible definitions.

Validation uses the repository's existing commands and frozen differential
checks. Source/evidence identities bind results to the compared snapshots.
Separate behavior failure, incomplete evidence and insufficient compression.
Passing finite checks is qualified empirical evidence, not universal equivalence.
Existing tests, types, names, validation and API seams remain protected. Counts
support review; they cannot establish readability or maintenance savings alone.

MCP may later wrap these same library operations. An official Rust MCP SDK exists,
so a transport choice need not dictate the first implementation.
[Official Rust MCP SDK](https://github.com/modelcontextprotocol/rust-sdk/blob/main/crates/rmcp/README.md)

## Implementation sequence and stop conditions

1. **Replay one supplied capability pair.** Extract language-neutral scope and
   evidence fixtures from ATS01, plus its behavior-breaking negative control.
   Build only inventory, whole-replacement accounting and comparison. Preserve
   the source project. Match explicitly compatible historical metrics and
   independently verify new metric definitions. No discovery claims yet.
2. **Challenge the boundary.** Reuse NPU01 and rejection cases. Move helpers out
   of the original files, split functions, narrow scope, omit checks and alter
   identities in fixtures. The tool must not reward those manipulations. Report
   production, tests and research support separately. Existing project checks
   continue to run in their existing environments.
3. **Add skill-driven discovery.** Freeze one repository capability inventory;
   select a previously untried capability, record all candidates and rejected
   attempts, and compare the workflow with the existing manual procedure. Require
   a concrete deletion hypothesis before asking an agent to edit.
4. **Exercise TypeScript.** Use an actual typed capability and its native checks.
   Establish language-specific measurement semantics; do not infer TS readiness
   from Python results. Python and TS are targets; Java remains excluded.

Prevention uses the same frozen scope and declared targets for agent proposals;
it is not a fifth platform-building milestone. Scope updates must be explicit,
and function splitting must not improve acceptance. No integration or rule-engine
extension is scheduled.

Stop expansion if results cannot be reproduced, behavior fails, accounting omits
support code, or new tooling duplicates the reference without improving the
workflow. Record the native tool's own production and test footprint against
delivered operations; a language migration is not itself code compression.
The first milestone ends with one end-to-end report and adverse checks, not a
general synthesis platform. Exact tasks follow requirements/design review.

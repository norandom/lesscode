# Synthesis report composition notes

COBESY writing mode, 2026-11-01. Full report requested by the owner.

- Target behavior: compare complete verified alternatives before adopting a compression technique.
- Hidden assumption to test (inferred from the proposal, not an organizational diagnosis): a normalized shared kernel must be smaller and easier to maintain.
- Anchor: the project owner and maintainers reviewing the next empirical case. No wider organization or adoption network was supplied.

Governing claim: equivalent code can still be larger; direct idiomatic expressions must compete with sharing.

Composition blueprint: lead with the measured choice; show the whole-source chart and negative control; explain the mechanism and proof boundary; correct theoretical overclaims; finish with the Facdrone measurement decision. Keep reproduction detail in the experiment specification and raw evidence beside the code.

Disproof: reject a candidate if behavior changes, complete implementation does not shrink, or maintenance exercises expose worse navigation/change effort. Successful synthetic examples do not establish real-repository applicability.

Validation: conclusion precedes theory; figures link to raw evidence; failures remain visible; no blame is assigned to agents or authors; source size is separated from maintenance effort. Behavioral rollout is unnecessary for this report. The point of action is the docs index and README, leading to the next measurement rather than a speculative tool build.

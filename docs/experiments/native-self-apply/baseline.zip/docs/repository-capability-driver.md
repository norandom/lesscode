# One repository capability inventory, shared by local compression agents

Establish the repository's existing capabilities once before distributing local
simplification work. Local agents reuse that evidence and stay within a common
dependency policy. They do not independently choose new frameworks for each
function. The workflow has now been exercised in one [local pilot](experiments/capability-guided/run-01/README.md),
which did not establish additional verified removal from the inventory. It is
not an implemented MCP service.

The outcome-classifier trials found a useful first reduction, then stalled at
60 physical lines despite further complexity changes. The next hypothesis is
that better repository context helps agents identify whole implementations that
can disappear into existing capabilities. More local rewrite rounds alone do
not establish that opportunity.

## Global discovery responsibilities

One discovery subagent performs a multistep, read-only pass. The coordinating
agent owns the resulting inventory and the repository-wide consistency check.

1. Identify workspace/package boundaries. Read build configuration, dependency
   manifests, lockfiles, runtime/platform targets, optional extras, CI setup and
   repository guidance. Do not execute build hooks merely to inspect them.
2. Classify dependencies by role: production runtime, optional runtime, build,
   development/test, analyzer and research-only. Record direct versus transitive
   availability, declared version constraints and actual lock resolution where
   present. Environment installation alone does not authorize production use.
3. Inspect real imports, call sites, internal utilities and existing wrappers.
   Identify established implementations and conventions, including why a wrapper
   may own a required policy or lifecycle boundary.
4. Map relevant operations to existing capabilities. Verify proposed library APIs
   against the project's supported version using local source or official docs.
   Record semantic gaps, such as error handling, ordering, numeric behavior,
   serialization, resource lifetime and platform support. Unknown remains unknown.
5. Publish a small shared inventory and dependency policy, with evidence links
   and fingerprints. Do not create an encyclopedic catalog or prescribe a new
   framework merely because it is familiar to the agent.

The discovery agent does not rewrite source, install product dependencies or
establish behavioral equivalence. Local trials still have to demonstrate that
the chosen existing capability preserves their particular boundary.

## What local agents receive

| Inventory field | Purpose |
| --- | --- |
| Inventory ID and fingerprints | Bind knowledge to manifest, lock, runtime and guidance inputs. |
| Package and deployment boundary | Prevent use of a dependency available only in another workspace or service. |
| Capability ID and operation | Name the behavior supplied, not just a package name. |
| Provider and dependency role | Distinguish standard library, declared runtime dependency, internal implementation and tooling. |
| Supported version/API and evidence | Make the proposed reuse inspectable and version-specific. |
| Existing call sites and preferred implementation | Keep proposals consistent with established repository practice. |
| Semantic differences and exclusions | Record reasons a seemingly similar API may not substitute safely. |
| Confidence and unresolved questions | Prevent speculative knowledge from becoming an assumed contract. |

A local proposal cites capability IDs and states which maintained implementation
will disappear, which adapters remain, and how behavior will be checked. Agents
may report a missing capability for centralized investigation. They must not
silently invent a different provider or promote a development dependency into
the runtime stack.

## Dependency and consistency policy

Prefer the language/standard library, an existing internal implementation, or a
declared runtime capability compatible with the relevant package. These are
options to compare, not a fixed ranking that overrides semantic fit.

New dependencies, upgrades, new extras and reliance on undeclared transitive
packages are repository-level proposals. The coordinator evaluates all affected
callers, licensing, deployment compatibility, integration cost and competing
providers together. A central decision is not blanket authorization to change
dependencies; follow the user's scope and normal project workflow. The next
experiment freezes dependencies entirely so this tradeoff cannot confound it.

Before combining successful local patches, the coordinator checks that they:

- Use the same established provider for the same responsibility where appropriate.
- Do not create competing wrappers or duplicate adapters.
- Preserve package boundaries and runtime availability.
- Count shared helpers only once, including changes to existing callers.
- Pass integration checks together, not only in isolated candidate copies.

## Run once, refresh on evidence changes

Run discovery once for the initial frozen snapshot. Refresh affected entries when
manifests, lockfiles, runtime targets, guidance, cited internal implementations
or relevant call sites change. Manifest hashes alone cannot detect a changed
wrapper contract. Each local proposal records the inventory revision it used;
invalidate stale evidence before accepting the proposal.

```mermaid
flowchart TD
    A[Repository discovery subagent] --> B[Versioned capability inventory and dependency policy]
    B --> C[Local responsibility trials]
    C --> D[Source-derived SMT where supported]
    C --> E[Behavior tests and full replacement measurements]
    D --> F[Repository consistency and integration review]
    E --> F
    C --> G[Unresolved capability request]
    G --> A
    F --> H[Retain candidate or reject with evidence]
```

MCP can later expose inventory lookup, refresh requests, proposal verification
and measurement. The driver is orchestration and shared evidence; MCP is its
interface. First test whether this knowledge produces additional verified code
removal using the [next experiment protocol](experiments/capability-guided/plan.md).

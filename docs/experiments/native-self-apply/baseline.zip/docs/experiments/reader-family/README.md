# Reader-family trial: input, mechanism and first result

**We have a clear bounded experiment, not a general minimization algorithm.** This prototype tests one actual family in Lesscode: strict object-to-record readers. It can remove mechanical repetition without changing the checked behavior, but saves only three lines after adding its helper. Keep it as research; do not adopt the factory into production.

Read the [trial plan](plan.md), written before execution, and the [concrete input](input.json). The [driver](trial.py), [shared-kernel source](reader-kernel.txt), [complete module diff](candidate.diff) and [raw results](result.json) make the trial reproducible. Facdrone and production source remain unchanged.

## What the input should look like

The user supplies a repository and an intended scope, optionally naming the responsibility or tests. The agent derives a candidate family and records its assumptions; the user does not have to prepare an AST or enumerate every member.

The executable trial needs three things:

1. **Source identity and boundary:** actual source, revision/hashes, member symbols, helpers and affected callers.
2. **Compression hypothesis:** the repeated operation, data variations, required behavioral differences, and a concrete alternative expected to remove code.
3. **Behavioral evidence:** baseline tests, representative and adversarial inputs, invariants and explicit exclusions.

Here those become `input.json`, `contracts.py`, the unchanged contract tests and a deterministic differential corpus. An AST alone cannot tell us whether error order matters, whether a wrapper owns a lifecycle, or whether two validators intentionally differ.

## How simplification is driven

```text
Repository + requested scope
  → agent identifies a responsibility and plausible replacement
  → source/AST checks the mechanical family template
  → generate a bounded alternative using a known transformation
  → compare behavior against the original
  → measure the complete replacement
  → keep original or retain a candidate for adoption review
```

The optimization is constrained candidate comparison: among the alternatives actually examined, prefer less maintained implementation only after the behavior and usefulness gates pass. There is no claim of finding the globally smallest program. An LLM or experienced developer still supplies semantic judgments and proposes replacements. AST tools locate and transform structure; tests check executable observations; a solver can prove a supported model when that is relevant.

This trial uses AST pattern matching and a functional reader factory, not SMT. Its source policy includes arbitrary objects, nested validators and diagnostic strings. Encoding all that into the pricing sketch would add machinery without helping this question.

## The concrete family

The original methods repeat:

```python
d = _object(value, path, "path nloc")
return cls(_relative(d["path"], path + ".path"),
           _integer(d["nloc"], path + ".nloc"))
```

The alternative retains the typed dataclass fields and declares the variations:

```python
from_dict = _record_reader('path nloc',
    '_relative', '_integer')
```

The complete factory is included in the cost. It preserves call-time lookup of validators rather than capturing their original functions at import time. This adds a lookup operation and indirection; source reduction alone cannot justify it. It is higher-order reuse of existing validators, not solver synthesis of arbitrary validation semantics.

All **52** `from_dict` methods in the module were inspected mechanically. **Five** matched the fixed template: ResourceIdentity, FileComplexity, ClonePair, EnvironmentInfo and RuntimeBenchmark. **47** were recorded as outside this transformation: 34 have extra statements or a different interface; 13 require parameters, composition or non-field expressions. These categories describe the first refusal, not a complete semantic classification.

## Results

| Measurement | Original | Candidate |
| --- | ---: | ---: |
| Whole five-class family, including dataclass decorators and candidate helper | 63 lines | 60 lines |
| Same family, UTF-8 source bytes | 2,317 | 1,827 |
| Same family, AST nodes | 444 | 291 |
| Entire contracts module | 1,376 lines | 1,373 lines |
| Entire production Python population | 6,589 lines | 6,586 lines, hypothetical |
| Unchanged contract suite | 103 tests passed | Same 103 tests passed |

**1,126 concrete comparisons matched**, including accepted values, canonical JSON output, exact error type names/messages, custom paths, nested invalid fields and multiple invalid fields. Additional checks preserved inherited construction, callable signatures, call-time validator rebinding and rejection of an invalid directly constructed record during serialization. The corpus is finite and deterministic; it is not a proof or 1,126 independent trials.

The apparent 21.1% family byte reduction and 34.5% AST-node reduction become only **three physical lines** when all support is counted: 4.8% of this selected family and approximately 0.046% of production Python. Different source formatting affects physical lines; none of these metrics establishes readability or maintenance benefit.

The original classes, shared validators and other 47 readers remain. No dependency was introduced. Existing tests were not edited. The raw result accounts for the prototype driver separately; that research code is not claimed as a production saving. Exact method qualified names/traceback structure change, and static typing and performance have not been established for the replacement. Those limits prevent a claim of full API equivalence.

**Decision: stop this factory route at prototype scale.** Its useful reduction is too small to justify its indirection and unresolved typing/debugging cost. Actual adopted reduction is zero. This is a correctly scoped family experiment, unlike forcing one compact classifier into a table, but it does not yet demonstrate substantial simplification.

## What is known and what remains open

We now have a concrete input format and a working source → family → candidate → behavioral checks → full-cost comparison cycle. We do not yet have a proven catalogue of transformations that reliably produces substantial compression in grown projects, automatic semantic family discovery, or a general minimizer.

The next trial should compare an existing language/library capability or a simpler whole-operation representation against a larger custom responsibility. Before expanding this reader cohort, show that the new members genuinely share policy and that new adapters will not consume the savings. Do not broaden the factory into a miniature validation framework merely to make it cover all readers. The [reusable procedure](../../compression-procedure.md) drives that selection; the tool does not choose the opportunity by what it happens to support.

Reproduce from Lesscode's root, using the local Python environment through uv:

```powershell
$env:PYTHONPATH=(Resolve-Path src).Path + ';' + (Get-Location).Path
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/reader-family/trial.py
```

The script regenerates the diff and result, tests a complete temporary package, then removes that temporary copy. It checks that production and selected test hashes remain unchanged. No Kiro specification or Facdrone change is part of this prototype.

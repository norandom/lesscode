"""Prototype a whole reader family in a temporary package; preserve diagnostics."""
import ast
from copy import deepcopy
from dataclasses import asdict
import difflib
import hashlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

from lesscode_baseline import contracts as original

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SPEC = json.loads((HERE / "input.json").read_text())
HASH = "a" * 64
VALID = {
    "ResourceIdentity": dict(logical_path="src/a.py", path="/tmp/a.py", content_hash=HASH, size_bytes=0),
    "FileComplexity": dict(path="src/a.py", nloc=0),
    "ClonePair": dict(first=dict(path="a.py", start_line=1, end_line=2), second=dict(path="b.py", start_line=3, end_line=4)),
    "EnvironmentInfo": dict(os="Windows", python="3.12.10", secrets_supplied=False),
    "RuntimeBenchmark": dict(benchmark_id="case", workload_hash=HASH, environment_hash=HASH,
        measurement=dict(status="available", value=1, unit="seconds", source="runner", observed_at="2026-11-01T00:00:00Z", reason=None)),
}
INVALID_VALUES = (None, True, False, -1, 0, 1, 1.5, float("inf"), float("nan"),
                  "", " ", "../x", "x\\y", "x.", "x\x00", [], {}, 10**100)


def template(method):
    if (len(method.body) != 2 or ast.unparse(method.args) != "cls, value, path='$input'"
            or [ast.unparse(d) for d in method.decorator_list] != ["classmethod"]):
        raise ValueError("reader has additional statements or a different interface")
    assignment, result = method.body
    if (not isinstance(assignment, ast.Assign) or [ast.unparse(t) for t in assignment.targets] != ["d"]
            or not isinstance(assignment.value, ast.Call) or ast.unparse(assignment.value.func) != "_object"
            or assignment.value.keywords or len(assignment.value.args) != 3):
        raise ValueError("object boundary differs")
    value, path, field_names = assignment.value.args
    if ast.unparse(value) != "value" or ast.unparse(path) != "path" or not isinstance(field_names, ast.Constant) or not isinstance(field_names.value, str):
        raise ValueError("object boundary is not literal required fields")
    names = field_names.value.split()
    if (not isinstance(result, ast.Return) or not isinstance(result.value, ast.Call)
            or ast.unparse(result.value.func) != "cls" or result.value.keywords
            or len(result.value.args) != len(names)):
        raise ValueError("construction differs")
    readers = []
    for name, call in zip(names, result.value.args):
        if (not isinstance(call, ast.Call) or call.keywords or len(call.args) != 2
                or ast.unparse(call.args[0]) != f"d[{name!r}]"
                or ast.unparse(call.args[1]) != f"path + {('.' + name)!r}"
                or not isinstance(call.func, (ast.Name, ast.Attribute))):
            raise ValueError("field policy needs parameters, composition or non-field expressions")
        readers.append(ast.unparse(call.func))
    return field_names.value, readers


def outcomes(module, name, value, prefix):
    try:
        record = getattr(module, name).from_dict(deepcopy(value), path=prefix)
        return "accepted", asdict(record), module.dumps(record)
    except (ValueError, TypeError, OverflowError) as error:
        return "rejected", type(error).__name__, str(error)


def mutations(value):
    yield deepcopy(value)
    yield {**deepcopy(value), "unknown": 1}
    for key in value:
        yield {k: deepcopy(v) for k, v in value.items() if k != key}
        for replacement in INVALID_VALUES:
            yield {**deepcopy(value), key: deepcopy(replacement)}
        if isinstance(value[key], dict):
            for nested in mutations(value[key]):
                yield {**deepcopy(value), key: nested}
    for left, right in zip(value, list(value)[1:]):
        yield {**deepcopy(value), left: None, right: None}


def counts(source):
    return {"physical_lines": len(source.splitlines()), "utf8_bytes_lf": len(source.encode()),
            "ast_nodes": sum(1 for _ in ast.walk(ast.parse(source)))}


def tests(source_root):
    environment = {**os.environ, "PYTHONPATH": str(source_root) + os.pathsep + str(ROOT), "PYTHONDONTWRITEBYTECODE": "1"}
    result = subprocess.run([sys.executable, "-m", "unittest", *SPEC["checks"], "-q"], cwd=ROOT,
                            env=environment, capture_output=True, text=True, timeout=120)
    return {"exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


if __name__ == "__main__":
    source_path = ROOT / SPEC["source"]
    raw = source_path.read_bytes()
    source = raw.decode("utf-8").replace("\r\n", "\n")
    production_paths = sorted((ROOT / "src").rglob("*.py"))
    production_hashes = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in production_paths}
    tree = ast.parse(source)
    cohort, excluded, spans = {}, [], []
    for record in (n for n in tree.body if isinstance(n, ast.ClassDef)):
        for method in (n for n in record.body if isinstance(n, ast.FunctionDef) and n.name == "from_dict"):
            try:
                fields, readers = template(method)
            except ValueError as error:
                excluded.append({"record": record.name, "reason": str(error)})
            else:
                cohort[record.name] = {"fields": fields, "readers": readers}
                declaration = f"    from_dict = _record_reader({fields!r},\n        " + ", ".join(repr(r) for r in readers) + ")\n"
                spans.append((method.decorator_list[0].lineno - 1, method.end_lineno, declaration))
    assert set(cohort) == set(SPEC["members"]) == set(VALID), cohort
    baseline_tests = tests(ROOT / "src")
    assert baseline_tests["exit_code"] == 0, baseline_tests
    test_hashes = {name: hashlib.sha256((ROOT / (name.replace(".", "/") + ".py")).read_bytes()).hexdigest() for name in SPEC["checks"]}
    lines = source.splitlines(True)
    for start, end, replacement in sorted(spans, reverse=True):
        lines[start:end] = [replacement]
    kernel = (HERE / "reader-kernel.txt").read_text()
    assert "def _record_reader(" not in source
    candidate_source = "".join(lines).replace("class Record:", kernel + "\n\nclass Record:", 1)
    mismatches, comparisons = [], 0
    with tempfile.TemporaryDirectory(prefix="lesscode-reader-") as temporary:
        candidate_root = Path(temporary) / "src"
        shutil.copytree(ROOT / "src", candidate_root, ignore=shutil.ignore_patterns("__pycache__"))
        candidate_path = candidate_root / "lesscode_baseline/contracts.py"
        candidate_path.write_text(candidate_source, encoding="utf-8")
        spec = importlib.util.spec_from_file_location("reader_candidate", candidate_path)
        candidate = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = candidate
        spec.loader.exec_module(candidate)
        for name, valid in VALID.items():
            for value in [None, [], True, *mutations(valid)]:
                for prefix in ("$input", "$.custom[2]"):
                    comparisons += 1
                    old, new = outcomes(original, name, value, prefix), outcomes(candidate, name, value, prefix)
                    if old != new:
                        mismatches.append({"record": name, "input": repr(value), "original": repr(old), "candidate": repr(new)})
            for module in (original, candidate):
                child = type("Child", (getattr(module, name),), {})
                assert type(child.from_dict(valid)) is child
            assert inspect.signature(getattr(original, name).from_dict) == inspect.signature(getattr(candidate, name).from_dict)
        for module in (original, candidate):
            try:
                module.FileComplexity("a.py", -1).to_dict()
            except module.ContractError as error:
                assert str(error) == "$input.nloc: expected integer >= 0"
            else:
                raise AssertionError("direct construction bypassed serialization validation")
            with patch.object(module, "_relative", side_effect=module.ContractError("rebound validator")):
                assert outcomes(module, "FileComplexity", VALID["FileComplexity"], "$input") == ("rejected", "ContractError", "rebound validator")
        candidate_tests = tests(candidate_root)
    def family(text):
        parsed = ast.parse(text)
        lines = text.splitlines()
        return "\n\n".join("\n".join(lines[min([n.lineno, *(d.lineno for d in n.decorator_list)]) - 1:n.end_lineno])
                           for n in parsed.body if isinstance(n, ast.ClassDef) and n.name in cohort)
    original_family = family(source)
    candidate_family = kernel + "\n\n" + family(candidate_source)
    production = [counts(p.read_text(encoding="utf-8-sig")) for p in production_paths]
    result = {"source_sha256_raw": hashlib.sha256(raw).hexdigest(), "input_sha256": hashlib.sha256((HERE / "input.json").read_bytes()).hexdigest(),
              "candidate_sha256_lf": hashlib.sha256(candidate_source.encode()).hexdigest(),
              "kernel_sha256": hashlib.sha256((HERE / "reader-kernel.txt").read_bytes()).hexdigest(),
              "test_hashes": test_hashes, "cohort": cohort, "exclusions": excluded,
              "comparisons": comparisons, "mismatch_count": len(mismatches), "mismatches": mismatches[:20],
              "baseline_tests": baseline_tests, "candidate_tests": candidate_tests,
              "family_before": counts(original_family), "family_after_including_kernel": counts(candidate_family),
              "module_before": counts(source), "module_after": counts(candidate_source),
              "production_before": {key: sum(m[key] for m in production) for key in production[0]},
              "production_after": {key: sum(m[key] for m in production) - counts(source)[key] + counts(candidate_source)[key] for key in production[0]},
              "production_hashes": production_hashes,
              "production_line_delta": len(candidate_source.splitlines()) - len(source.splitlines()),
              "prototype_driver": counts(Path(__file__).read_text()),
              "limits": ["Finite deterministic corpus, not proof", "Exact method qualnames/tracebacks and static typing not preserved or established", "Performance not measured", "Prototype only; no production adoption"],
              "production_modified": False, "adopted_net_reduction": 0}
    assert source_path.read_bytes() == raw
    assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest for name, digest in production_hashes.items())
    assert all(hashlib.sha256((ROOT / (name.replace('.', '/') + '.py')).read_bytes()).hexdigest() == digest for name, digest in test_hashes.items())
    (HERE / "candidate.diff").write_text("".join(difflib.unified_diff(source.splitlines(True), candidate_source.splitlines(True), fromfile=SPEC["source"], tofile="candidate/" + SPEC["source"])), encoding="utf-8")
    (HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in ("exclusions", "cohort", "test_hashes", "production_hashes")}, indent=2))
    assert not mismatches and candidate_tests["exit_code"] == 0, "Candidate failed; see result.json"

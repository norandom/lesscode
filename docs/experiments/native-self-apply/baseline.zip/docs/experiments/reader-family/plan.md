# Trial plan: factor a real family of record readers

Written before running this prototype, 2026-11-01. Source inspection informed the selection; this is an exploratory trial, not a randomized benchmark or a formal Kiro specification amendment.

## Question and hypothesis

Can repeated **object-shape checking → ordered field validation → typed construction** be expressed once, with each record declaring only field and validator names, while preserving the existing observable contract?

The candidate keeps named dataclass fields, existing validator implementations and all records. It replaces mechanically repeated classmethod bodies with one classmethod factory plus per-record declarations. The original remains an alternative. No new validation framework, solver, MCP server or production dependency is needed for this bounded test.

## Input: source, a family description and a behavior boundary

The input is [input.json](input.json), the referenced working-tree source and unchanged tests. Source hashes are captured in the result before transformation. Users do not need to supply ASTs.

The input specifies the responsibility, member symbols, common operation, behavioral obligations and accounting scope. AST parsing checks the proposed mechanical template and locates exact replacement spans. It does not infer that fields are interchangeable or prove that a generic reader is useful.

This first cohort contains `ResourceIdentity`, `FileComplexity`, `ClonePair`, `EnvironmentInfo` and `RuntimeBenchmark` in `contracts.py`. Inspection found the same two-statement reader shape with two-argument field validators. All members of this exact supported template in that module must be reported; do not select only those that save lines.

Keep readers with nullable/sequence adapters, validator parameters, precomputed values, conditionals or cross-field invariants out of this first transformation. Record each exclusion. These are potentially separate cohorts, not intrinsically incompressible code.

## Fixed boundary

- Preserve accepted values, nested record values, deterministic JSON and returned record classes.
- Preserve missing/unknown-field errors, exact diagnostic messages and custom path prefixes, first-error ordering and invalid input rejection.
- Preserve direct construction and subsequent serialization validation, inherited classmethod construction and call-time validator lookup.
- Retain method name and callable signature; record static typing, reflection/traceback metadata and performance as unresolved unless explicitly checked.
- Do not edit production code, existing tests, user changes or Facdrone. Build the complete candidate package in a temporary directory and retain its diff.

## Prototype sequence and budget

1. Enumerate every `from_dict` method in the source module; match the strict cohort template and record exclusions.
2. Freeze corpus and run the original contract tests. Baseline failures stop candidate assessment.
3. Generate one factory-based candidate, preserving all other source text. No iterative search for a smaller-looking format.
4. Compare exact success outputs and error type names/messages on deterministic valid and adversarial cases, custom error paths, nested fields and simultaneous invalid fields. Check inheritance and validator rebinding explicitly.
5. Run the same five contract-test modules against the isolated candidate package. Do not modify the tests.
6. Measure all five class definitions plus the entire shared factory; also report complete module and production-package deltas. Count existing shared validators on both sides, without claiming their removal. Keep test/experiment source separate.

Budget: one source module, one exact template, one candidate, at most 120 seconds for each test process. Unsupported shapes remain exclusions instead of triggering new infrastructure.

## Decision and subsequent trials

Behavior mismatch rejects this prototype. Passing checks only establishes a candidate for review. A local reduction must still be useful after accounting for declarations, helper code, static typing, debugging and integration costs. Do not adopt a marginal or opaque factory just to obtain a positive statistic.

If this cohort succeeds behaviorally, use its actual break-even result to decide whether another observed cohort warrants investigation. Before expanding, establish its distinct behavior and new support cost. Do not extrapolate the cohort's reduction percentage to all 524 reader-method lines.

The larger trial sequence is: establish the repeated kernel on one real family; compare direct/native/library alternatives for the complete responsibility; verify interfaces and whole-replacement cost; only then consider a production patch and full regression run. A general-purpose minimizer is not yet established.

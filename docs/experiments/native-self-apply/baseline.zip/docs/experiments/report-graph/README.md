# Graph-guided compression: preserve the original

The joint rewrite passed the behavioral checks but increased logical code from
69 to 73 LLOC. The local rewrite reached 70. Neither meets the preregistered
acceptance rule, so neither is adopted. This trial supports using a graph to
identify verification obligations; it does not demonstrate a compression gain.

## Whole replacements, not selected savings

The measured subgraph contains `_json_unique`, `_read_check_report`,
`_add_check_status` and `_validate_junit_tree` from Lesscode's report ingestion.
Every changed collector and caller counts. The full module is measured separately.

| Candidate | Subgraph physical lines | Subgraph LLOC | Subgraph CCN sum | Module physical lines | Module LLOC | Module CCN sum |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Original | 85 | 69 | 44 | 359 | 271 | 61 |
| Local rewrite | 82 | 70 | 42 | 356 | 272 | 59 |
| Joint rewrite | 84 | 73 | 42 | 358 | 275 | 59 |

Physical lines use source line counts; subgraph spans exclude gaps between
functions. LLOC uses Radon 6.0.1; CCN sums Lizard 1.17.31 function measurements.
Lower CCN and fewer physical lines did not yield less logical code here.
The joint rewrite costs two physical lines and three LLOC more than the local one.
No byte score or inferred maintenance-hours saving is used.

## What the graph exposed

```mermaid
flowchart TD
    E[Execute check and retain raw artifacts] --> R[Read report]
    R --> J[JSON fields and typed records]
    R --> V[Validate JUnit structure]
    V --> V
    R --> I[Admit identities and statuses]
    R --> C[Reconcile suite counts]
    V -. complete validation before .-> I
    I -. complete identities before .-> C
    V -. joint proposal: complete outcome sets .-> C
```

The recursive validator is one coupled unit. A leaf-to-root ordering alone is
insufficient: edges must also record data content, error precedence and effects.
The caller retains original report bytes; the parser must preserve ordered
statuses and exception type/message. Complexity need not grow toward the root.

The local proposal replaces explicit status/count expressions inside the reader
with literal mappings. The joint proposal also makes the validator return a map
of testcase elements to their complete direct-child tag sets. The reader reuses
that map for status selection and count reconciliation. This removes repeated
tag extraction, but collecting and combining the map costs more code than it
removes. Its memory/runtime effects were not benchmarked.

One testcase can contain both `failure` and `error`. Its selected status is
`error`, yet it contributes to both suite counts. A single selected outcome
cannot replace the complete evidence set. A deliberately broken variant that
retains only the selected outcome produced 176 mismatches. For example, a valid
two-case suite with one failure and one error marker on the same case incorrectly
raised `JUnit failures count does not match testcase evidence`.

## Verification and its limits

| Version | Generated comparisons | Mismatches | Unchanged integration tests |
| --- | ---: | ---: | --- |
| Original | Reference | N/A | 18 passed, 17.837 s |
| Local | 6,234 | 0 | 18 passed, 17.480 s |
| Joint | 6,234 | 0 | 18 passed, 17.657 s |
| Deliberate outcome-collapse mutant | 6,234 | 176 | Not run |

The fixed corpus combines outcome subsets, identities, nesting, suite counts,
status attributes, malformed/unsupported XML, encodings, DTD cases and normalized
JSON inputs. Comparisons check ordered results or exact exception type/message.
The unchanged `tests.test_checks` and `tests.test_fixtures` suites exercise the
real execution/report path, including artifact retention and failures. Logs
identify the loaded snapshot and end in `OK`. The times are observations from
concurrent runs, not performance comparisons.

These are finite tests, not a universal equivalence proof. There is no faithful
SMT model of this parser's XML, exception and effect semantics in this trial.
The deliberate mutant tests one information-loss hazard; 176 mismatches are not
a mutation score. The entire repository suite was not run for these rejected,
isolated proposals.

One agent authored both proposals sequentially. This is a mechanism experiment,
not a blinded or independent comparison of agent effectiveness. The
[plan](plan.md) fixed scope and acceptance before candidate construction. Both
physical lines and LLOC had to decrease after behavioral validation; neither did.

## What carries into the next trial

Keep the graph as a small map of responsibilities and obligations. Before
rewriting a connected region, name the implementation that can disappear and
the existing capability or shared expression that replaces it. Repeated traversal
alone was an inadequate deletion hypothesis here.

Use two graphs: the code graph above identifies affected responsibilities; the
task graph orders evidence collection. A validator change invalidates reader,
count and caller evidence, so passing leaf tests cannot certify the replacement.

```mermaid
flowchart LR
    A[Freeze source and checks] --> B[Record edge obligations]
    B --> C[Save local and joint proposals]
    C --> D[Differential comparisons]
    D --> E[Caller integration tests]
    E --> F[Whole replacement metrics]
    F --> G[Retain or reject]
```

Do not build a graph scheduler or another solver from this result. A subsequent
trial should select a connected region with a concrete removable implementation,
then test whether joint work saves more than isolated work. No additional trial
or product implementation is included here.

## Evidence and reproduction

- [Frozen inputs](inputs.json): 339 fingerprints, including source, tests and
  earlier experiment evidence; [results](result.json) record no changed inputs.
- [Original source](original/process.py.txt), [local diff](local/candidate.diff),
  [joint diff](joint/candidate.diff), and [deliberate mutant](joint/collapse-mutant.py.txt).
- Native logs: [original](original/tests.log), [local](local/tests.log),
  [joint](joint/tests.log).
- [Candidate builder](build.py) and [trial runner](trial.py): 51 and 142 physical
  lines respectively, 193 research-code lines added. Archived module copies are
  separate evidence, not product-code savings. Production and test code edits: zero.

From the repository root, using the existing local uv-managed interpreter:

```powershell
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/report-graph/trial.py
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/report-graph/trial.py original
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/report-graph/trial.py local
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/report-graph/trial.py joint
```

The first command regenerates `result.json` and the deliberate mutant; copy the
experiment directory first to preserve this run. Do not rerun `build.py` against
an existing manifest. Production, dependencies, prior trial evidence and Facdrone
were not changed by this experiment.

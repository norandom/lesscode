# Report-ingestion graph trial

Written before candidate construction. Compare one-node simplification with a
joint rewrite of JUnit validation and report assembly. No production adoption,
new dependency, Facdrone change or graph-processing framework is proposed.

The existing stack inventory remains applicable to unchanged dependencies and
existing contract/process providers; this pass inspects the report parser that
the earlier inventory did not characterize. Use Python 3.12's existing XML and
JSON APIs. No new API capability is assumed.

## Code graph and edge obligations

| Vertex | Source responsibility | Output / obligation |
| --- | --- | --- |
| E | `execute_check` | Execute, retain raw bytes, catch parser errors and construct declared check evidence. |
| R | `_read_check_report` | Decode JSON or XML, validate bindings, preserve identities/statuses and error order. |
| J | `_json_unique` / `CheckEvidence.from_dict` | Reject duplicate JSON fields and malformed/badly bound records. |
| V | `_validate_junit_tree` | Reject unsupported hierarchy/outcomes and executable nodes inside metadata. |
| I | `_add_check_status` | Duplicate identity precedes undeclared identity; insertion order preserved. |
| C | Suite-count reconciliation inside R | Count presence of each outcome independently, even when multiple markers coexist. |

Call edges: E to R; R to J, V, I and C; V to V (recursive self-cycle).
V's recursion is one coupled unit, not a falsely acyclic collection of leaves.
Ordering/data edges: complete V validation precedes identity errors; identity
validation precedes C; raw XML is retained unchanged at E. Graph edges therefore
carry ordering and data obligations, not merely dependency or complexity scores.

```mermaid
flowchart TD
 E[execute_check: retained artifacts and evidence] --> R[read report]
 R --> J[JSON fields and typed records]
 R --> V[JUnit structural validation]
 V --> V
 R --> I[Identity/status admission]
 R --> C[Suite counts]
 V -. must complete before .-> I
 I -. must complete before .-> C
 V -. joint candidate: complete outcome sets .-> C
```

## Hypotheses and fixed comparison

Local candidate: simplify outcome selection/count reconciliation inside R alone,
using a small literal field mapping; preserve interfaces and all other vertices.

Joint candidate: V returns the complete direct-child tag sets for validated
testcases. R reuses those sets for status selection and suite reconciliation,
removing repeated outcome extraction across V/R/C. Count every new collector and
changed caller. A single winning status is insufficient to represent counts.

This is a sequential, single-agent mechanism trial, not a blinded comparison of
LLMs or evidence that a graph scheduler causes better performance. At most one
local and one joint candidate, plus a deliberately incorrect outcome-collapse
mutant to challenge verification. Both candidates share the same frozen source,
tests, dependencies, generated inputs and measurement definitions. Preserve all
artifacts; do not tune the test population after seeing a mismatch.

## Task graph and acceptance

Freeze inputs -> capture node contracts and ordering -> save candidates -> compare
returned ordered statuses or exact exception type/message on the same inputs ->
run unchanged check/fixture tests -> measure complete parser subgraph and module.
Changes to V invalidate R/C evidence and E integration checks; leaf tests alone
cannot certify the joint candidate. There is no faithful SMT model of this XML
parser here, so use finite differential tests, not an equivalence-proof claim.

Include XML outcome subsets, bad names/identities, nested suites, count mismatch,
unsupported nodes/status attributes, malformed encodings/DTD and competing
defects. Include normalized JSON valid/invalid reports so an XML edit cannot
silently change the other input path. Verify the intentional mutant is caught.

Qualify only if behavior checks pass and both complete physical lines and Radon
LLOC decrease, with readable names/control flow. A graph advantage requires more
useful whole-replacement removal than the local candidate. Count node spans,
module, tests and research scripts separately. No byte score, fixed CCN cap,
runtime claim, maintenance-hours claim or fixed reduction percentage.

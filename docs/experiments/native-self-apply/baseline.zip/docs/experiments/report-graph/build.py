"""Save two bounded proposals; never edit the production module."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
source = ROOT / "src/lesscode_baseline/process.py"
original = source.read_text(encoding="utf-8")
assert not (HERE / "inputs.json").exists(), "Use a new run directory for new proposals"
protected = [p for name in ("src", "tests", "docs/experiments/capability-guided/run-01", "docs/experiments/outcome-hotspot", "docs/experiments/outcome-llm")
             for p in (ROOT / name).rglob("*") if p.is_file() and "__pycache__" not in p.parts]
protected += [ROOT / "pyproject.toml", ROOT / "requirements-tools.lock", ROOT / "tools/package-lock.json"]
(HERE / "inputs.json").write_text(json.dumps({p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                                              for p in protected}, indent=2) + "\n")
local = original.replace('''            status = ("error" if case.find("error") is not None else
                      "failed" if case.find("failure") is not None else
                      "skipped" if case.find("skipped") is not None else "passed")''',
'''            status = next((status for tag, status in (("error", "error"), ("failure", "failed"), ("skipped", "skipped"))
                           if case.find(tag) is not None), "passed")''')
local = local.replace('''            for field, actual in (("tests", len(cases)),
                    ("failures", sum(c.find("failure") is not None for c in cases)),
                    ("errors", sum(c.find("error") is not None for c in cases)),
                    ("skipped", sum(c.find("skipped") is not None for c in cases))):''',
'''            for field, tag in (("tests", None), ("failures", "failure"), ("errors", "error"), ("skipped", "skipped")):
                actual = len(cases) if tag is None else sum(c.find(tag) is not None for c in cases)''')
assert local != original
joint = local.replace('        _validate_junit_tree(tree)\n        for case in tree.iter("testcase"):',
                      '        outcome_tags = _validate_junit_tree(tree)\n        for case in outcome_tags:')
joint = joint.replace('if case.find(tag) is not None), "passed")', 'if tag in outcome_tags[case]), "passed")')
joint = joint.replace('sum(c.find(tag) is not None for c in cases)', 'sum(tag in outcome_tags[c] for c in cases)')
joint = joint.replace('    """Support explicit testcase outcome elements; reject ambiguous dialects."""',
                      '    """Validate the whole tree before returning direct testcase outcome tags."""\n    outcome_tags = {}')
joint = joint.replace('                _validate_junit_tree(child)', '                outcome_tags.update(_validate_junit_tree(child))')
joint = joint.replace('''        if element.get("status") == "failed" and not any(
                child.tag in ("failure", "error") for child in element):''',
'''        outcome_tags[element] = {child.tag for child in element}
        if element.get("status") == "failed" and not outcome_tags[element] & {"failure", "error"}:''')
joint = joint.replace('            raise ContractError(f"JUnit executable elements inside {child.tag} are forbidden")',
                      '            raise ContractError(f"JUnit executable elements inside {child.tag} are forbidden")\n    return outcome_tags')
for name, text in (("original", original), ("local", local), ("joint", joint)):
    ast.parse(text)
    directory = HERE / name
    directory.mkdir()
    (directory / "process.py.txt").write_text(text, encoding="utf-8", newline="\n")
    if name != "original":
        (directory / "candidate.diff").write_text("".join(difflib.unified_diff(original.splitlines(True), text.splitlines(True),
            fromfile="original/process.py", tofile=name + "/process.py")), encoding="utf-8")
print("Frozen original, local and joint proposals")

"""One fixed corpus for local and joint proposals; no production writes."""
import ast
from itertools import product
import hashlib
import json
from pathlib import Path
import sys
from types import ModuleType
import unittest
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]
from lesscode_baseline import contracts as c
import lesscode_baseline


def load(name, text=None):
    path = HERE / name / "process.py.txt"
    module = ModuleType("lesscode_baseline.process")
    module.__package__, module.__file__ = "lesscode_baseline", str(path)
    exec(compile(text if text is not None else path.read_text(), str(path), "exec"), vars(module))
    return module


if len(sys.argv) > 1:
    name = sys.argv[1]
    module = load(name)
    sys.modules["lesscode_baseline.process"] = module
    lesscode_baseline.process = module
    print("Parser module:", module.__file__, flush=True)
    suite = unittest.defaultTestLoader.loadTestsFromNames(["tests.test_checks", "tests.test_fixtures"])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())

import lizard
from radon.raw import analyze

original, local, joint = [load(name) for name in ("original", "local", "joint")]
mutant_source = (HERE / "joint/process.py.txt").read_text().replace(
    "        for case in outcome_tags:",
    '        outcome_tags = {case: next(({tag} for tag in ("error", "failure", "skipped") if tag in tags), set())\n'
    '                        for case, tags in outcome_tags.items()}\n        for case in outcome_tags:')
(HERE / "joint/collapse-mutant.py.txt").write_text(mutant_source)
mutant = load("joint", mutant_source)
command = c.CommandSpec("check", ("python",), ".", {}, c.Limits(1, 8192))
specs = {fmt: c.CheckSpec("check", "native", True, command, "result", fmt, ("one", "two", "suite.one"))
         for fmt in ("junit", "normalized")}


def outcome(module, raw, fmt):
    try:
        return ["returned", list(module._read_check_report(raw, specs[fmt], "a" * 64, "b" * 64).items())]
    except Exception as error:
        return ["raised", type(error).__name__, str(error)]


def corpus():
    tags = ("failure", "error", "skipped")
    subsets = [tuple(tag for i, tag in enumerate(tags) if mask & (1 << i)) for mask in range(8)]
    for left, right, names, wrapper, counts, status in product(subsets, subsets,
            (("one", "two"), ("one", "one"), ("one", "foreign"), ("", "two")),
            ("flat", "nested"), ("absent", "correct", "bad", "not_integer"), (None, "failed", "notrun")):
        suite = ET.Element("testsuite")
        for index, (name, markers) in enumerate(zip(names, (left, right))):
            case = ET.SubElement(suite, "testcase", name=name)
            if index == 0 and status is not None:
                case.set("status", status)
            for tag in markers:
                ET.SubElement(case, tag)
        if counts != "absent":
            suite.attrib.update(tests="2", failures=str(("failure" in left) + ("failure" in right)),
                                errors=str(("error" in left) + ("error" in right)),
                                skipped=str(("skipped" in left) + ("skipped" in right)))
            if counts == "bad":
                suite.set("failures", "99")
            if counts == "not_integer":
                suite.set("tests", "not-an-integer")
        root = suite
        if wrapper == "nested":
            root = ET.Element("testsuites")
            parent = ET.SubElement(root, "testsuite")
            parent.append(suite)
        yield "junit", ET.tostring(root)
    for xml in ('<testsuite><testcase name=""/><unknown/></testsuite>',
                '<testsuite tests="99"><testcase name="foreign"/></testsuite>',
                '<testsuite><testcase name="one"/><testcase name="one"/><unknown/></testsuite>',
                '<testsuite><properties><testcase name="one"/></properties></testsuite>',
                '<testsuite><testcase name="one"><failure><testcase name="two"/></failure></testcase></testsuite>',
                '<testsuite><testcase classname="suite" name="one"/></testsuite>',
                '<testsuite><testcase name="one"><disabled/></testcase></testsuite>',
                '<!DOCTYPE testsuite><testsuite/>', '<testsuite>', '<other/>', '<testsuite/>'):
        for encoding in ("utf-8", "utf-16", "utf-32"):
            yield "junit", xml.encode(encoding)
    record = dict(check_id="one", status="passed", kind="native", required=True,
                  source_hash="a" * 64, plan_hash="b" * 64, diagnostic_artifact=None)
    for value in ([], [record], [record, record], {}, None, [True]):
        yield "normalized", json.dumps(value).encode()
    for key in record:
        for value in (None, "", "foreign", True, 0, [], {}):
            yield "normalized", json.dumps([{**record, key: value}]).encode()
    yield "normalized", b'[{"check_id":"one","check_id":"two"}]'
    yield "normalized", b'['


stats = {name: {"cases": 0, "mismatches": 0, "examples": []} for name in ("local", "joint", "mutant")}
corpus_hash = hashlib.sha256()
for number, (fmt, raw) in enumerate(corpus()):
    corpus_hash.update(fmt.encode() + len(raw).to_bytes(8, "big") + raw)
    expected = outcome(original, raw, fmt)
    for name, module in (("local", local), ("joint", joint), ("mutant", mutant)):
        actual = outcome(module, raw, fmt)
        stats[name]["cases"] += 1
        if actual != expected:
            stats[name]["mismatches"] += 1
            if len(stats[name]["examples"]) < 3:
                stats[name]["examples"].append(dict(case=number, format=fmt, raw_hex=raw.hex(), expected=expected, actual=actual))


def metrics(text):
    functions = lizard.analyze_file.analyze_source_code("process.py", text).function_list
    return dict(physical=len(text.splitlines()), lloc=analyze(text).lloc,
                ccn_sum=sum(f.cyclomatic_complexity for f in functions))


measurements = {}
for name in ("original", "local", "joint"):
    text = (HERE / name / "process.py.txt").read_text()
    nodes = [node for node in ast.parse(text).body if getattr(node, "name", None) in
             ("_json_unique", "_read_check_report", "_add_check_status", "_validate_junit_tree")]
    lines = text.splitlines(True)
    selected = "".join("".join(lines[node.lineno - 1:node.end_lineno]) for node in nodes)
    measurements[name] = {"module": metrics(text), "parser_subgraph": metrics(selected)}
protected = json.loads((HERE / "inputs.json").read_text())
changed = [path for path, fingerprint in protected.items() if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != fingerprint]
result = dict(comparisons=stats, corpus_sha256=corpus_hash.hexdigest(), measurements=measurements,
              changed_protected_inputs=changed, preserved_input_count=len(protected), versions={"python": sys.version, "lizard": "1.17.31", "radon": "6.0.1"})
(HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"comparisons": {n: {k: v for k, v in s.items() if k != "examples"} for n, s in stats.items()}, "measurements": measurements}, indent=2))
assert not changed
assert stats["mutant"]["mismatches"] > 0

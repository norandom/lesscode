"""Source-derived final-decision verification, not a whole-Python proof."""
import ast
import json
from pathlib import Path
import z3

HERE = Path(__file__).resolve().parent


def expression(node, env):
    match node:
        case ast.Constant(value=value):
            return z3.BoolVal(value) if isinstance(value, bool) else z3.StringVal(value)
        case ast.Name(id=name):
            return env[name]
        case ast.Attribute():
            return env[ast.unparse(node)]
        case ast.Tuple(elts=items):
            return [expression(item, env) for item in items]
        case ast.IfExp(test=test, body=yes, orelse=no):
            return z3.If(expression(test, env), expression(yes, env), expression(no, env))
        case ast.UnaryOp(op=ast.Not(), operand=value):
            return z3.Not(expression(value, env))
        case ast.BoolOp(op=op, values=values):
            return (z3.And if isinstance(op, ast.And) else z3.Or)(*[expression(v, env) for v in values])
        case ast.Compare(left=left, ops=[op], comparators=[right]):
            left, right = expression(left, env), expression(right, env)
            if isinstance(op, ast.Eq):
                return left == right
            if isinstance(op, (ast.In, ast.NotIn)):
                member = z3.Or(*[left == value for value in right])
                return z3.Not(member) if isinstance(op, ast.NotIn) else member
    raise ValueError("unsupported expression: " + ast.dump(node))


def statements(nodes, env):
    env = env.copy()
    for node in nodes:
        match node:
            case ast.Assign(targets=[ast.Name(id=name)], value=value):
                env[name] = expression(value, env)
            case ast.If(test=test, body=body, orelse=otherwise):
                condition = expression(test, env)
                yes, no = statements(body, env), statements(otherwise, env)
                env = {key: z3.If(condition, yes[key], no[key]) for key in env}
            case _:
                raise ValueError("unsupported statement: " + ast.dump(node))
    return env


def parse_tail(filename, starting_name):
    function, = ast.parse((HERE / filename).read_text()).body
    start = next(i for i, node in enumerate(function.body) if isinstance(node, ast.Assign)
                 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == starting_name)
    assert isinstance(function.body[-1], ast.Return)
    return function.body[start:-1]


invalid, exhausted, complete = z3.Bools("invalid exhausted complete")
baseline, recorded, behavior = z3.Strings("baseline recorded behavior")
env = {"invalid": invalid, "record.budget_exhausted": exhausted, "required_complete": complete,
       "baseline": baseline, "run.decision": recorded, "behavior": behavior, "decision": recorded}
before = statements(parse_tail("original.py.txt", "decision"), env)
nodes = parse_tail("candidate.py.txt", "decisions")
assert len(nodes) == 2 and ast.unparse(nodes[1]) == (
    "decision = next((value for applies, value in decisions if applies), run.decision)")
candidate_function, = ast.parse((HERE / "candidate.py.txt").read_text()).body
normalization = next(node.value for node in candidate_function.body if isinstance(node, ast.Assign)
                     and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "behavior")
assert isinstance(normalization, ast.IfExp) and ast.unparse(normalization.test) == "invalid"
# Abstract the non-invalid behavior computation at the declared proof boundary.
normalization.orelse = ast.Name(id="behavior", ctx=ast.Load())
candidate_env = {**env, "behavior": expression(normalization, env)}
rules = expression(nodes[0].value, candidate_env)


def ordered_decision(pairs):
    result = recorded
    for guard, value in reversed(pairs):
        result = z3.If(guard, value, result)
    return result


domain = z3.And(z3.Or(*[baseline == value for value in ("passed", "missing", "invalid", "ineligible")]),
                z3.Or(*[recorded == value for value in ("accepted", "rejected", "invalid", "incomplete", "baseline_ineligible")]),
                z3.Or(*[behavior == value for value in ("passed", "failed", "incomplete")]))


def query(name, condition):
    solver = z3.Solver()
    solver.set(timeout=10000)
    solver.add(domain, condition)
    (HERE / (name + ".smt2")).write_text(solver.to_smt2(), encoding="utf-8")
    status = solver.check()
    result = {"status": str(status)}
    if status == z3.sat:
        result["counterexample"] = {str(v): str(solver.model().eval(v, model_completion=True))
                                    for v in (invalid, exhausted, complete, baseline, recorded, behavior)}
    elif status == z3.unknown:
        result["reason"] = solver.reason_unknown()
    return result


equivalence = query("decision-equivalence", z3.Or(before["decision"] != ordered_decision(rules),
                                                 before["behavior"] != candidate_env["behavior"]))
mutant = query("decision-mutant", before["decision"] != ordered_decision(rules[1:]))
assert equivalence["status"] == "unsat", equivalence
assert mutant["status"] == "sat", mutant
result = {"z3_version": z3.get_version_string(), "equivalence": equivalence, "invalidity_rule_removed": mutant,
          "scope": "AST-derived final decision precedence and invalidity normalization; incoming non-invalid behavior and completeness are abstract inputs assumed equal. Not a proof of inventories, diagnostics or full Python semantics."}
(HERE / "logic-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))

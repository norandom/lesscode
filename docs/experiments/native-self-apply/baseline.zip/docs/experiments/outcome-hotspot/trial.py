"""Compare a complete outcome classifier, without changing production files."""
import ast
from dataclasses import replace
import difflib
import hashlib
from itertools import product
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]

import lizard
from radon.raw import analyze
from lesscode_baseline import experiments as original
from tests.test_experiments import evaluated, producer, manifest, AggregationTests
from lesscode_baseline.contracts import ExperimentManifest

source_path = ROOT / "src/lesscode_baseline/experiments.py"
source = source_path.read_text(encoding="utf-8")
before = (HERE / "original.py.txt").read_text(encoding="utf-8")
after = (HERE / "candidate.py.txt").read_text(encoding="utf-8")
assert source.count(before) == 1, "source changed: refresh the trial explicitly"
namespace = vars(original).copy()
exec(compile(after, str(HERE / "candidate.py.txt"), "exec"), namespace)
candidate = namespace["_outcome"]

if len(sys.argv) > 1:
    if sys.argv[1] == "candidate":
        original._outcome = candidate
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        "tests.test_experiments", "tests.test_experiment_contracts", "tests.test_experiment_cli"])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())


def metrics(text):
    functions = lizard.analyze_file.analyze_source_code("sample.py", text).function_list
    return dict(physical=len(text.splitlines()), lloc=analyze(text).lloc,
                nloc=sum(f.nloc for f in functions), ccn=sum(f.cyclomatic_complexity for f in functions),
                ast_nodes=sum(1 for _ in ast.walk(ast.parse(text))))


run = evaluated()
item = original.reconcile(ExperimentManifest.from_dict(manifest()), (producer(),)).planned_trials[0]
missing_item = original.reconcile(ExperimentManifest.from_dict(manifest()), ()).planned_trials[0]
check = run.baseline.checks[0]
check_sets = [(), *((replace(check, status=s),) for s in ("passed", "failed", "missing", "error")),
              (check, replace(check, check_id="second", status="missing")),
              (replace(check, required=False),), (replace(check, kind="golden"),),
              (replace(check, source_hash="b" * 64),)]
execution_sets = [(), *((AggregationTests().execution(s, code),) for s, code in
                      (("completed", 0), ("completed", 1), ("timeout", None), ("error", None)))]
count = 0
mutant_mismatches = 0
mutant_namespace = vars(original).copy()
exec(after.replace('(invalid, "invalid")', '(False, "invalid")'), mutant_namespace)
mutant = mutant_namespace["_outcome"]


def compare(selected_item, selected_run):
    global count, mutant_mismatches
    expected = original._outcome(selected_item, selected_run, ("diagnostic",))
    actual = candidate(selected_item, selected_run, ("diagnostic",))
    assert actual == expected, (count, expected, actual)
    mutant_mismatches += mutant(selected_item, selected_run, ("diagnostic",)) != expected
    count += 1


for decision, baseline_checks, candidate_checks, baseline_exec, candidate_exec, exhausted in product(
        ("accepted", "rejected", "invalid", "incomplete", "baseline_ineligible"),
        check_sets, check_sets, execution_sets, execution_sets, (False, True)):
    selected = replace(run, decision=decision,
                       baseline=replace(run.baseline, checks=baseline_checks, executions=baseline_exec),
                       candidate=replace(run.candidate, checks=candidate_checks, executions=candidate_exec))
    compare(replace(item, record=replace(item.record, budget_exhausted=exhausted)), selected)
for selected in (None, run, replace(run, integrity=replace(run.integrity, status="changed")),
                 replace(run, baseline=replace(run.baseline,
                         snapshot=replace(run.baseline.snapshot, content_hash="b" * 64)))):
    compare(item, selected)
    compare(missing_item, selected)
assert mutant_mismatches > 0
replacement = source.replace(before, after)
(HERE / "candidate.diff").write_text("".join(difflib.unified_diff(source.splitlines(True), replacement.splitlines(True),
    fromfile="a/src/lesscode_baseline/experiments.py", tofile="b/src/lesscode_baseline/experiments.py")), encoding="utf-8")
totals = {}
for name, paths in (("production", sorted((ROOT / "src").rglob("*.py"))),
                    ("tests", sorted((ROOT / "tests").rglob("*.py"))),
                    ("apparatus", sorted(HERE.glob("*.py")))):
    values = [metrics(p.read_text(encoding="utf-8")) for p in paths]
    totals[name] = {"files": len(paths), **{k: sum(v[k] for v in values) for k in values[0]}}
result = dict(source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),
              candidate_sha256_lf=hashlib.sha256(replacement.encode()).hexdigest(),
              differential_cases=count, precedence_mutant_detected=mutant_mismatches,
              function={"before": metrics(before), "after": metrics(after)},
              module={"before": metrics(source), "after": metrics(replacement)}, populations=totals,
              versions={"python": sys.version, "lizard": "1.17.31", "radon": "6.0.1"})
(HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))

# Outcome hotspot trial

Owner amendment after the first result: ignore bytes as an assessment metric;
72 to 60 lines is a useful direction despite missing the initial 20% cutoff.
Continue toward SMT-augmented LLM proposals with a measured complexity budget.
The initial plan below is retained as history, not silently rewritten.

## Decision before prototyping

Replace repeated check inventories and nested final-decision assignment in
`experiments._outcome` with one baseline inventory and an ordered decision list.
Retain check ordering, diagnostic ordering, invalidity precedence, missing
evidence, execution failures and budget-exhaustion semantics. No helper framework,
new dependency, public API change or production edit is proposed by this trial.

Selection: existing Lizard measurements put this function second by CCN (54),
with 69 NLOC. This is a whole outcome-classification responsibility, not a
solver-compatible arithmetic sample. Aim for at least 20% function physical-line
reduction; count all replacement code. A smaller result or less understandable
precedence is a reason to retain the original, even if comparisons pass.

Other inspected candidates: config command preparation/integrity has different
probe and trust semantics; metric parsers enforce independent inventories;
report storage includes distinct lifecycle and corruption behavior. No worthwhile
whole replacement was established for those during this bounded inspection.
The five-reader factory is not extended: its prior three-line saving was weak.

## Frozen checks and accounting

- Compare complete returned outcomes against the original over combinations of
  decisions, required-check states, baseline eligibility, execution states,
  integrity and budget exhaustion. Include missing runs/records and binding drift.
- Run the unchanged experiment tests against both implementations.
- Deliberately break decision precedence to challenge the differential checks.
- Record function/module/project physical lines, UTF-8 LF bytes, Radon LLOC,
  Lizard NLOC and CCN. Separate existing tests and experiment apparatus.
- Keep Facdrone and production source unchanged. Save the complete candidate diff.
- No timing, maintainability or universal equivalence claim follows from these tests.

## COBESY experiment ledger / composition blueprint

| Element | Working choice |
| --- | --- |
| Target behavior | Maintainer and coding agent select a complete removable responsibility and reject metric-only wins. |
| Assumption under test | A large branch hotspot contains compressible repeated representation, not only necessary policy. |
| Disproof | Any outcome/diagnostic mismatch; insufficient complete reduction; worse readable precedence. |
| Anchor | Project owner and future agent using the saved diff, inputs and checks; no assumed organizational network. |
| Headline to fill | Measured outcome and adoption decision, including a negative result. |
| Evidence order | Whole replacement, behavior checks, project effect, apparatus cost, limits. |
| Next decision | Adopt only after sufficient evidence and useful reduction; otherwise retain and change the next hypothesis. |

This ledger is written before candidate construction. It applies COBESY Scientist
Mode and conclusion-first composition, without treating counts as persuasion.

# A smaller outcome classifier, with an SMT-checked decision boundary

**Keep this candidate for a second, SMT-augmented LLM pass.** Replacing repeated
inventories and nested decision assignment in Lesscode's `_outcome` preserved
the tested results and reduced 72 physical lines to 60. The owner accepted this
16.7% reduction as a useful direction, overriding the provisional 20% cutoff
after seeing the result. Bytes are excluded from the assessment at the owner's
request. Production remains unchanged; readable precedence still needs review.

This round used the existing Lizard/Radon measurements to choose a complete
responsibility. `_outcome` ranked second by function CCN in the 17 production
Python files. It classifies recorded experiment outcomes; no application-domain
logic or Facdrone code was changed.

![Measured changes in the complete outcome classifier](comparison.svg)

## Whole replacement, not the edited lines alone

| Scope / measure | Original | Candidate | Difference |
| --- | ---: | ---: | ---: |
| Complete function physical lines | 72 | 60 | -12 (-16.7%) |
| Complete function Radon LLOC | 62 | 41 | -21 (-33.9%) |
| Complete function Lizard NLOC | 69 | 57 | -12 |
| Complete function Lizard CCN | 54 | 45 | -9 (-16.7%) |
| Complete function AST nodes | 784 | 748 | -36 (-4.6%) |
| Experiments module physical lines | 394 | 382 | -12 |
| Experiments module Radon LLOC | 307 | 286 | -21 |
| Whole production physical lines, hypothetical | 6,589 | 6,577 | -0.18% |
| Production change actually adopted | 0 | 0 | 0 |

All new expressions and the decision list are included. No residual helper,
wrapper, dependency or configuration is omitted. Physical lines include comments
and blanks; Radon LLOC and Lizard NLOC are different definitions. CCN is the
Lizard count, not an entropy or maintainability score. The relatively large LLOC
drop alongside the smaller AST drop exposes a representation change: most
policy conditions still exist, now inside expressions and an ordered list.

## Behavior checks and limits

- **20,258 exact differential comparisons** matched the complete `TrialOutcome`,
  including reasons in order. The main cross-product covers five decisions,
  nine baseline and candidate check inventories, five execution inventories on
  each side, and exhaustion on/off. Eight additional cases cover missing runs,
  missing producer records, changed integrity and source mismatch.
- A deliberate mutant disabling invalidity's final-decision precedence was
  detected in **9,827 cases**. This challenges one important failure mode; it is
  not a mutation score for the project.
- All **65 unchanged experiment aggregation, contracts and CLI tests** passed against
  both implementations. See the complete [baseline log](baseline-tests.txt) and
  [candidate log](candidate-tests.txt) for test counts and timings.
- The candidate is loaded into the module in an isolated Python process. The
  repository source stays untouched; the CLI tests call `cli.main` in that
  process, exercising aggregation with the replaced function.
- This is finite differential testing, not an SMT proof or exhaustive Python
  equivalence. Some generated combinations are defensive internal record states,
  not independently validated public JSON inputs. Existing contract tests cover
  admission separately. Duplicate IDs and arbitrary hostile objects are not a
  claimed supported domain.
- No full-project regression run or production adoption has occurred. No
  production or existing test file was changed.

### SMT result: equivalent final precedence, under an explicit boundary

The [source-derived verifier](verify_logic.py) parses the original final
`if/elif` assignments and the candidate's ordered decisions into Z3 expressions.
It also extracts the candidate's invalidity normalization. It treats incoming
non-invalid behavior and completeness as equal abstract inputs; that assumption
is tested concretely above, not proved by this model.

Z3 4.15.3 returned **UNSAT** for a difference in final decision or behavior over
the declared finite status domains and all Boolean inputs. Removing invalidity's
precedence returned **SAT**, with a counterexample: invalid evidence, an
ineligible baseline, exhausted=false, complete=true, recorded=invalid and
incoming behavior=failed. The mutant chooses baseline-ineligible instead of
invalid. This demonstrates a useful counterexample signal for the proposing LLM.

See [solver results](logic-result.json), [equivalence query](decision-equivalence.smt2)
and [mutant query](decision-mutant.smt2). This is a proof of the extracted decision
boundary under its assumptions, not the entire function, diagnostics, Python
semantics or repository. Unsupported AST forms fail explicitly. No concolic
tracer or general synthesizer was built.

## Account for the respective parts

| Population | Python files | Physical lines | Radon LLOC |
| --- | ---: | ---: | ---: |
| Production (`src/**/*.py`) | 17 | 6,589 | 5,563 |
| Existing tests (`tests/**/*.py`, including fixtures) | 45 | 7,863 | 6,402 |
| Trial construction/comparison and SMT scripts | 3 | 251 | 183 |

The trial scripts are research apparatus, not a product saving. The archived
original/candidate snippets, diff, logs, measurements and this report are
additional evidence storage, not runtime code. The candidate itself adds no
runtime dependency. Research uses pinned Lizard 1.17.31 and Radon 6.0.1 via uv
with local Python 3.12.10. Tests remain a separate population; they were neither
removed nor weakened. Maintenance hours, cognitive load and runtime improvement
were not measured.

## COBESY ledger: hypothesis, disproof and next decision

The [plan and composition blueprint](plan.md) were written before building the
candidate. They name the intended maintainer behavior, hidden assumption and
initial rejection criteria. The assumption was that a large branch hotspot
contains removable representation. This trial found a modest reduction; it does
not establish the large-scale compression objective. The owner's later change
to the cutoff is retained explicitly, rather than presented as preregistered.

Five candidate areas were inspected qualitatively: command preparation/integrity,
metric parsing, report storage, the already-tested reader family and outcome
classification. One responsibility was prototyped; one candidate was compared;
zero replacements were adopted. The later SMT check adds verification, not a
second compression trial. These are not a representative sample or a
general success-rate estimate. Other inspected areas were deferred because no
concrete useful whole replacement was established, not proved incompressible.

## Step 2: an SMT-augmented LLM compression loop

The LLM proposes implementations; the solver challenges supported semantics;
unchanged tests and whole-responsibility measurements decide whether a proposal
is useful. A later MCP server can expose these operations. Building the server
now would not establish that the compression loop works.

1. Supply original source, current candidate, observable contract, unchanged
   tests, metrics and the exact supported proof boundary to the LLM.
2. Give it a bounded search budget of three proposals. A provisional complexity
   cap is `floor(45 * 0.8) = 36` Lizard CCN, a 20% improvement over this candidate.
   This is an explicit experimental budget, not a mathematical minimum or a
   validated maintainability threshold. Require whole-responsibility physical
   lines and LLOC below the original, and no growth over the 60-line candidate.
3. Re-extract supported logic from each proposed source. Verify against the
   original. Return SAT counterexamples to the LLM; reject UNKNOWN/timeouts and
   unsupported constructs as unverified, never as successful checks.
4. Preserve the same external tests and exact outcome/diagnostic comparisons.
   SMT does not replace tests outside its model. Count all new helpers, tables,
   adapters and callers. Inspect moved branches: a lower isolated CCN does not
   satisfy the cap if the responsibility's control flow merely moved elsewhere.
5. Compare the original, current candidate and successful proposals. Keep useful
   names, types and explicit precedence. If none improves the complete result,
   retain this candidate and record the limit; do not add a framework to pass.

Potential later MCP operations are candidate analysis, supported-logic extraction,
verification with counterexamples, test execution and full-cost measurement.
Record source hashes and assumptions with every result. Mutating code remains a
separate operation. Neither this loop nor a server is claimed implemented here;
the local experiment establishes a small verification step to build on.

## Reproduce and inspect

Run from the repository root, with the existing local Python environment:

```powershell
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/outcome-hotspot/build_candidate.py
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/outcome-hotspot/trial.py
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/outcome-hotspot/trial.py baseline
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/outcome-hotspot/trial.py candidate
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with z3-solver==4.15.3.0 python docs/experiments/outcome-hotspot/verify_logic.py
```

The builder explicitly regenerates the candidate from current source. The trial
asserts its saved original still matches before comparing. Source identities,
versions and all measured totals are in [result.json](result.json). Inspect the
[complete module diff](candidate.diff), [original](original.py.txt),
[candidate](candidate.py.txt), [trial driver](trial.py) and
[hotspot inventory](hotspots.json). Results describe this source snapshot only.

"""One-off, guarded prototype construction; no production writes."""
import ast
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / "src/lesscode_baseline/experiments.py"
source = SOURCE.read_text(encoding="utf-8")
node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "_outcome")
original = "\n".join(source.splitlines()[node.lineno - 1:node.end_lineno]) + "\n"
candidate = original.replace(
    '    expected = {check.check_id: check for check in run.baseline.checks if check.required}\n', '')
start = candidate.index('    required = {**expected')
end = candidate.index('    return TrialOutcome', start)
candidate = candidate[:start] + '''    required = dict.fromkeys(check.check_id for check in (*run.baseline.checks, *run.candidate.checks)
                             if check.required)
    statuses = [actual[identity].status if identity in actual else "missing" for identity in required]
    reasons.extend(f"candidate required check {identity}: {status}"
                   for identity, status in zip(required, statuses) if status != "passed")
    # Completeness and failure are independent; an observed failure cannot hide
    # absent checks or unfinished executions. Completed nonzero exits need a failed check.
    failed = "failed" in statuses
    required_complete = (bool(statuses) and set(statuses) <= {"passed", "failed"}
                         and all(e.status == "completed" for e in unsuccessful["candidate"])
                         and (not unsuccessful["candidate"] or failed))
    behavior = "incomplete" if invalid else "failed" if failed else "passed" if required_complete else "incomplete"
    # First applicable rule wins; the recorded decision remains the fallback.
    decisions = ((invalid, "invalid"), (baseline == "ineligible", "baseline_ineligible"),
                 (baseline == "missing", "incomplete"),
                 (record.budget_exhausted and (run.decision not in ("accepted", "rejected") or not required_complete), "incomplete"),
                 (behavior == "failed", "rejected"),
                 (behavior == "incomplete" and run.decision == "accepted", "incomplete"))
    decision = next((value for applies, value in decisions if applies), run.decision)
''' + candidate[end:]
assert candidate != original
ast.parse(candidate)
(HERE / "candidate.py.txt").write_text(candidate, encoding="utf-8", newline="\n")
(HERE / "original.py.txt").write_text(original, encoding="utf-8", newline="\n")

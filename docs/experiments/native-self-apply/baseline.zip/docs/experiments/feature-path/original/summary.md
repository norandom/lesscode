# Evaluation summary

Report format version: 1
Run: `run-1`; plan: `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa`
Decision: `accepted`

## Decision reasons

- `Candidate accepted under the frozen profile; required declared checks passed`
- `Results cover only declared checks; unchecked behavior remains; not proof of equivalence`
- `Protection: local_detection; provider evidence: None`

## Declared checks

Passing results mean passing the declared checks; this is not proof of equivalence. Unchecked behavior remains unverified.

### Baseline

- Check evidence unavailable: no outcomes recorded.

### Candidate

- Check evidence unavailable: no outcomes recorded.

## Integrity and protections

Status: `unchanged`; protection: `local_detection`.
Local change detection does not isolate malicious workloads or prevent privileged writes.

## Structural and other metrics

Each producer and definition is separate. Structured payloads are retained as recorded; no combined quality score is calculated.

### `complexity`

- Before: `available`; value `{&quot;count&quot;: 2, &quot;files&quot;: [{&quot;nloc&quot;: 6, &quot;path&quot;: &quot;sample.py&quot;}], &quot;functions&quot;: [{&quot;ccn&quot;: 2, &quot;end_line&quot;: 4, &quot;long_name&quot;: &quot;fee( x )&quot;, &quot;name&quot;: &quot;fee&quot;, &quot;nloc&quot;: 4, &quot;path&quot;: &quot;sample.py&quot;, &quot;start_line&quot;: 1, &quot;token_count&quot;: 18}, {&quot;ccn&quot;: 1, &quot;end_line&quot;: 7, &quot;long_name&quot;: &quot;identity( x )&quot;, &quot;name&quot;: &quot;identity&quot;, &quot;nloc&quot;: 2, &quot;path&quot;: &quot;sample.py&quot;, &quot;start_line&quot;: 6, &quot;token_count&quot;: 7}], &quot;kind&quot;: &quot;complexity&quot;, &quot;maximum&quot;: 2, &quot;median&quot;: 1.5, &quot;minimum&quot;: 1, &quot;p95&quot;: 2}`; unit `CCN`; producer `lizard` version `1.17.31`; definition `lizard-python-ccn-files-functions-median-nearest-rank-p95-v1`; scope `c07ee05c1e24b5c945b7b409587ab76a0c077b7b9e20595d128a773963916bf6`; reason unavailable; raw `3b0562a401b346799e04044878b3b7ef.stdout.log`
- After: `available`; value `{&quot;count&quot;: 2, &quot;files&quot;: [{&quot;nloc&quot;: 6, &quot;path&quot;: &quot;sample.py&quot;}], &quot;functions&quot;: [{&quot;ccn&quot;: 2, &quot;end_line&quot;: 4, &quot;long_name&quot;: &quot;fee( x )&quot;, &quot;name&quot;: &quot;fee&quot;, &quot;nloc&quot;: 4, &quot;path&quot;: &quot;sample.py&quot;, &quot;start_line&quot;: 1, &quot;token_count&quot;: 18}, {&quot;ccn&quot;: 1, &quot;end_line&quot;: 7, &quot;long_name&quot;: &quot;identity( x )&quot;, &quot;name&quot;: &quot;identity&quot;, &quot;nloc&quot;: 2, &quot;path&quot;: &quot;sample.py&quot;, &quot;start_line&quot;: 6, &quot;token_count&quot;: 7}], &quot;kind&quot;: &quot;complexity&quot;, &quot;maximum&quot;: 2, &quot;median&quot;: 1.5, &quot;minimum&quot;: 1, &quot;p95&quot;: 2}`; unit `CCN`; producer `lizard` version `1.17.31`; definition `lizard-python-ccn-files-functions-median-nearest-rank-p95-v1`; scope `c07ee05c1e24b5c945b7b409587ab76a0c077b7b9e20595d128a773963916bf6`; reason unavailable; raw `3b0562a401b346799e04044878b3b7ef.stdout.log`
- Comparison: `unavailable`; before unavailable; after unavailable; absolute delta unavailable `CCN`; percentage delta unavailable percent; reason `structured measurement has no declared scalar projection`; percentage reason `structured measurement has no declared scalar projection`

## File changes

- Product files:
  - added: none
  - removed: none
  - modified: none
- Test files:
  - added: none
  - modified: none
  - removed: none

## Time and cost

Evaluation elapsed: `0.1` seconds.
Agent execution time: unavailable (not supplied in RunReport).
Agent token usage and provider cost: unavailable (not supplied in RunReport).

## Limitations

- `Unchecked behavior remains`

def fee(x):
    if x > 100:
        return x * 0.9
    return x

def identity(x):
    return x

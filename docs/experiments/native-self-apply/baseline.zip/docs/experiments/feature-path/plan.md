# FP01: can the analyzer-to-report path lose an intermediate representation?

Recorded after source inspection, before running the probes. Discovery is not
preregistered. This is a bounded falsification experiment, not an efficacy trial
or an automatic refactoring system.

## Hypothesis and scope

Trace one real Lizard result through worker JSON, validated ComplexityPayload,
MetricEvidence, comparison, RunReport, human summary and persisted recovery.
Hypothesis: an intermediate representation or repeated decision is unnecessary;
an existing record/provider can replace it without losing any observable behavior.

The initial proposal was a complete feature-path rewrite. Inspection instead
identified two concrete, questionable deletion premises. Test those premises
before writing a large candidate:

1. Reuse MetricDelta's status as MetricComparison's status, eliminating a distinct
   compatibility state. Probe by changing the comparison return to use delta status.
2. Retain only the analyzer distribution, eliminating the detailed function
   inventory and its associated downstream handling. Probe by emitting an empty,
   internally valid ComplexityPayload from the adapter. This is deliberately a
   loss-of-information control, not an equivalent implementation claim.

Keep the original as the default. Do not claim either probe's line deletion as
compression. If a premise fails, retain its witness and do not build that rewrite.

## Boundary and trace

Preserve available versus unavailable evidence, independent scalar availability,
required-metric decisions, reasons, complete serialized evidence, function names
and locations, exact human summary, raw references and recoverable artifacts.
Capture is real pinned Lizard execution on a small two-function Python input;
the downstream report uses an existing fixture envelope and no behavior checks.
An accepted decision in that fixture is not a behavioral-equivalence claim about
the source program. No modification to Lesscode production/tests or Facdrone.

Refresh the existing capability inventory against current manifests: no runtime
dependencies, no new framework or imports from the analyzer environment into the
product. Existing contracts, decision and report providers are the alternatives.

## Checks fixed before probes

- Capture a real successful Lizard record and retain stdout/stderr and audit.
- Compare original versus each isolated probe through decision and summary.
- Generate combinations of scalar/structured/absent/invalid measurement and
  provenance changes; compare complete comparison records and exceptions.
- Run unchanged decision, contract and report tests against original and probes.
- Persist and recover the original traced report, retaining raw references.
- Check frozen source/tests/config and earlier experimental evidence hashes.

No SMT model is appropriate for the complete I/O and report boundary here.
Finite checks cannot prove universal equivalence. One agent performs this trial.
Stop after these two premises; do not build new infrastructure to force a win.

## Accounting and acceptance

Measure the entire five-module traced implementation (metrics, evaluation,
decision, contracts, report), and the changed modules separately. Keep tests,
synthetic input and research scripts outside production totals. Ignore bytes as
a compression metric. Record physical lines and Radon LLOC with pinned versions.
An admissible proposal must preserve the boundary and remove a concrete complete
implementation, counting all new helpers/adapters/callers. A failed premise has
zero accepted savings, regardless of any smaller source artifact.

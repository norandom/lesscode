"""FP01: isolated deletion-premise probes; never edit production inputs."""
import ast
from dataclasses import asdict, replace
import difflib
import hashlib
from itertools import product
import json
from pathlib import Path
import sys
from types import ModuleType
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT / "src"), str(ROOT)]
MODULES = ("metrics", "evaluation", "decision", "contracts", "report")


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, default=str) + "\n", encoding="utf-8")


def load(name, path):
    module = ModuleType("lesscode_baseline." + name)
    module.__package__, module.__file__ = "lesscode_baseline", str(path)
    sys.modules[module.__name__] = module
    exec(compile(path.read_text(), str(path), "exec"), vars(module))
    import lesscode_baseline
    setattr(lesscode_baseline, name, module)
    return module


if len(sys.argv) > 1:
    arm = sys.argv[1]
    if arm == "status":
        load("decision", HERE / arm / "decision.py.txt")
    elif arm == "inventory":
        load("metrics", HERE / arm / "metrics.py.txt")
    names = (["tests.test_metrics.ComplexityMetricTests"] if arm in ("inventory", "original-inventory") else
             ["tests.test_decision", "tests.test_contracts", "tests.test_report"])
    with (HERE / arm / "tests.log").open("w") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames(names))
    save(HERE / arm / "tests.json", dict(run=result.testsRun, failures=len(result.failures),
         errors=len(result.errors), skipped=len(result.skipped), exit_code=int(not result.wasSuccessful())))
    raise SystemExit(not result.wasSuccessful())

assert not (HERE / "inputs.json").exists(), "preserve this run; use a new directory"
paths = [p for folder in ("src", "tests", "docs/experiments")
         for p in (ROOT / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts
         and HERE not in p.parents]
paths += [ROOT / "pyproject.toml", ROOT / "tools/requirements-tools.lock"]
paths = [p for p in paths if p.exists()]
frozen = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
save(HERE / "inputs.json", frozen)
for name in MODULES:
    target = HERE / "original" / (name + ".py.txt")
    target.parent.mkdir(exist_ok=True)
    target.write_bytes((ROOT / "src/lesscode_baseline" / (name + ".py")).read_bytes())
changes = {
    "status": ("decision", "return MetricComparison(before, after, status, tuple(differences), delta)",
               "return MetricComparison(before, after, delta.status, tuple(differences), delta)"),
    "inventory": ("metrics", '    return MetricEvidence("complexity",',
                  '    if payload is not None:\n        payload = replace(payload, functions=())\n    return MetricEvidence("complexity",'),
}
for arm, (name, old, new) in changes.items():
    source = (HERE / "original" / (name + ".py.txt")).read_text()
    assert source.count(old) == 1
    candidate = source.replace(old, new)
    target = HERE / arm / (name + ".py.txt")
    target.parent.mkdir(exist_ok=True)
    target.write_text(candidate)
    (target.parent / "candidate.diff").write_text("".join(difflib.unified_diff(
        source.splitlines(True), candidate.splitlines(True), fromfile=name + ".py", tofile=arm + "/" + name + ".py")))

from lesscode_baseline import contracts as c, decision, metrics, report, snapshot
from tests.test_contracts import report as report_fixture, profile as profile_fixture, scope
from tests.test_decision import metric
source = HERE / "specimen"
source.mkdir()
(source / "sample.py").write_text("def fee(x):\n    if x > 100:\n        return x * 0.9\n    return x\n\ndef identity(x):\n    return x\n")
captured = snapshot.capture_scope(source, c.ScopeRules.from_dict(scope()))
assert isinstance(captured, c.Snapshot)
evidence = metrics.measure_complexity(captured, ROOT / ".tools/analyzers/python/Scripts/python.exe",
                                    c.Limits(30, 100000), HERE / "raw")
assert evidence.status == "available", evidence.reason
save(HERE / "evidence.json", evidence.to_dict())
base_report = c.RunReport.from_dict(report_fixture())
observation = c.Observation(captured, (evidence,), (), (), ())
profile = replace(c.Profile.from_dict(profile_fixture()), checks=(), required_metrics=("complexity",), thresholds=())


def end_to_end(engine, record):
    observed = replace(observation, metrics=(record,))
    comparison = engine.compare(observed, observed, profile, base_report.integrity)
    result = replace(base_report, baseline=observed, candidate=observed,
                     decision=comparison.decision, reasons=comparison.reasons, metric_deltas=comparison.metric_deltas)
    return result, report.render_summary(result)


# Comparison's field is named metric_deltas; inspect the frozen contract explicitly.
assert "metric_deltas" in c.Comparison.__dataclass_fields__
original_report, original_summary = end_to_end(decision, evidence)
(HERE / "original/report.json").write_text(c.dumps(original_report))
(HERE / "original/summary.md").write_text(original_summary)
report.persist(original_report, HERE / "persisted", artifact_root=HERE / "raw")
recovered = report.recover(HERE / "persisted")
assert recovered.state == "complete" and recovered.report == original_report
status_engine = load("decision", HERE / "status/decision.py.txt")
status_report, status_summary = end_to_end(status_engine, evidence)
(HERE / "status/report.json").write_text(c.dumps(status_report))
(HERE / "status/summary.md").write_text(status_summary)
values = [None, True, 0, 1, -1, 100, 1e308, -1e308, 1e-308, float("inf"),
          evidence.value, c.FindingsPayload("findings", ()),
          c.PopulationPayload("population", ("a",), "a" * 64, 1, 1, None)]
records = [None] + [metric(value) for value in values] + [
    metric(None, status=state, reason="absent") for state in ("unavailable", "non_comparable")]


def outcome(engine, before, after):
    try:
        return ["returned", asdict(engine.compare_metric(before, after))]
    except Exception as exc:
        return ["raised", type(exc).__name__, str(exc)]


count = mismatches = 0
witnesses = []
for before, after, changed_field in product(records, records, (None, "scope_hash", "producer", "unit")):
    if after is not None and changed_field:
        after = replace(after, **{changed_field: "b" * 64 if changed_field == "scope_hash" else "different"})
    expected, actual = outcome(decision, before, after), outcome(status_engine, before, after)
    count += 1
    # JSON strings avoid NaN identity/equality artifacts in exceptional inputs.
    if json.dumps(expected, sort_keys=True) != json.dumps(actual, sort_keys=True):
        mismatches += 1
        if len(witnesses) < 4:
            witnesses.append(dict(expected=expected, actual=actual))
inventory_engine = load("metrics", HERE / "inventory/metrics.py.txt")
inventory_evidence = inventory_engine.measure_complexity(captured,
    ROOT / ".tools/analyzers/python/Scripts/python.exe", c.Limits(30, 100000), HERE / "inventory/raw")
try:
    end_to_end(decision, inventory_evidence)
    inventory_error = None
except Exception as exc:
    inventory_error = dict(type=type(exc).__name__, message=str(exc))
from radon.raw import analyze


def size(text):
    return dict(physical=len(text.splitlines()), lloc=analyze(text).lloc)


sizes = {name: size((HERE / "original" / (name + ".py.txt")).read_text()) for name in MODULES}
changed = [name for name, digest in frozen.items() if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
save(HERE / "result.json", dict(
    original_decision=original_report.decision, status_probe_decision=status_report.decision,
    original_compatibility=decision.compare_metric(evidence, evidence).status,
    original_scalar_status=decision.compare_metric(evidence, evidence).delta.status,
    measured_functions=[asdict(f) for f in evidence.value.functions],
    recovered_original=recovered.state, status_cases=count, status_mismatches=mismatches,
    witnesses=witnesses, inventory_probe_error=inventory_error, original_modules=sizes,
    original_path_totals={key: sum(v[key] for v in sizes.values()) for key in ("physical", "lloc")},
    probe_modules={arm: size((HERE / arm / (name + ".py.txt")).read_text())
                   for arm, (name, _, _) in changes.items()},
    accepted_savings=0, frozen_inputs=len(frozen), changed_inputs=changed,
    versions={"python": sys.version, "radon": "6.0.1", "lizard": "1.17.31"}))
(HERE / "original-inventory").mkdir(exist_ok=True)
assert not changed and mismatches and inventory_error
print(json.dumps(dict(cases=count, mismatches=mismatches, inventory_error=inventory_error,
                     original=original_report.decision, status=status_report.decision)))

# FP01: the traced representations carry different information

The analyzer-to-report trace did not establish a removable intermediate layer.
Two deletion-premise probes failed: merging compatibility with scalar availability
changed acceptance, and removing the function inventory lost required evidence.
Accepted reduction is zero. This is a documented rejection of two premises, not
a claim that Lesscode is minimal or that a different representation cannot help.

The earlier graph experiment rewrote a small implementation without identifying
enough removable code. This experiment moved outward to one feature path. Source
inspection found distinct responsibilities rather than repeated decisions, so
the work stopped at falsification probes instead of building a speculative rewrite.
The originally proposed two complete compression alternatives were therefore
not built. These probes are not substitutes for an efficacy comparison.

## One actual result, from analyzer to recovered report

The [seven-line specimen](specimen/sample.py) contains `fee` and `identity`.
Lizard 1.17.31 actually ran in the pinned analyzer environment. Its validated
[evidence](evidence.json) records CCN 2 and 1, their names and line ranges, count 2,
minimum 1, maximum 2, median 1.5 and nearest-rank p95 2. This specimen drives real
Lesscode code; it is not a grown-code compression example itself.

```mermaid
flowchart TD
    W[Real Lizard worker: two function records] --> P[Validate payload and inventory]
    P --> M[MetricEvidence: available, full payload and provenance]
    M --> C[Compare: compatible evidence]
    C --> D[Scalar delta: unavailable, no declared projection]
    C --> A[Required metric satisfied]
    A --> R[RunReport: accepted in this fixture]
    D --> R
    R --> H[Human summary preserves inventory and unavailable delta]
    R --> S[Persist raw reference and report; recover complete]
    D -. status-collapse probe .-> X[Required metric appears unavailable: incomplete]
```

The trace uses a profile with complexity required, no thresholds and no declared
behavior checks. Its `accepted` result only establishes evidence availability
under that fixture. It does not establish equivalence of the specimen's behavior.
The unchanged report providers persisted and recovered the original report with
its raw analyzer reference. See the [original JSON](original/report.json),
[human summary](original/summary.md) and [artifact index](persisted/artifacts.json).

| Stage | Current implementation | What it contributes |
| --- | --- | --- |
| Capture | `metrics.measure_complexity`, worker, bounded execution | Actual analyzer output and diagnostic artifacts |
| Admission | `metrics._complexity_payload`, contract readers | Complete staged inventory, bounds, typed function records and distribution |
| Provenance | `MetricEvidence`; evaluation's artifact rebasing | Producer, definition, scope and retained raw reference |
| Decision | `decision.compare_metric`, `compare` | Compatibility, scalar arithmetic availability and frozen-profile decision |
| Public result | `RunReport`, `report.render_summary` | Recorded observations, reasons and deltas; rendering does not recalculate the decision |
| Storage | `report.persist`, `recover` | Artifact identity and recoverable publication |

Evaluation's orchestration/rebasing was source-traced, not invoked by this runner.
The runner directly composes the real adapter, decision and report providers.
It does not exercise the full CLI, optional imports or interruption recovery.

## Two premises tested, both rejected

| Probe | Proposed simplification premise | Executed witness | Disposition |
| --- | --- | --- | --- |
| Status reuse | MetricDelta can supply the compatibility status, removing a distinct state | The same real evidence changes the final decision from `accepted` to `incomplete` | Reject: availability of evidence is different from availability of scalar arithmetic |
| Inventory omission | Distribution statistics make detailed function evidence unnecessary | Report validation rejects count 2 with zero functions; existing tests also detect missing names, locations and CCNs | Reject: a distribution does not replace a hotspot inventory |

The [status diff](status/candidate.diff) deliberately changes only the returned
compatibility status; it does not pretend to implement every downstream deletion.
Its [report](status/report.json) and [summary](status/summary.md) retain the changed
decision. The [inventory diff](inventory/candidate.diff) removes functions while
retaining aggregate statistics, exposing the consumer obligation directly.

Protocol correction: the plan called the inventory probe "internally valid".
It is not: count and function inventory are coupled by the existing contract.
That failed assumption is retained here. This probe demonstrates the loss and
schema incompatibility, not impossibility of a redesigned representation that
still supplies every function record. Such a design has not been tested.

## Behavior evidence

The corpus was fixed in [the runner](trial.py) before execution: 16 measurement
variants on each side, combined with four provenance conditions, produce 1,024
comparisons. The status probe differs in five cases. Variants include structured,
scalar, missing and directly constructed invalid evidence. Repeated conditions
are cases, not independent experiments. Full returned records or exception
type/message are compared; [results](result.json) retain witnesses.

| Run | Tests run | Passed | Failures | Errors | Skipped | Exit |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Original decision/contracts/report | 81 | 80 | 0 | 0 | 1 | 0 |
| Status probe, same tests | 81 | 75 | 5 | 0 | 1 | 1 |
| Original complexity adapter | 8 | 8 | 0 | 0 | 0 | 0 |
| Inventory probe, same tests | 8 | 3 | 3 | 2 | 0 | 1 |

Logs and machine receipts: [original](original/tests.log),
[status](status/tests.log), [original adapter](original-inventory/tests.log),
[inventory](inventory/tests.log); each directory also contains `tests.json`.
No test expectation was changed. Negative exit codes are expected probe results,
not a broken production baseline. There is no SMT proof and no full-suite claim.

## Whole-path accounting

| Inspected module | Physical lines | Radon LLOC |
| --- | ---: | ---: |
| metrics | 567 | 364 |
| evaluation | 346 | 252 |
| decision | 285 | 240 |
| contracts | 1,376 | 1,379 |
| report | 620 | 519 |
| Total inspected module envelope | 3,194 | 2,754 |

This is an inventory denominator, not measured execution coverage or removable
code. The modules include other features. Radon logical statements can outnumber
physical lines, as in contracts; physical and logical counts are not interchangeable.
The status probe leaves its module at 285/240; the inventory probe adds two lines
to its module, reaching 569/366. Neither is a compression candidate. Product and
test edits are zero, and accepted savings are zero.

Research cost is 172 Python lines for the runner, plus the seven-line synthetic
specimen. Frozen module copies, logs and reports are evidence, not product code.
No runtime dependency was added. Source/tests/manifests and earlier experiments
are covered by 412 [frozen input fingerprints](inputs.json), all unchanged at
execution. Prior graph and capability trials remain separate.

## What this changes in discovery

The trace disconfirms two specific deletion premises. It does not support the
broader conclusion that the feature path has no redundancy. It also does not
justify another pass that merely combines fields or removes validation.

For the next candidate, require an explicit replacement mapping before coding:
which existing operation supplies each currently maintained operation, and which
implementation consequently disappears? A proposed representation must preserve
all observable information, not only its aggregate or its most convenient status.
The test for redundancy is interchangeable behavior across consumers, not
similar field names or repeated passage through a graph.

No additional graph/SMT infrastructure or production refactor follows from this
result. A larger compression proposal remains unestablished. That limitation is
the outcome of this trial, rather than an unearned claim of progress toward less code.

## Reproduction

The [plan](plan.md) was written after inspection and before probe execution. The
runner refuses to overwrite its frozen manifest. To reproduce the complete run,
copy `plan.md` and `trial.py` into a fresh sibling directory under `docs/experiments`
and substitute that directory below. Use the existing local interpreter via uv:

```powershell
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with radon==6.0.1 python docs/experiments/feature-path/trial.py
```

That command ran successfully with exit 0. To rerun a test arm, append `original`,
`status`, `original-inventory` or `inventory` to the runner command (Radon is not
needed for test mode). Test mode replaces that arm's logs/receipt; preserve them
first. The test exits above are recorded independently of the main runner.

# ATS01: compress a capability, not individual functions

Written after read-only discovery, before constructing the candidate. One manual
real-code efficacy candidate; the specimen is the legacy Python application in
ats-agent, not its current portable skill product. Do not change that repository,
its private content, or npu_rag_from_folder. Use fictional inputs exclusively.

## Fixed scope and hypothesis

Capability: bilingual text report generation. Boundary: `generate_report` and its
two existing language-specific methods, inputs, exact returned text and exception
type/message. Include language dispatch, every section, formatting, defaults,
translation data, any helper and compatibility wrapper. Preserve original method
dispatch so existing overrides of the language-specific methods still work.

Replace the duplicated English/German traversal and assembly algorithms with
one renderer plus literal translation data. Keep German-only AGG reporting,
category names/width, language-display rules and all localized messages. The
deletion hypothesis is duplicated orchestration, not information or validation.
Ordinary Python is sufficient; no new framework, dependency or solver.

Baseline: three methods, including dispatch, from the source snapshot. Candidate:
every line needed for the same capability, wherever located. Also report the
whole source module with unchanged surrounding code. Imports count identically.
No per-function complexity ceiling or reward for extracting tiny functions.
Record physical lines, LLOC, aggregate decisions/CCN, function count and internal
call depth. Tables/wrappers and comments stay in the denominator. Data and runtime
structure must remain readable, without semicolon packing or generated exec code.

## Verification frozen before replacement

Extract the three original methods into a dependency-free fixture class via AST
source spans; do not instantiate the OpenAI client or read private documents.
Use JSON-shaped inputs, all subsets of optional report sections, both languages,
category ordering/boundaries, list truncation, missing/null/malformed fields,
language overrides and unsuccessful-result dispatch. Record original outcomes
before candidate construction. Exact output or exception class/message defines
the differential oracle. Include separate full-text examples and dispatch-override
checks. No claim for arbitrary user objects with side-effecting special methods.

No existing Python renderer tests were found in the inspected tests tree. Build
the characterization checks against the original first; leave existing repository
tests untouched. Compare a deliberately broken German-only-section variant to
demonstrate that language asymmetry is exercised. Preserve every failed attempt.

## Budget and decision

One shared-renderer proposal, with at most one corrective revision after concrete
counterexamples. Keep original if checks fail or whole-capability savings are
not useful. Count research/test apparatus separately; no reduction from deleting
comments alone or moving strings out of measured files. Data and executable
statements are reported separately. No performance or human maintenance-time
claims. Freeze source, callers, manifests and earlier Lesscode experiments.
Evidence lives here, with no upstream edits or commits.

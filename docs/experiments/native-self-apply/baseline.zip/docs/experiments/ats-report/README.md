# ATS01: a scoped replacement removes duplicated report assembly

The bilingual reporting candidate matches all 8,820 frozen cases while reducing
the complete isolated capability from 384 to 202 physical lines and from 298 to
135 LLOC. Translation tables, language dispatch and compatibility wrappers are
included. The candidate remains here as an experiment; ats-agent is unchanged.

This target differs from the previous Lesscode trials: two implementations
repeat the same section sequence. Sharing that sequence removes maintained
control flow without discarding report fields. The target belongs to ats-agent's
legacy Python application, which has a separate retirement plan. These results
are not savings in its current portable skill product.

![Complete capability measurements](scope-chart.png)

## Scope owns the goal

The unit is "generate the English or German text report", not a function. The
frozen boundary contains `generate_report`, both language-specific renderers,
and every new helper, wrapper and translation entry. Original callers in
`main.py` and `example.py` need no changes. The whole-module diff is a second
accounting boundary that detects relocation outside the selected methods.

```mermaid
flowchart LR
    I[Analysis result and language override] --> D[Existing language dispatch]
    subgraph Before
      E[English section traversal]
      G[German section traversal]
    end
    D --> E
    D --> G
    subgraph Candidate
      W[Compatibility methods]
      R[One section traversal]
      T[Literal translations and category labels]
      A[Explicit German-only section]
      W --> R
      T --> R
      R --> A
    end
    D -. replacement .-> W
```

Creating more atomic functions cannot improve the goal by itself. Count all owned
code in the capability, aggregate its decisions, then inspect the call structure
and responsibilities. In this trial function count actually rises, as does call
depth. The tradeoff is one maintained section sequence instead of two.

## Complete replacement accounting

| Measure | Original | Candidate | Change |
| --- | ---: | ---: | ---: |
| Capability physical lines | 384 | 202 | -182 (-47.4%) |
| Capability Radon LLOC | 298 | 135 | -163 (-54.7%) |
| Aggregate AST decision points | 76 | 47 | -29 |
| Summed Lizard CCN | 76 | 51 | -25 |
| Capability AST nodes | 3,031 | 1,817 | -1,214 |
| Functions, including nested helper | 3 | 5 | +2 |
| Maximum internal call-chain edges | 1 | 3 | +2 |
| Dictionary entries | 18 | 53 | +35 |
| String literal AST nodes | 418 | 352 | -66 |
| Whole source module physical lines | 815 | 634 | -181 |
| Whole source module LLOC | 366 | 203 | -163 |

The isolated scope includes an identical minimal class/import fixture shell.
Its physical-line delta differs by one from the integrated module because of
blank-line placement. The whole-module replacement retains the other class
members unchanged by AST comparison. All new tables are in that module; no
configuration, runtime dependency or changed external caller is omitted.

LLOC counts statements, so combining consecutive appends into `extend` calls
contributes to its reduction. It does not independently prove less convolution.
The separate AST/decision counts show that duplicated control flow also declines;
the dictionary-entry count exposes the added data rather than hiding it in one
statement. Comments/docstrings also affect physical lines. No percentage here
means an equivalent reduction in maintenance effort.

AST decision points count `if`, conditional expressions, loops and exception
handlers, Boolean operator operands beyond the first, and comprehension loops
and filters. This definition is in [trial.py](trial.py); it is not cognitive
complexity. Lizard and Radon retain their own definitions. Internal call depth is
an inspected path: dispatch to renderer before; dispatch to compatibility method
to shared renderer to label lookup after. Built-ins are excluded.

## What stays different

One renderer retains section order and explicitly handles the German-only AGG
section. Translation data supplies labels and messages. German category names,
25-column formatting versus English 20-column formatting, unconditional German
language display, English detected-language display, defaults, severity icons,
list truncation and blank lines remain observable behavior.

The existing language-specific methods remain as small wrappers because public
dispatch calls them. A separate override check confirms both methods can still
be replaced on an instance. The implementation uses ordinary Python and does
not introduce a template language, a generic section engine or executable data.

Inline review finds one tradeoff worth retaining in the result: translations
are now looked up by their English text, so wording edits must update the mapping
consistently. The labels are visible in one table. This is a manual review, not
independent validation or a measured developer-maintenance exercise.

## Verification before and after

The [plan](plan.md), corpus generator and original output hashes were established
before the candidate. The first candidate needed no corrective revision.

| Run | Comparisons | Mismatches | Dispatch override check | Exit |
| --- | ---: | ---: | --- | ---: |
| Original characterization | 8,820 | Reference | Reference | 0 |
| Shared renderer | 8,820 | 0 | Preserved | 0 |
| Deliberate German-section omission | 8,820 | 2,251 | Preserved | 1 |

The corpus includes all 4,096 presence/absence combinations of twelve optional
sections in both languages (8,192 cases), plus 628 malformed, boundary and
dispatch cases. Inputs are fictional JSON-shaped data. Comparisons require exact
returned text or exception class/message, including unsuccessful-result behavior.
Full-section examples are retained for [English](example-en.txt) and
[German](example-de.txt). No real candidate documents were read.

The deliberate mutant disables the German-only section. Its 2,251 mismatches
show that the corpus detects that information loss; this is not a mutation score.
The candidate and mutant use exactly the same frozen oracle. The broader Python
renderer tests were not found in the inspected ATS tests tree, so this is new
characterization coverage, not a claim that a pre-existing full suite passed.

Limits: finite comparisons do not prove equivalence for every input. Arbitrary
objects with side-effecting special methods, collisions with the new private
helper in downstream subclasses, OpenAI calls, CV parsing and the current skill's
WordCraft workflow were not exercised. Both renderers are extracted as original
source spans; the containing module is reconstructed and compiled, not imported
with live external dependencies. No SMT claim is made.

## Cost, decision and reusable lesson

One real source family was selected, one candidate was tested and one deliberately
broken control challenged the checks. There is a useful scoped reduction on the
tested boundary. Upstream adoption is zero; no code was changed in ats-agent,
npu_rag_from_folder or Lesscode production/tests during this trial.

The research scripts add 223 physical Python lines: 151 for characterization and
comparison, 72 for integration accounting and charting. The candidate, mutant,
snapshots and oracle are separate experiment evidence. This research cost is not
subtracted from a product saving or presented as a net reduction in this checkout.
All frozen inputs remained unchanged. Dependencies of the product are unchanged;
Radon, Lizard and Matplotlib run only through uv in the research environment.

The reusable rule is to seek an entire repeated responsibility whose differences
can be retained as explicit data and small behavior variations. Freeze the scope
before rewriting. Count all support afterward. Reject improvements that only
redistribute decisions among functions. This trial supports that mechanism on
one historical renderer family; it does not establish a general success rate or
validate the separate NPU candidate.

## Inspect or reproduce

- [Original capability](original.py.txt), [candidate](candidate.py),
  [capability diff](candidate.diff), [whole-module diff](module.diff).
- [Candidate results](candidate-result.json), [accounting](accounting.json),
  [mutant results](mutant-result.json), [oracle](oracle.json),
  [input fingerprints](frozen.json), [SVG chart](scope-chart.svg).
- [Runner](trial.py) and [integration/chart script](account.py).

Commands ran from Lesscode using its existing local Python 3.12.10:

```powershell
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/ats-report/trial.py freeze
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with radon==6.0.1 --with lizard==1.17.31 python docs/experiments/ats-report/trial.py candidate.py
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with radon==6.0.1 --with lizard==1.17.31 python docs/experiments/ats-report/trial.py mutant.py
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with radon==6.0.1 --with matplotlib==3.11.2 python docs/experiments/ats-report/account.py
```

The mutant's nonzero exit is expected. Freeze refuses an existing manifest;
preserve this directory before rerunning any command that regenerates evidence.

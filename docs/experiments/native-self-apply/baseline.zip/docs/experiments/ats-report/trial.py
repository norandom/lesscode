"""Characterize first, then compare a whole report capability in isolation."""
import ast
import copy
import difflib
import hashlib
import itertools
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ATS = ROOT.parent / "ats-agent"
NAMES = ("generate_report", "_generate_english_report", "_generate_german_report")


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load(text):
    namespace = {}
    exec(compile(text, "report-fixture", "exec"), namespace)
    return namespace["ReportFixture"]()


def corpus():
    parsing = dict(page_count=2, word_count=450, sections_found=["Experience", "Skills"],
                   has_contact_info=True, detected_language="de")
    sections = dict(
        parsed_information=dict(name="Fictional Person", email="fiction@example.invalid", phone="fictional",
            experience_years="5", skills=[f"skill-{i}" for i in range(12)], job_titles=[f"role-{i}" for i in range(7)]),
        spelling_errors=[dict(word="exampl", location="section", suggestion="example")],
        grammar_errors=[dict(issue="fictional grammar", location="section", suggestion="revision")],
        keyword_analysis=dict(overspecialized_terms=["term"], missing_common_keywords=["keyword"],
                              suggested_alternatives={"term": "alternative"}),
        industry_parsing_issues=[dict(issue="fictional issue", severity="high", location="section",
            ats_impact="fictional impact", score_deduction=3, recommendation="revision")],
        date_consistency=dict(has_issues=True, problems=["fictional date issue"]),
        employment_gaps=[dict(gap="fictional interval", duration=3, explained=False),
                         dict(gap="explained interval", duration=2, explained=True)],
        strengths=["fictional strength"], weaknesses=["fictional weakness"],
        improvement_steps=["fictional step"], ats_reasoning="Fictional analysis\nsecond line",
        agg_compliance_issues=[dict(issue="fictional issue", severity="high", location="section", recommendation="revision")])
    base = dict(overall_score=75, category_scores={"keywords": 75, "unknown_category": 0, "structure": None})
    for flags in itertools.product((False, True), repeat=len(sections)):
        ats = {**base, **{key: value for (key, value), flag in zip(sections.items(), flags) if flag}}
        for language in ("en", "de"):
            yield dict(success=True, ats_analysis=ats, parsing_summary=parsing, language=language), None
    full = dict(success=True, ats_analysis={**base, **sections}, parsing_summary=parsing, language="en")
    variants = [None, False, True, 0, -1, 3.5, "", "text", [], {}, [None], ["text"], [1]]
    for group in ("ats_analysis", "parsing_summary"):
        for key in full[group]:
            for value in variants + ["__DELETE__"]:
                item = copy.deepcopy(full)
                if value == "__DELETE__":
                    del item[group][key]
                else:
                    item[group][key] = value
                for language in ("en", "de"):
                    yield item, language
    for category in (None, -5, 0, 4, 5, 100, 105, 3.5, "75", True):
        item = copy.deepcopy(full)
        item["ats_analysis"]["category_scores"] = {"keywords": category, "context_match": 10}
        for language in ("en", "de"):
            yield item, language
    for field in ("spelling_errors", "grammar_errors", "industry_parsing_issues", "agg_compliance_issues", "employment_gaps"):
        for value in ({}, {"severity": None}, {"severity": "unexpected"}, {"explained": True}):
            item = copy.deepcopy(full)
            item["ats_analysis"][field] = [value]
            for language in ("en", "de"):
                yield item, language
    for language in (None, "en", "de", "fr", "", 0):
        for item in ({}, {"success": False}, {"success": False, "error": None}, full,
                     {"success": True}, {"success": True, "ats_analysis": {}}):
            yield item, language


def outcome(instance, item, language):
    try:
        return ["returned", instance.generate_report(copy.deepcopy(item), language)]
    except Exception as exc:
        return ["raised", type(exc).__name__, str(exc)]


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False).encode()).hexdigest()


if sys.argv[1] == "freeze":
    assert not (HERE / "frozen.json").exists()
    source = (ATS / "ats_agent.py").read_text(encoding="utf-8")
    (HERE / "source.py.txt").write_text(source, encoding="utf-8")
    nodes = [n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.FunctionDef) and n.name in NAMES]
    lines = source.splitlines(True)
    fixture = "from typing import Optional\n\nclass ReportFixture:\n" + "\n".join(
        "".join(lines[n.lineno - 1:n.end_lineno]) for n in nodes)
    (HERE / "original.py.txt").write_text(fixture, encoding="utf-8")
    originals = [outcome(load(fixture), *case) for case in corpus()]
    write_json(HERE / "oracle.json", [digest(value) for value in originals])
    (HERE / "example-en.txt").write_text(originals[8190][1], encoding="utf-8")
    (HERE / "example-de.txt").write_text(originals[8191][1], encoding="utf-8")
    paths = [ATS / name for name in ("ats_agent.py", "main.py", "example.py", "requirements.txt", "package.json")]
    paths += [p for p in (ROOT / "docs/experiments").rglob("*") if p.is_file()
              and HERE not in p.parents and "__pycache__" not in p.parts]
    paths += [p for folder in ("src", "tests") for p in (ROOT / folder).rglob("*")
              if p.is_file() and "__pycache__" not in p.parts]
    write_json(HERE / "frozen.json", {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    print(json.dumps(dict(cases=len(originals), original_recorded=True)))
else:
    candidate_path = HERE / sys.argv[1]
    candidate = candidate_path.read_text(encoding="utf-8")
    original = (HERE / "original.py.txt").read_text(encoding="utf-8")
    oracle = json.loads((HERE / "oracle.json").read_text())
    mismatches = []
    for number, case in enumerate(corpus()):
        actual = outcome(load(candidate), *case)
        if digest(actual) != oracle[number]:
            mismatches.append(dict(case=number, input=case, expected=outcome(load(original), *case), actual=actual))
    # Existing dispatch seam must remain observable to subclasses.
    dispatch = []
    for source in (original, candidate):
        instance = load(source)
        instance._generate_german_report = lambda *args: "override-de"
        instance._generate_english_report = lambda *args: "override-en"
        dispatch.append([instance.generate_report(dict(success=True, ats_analysis={}, parsing_summary={}), language)
                         for language in ("de", "en", None)])
    from radon.raw import analyze
    import lizard

    def metrics(text):
        tree = ast.parse(text)
        return dict(physical=len(text.splitlines()), lloc=analyze(text).lloc,
                    functions=sum(isinstance(n, ast.FunctionDef) for n in ast.walk(tree)),
                    decisions=sum(isinstance(n, (ast.If, ast.IfExp, ast.For, ast.While, ast.ExceptHandler))
                                  + (len(n.values)-1 if isinstance(n, ast.BoolOp) else 0)
                                  + (1+len(n.ifs) if isinstance(n, ast.comprehension) else 0) for n in ast.walk(tree)),
                    ccn_sum=sum(f.cyclomatic_complexity for f in lizard.analyze_file.analyze_source_code("report.py", text).function_list))

    frozen = json.loads((HERE / "frozen.json").read_text())
    changed = [p for p, value in frozen.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest() != value]
    result = dict(cases=len(oracle), mismatches=len(mismatches), witnesses=mismatches[:8],
                  dispatch_preserved=dispatch[0] == dispatch[1], changed_inputs=changed,
                  scope={"original": metrics(original), "candidate": metrics(candidate)},
                  candidate_sha256=hashlib.sha256(candidate_path.read_bytes()).hexdigest())
    write_json(HERE / (candidate_path.stem + "-result.json"), result)
    (HERE / (candidate_path.stem + ".diff")).write_text("".join(difflib.unified_diff(
        original.splitlines(True), candidate.splitlines(True), fromfile="original", tofile=candidate_path.name)), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "witnesses"}))
    assert not changed and dispatch[0] == dispatch[1]
    raise SystemExit(bool(mismatches))

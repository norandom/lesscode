from typing import Optional

GERMAN = {
    "ATS CV COMPATIBILITY REPORT": "ATS LEBENSLAUF-KOMPATIBILITÄTSBERICHT",
    "OVERALL ATS SCORE": "GESAMT-ATS-BEWERTUNG",
    "CATEGORY SCORES:": "KATEGORIE-BEWERTUNGEN:",
    "PARSING SUMMARY:": "PARSING-ZUSAMMENFASSUNG:",
    "Pages": "Seiten",
    "Words": "Wörter",
    "Sections Found": "Gefundene Abschnitte",
    "None detected": "Keine erkannt",
    "Contact Info": "Kontaktinformationen",
    "EXTRACTED INFORMATION:": "EXTRAHIERTE INFORMATIONEN:",
    "Email": "E-Mail",
    "Phone": "Telefon",
    "Experience": "Berufserfahrung",
    "Not found": "Nicht gefunden",
    "Unknown": "Unbekannt",
    "Skills": "Kenntnisse",
    "Job Titles": "Berufsbezeichnungen",
    "SPELLING ERRORS FOUND:": "RECHTSCHREIBFEHLER GEFUNDEN:",
    "GRAMMAR ERRORS FOUND:": "GRAMMATIKFEHLER GEFUNDEN:",
    "Suggestion": "Vorschlag",
    "KEYWORD OPTIMIZATION:": "KEYWORD-OPTIMIERUNG:",
    "  Overspecialized terms (too niche):": "  Überspezialisierte Begriffe (zu spezifisch/selten):",
    "Consider": "Erwägen Sie",
    "  Missing common keywords:": "  Fehlende gängige Keywords:",
    "⚠ INDUSTRY ATS PARSING ISSUES:": "⚠ INDUSTRIE-STANDARD ATS-PARSING-PROBLEME:",
    "Based on real ATS systems (Ashby, Greenhouse, Workday, Lever):": "Basierend auf echten ATS-Systemen (StepStone, XING, Indeed.de):",
    "Location": "Position",
    "ATS Impact": "ATS-Auswirkung",
    "Score Deduction": "Punktabzug",
    "points": "Punkte",
    "Fix": "Behebung",
    "⏰ DATE FORMAT ISSUES:": "⏰ DATUMSFORMAT-PROBLEME:",
    "📅 EMPLOYMENT GAPS (Unexplained):": "📅 BESCHÄFTIGUNGSLÜCKEN (Unerklärte):",
    "months": "Monate",
    "  Recommendation: Add explanations (e.g., 'Sabbatical', 'Professional Development')": "  Empfehlung: Lücken erklären (z.B. 'Sabbatical', 'Weiterbildung', 'Elternzeit')",
    "STRENGTHS:": "STÄRKEN:",
    "WEAKNESSES:": "SCHWÄCHEN:",
    "IMPROVEMENT RECOMMENDATIONS:": "VERBESSERUNGSEMPFEHLUNGEN:",
    "DETAILED ANALYSIS:": "DETAILLIERTE ANALYSE:",
}
CATEGORY_NAMES_DE = {
    "keywords": "Schlüsselwörter",
    "structure": "Struktur",
    "parsing_capability": "Parsing-Fähigkeit",
    "content_quality": "Inhaltsqualität",
    "spelling_grammar": "Rechtschreibung/Grammatik",
    "agg_compliance": "AGG-Konformität",
    "context_match": "Kontext-Übereinstimmung",
}


class ReportFixture:
    def generate_report(self, analysis_result: dict, language: Optional[str] = None) -> str:
        """Dispatch the existing public report operation, including error behavior."""
        if not analysis_result.get("success"):
            error_msg = analysis_result.get('error', 'Unknown error')
            return f"ERROR: {error_msg}" if language != "de" else f"FEHLER: {error_msg}"
        if language is None:
            language = analysis_result.get("language", "en")
        ats = analysis_result["ats_analysis"]
        parsing = analysis_result["parsing_summary"]
        if language == "de":
            return self._generate_german_report(ats, parsing)
        else:
            return self._generate_english_report(ats, parsing)

    def _generate_english_report(self, ats: dict, parsing: dict) -> str:
        return self._render_report(ats, parsing, german=False)

    def _generate_german_report(self, ats: dict, parsing: dict) -> str:
        return self._render_report(ats, parsing, german=True)

    def _render_report(self, ats: dict, parsing: dict, *, german: bool) -> str:
        """One section sequence; translations are data, German-only behavior explicit."""
        def label(english: str) -> str:
            return GERMAN.get(english, english) if german else english

        report = ["=" * 80, label("ATS CV COMPATIBILITY REPORT"), "=" * 80, "",
                  f"{label('OVERALL ATS SCORE')}: {ats.get('overall_score', 'N/A')}/100", ""]
        if german:
            report.extend(["Erkannte Sprache: Deutsch", ""])
        elif parsing.get("detected_language"):
            lang_display = "German" if parsing["detected_language"] == "de" else parsing["detected_language"].upper()
            report.extend([f"Detected Language: {lang_display}", ""])
        report.extend([label("CATEGORY SCORES:"), "-" * 40])
        for category, score in ats.get("category_scores", {}).items():
            if score is not None:
                bar = "█" * (score // 5) + "░" * (20 - score // 5)
                category_name = category.replace('_', ' ').title()
                if german:
                    category_name = CATEGORY_NAMES_DE.get(category, category_name)
                width = 25 if german else 20
                report.append(f"  {category_name:{width}s}: {score:3d}/100 [{bar}]")
        report.extend(["", label("PARSING SUMMARY:"), "-" * 40,
                       f"  {label('Pages')}: {parsing['page_count']}",
                       f"  {label('Words')}: {parsing['word_count']}"])
        sections = ', '.join(parsing['sections_found']) if parsing['sections_found'] else label('None detected')
        report.extend([f"  {label('Sections Found')}: {sections}",
                       f"  {label('Contact Info')}: {'✓' if parsing['has_contact_info'] else '✗'}", ""])
        parsed_info = ats.get("parsed_information", {})
        if parsed_info:
            report.extend([label("EXTRACTED INFORMATION:"), "-" * 40,
                f"  Name: {parsed_info.get('name', label('Not found'))}",
                f"  {label('Email')}: {parsed_info.get('email', label('Not found'))}",
                f"  {label('Phone')}: {parsed_info.get('phone', label('Not found'))}",
                f"  {label('Experience')}: {parsed_info.get('experience_years', label('Unknown'))}"])
            if parsed_info.get('skills'):
                report.append(f"  {label('Skills')}: {', '.join(parsed_info['skills'][:10])}")
            if parsed_info.get('job_titles'):
                report.append(f"  {label('Job Titles')}: {', '.join(parsed_info['job_titles'][:5])}")
            report.append("")
        if german:
            agg_issues = ats.get("agg_compliance_issues", [])
            if agg_issues:
                report.extend(["⚠ AGG-KONFORMITÄTSPROBLEME GEFUNDEN:", "-" * 40,
                    "WARNUNG: Folgende Angaben sind in Deutschland seit 2006 nicht erlaubt",
                    "(Allgemeines Gleichbehandlungsgesetz - Diskriminierungsschutz):", ""])
                for i, issue in enumerate(agg_issues, 1):
                    severity_icon = {"high": "❌", "medium": "⚠", "low": "ℹ"}.get(issue.get("severity", "medium"), "⚠")
                    report.extend([f"  {severity_icon} {i}. {issue.get('issue')} (gefunden in: {issue.get('location')})",
                                   f"       Empfehlung: {issue.get('recommendation')}"])
                report.append("")
        spelling_errors = ats.get("spelling_errors", [])
        if spelling_errors:
            report.extend([label("SPELLING ERRORS FOUND:"), "-" * 40])
            for i, error in enumerate(spelling_errors, 1):
                report.extend([f"  {i}. '{error.get('word')}' in {error.get('location')}",
                               f"     → {label('Suggestion')}: {error.get('suggestion')}"])
            report.append("")
        grammar_errors = ats.get("grammar_errors", [])
        if grammar_errors:
            report.extend([label("GRAMMAR ERRORS FOUND:"), "-" * 40])
            for i, error in enumerate(grammar_errors, 1):
                report.extend([f"  {i}. {error.get('issue')} in {error.get('location')}",
                               f"     → {label('Suggestion')}: {error.get('suggestion')}"])
            report.append("")
        keyword_analysis = ats.get("keyword_analysis", {})
        if keyword_analysis and (keyword_analysis.get("overspecialized_terms") or
                                 keyword_analysis.get("missing_common_keywords")):
            report.extend([label("KEYWORD OPTIMIZATION:"), "-" * 40])
            if keyword_analysis.get("overspecialized_terms"):
                report.append(label("  Overspecialized terms (too niche):"))
                for term in keyword_analysis["overspecialized_terms"]:
                    alternative = keyword_analysis.get("suggested_alternatives", {}).get(term, "N/A")
                    report.append(f"    • '{term}' → {label('Consider')}: '{alternative}'")
            if keyword_analysis.get("missing_common_keywords"):
                report.append(label("  Missing common keywords:"))
                for keyword in keyword_analysis["missing_common_keywords"]:
                    report.append(f"    • {keyword}")
            report.append("")
        parsing_issues = ats.get("industry_parsing_issues", [])
        if parsing_issues:
            report.extend([label("⚠ INDUSTRY ATS PARSING ISSUES:"), "-" * 40,
                           label("Based on real ATS systems (Ashby, Greenhouse, Workday, Lever):"), ""])
            for i, issue in enumerate(parsing_issues, 1):
                severity_icon = {"critical": "❌", "high": "⚠", "medium": "ℹ", "low": "•"}.get(issue.get("severity", "medium"), "ℹ")
                report.extend([f"  {severity_icon} {i}. {issue.get('issue')} ({issue.get('severity', 'unknown').upper()})",
                    f"       {label('Location')}: {issue.get('location')}",
                    f"       {label('ATS Impact')}: {issue.get('ats_impact')}",
                    f"       {label('Score Deduction')}: -{issue.get('score_deduction', 0)} {label('points')}",
                    f"       {label('Fix')}: {issue.get('recommendation')}"])
            report.append("")
        date_issues = ats.get("date_consistency", {})
        if date_issues.get("has_issues"):
            report.extend([label("⏰ DATE FORMAT ISSUES:"), "-" * 40])
            for problem in date_issues.get("problems", []):
                report.append(f"  • {problem}")
            report.append("")
        emp_gaps = ats.get("employment_gaps", [])
        if emp_gaps:
            unexplained = [gap for gap in emp_gaps if not gap.get("explained", False)]
            if unexplained:
                report.extend([label("📅 EMPLOYMENT GAPS (Unexplained):"), "-" * 40])
                for gap in unexplained:
                    report.append(f"  • {gap.get('gap')}: {gap.get('duration')} {label('months')}")
                report.extend([label("  Recommendation: Add explanations (e.g., 'Sabbatical', 'Professional Development')"), ""])
        strengths = ats.get("strengths", [])
        if strengths:
            report.extend([label("STRENGTHS:"), "-" * 40])
            for strength in strengths:
                report.append(f"  ✓ {strength}")
            report.append("")
        weaknesses = ats.get("weaknesses", [])
        if weaknesses:
            report.extend([label("WEAKNESSES:"), "-" * 40])
            for weakness in weaknesses:
                report.append(f"  ✗ {weakness}")
            report.append("")
        improvements = ats.get("improvement_steps", [])
        if improvements:
            report.extend([label("IMPROVEMENT RECOMMENDATIONS:"), "-" * 40])
            for i, step in enumerate(improvements, 1):
                report.append(f"  {i}. {step}")
            report.append("")
        reasoning = ats.get("ats_reasoning", "")
        if reasoning:
            report.extend([label("DETAILED ANALYSIS:"), "-" * 40, reasoning, ""])
        report.append("=" * 80)
        return "\n".join(report)

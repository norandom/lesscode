"""Whole-module accounting and a standalone chart for the frozen scope."""
import ast
import difflib
import json
import importlib.metadata
from pathlib import Path

from radon.raw import analyze
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
original = (HERE / "source.py.txt").read_text(encoding="utf-8")
candidate = (HERE / "candidate.py").read_text(encoding="utf-8")
tree = ast.parse(candidate)
fixture = next(node for node in tree.body if isinstance(node, ast.ClassDef))
lines = candidate.splitlines(True)
constants = "".join("".join(lines[node.lineno - 1:node.end_lineno]) + "\n"
                    for node in tree.body if isinstance(node, ast.Assign))
body = "".join(lines[fixture.lineno:])
original_tree = ast.parse(original)
agent = next(node for node in original_tree.body if isinstance(node, ast.ClassDef))
entry = next(node for node in agent.body if isinstance(node, ast.FunctionDef) and node.name == "generate_report")
original_lines = original.splitlines(True)
module = ("".join(original_lines[:agent.lineno - 1]) + constants + "\n" +
          "".join(original_lines[agent.lineno - 1:entry.lineno - 1]) + body +
          "".join(original_lines[agent.end_lineno:]))
compile(module, "candidate-module", "exec")
replacement_agent = next(n for n in ast.parse(module).body if isinstance(n, ast.ClassDef))
scope_names = {"generate_report", "_generate_english_report", "_generate_german_report", "_render_report"}
assert [ast.dump(n) for n in agent.body if getattr(n, "name", None) not in scope_names] == [
    ast.dump(n) for n in replacement_agent.body if getattr(n, "name", None) not in scope_names]
(HERE / "candidate-module.py.txt").write_text(module, encoding="utf-8")
(HERE / "module.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(True), module.splitlines(True), fromfile="ats_agent.py",
    tofile="candidate/ats_agent.py")), encoding="utf-8")


def structural(text):
    nodes = list(ast.walk(ast.parse(text)))
    return dict(physical=len(text.splitlines()), lloc=analyze(text).lloc,
                ast_nodes=len(nodes), dictionary_entries=sum(len(n.keys) for n in nodes if isinstance(n, ast.Dict)),
                string_literals=sum(isinstance(n, ast.Constant) and isinstance(n.value, str) for n in nodes))


account = dict(module={"original": structural(original), "candidate": structural(module)},
               capability={"original": structural((HERE / "original.py.txt").read_text(encoding="utf-8")),
                           "candidate": structural(candidate)},
               added_runtime_dependencies=0, upstream_edits=0,
               surrounding_class_members_ast_unchanged=True,
               versions={name: importlib.metadata.version(name) for name in ("radon", "matplotlib")},
               internal_call_edges={"original": 1, "candidate": 3},
               research_physical_lines={p.name: len(p.read_text(encoding="utf-8").splitlines())
                                        for p in (HERE / "trial.py", HERE / "account.py")})
(HERE / "accounting.json").write_text(json.dumps(account, indent=2) + "\n")
results = json.loads((HERE / "candidate-result.json").read_text())
fig, axes = plt.subplots(1, 3, figsize=(10, 3.6))
for axis, key, label in zip(axes, ("physical", "lloc", "decisions"),
                            ("Physical lines", "Logical lines (Radon)", "AST decision points")):
    values = [results["scope"][name][key] for name in ("original", "candidate")]
    bars = axis.bar(["Original", "Candidate"], values, color=["#64748b", "#087e8b"])
    axis.bar_label(bars, padding=3)
    axis.set_ylim(0, max(values) * 1.2)
    axis.set_title(label)
    axis.spines[["top", "right"]].set_visible(False)
fig.suptitle("ATS01: complete bilingual reporting capability")
fig.text(.5, .01, "All translation data and wrappers included. Tested candidate; no upstream adoption.", ha="center", fontsize=9)
fig.tight_layout(rect=(0, .05, 1, .93))
fig.savefig(HERE / "scope-chart.svg")
fig.savefig(HERE / "scope-chart.png", dpi=150)
print(json.dumps(account))

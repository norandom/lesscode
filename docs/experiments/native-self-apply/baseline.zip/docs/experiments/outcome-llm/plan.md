# Stage 2: bounded LLM proposals with SMT feedback

Start from the preserved stage-1 candidate, not a new synthetic example. The
original remains the behavior oracle. Budget: at most three proposals, CCN cap
36, no more than 60 physical lines, LLOC below the original 62, no new helpers
or dependencies. The cap is a search constraint, not a claim of readability.

Proposal 1 replaces repeated Boolean comparisons/scans with tuple equality and
sets. It also tests shortening exhausted-budget handling to missing completeness
alone. Hypothesis: final fallback decisions already preserve the other cases.
Ask the existing source-derived SMT checker to challenge that hypothesis; retain
its counterexample if wrong. Concrete comparisons cover the changed inventory
and completeness operations outside the SMT boundary. Existing tests stay fixed.

Save each attempt separately. A runner reuses stage-1 verification/comparison
code in memory, redirects artifacts to the attempt directory and records
mismatches instead of stopping at the first one. It never overwrites stage 1.
No production or Facdrone edits are made. Hash all stage-1 evidence and the
production/test inputs before starting; verify those hashes at the end.

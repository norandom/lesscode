# Proposal 2

Restore the exhaustion guard after proposal 1 changed six concrete outcomes. Retain the tuple and set substitutions. Do not weaken the proof domain to dismiss the failure. The first SMT model allowed unreachable input combinations; concrete mismatches independently establish the defect.

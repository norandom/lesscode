"""Reuse the frozen stage-1 harnesses, writing only into a named new attempt."""
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PREVIOUS = HERE.parent / "outcome-hotspot"
attempt = HERE / sys.argv[1]
mode = sys.argv[2] if len(sys.argv) > 2 else "compare"
assert attempt.parent == HERE and attempt.is_dir()
manifest = json.loads((HERE / "preserved-inputs.json").read_text())
for relative, expected in manifest.items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative

filename = "verify_logic.py" if mode == "smt" else "trial.py"
script = (PREVIOUS / filename).read_text()
script = script.replace("HERE = Path(__file__).resolve().parent", f"HERE = Path({str(attempt)!r})")
script = script.replace("ROOT = HERE.parents[2]", f"ROOT = Path({str(ROOT)!r})")
if mode == "smt":
    script = script.replace('assert equivalence["status"] == "unsat", equivalence', "# Retain a failed proposal.")
else:
    script = script.replace('sorted(HERE.glob("*.py"))', f'sorted(Path({str(HERE)!r}).glob("*.py"))')
    script = script.replace("count = 0", "count = 0\nmismatches = []", 1)
    script = script.replace("assert actual == expected, (count, expected, actual)",
        "if actual != expected:\n        mismatches.append(dict(case=count, expected=repr(expected), actual=repr(actual)))")
    script = script.replace("differential_cases=count,", "differential_cases=count, mismatch_count=len(mismatches), first_mismatches=mismatches[:3],")
sys.argv = [filename] + ([mode] if mode in ("baseline", "candidate") else [])
exec(compile(script, str(PREVIOUS / filename), "exec"), {"__name__": "__main__", "__file__": str(PREVIOUS / filename)})

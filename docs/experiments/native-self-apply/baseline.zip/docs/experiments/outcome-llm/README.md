# SMT feedback caught an unsafe simplification; the revision saved no more lines

Stage 2 retained the 60-line candidate and tried two LLM-authored proposals.
The first changed six concrete outcomes. The second restored the missing
condition and passed the checks, reducing Lizard CCN from 45 to 43 while staying
at 60 physical lines and 41 LLOC. Neither met the provisional CCN cap of 36.
No production replacement was adopted.

![Original, intermediate and attempted implementations](progress.svg)

| Implementation | Physical lines | Radon LLOC | Lizard CCN | Concrete mismatches | Decision-boundary SMT |
| --- | ---: | ---: | ---: | ---: | --- |
| Production original | 72 | 62 | 54 | Oracle | Reference |
| Retained stage 1 | 60 | 41 | 45 | 0 / 20,258 | UNSAT |
| Proposal 1 | 60 | 41 | 42 | 6 / 20,258 | SAT |
| Proposal 2 | 60 | 41 | 43 | 0 / 20,258 | UNSAT |

The original and proposal 2 each passed the same 65 tests. Proposal 1 was rejected
before running that suite. These are repeated checks, not independent compression
experiments. All stage-1 files and production/test inputs were hash-checked and
preserved. Facdrone was not modified.

## What the feedback changed

Proposal 1 replaced compound equality checks with pair comparison, used sets for
status scans, and hypothesized that exhaustion needed only `not required_complete`.
That last change removed required policy: an exhausted run with recorded decision
`incomplete` and a completed, failed required check must stay incomplete. The
proposal instead rejected it.

SMT returned SAT first. Its initial model included `invalid=false` with recorded
decision `invalid`, which is unreachable in the complete function. A SAT model
from this abstraction is not automatically a realizable Python input. Concrete
comparison independently found six mismatches, including the case above. Those
establish an actual defect. Proposal 2 restored the original exhaustion guard
after this feedback, retaining the pair and set substitutions.

The revised final-decision query is UNSAT and all concrete comparisons match.
The proof still assumes equal incoming behavior and completeness. It does not
prove the rewritten scans or diagnostic construction; those have concrete test
evidence only. The deliberately broken invalidity-precedence mutant is still
detected. Source and queries are saved for both attempts.

This assistant acted as the LLM proposer, read the feedback and authored the
revision. Local scripts execute measurements and checks. This is a manually
orchestrated prototype, not an autonomous service or MCP server. No third
proposal was forced merely to consume the three-attempt budget: no further
useful deletion hypothesis was established in this bounded pass.

## Complete costs and decision

Proposal 2's whole experiments module would have 382 physical lines and 286 LLOC,
unchanged from stage 1. Production remains 17 Python files, 6,589 physical lines
and 5,563 LLOC. Tests remain 45 files, 7,863 physical lines and 6,402 LLOC. The new
runner adds 30 research-script lines / 28 LLOC and reuses the prior 251 script
lines / 183 LLOC. Snippets, diffs, queries, reports and logs are additional retained
evidence, not hidden production code or claimed savings. Bytes are not assessed.

The feedback loop prevented an unsafe change. It did not produce further line
savings. The lower CCN largely reflects tuple/set representation; maintenance
effort and comprehension were not measured. Keep both the intermediate and
revised candidates for comparison rather than declaring the cap satisfied.

Next: extend source-derived verification toward completeness and validate SAT
models against real inputs before feeding them back as defects. Select another
compression proposal only when it can remove maintained implementation. Do not
lower the cap or move branches into helpers just to label this round successful.
No Kiro spec or MCP infrastructure is expanded by this trial.

## Evidence and reproduction

- [Protocol](plan.md), [frozen input hashes](preserved-inputs.json).
- Proposal 1: [source](attempt-1/candidate.py.txt), [diff](attempt-1/candidate.diff),
  [measurements and mismatches](attempt-1/result.json), [SMT result](attempt-1/logic-result.json).
- Proposal 2: [hypothesis](attempt-2/hypothesis.md), [source](attempt-2/candidate.py.txt),
  [diff](attempt-2/candidate.diff), [measurements](attempt-2/result.json),
  [SMT result](attempt-2/logic-result.json), [baseline tests](attempt-2/baseline-tests.txt),
  [candidate tests](attempt-2/candidate-tests.txt).
- [Runner](run_attempt.py). An initial harness error came from an empty apparatus
  inventory; the runner was corrected to count its parent directory. This was
  not a candidate behavior failure. Final outputs are retained per attempt.

```powershell
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with z3-solver==4.15.3.0 python docs/experiments/outcome-llm/run_attempt.py attempt-2 smt
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/outcome-llm/run_attempt.py attempt-2
uv run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/outcome-llm/run_attempt.py attempt-2 candidate
```

Reproduction rewrites the selected attempt's generated outputs; use a separate
copy to retain an additional run. New hypotheses must use new directories. The
runner never regenerates snippets or stage-1 artifacts. The [progress report](../../reports/compression-trial-progress.md)
keeps historical populations and COBESY framing separate from these results.

# Next experiment: does shared repository knowledge improve compression?

Status: first pilot completed; see [run-01 results](run-01/README.md). The original
pre-run protocol is preserved in [run-01/protocol.md](run-01/protocol.md).
Production source, dependencies, Facdrone and Kiro specification status are unchanged.

## Hypothesis and comparison

One repository-wide capability discovery pass will help local LLM agents remove
custom implementation by reusing existing capabilities, while keeping dependency
choices consistent. Test the knowledge intervention separately from SMT: both
arms use the same verification requirements and available tools.

| Arm | Supplied context | Fixed conditions |
| --- | --- | --- |
| A: local discovery | Target responsibility, callers, tests, repository access and dependency policy | Same starting source, model/settings, task and proposal budget as B. May inspect the repository normally. |
| B: shared discovery | Everything in A plus the frozen global capability inventory | Same rules; inventory contains evidence, not prewritten candidate code. |

Both arms prohibit new runtime dependencies, upgrades, extras and manifest/lock
changes. This measures the benefit of shared knowledge, not the effect of giving
one arm permission to install a more powerful library. Record discoveries made
independently by arm A; do not deny it normal repository access.

Lesscode is the initial specimen. Its current `pyproject.toml` has no runtime
dependencies. Eligible replacements therefore come primarily from the supported
standard library and existing internal implementations. Build/analyzer/research
packages do not count as runtime capabilities. A lack of eligible opportunities
is a valid result; do not install a framework to rescue the hypothesis. A later
dependency-rich specimen can test external-library reuse separately. Facdrone
remains read-only and is not part of this round's mutation scope.

## Execution order and responsibilities

1. **Coordinator freezes the inputs.** Capture source identity, dirty-file state,
   production/test scope, dependency policy and measurement definitions. Preserve
   all prior experiment directories. Use isolated copies including current source
   changes; do not reset the checkout.
2. **Coordinator selects three responsibilities before seeing the inventory.**
   Start with existing size, complexity and duplication evidence, then inspect
   callers and tests. Choose whole operations, not arbitrary functions. Favor
   custom conversion/serialization, artifact handling or analyzer normalization
   where there is a concrete candidate for reuse. These are search areas, not
   asserted safe replacements. Exclude the already-exhausted outcome classifier
   and five-reader factory. Record every inspected candidate and exclusion.
3. **A discovery subagent runs once.** Follow the [global driver](../../repository-capability-driver.md).
   Inspect build/dependency roles, internal implementations and relevant APIs;
   publish the inventory and unresolved questions without authoring local patches.
   Record its time and tokens separately. Stop after 30 minutes if incomplete;
   retain limitations rather than silently extending the discovery budget.
4. **Fresh local agents run each arm independently.** Six isolated sessions for
   three matched responsibilities. No access to the other arm's proposal/results
   in the task context; keep generated artifacts outside the specimen. Alternate
   arm order across targets. Fresh contexts are practical contamination control,
   not a security boundary. Record model/settings and actual execution order.
5. **Each session gets at most two proposals and 20 minutes.** First state the
   specific implementation that could disappear, replacement capability, semantic
   differences and estimated whole saving. Reject unsupported API assumptions.
   Save proposal 1 before feedback; save any revision as proposal 2. No plausible
   deletion hypothesis is a recorded outcome, not a reason to invent scaffolding.
6. **Verifier checks saved candidates.** Use frozen original tests, targeted
   differential/property tests and source-derived SMT only for supported logic.
   Retain SAT/UNKNOWN and concrete counterexamples. Check whether SAT examples
   are realizable before labeling them source defects. Do not weaken tests or
   proof assumptions to accept a proposal. Allow up to 15 minutes of verification
   per proposal; an unfinished check is validation-incomplete.
7. **Coordinator compares and reviews.** Inspect whole replacements and naming,
   typing, explicit control flow and dependency consistency. Combine only disjoint
   viable patches in another isolated copy and run integration checks. Shared
   savings count once. No production adoption is required by this experiment.

If fewer than three defensible targets exist, keep the smaller denominator and
report limited applicability. Do not relabel tiny controls as efficacy trials.
Record time limits before launch; any necessary amendment gets a new protocol
revision and explanation, not a retroactive success criterion.

## Acceptance, metrics and falsification

Behavior and dependency constraints are hard gates. A viable simplification must
reduce both owned physical lines and Radon LLOC across the complete responsibility,
including helpers, tables, adapters and changed callers. It must preserve useful
types/names and pass review for understandable control flow. Retain the original
as a valid winner. Do not accept dense formatting as code removal.

CCN locates hotspots and describes the change. Do not carry the classifier's
arbitrary cap of 36 to unrelated responsibilities. Record per-function and whole
responsibility CCN/NLOC, including extracted helpers; explain increases rather
than hiding them. Bytes are not an assessment metric.

| Outcome | Report separately |
| --- | --- |
| Verified removal | Net physical lines and LLOC removed per target/arm, with the entire replacement accounted for. |
| Failures and missing evidence | No proposal, invalid API assumption, behavioral failure, unsupported proof, timeout, no useful reduction. Missing measurements are not zero. |
| Dependency coherence | Manifest/lock drift, unapproved imports, competing providers and duplicate adapters, even in rejected proposals. |
| Behavior evidence | Unchanged tests, differential checks and exact SMT boundary; do not sum repeated tests as independent evidence. |
| Review | Readable names/control flow, retained types, caller changes and semantic gaps. No invented maintainability score. |
| Cost | One-time discovery, per-arm proposal/verification time and tokens if available. Unavailable stays unavailable. |
| Footprint | Production, tests, fixtures and research apparatus separately; tests are not the reduction target. |

Compare paired target results before aggregating. Report arm B's discovery cost
in full and amortized across the actual number of targets; never omit it. This
small pilot is descriptive, not statistically conclusive. A non-viable candidate
has no adopted saving, but its raw measurement remains visible.

The hypothesis is weakened if shared discovery provides no additional verified
removal, creates incompatible choices, or costs more without observable benefit.
Successful simplifications in both arms may support the replacement mechanism
without supporting the inventory intervention. A positive pilot requires useful
verified removal on at least two targets in B, no dependency violations, and an
observed advantage over A that survives full-cost review. One target is a case
study. These are predeclared pilot decisions, not population-level guarantees.

## Evidence layout and continuation decision

On execution, create a new run directory beneath this experiment with input
hashes, selection ledger, global inventory and discovery cost. Each target has
separate A/B directories with prompts/context references, each proposal source,
diff, metrics, test logs, proof queries/assumptions and disposition. Use fresh run
IDs for reruns. Preserve failed attempts and intermediate versions verbatim.

Publish a paired-results table and one chart of verified whole-responsibility
line/LLOC changes, showing failed or incomplete attempts explicitly. Link it from
the progress report; never replace historical tables. Add integration results
only after combined patches are actually checked.

Decide whether to repeat on more targets, improve discovery, or move to a larger
dependency-rich specimen. Build MCP features only after repeated trials establish
which operations earn their cost. This protocol is the experiment design;
execution claims and results belong to the linked run report.

"""Freeze this pilot's inputs and create source-only local experiment copies."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / "docs/experiments/capability-guided/run-01"
BASE = ROOT / ".runs/capability-01/base"
RUN.mkdir(exist_ok=False)
BASE.mkdir(parents=True, exist_ok=False)
for name in ("src", "tests", "tools", "benchmarks", ".github", ".kiro/steering"):
    shutil.copytree(ROOT / name, BASE / name, ignore=shutil.ignore_patterns("__pycache__", "node_modules"))
for name in ("pyproject.toml", "requirements-tools.lock", "AGENTS.md"):
    shutil.copy2(ROOT / name, BASE / name)
paths = [p for p in BASE.rglob("*") if p.is_file()]
hashes = {p.relative_to(BASE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
prior = [p for name in ("outcome-hotspot", "outcome-llm", "reader-family", "cegis", "self-apply")
         for p in (ROOT / "docs/experiments" / name).rglob("*") if p.is_file() and "__pycache__" not in p.parts]
preserved = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in prior}
targets = {
    "T1": {"path": "src/lesscode_baseline/metrics.py", "responsibility": "analyzer measurement lifecycle",
           "members": ["measure_duplication", "measure_complexity", "measure_sizes"],
           "hypothesis": "Repeated staging, execution, diagnostics and evidence assembly may reuse one existing or simpler lifecycle while retaining analyzer-specific semantics."},
    "T2": {"path": "src/lesscode_baseline/report.py", "responsibility": "durable artifact publication and recovery",
           "members": ["RunStore", "persist", "recover", "persist_experiment", "recover_experiment"],
           "hypothesis": "Run and experiment storage repeat atomic publication and identity verification; an existing implementation may remove duplicate machinery without merging their distinct contracts."},
    "T3": {"path": "src/lesscode_baseline/rules/evidence.py", "responsibility": "admission of complete and partial stored rule evidence",
           "members": ["read_evidence", "_read_present", "_validate_partial_store", "_validate_available_records", "_validate_snapshot_identity", "_validate_report_bindings", "_validate_plan_identity", "_validate_bindings"],
           "hypothesis": "Evidence admission reconstructs references and identities already available elsewhere; reuse may remove duplicated reconstruction while retaining partial-store and corruption distinctions."}}
for target in targets.values():
    text = (BASE / target["path"]).read_text()
    target["spans"] = {node.name: [node.lineno, node.end_lineno] for node in ast.parse(text).body
                       if getattr(node, "name", None) in target["members"]}
(RUN / "inputs.json").write_text(json.dumps(dict(started_utc=datetime.now(timezone.utc).isoformat(),
    snapshot=str(BASE), hashes=hashes, preserved_previous=preserved, targets=targets,
    dependency_policy="No new runtime imports from external packages, upgrades, extras, manifest or lock changes. Standard library and existing internal capabilities only.",
    excluded=["outcome classifier: exhausted prior trial", "five-reader factory: prior marginal result",
              "glob matching: prior behavior mismatch", "config command integrity: distinct probe/trust roles; deferred"],
    metrics="Physical lines and Radon LLOC; Lizard CCN/NLOC; no bytes score",
    planned_order=["T1-A", "T2-B", "T3-A", "T1-B", "T2-A", "T3-B"],
    model_settings="Parent inherited model/settings for all fresh agents; exact model identifier and token telemetry unavailable through orchestration API."), indent=2) + "\n")
(RUN / "dirty-state.txt").write_text(subprocess.check_output(["git", "status", "--short"], cwd=ROOT, text=True))
print(RUN)

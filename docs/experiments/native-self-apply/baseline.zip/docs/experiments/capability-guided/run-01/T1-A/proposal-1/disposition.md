# Candidate 1 disposition

Rejected for changed behavior. No production adoption. The replacement reuses an existing internal worker; it is not a standard-library substitution. Local discovery did not consult the shared inventory.

The saved proposal reduces metrics.py from 567 to 564 physical lines, 364 to 358 Radon LLOC, and 507 to 504 Lizard NLOC. Complete module and per-function reports include the generalized worker and exception class. These small counts do not establish improved clarity or lower maintenance effort.

The worker call was moved inside complexity's report exception handler. Consequently, a real relative interpreter path that previously raises ContractError now becomes unavailable evidence with a misleading complexity-report reason. The external relative_runtime_probe.py reproduces this without mocks. Fault injection independently observes broadened handling for ValueError, TypeError, KeyError and UnicodeError; OSError still propagates. These checks are finite examples, not proof.

A separate outer exception handler and inner payload handler could restore the original exception boundary, but would consume most of the three-line saving. No second proposal was saved because that direction lacks a useful reduction hypothesis. Sharing the complete lifecycle would additionally need policies for size's accepted stderr, successful stderr artifact, runtime augmentation and separate byte measurement, versus duplication's multiple workers and CLI file report. Keeping these behaviors direct is preferable to adding a generic framework for this result.

Existing tests are unchanged. Logs and commands are retained separately. Native suites supply supplementary regression evidence; they cannot override the observed mismatch. No SMT model was constructed. No claims are made about non-Windows execution or exhaustive behavioral equivalence.

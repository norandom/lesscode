import ast, json, importlib.metadata
from pathlib import Path
from radon.raw import analyze
import lizard
ROOT=Path('D:/Source/lesscode')
E=ROOT/'docs/experiments/capability-guided/run-01/T2-B/proposal-1'
result={'definitions':{'physical':'splitlines count; target is union of complete top-level AST node spans from PersistenceError onward except render_experiment_summary, with no artificial separators counted','LLOC':'Radon raw analyze LLOC','NLOC':'Lizard file nloc; target text assembled with blank separators','CCN':'Lizard per function; nested functions retained; total sums listed functions'},'versions':{n:importlib.metadata.version(n) for n in ['lizard','radon']}}
for label,arm in [('baseline','base'),('candidate','T2-B')]:
    path=ROOT/'.runs/capability-01'/arm/'src/lesscode_baseline/report.py'
    text=path.read_text()
    nodes=[n for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.lineno >= next(n.lineno for n in ast.parse(text).body if getattr(n,'name',None)=='PersistenceError') and n.name!='render_experiment_summary']
    lines=text.splitlines()
    target='\n\n'.join('\n'.join(lines[n.lineno-1:n.end_lineno]) for n in nodes)+'\n'
    scopes={}
    for scope,code in [('module',text),('target',target)]:
        measured=lizard.analyze_file.analyze_source_code('report.py',code)
        scopes[scope]={'physical':len(code.splitlines()) if scope=='module' else sum(n.end_lineno-n.lineno+1 for n in nodes),'LLOC':analyze(code).lloc,'NLOC':measured.nloc,'CCN_sum':sum(f.cyclomatic_complexity for f in measured.function_list),'functions':[{'name':f.long_name,'NLOC':f.nloc,'CCN':f.cyclomatic_complexity} for f in measured.function_list]}
    result[label]={'path':str(path),'target_members':[n.name for n in nodes],**scopes}
(E/'measurements.json').write_text(json.dumps(result,indent=2))
print(json.dumps({label:{s:{k:v for k,v in result[label][s].items() if k!='functions'} for s in ['module','target']} for label in ['baseline','candidate']},indent=2))

from run_tests import run, BASE, CANDIDATE, EVIDENCE
for label, root in [('baseline', BASE), ('candidate', CANDIDATE)]:
    run(label+'-relative-runtime', root, [str(EVIDENCE/'relative_runtime_probe.py')])

from run_tests import run, BASE, CANDIDATE, EVIDENCE
for label, root in [('baseline', BASE), ('candidate', CANDIDATE)]:
    run(label+'-fault-probe', root, [str(EVIDENCE/'fault_probe.py')])

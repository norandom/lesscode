# T3-A outcome

One proposal saved, no production adoption. Locally qualifying modest compression: evidence.py 423 to 411 physical lines, Radon LLOC 326 to 317, Lizard NLOC 361 to 349. Eight admission functions total 173 to 160 physical lines and 148 to 138 LLOC. Module imports cost one extra logical/physical line. Existing provider implementations remain unchanged and are separately measured in measurements.json. Source and test audit reports only evidence.py changed; no dependency changes.

The candidate replaces repeated reference traversal and identity serialization with existing report._references, config._inventory_hash and snapshot._hash. Diagnostic construction, validation order and I/O remain as before. Private helper imports add coupling; no public API changes. This is not a substantial project-wide reduction or evidence of lower maintenance cost.

## Fresh verification

Baseline and candidate each ran 127 tests: OK, one skip (Windows symlink creation lacks privilege). EvidenceAdmissionTests directly covers incomplete-store admission, rehashed corruption, report-only stores, each reference category, plan-internal corruption, snapshot corruption, upstream outcomes and policy-reference binding. Rule evaluation and report storage tests add consumer/provider coverage. Both also passed 200 finite Unicode identity/reference checks. Thirty-two missing-record/corrupt-summary cases preserve failure kinds and ordered diagnostics after normalizing only temporary-root paths. No equivalence proof or SMT model claimed.

## Reproduction commands

From each copy root (base then T3-A), set PowerShell PYTHONPATH to that copy's absolute src and root separated by semicolon. Then run:

```
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python -m unittest tests.test_rule_evidence tests.test_rule_evaluation tests.test_report -v
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python D:/Source/lesscode/docs/experiments/capability-guided/run-01/T3-A/boundary_checks.py
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python D:/Source/lesscode/docs/experiments/capability-guided/run-01/T3-A/admission_matrix.py
```

From repository root:

```
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/capability-guided/run-01/T3-A/measure.py
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python docs/experiments/capability-guided/run-01/T3-A/finalize.py
```

All claimed validation commands exited zero. First baseline attempt used repository-root cwd and is retained as baseline-tests.log, excluded from claims; baseline-corrected-tests.log is authoritative. Module paths are recorded in both boundary logs. Both copies use .tools junction to existing D:/Source/lesscode/.tools. Source/test hashes, complete source/diff, metric logs, test logs and exits are retained. Research apparatus is outside product and test metrics.

## Timing correction

First exact timestamp is 2026-11-01T10:30:51.764065Z. Discovery/proposal observed interval 48.067731 seconds is a lower bound: initial reading was uninstrumented. The hypothesis's rough initial interval estimate is withdrawn. Verification window through result creation was 202.481343 seconds. Token telemetry unavailable. No comparative cost claim follows from this timing.

Claim gate: VERIFIED for the stated local test/measurement results, not FEATURE_GO. Coordinator independent review remains pending.

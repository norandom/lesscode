# T2-A preregistered hypothesis

Recorded before edits, 2026-11-01 (first clock 10:37:00 UTC; dispatched 10:36:44 UTC).

Assignment: Run independent local compression trial T2 arm A (LOCAL discovery, NO shared inventory). Target durable artifact publication/recovery src/lesscode_baseline/report.py: RunStore, persist, recover, persist_experiment, recover_experiment plus relevant helpers. Hypothesis: repeated atomic publication/identity verification may reuse existing or simpler operation while retaining distinct run/experiment contracts. Frozen base .runs/capability-01/base; own copy .runs/capability-01/T2-A; evidence docs/experiments/capability-guided/run-01/T2-A. Exclude .tools during copying and create a junction to root .tools. At most 20 minutes discovery/proposal, two proposals, 15 minutes verification each. Use unchanged tests, identical dependencies, uv and explicit Python from task brief. No production adoption.

Replace the two duplicate temporary-file write/flush/fsync/revalidate/replace sequences with one module-private durable publication operation. Keep overwrite checks, diagnostic strings, ownership recording and lifecycle sequencing at their original callers. Replace the three identical exclusive byte write/flush/fsync sequences with one module-private operation. The concrete removed code is repeated I/O protocol, not lifecycle validation. Estimated whole-module savings: 5-12 physical lines and 8-15 Radon logical lines. All helpers are counted.

This is a manually selected efficacy candidate with likely modest savings, not a promised substantial reduction. Keep the original if sharing adds excessive argument/concept burden. Recovery's three-line hashing loops differ in diagnostics; factoring these probably adds more code than it removes, so they remain unchanged. Required-set subset vs equality semantics, manifest types and ordering remain explicit.

Member matrix:
- RunStore._atomic: temporary file + durable exclusive write + revalidation + replacement; unowned existing targets rejected, owned targets may overwrite; record ownership only after replace.
- persist_experiment.atomic: identical low-level publication; only manifest may overwrite; experiment-specific refusal diagnostic.
- RunStore.write_artifact: durable exclusive write directly to raw output; create parent and revalidate before write, register only after durable write.

Boundary: whole report.py measured; target is RunStore, persist/recover and experiment persist/recover plus storage records and helper functions. Rendering remains unchanged, included in module accounting. Callers in evaluation.py, cli.py, experiments.py and rules/evidence.py unchanged. No dependency, manifest, configuration, test or public signature changes.

Verification: baseline/candidate tests.test_report and tests.test_experiment_cli; targeted fault-injection comparisons for atomic operations at write/fsync/replace and collision boundaries, saved outside product. Finite checks cannot prove crash durability or adversarial filesystem race equivalence. No SMT model warranted. Keep full candidate and result regardless of disposition.

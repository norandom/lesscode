from pathlib import Path
from datetime import datetime, timezone
p = Path('D:/Source/lesscode/.runs/capability-01/T2-B/src/lesscode_baseline/report.py')
s = p.read_text()
helper = '''def _publish(directory, relative, data, *, overwrite, conflict):
    target = _safe(directory, relative)
    if target.exists() and not overwrite:
        raise OSError(conflict + relative)
    temporary = _safe(directory, "." + relative + "." + uuid.uuid4().hex + ".tmp")
    # Leave interrupted temporary bytes available for diagnosis.
    with temporary.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    _safe(directory, relative)
    os.replace(temporary, target)


'''
s = s.replace('class RunStore:', helper + 'class RunStore:', 1)
a = s.index('        target = _safe(self.directory, relative)', s.index('    def _atomic('))
b = s.index('        self._owned.add(relative)', a)
s = s[:a] + '''        _publish(self.directory, relative, data, overwrite=relative in self._owned,
                 conflict="refusing to overwrite unowned artifact: ")
''' + s[b:]
a = s.index('        path = _safe(target, name)', s.index('    def atomic(name, data):'))
b = s.index('    try:', a)
s = s[:a] + '''        _publish(target, name, data, overwrite=name == "manifest.json",
                 conflict="refusing to overwrite an existing experiment artifact: ")
''' + s[b:]
p.write_text(s)
Path('D:/Source/lesscode/docs/experiments/capability-guided/run-01/T2-B/proposal-1/phase-times.json').write_text(__import__('json').dumps({'first_recorded_discovery_utc':'2026-11-01T10:30:49Z','proposal_saved_before_edits':True,'candidate_edit_finished_utc':datetime.now(timezone.utc).isoformat(),'token_count':None},indent=2))

# Executed commands and scope

Run with uv.exe resolved to C:/Users/mariu/AppData/Local/Microsoft/WinGet/Packages/astral-sh.uv_Microsoft.Winget.Source_8wekyb3d8bbwe/uv.exe.

Baseline cwd: D:/Source/lesscode/.runs/capability-01/base. Candidate cwd: D:/Source/lesscode/.runs/capability-01/T3-B. Each test command used PYTHONPATH="<cwd>/src;<cwd>".

```
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python -m unittest tests.test_rule_evidence tests.test_rule_evaluation tests.test_report -q
```

Differential command used baseline cwd/PYTHONPATH; the script explicitly loads the isolated candidate evidence module and prints both paths. Shared providers are byte-identical and imported from baseline for this comparison. The independent candidate suite imports providers from candidate.

```
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python D:/Source/lesscode/docs/experiments/capability-guided/run-01/T3-B/verify.py
uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python D:/Source/lesscode/docs/experiments/capability-guided/run-01/T3-B/measure.py
```

One initial combined read command failed PowerShell parsing (brace-style file enumeration); corrected with comma-separated literal paths. Another pre-test read used repository-relative paths while cwd was baseline and failed; the subsequent absolute PYTHONPATH/test command still ran. These were inspection errors, not discarded test failures. Copy used robocopy /E /XD .tools; .tools was created as junction to D:/Source/lesscode/.tools.

Direct admission coverage is EvidenceAdmissionTests in tests/test_rule_evidence.py. Existing tests include all five report reference categories with and without a plan, and source/profile/resource identities with deliberately rebound outer hashes. The entire test module, downstream rule evaluation, and storage test_report suite were selected. No production adoption or whole-project reduction claim.

"""Collect completed evidence without erasing the handed-off pending record."""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
target = HERE / "T1-A"
for path in (target / "result.json", target / "proposal-1/result.json"):
    backup = path.with_name("result-validation-pending.json")
    if not backup.exists():
        shutil.copy2(path, backup)
    result = json.loads(path.read_text())
    for side in ("baseline", "candidate"):
        command = json.loads((target / (side + "-tests.json")).read_text())
        assert command["returncode"] == 0
        log = (target / (side + "-tests.log")).read_text()
        count = int(re.search(r"Ran (\d+) tests", log)[1])
        result["regression_suites"][side] = {"status": "passed", "returncode": 0, "tests_run": count,
                                                   "start_utc": command["start_utc"], "end_utc": command["end_utc"]}
    result["timing"]["verification_end_utc"] = command["end_utc"]
    result["limitations"] = [v for v in result["limitations"] if "running at handoff" not in v]
    result["verification_claim"] = "46 unchanged native tests pass on both sides, but actual-input counterexample rejects the candidate. No equivalence claim."
    result["coordinator_handoff_note"] = "Agent terminal session unavailable after handoff. Baseline completed; candidate-only queued suite was resumed by coordinator. Original pending record preserved."
    path.write_text(json.dumps(result, indent=2) + "\n")

scripts = [p for p in HERE.rglob("*.py") if "source" not in p.relative_to(HERE).parts and "__pycache__" not in p.parts]
scripts.append(HERE.parent / "prepare_run.py")
copies = [p for p in HERE.rglob("*.py") if "source" in p.relative_to(HERE).parts]
footprint = {"research_scripts": {"files": len(scripts), "physical_lines": sum(len(p.read_text().splitlines()) for p in scripts),
                                  "paths": [p.relative_to(HERE.parent).as_posix() for p in scripts]},
             "archived_candidate_source": {"files": len(copies), "physical_lines": sum(len(p.read_text().splitlines()) for p in copies)},
             "production": {"files": 17, "physical_lines": 6589, "radon_lloc": 5563},
             "tests_including_fixtures": {"files": 45, "physical_lines": 7863, "radon_lloc": 6402},
             "scope_note": "Research scripts and archived candidate copies are additional evidence cost, not production savings. JSON/log/docs excluded from Python line populations."}
(HERE / "footprint.json").write_text(json.dumps(footprint, indent=2) + "\n")
review = {"completed_utc": datetime.now(timezone.utc).isoformat(), "discovery_runs": 1, "local_sessions": 6,
          "saved_proposals": 5, "paired_targets": 3, "positive_pilot_criterion_met": False,
          "qualifying_trials": ["T3-A", "T3-B"], "unique_qualifying_replacements": 1,
          "unique_potential_savings": {"physical": 12, "lloc": 9}, "production_adoptions": 0,
          "new_runtime_dependencies": 0, "coordinator_checks": ["all six module deltas recomputed", "source diffs reviewed",
          "T2-B 39 native tests per side plus matching 28 fault cases", "T3-B cross-arm 200 boundary checks passed with original"],
          "combined_integration": "Not applicable: only qualifying candidates overlap on the same replacement. No disjoint qualifying patches to combine.",
          "limits": ["Finite Windows tests; no SMT proof", "three manual target pairs; no replication",
                     "initial timing intervals incomplete; concurrent workload contention; tokens unavailable",
                     "no external runtime framework surface in Lesscode"]}
(HERE / "coordinator-review.json").write_text(json.dumps(review, indent=2) + "\n")
print(json.dumps({"review": review, "research_script_lines": footprint["research_scripts"]["physical_lines"]}, indent=2))

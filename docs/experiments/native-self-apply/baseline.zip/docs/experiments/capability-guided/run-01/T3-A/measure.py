from pathlib import Path
import ast, difflib, hashlib, json
import lizard
from radon.raw import analyze
root=Path('D:/Source/lesscode')
e=root/'docs/experiments/capability-guided/run-01/T3-A'
base=root/'.runs/capability-01/base'
candidate=root/'.runs/capability-01/T3-A'
rel=Path('src/lesscode_baseline/rules/evidence.py')
names={'read_evidence','_read_present','_validate_partial_store','_validate_available_records','_validate_snapshot_identity','_validate_report_bindings','_validate_plan_identity','_validate_bindings'}
def metrics(text):
    raw=analyze(text)
    liz=lizard.analyze_file.analyze_source_code('evidence.py',text)
    return {'physical_lines':len(text.splitlines()),'radon_lloc':raw.lloc,'lizard_nloc':liz.nloc,'functions':[{'name':f.name,'nloc':f.nloc,'ccn':f.cyclomatic_complexity} for f in liz.function_list]}
def selected(text,names):
    lines=text.splitlines(True)
    return '\n'.join(''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names)
result={}
for label,p in [('before',base),('after',candidate)]:
    text=(p/rel).read_text()
    result[label]={'module':metrics(text),'admission_functions':metrics(selected(text,names)),'source_sha256':hashlib.sha256((p/rel).read_bytes()).hexdigest()}
result['unchanged_reused_helpers']={}
for path,ns in [('report.py',{'_references'}),('config.py',{'_inventory_hash','_hash'}),('snapshot.py',{'_hash'})]:
    result['unchanged_reused_helpers'][path]=metrics(selected((base/'src/lesscode_baseline'/path).read_text(),ns))
result['note']='Reused providers unchanged; shared implementation counted separately, no provider deletion claimed.'
(e/'proposal-1/measurements.json').write_text(json.dumps(result,indent=2))
(e/'proposal-1/complete.diff').write_text(''.join(difflib.unified_diff((base/rel).read_text().splitlines(True),(candidate/rel).read_text().splitlines(True),fromfile='base/'+rel.as_posix(),tofile='T3-A/'+rel.as_posix())))
hashes={}
changes=[]
for p in base.rglob('*'):
    if not p.is_file() or '.tools' in p.parts or '__pycache__' in p.parts: continue
    relpath=p.relative_to(base)
    other=candidate/relpath
    if not other.exists() or p.read_bytes()!=other.read_bytes(): changes.append(relpath.as_posix())
    if relpath.parts[0]=='tests': hashes[relpath.as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(e/'proposal-1/test-hashes.json').write_text(json.dumps(hashes,indent=2))
(e/'proposal-1/change-audit.json').write_text(json.dumps({'changed_files':changes,'test_changes':0 if not any(x.startswith('tests/') for x in changes) else 'unexpected','dependency_changes': [x for x in changes if any(n in x for n in ('lock','toml','requirements'))]},indent=2))
print(json.dumps(result,indent=2))

from pathlib import Path
p = Path(r'D:/Source/lesscode/.runs/capability-01/T1-A/src/lesscode_baseline/metrics.py')
s = p.read_text()
s = s.replace('_DuplicationFailure', '_AnalyzerFailure').replace('_duplication_worker', '_analyzer_worker')
s = s.replace('def _analyzer_worker(command: ResolvedCommand, root: Path, logs: Path) -> tuple[object, str]:', '''def _analyzer_worker(command: ResolvedCommand, root: Path, logs: Path, *,
                     execution_label: str | None = None,
                     report_label: str = "malformed worker report: ") -> tuple[object, str]:''')
s = s.replace('{command.command_id} execution {result.status}', '{execution_label or command.command_id} execution {result.status}')
s = s.replace('_AnalyzerFailure("malformed worker report: " + str(exc)', '_AnalyzerFailure(report_label + str(exc)')
start = s.index('            result = _execute_analyzer(command, Path(staged.root), logs)', s.index('def measure_complexity'))
end = s.index('    return MetricEvidence("complexity"', start)
s = s[:start] + '''            try:
                report, artifact = _analyzer_worker(command, Path(staged.root), logs,
                    execution_label="complexity", report_label="complexity report: ")
                payload = _complexity_payload(report, staged)
            except _AnalyzerFailure as exc:
                reason, artifact = str(exc), exc.artifact
            except (ValueError, TypeError, KeyError, UnicodeError) as exc:
                reason = f"complexity report: {exc}"
''' + s[end:]
p.write_text(s)

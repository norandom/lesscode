import hashlib,json,re
from pathlib import Path
from datetime import datetime,timezone
R=Path('D:/Source/lesscode'); E=R/'docs/experiments/capability-guided/run-01/T2-B/proposal-1'
commands=json.loads((E/'commands.json').read_text()); metrics=json.loads((E/'measurements.json').read_text()); hashes=json.loads((E/'file-hashes.json').read_text())
assert len(commands)==6
assert all(c['returncode']==0 for c in commands)
assert json.loads((E/'baseline-faults.stdout').read_text())==json.loads((E/'candidate-faults.stdout').read_text())
changes=[p for p in hashes['baseline'] if hashes['baseline'][p]!=hashes['candidate'].get(p)]
assert changes==['src/lesscode_baseline/report.py']
deps={}
for name in ['pyproject.toml','requirements-tools.lock','tools/package.json','tools/package-lock.json','src/lesscode_baseline/data/requirements-tools.lock','src/lesscode_baseline/data/tools/package-lock.json']:
    deps[name]={arm:hashlib.sha256((R/'.runs/capability-01'/arm/name).read_bytes()).hexdigest() for arm in ['base','T2-B']}
    assert len(set(deps[name].values()))==1
(E/'dependency-check.json').write_text(json.dumps(deps,indent=2))
times=json.loads((E/'phase-times.json').read_text()); times['verification_start_utc']=commands[0]['start_utc']; times['verification_end_utc']=commands[-1]['end_utc']; times['report_finished_utc']=datetime.now(timezone.utc).isoformat();times['initial_discovery_interval']='unmeasured; first-recorded elapsed is a lower bound';(E/'phase-times.json').write_text(json.dumps(times,indent=2))
counts={label:re.search(r'Ran (\d+) tests in ([\d.]+)s', (E/(label+'-tests.stderr')).read_text()).groups() for label in ['baseline','candidate']}
result={'arm':'T2-B','proposal':1,'disposition':'equivalent_but_not_useful','behavior_status':'tested finite Windows cases; no proof','qualification':{'whole_module_physical_reduced':True,'whole_module_LLOC_reduced':True},'production_adoption':False,'adopted_savings':0,'changed_files':changes,'test_changes':0,'tests':counts,'fault_comparisons':{'cases_per_side':28,'equal':True,'coverage':'fsync and replace injected at positions 1 through 7 in run finalization and experiment publication; state, surviving filenames, operation counts and normalized diagnostics'},'metrics':{label:{scope:{k:v for k,v in metrics[label][scope].items() if k!='functions'} for scope in ['target','module']} for label in ['baseline','candidate']},'new_runtime_dependencies':[],'dependency_check':'dependency-check.json','test_source_hashes':'file-hashes.json','commands':'commands.json','timings':'phase-times.json','token_count':None,'limitations':['Initial discovery timing uninstrumented; elapsed from first clock is lower bound.','Finite unchanged native tests and targeted fault injection do not prove behavioral equivalence.','Windows only; power loss, directory fsync and hostile concurrent writers unverified.','Target physical measurement sums full AST node spans; whole module includes inter-node whitespace.','New private _publish helper couples two publication callers and adds a parameter boundary; only 3 whole-module physical lines saved, insufficient useful compression.','Overwrite membership/equality is now evaluated before _safe; ordinary internal str/set callers are unchanged but arbitrary monkeypatched objects are not modeled.','No SMT model or maintenance-cost claim.'],'research_apparatus':{p.name:len(p.read_text().splitlines()) for p in E.parent.glob('*.py')}}
(E/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

from pathlib import Path
import json,re,datetime
p=Path('D:/Source/lesscode/docs/experiments/capability-guided/run-01/T3-A')
a=json.loads((p/'baseline-matrix.json').read_text(encoding='utf-8-sig'))
b=json.loads((p/'proposal-1/matrix.json').read_text(encoding='utf-8-sig'))
def normalize(items):
    for item in items:
        item['diagnostics']=[re.sub(r'C:\\\\Users\\\\mariu\\\\AppData\\\\Local\\\\Temp\\\\tmp[^\\]+', '<TEMP>', d) for d in item.get('diagnostics',[])]
    return items
same=normalize(a)==normalize(b)
(p/'proposal-1/matrix-comparison.json').write_text(json.dumps({'equal_after_temp_root_normalization':same,'cases':len(a),'note':'Original outputs preserved. Normalize only machine temporary root; retain case name, artifact suffix, diagnostic sequence and failure kind.'},indent=2))
assert same
m=json.loads((p/'proposal-1/measurements.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc)
start=datetime.datetime.fromisoformat((p/'start-utc.txt').read_text().strip().replace('Z','+00:00'))
proposal=datetime.datetime.fromisoformat((p/'proposal-utc.txt').read_text().strip())
result={'trial':'T3-A','arm':'local discovery without inventory','proposal':1,'disposition':'provisionally qualifying compression; awaiting coordinator independent review; no production adoption','metrics':m,'tests':{'baseline':'127 tests, OK, skipped=1, 117.225s','candidate':'127 tests, OK, skipped=1, 116.889s','baseline_exit':0,'candidate_exit':0,'selected_modules':['tests.test_rule_evidence','tests.test_rule_evaluation','tests.test_report'],'boundary_checks':'200 finite Unicode identity/reference cases pass both; exits 0','admission_matrix':'32 cases of missing records and summary corruption; identical kinds and exact ordered diagnostics after temporary-root normalization; exits 0'},'test_changes':0,'dependency_changes':0,'new_helpers':0,'timing':{'first_instrumented_utc':start.isoformat(),'proposal_saved_utc':proposal.isoformat(),'verification_end_utc':now.isoformat(),'observed_proposal_seconds':(proposal-start).total_seconds(),'verification_window_seconds':(now-proposal).total_seconds(),'initial_read_interval':'unmeasured; observed discovery interval is lower bound, not total','token_count':'unavailable'},'limitations':['Finite tests, not proof. One platform-dependent test skipped.','Private internal helper reuse couples admission to existing config/report/snapshot implementations. No changes to providers.','Initial baseline test attempt used repository-root cwd; retained but excluded from validation claims. Corrected executions use frozen/candidate cwd and PYTHONPATH.','Saved hypothesis estimated initial read interval; that estimate is withdrawn, initial interval unmeasured.','Whole module reduction modest; no project-wide or maintenance-cost benefit claimed.']}
(p/'proposal-1/result.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'matrix_equal':same,'timing':result['timing'],'skip':[x for x in (p/'proposal-1/tests.log').read_text().splitlines() if 'skipped' in x]},indent=2))

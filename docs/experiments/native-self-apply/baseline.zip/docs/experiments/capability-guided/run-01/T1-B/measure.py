from pathlib import Path
import ast, hashlib, json, sys
import lizard
from radon.raw import analyze
root=Path('D:/Source/lesscode')
evidence=root/'docs/experiments/capability-guided/run-01/T1-B'
base=root/'.runs/capability-01/base'
copy=root/'.runs/capability-01/T1-B'
path=base/'src/lesscode_baseline/metrics.py'
source=path.read_text(encoding='utf-8')
lines=source.splitlines(keepends=True)
tree=ast.parse(source)
functions={node.name: node for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
names=['measure_duplication','measure_complexity','measure_sizes','_input_artifact','_execute_analyzer','_DuplicationFailure','_duplication_worker','_duplication_bounds','_duplication_payload','_complexity_payload','_real_path','_content','stage_product','_size_values']
def counts(text):
    info=lizard.analyze_file.analyze_source_code('metrics.py',text)
    return dict(physical_lines=len(text.splitlines()),radon_lloc=analyze(text).lloc,lizard_nloc=info.nloc,functions=[dict(name=f.name,nloc=f.nloc,ccn=f.cyclomatic_complexity) for f in info.function_list])
def span(node):
    start=min([node.lineno]+[d.lineno for d in getattr(node,'decorator_list',[])])
    return ''.join(lines[start-1:node.end_lineno])
result={'module':counts(source),'target_functions':{name:counts(span(functions[name])) for name in names},'target_including_helpers':counts('\n\n'.join(span(functions[name]) for name in names)),'boundary_note':'Module includes worker strings, constants and imports; function union includes all fourteen top-level callable/class definitions and nested payload helpers. Workers in strings count in whole-module physical lines; analyzer definitions govern LLOC/NLOC.'}
result['copy_identical']=path.read_bytes()==(copy/'src/lesscode_baseline/metrics.py').read_bytes()
result['before']=result['module'].copy();result['after']=result['module'].copy()
result['hashes']={str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [path,*sorted((base/'tests').rglob('*.py')),base/'pyproject.toml']}
result['test_changes']=[str(p.relative_to(base)) for p in (base/'tests').rglob('*.py') if p.read_bytes()!=(copy/p.relative_to(base)).read_bytes()]
result['dependency_manifest_changes']=[str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and '.tools' not in p.parts and (p.name.endswith('.lock') or p.name in ('pyproject.toml','package.json','package-lock.json')) and p.read_bytes()!=(copy/p.relative_to(base)).read_bytes()]
import lesscode_baseline.metrics as metrics
result['resolved_module']=metrics.__file__
(evidence/'measurements.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['module','target_including_helpers','copy_identical','test_changes','dependency_manifest_changes','resolved_module']},indent=2))

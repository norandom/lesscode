import hashlib, json, random
from types import SimpleNamespace as NS
from pathlib import Path
from lesscode_baseline import config, snapshot, report
from lesscode_baseline.rules import evidence
from lesscode_baseline import contracts
import tests.test_rule_evidence as tests_module
print('module paths',evidence.__file__,tests_module.__file__)
rng=random.Random(731)
for i in range(200):
    files=[NS(path=f'src/é漢字-{i}-{j}.py',size_bytes=rng.randrange(10000),content_hash=f'{rng.getrandbits(256):064x}') for j in range(i%9)]
    raw=json.dumps([[f.path,f.size_bytes,f.content_hash] for f in files],ensure_ascii=False,separators=(',',':')).encode()
    source_hash=hashlib.sha256(raw).hexdigest()
    evidence._validate_snapshot_identity(NS(files=files,content_hash=source_hash),'candidate')
    try: evidence._validate_snapshot_identity(NS(files=files,content_hash='z'*64),'candidate')
    except contracts.ContractError as exc: assert str(exc)=='candidate source identity differs from file inventory'
    else: raise AssertionError('corrupt snapshot accepted')
    resources=[NS(logical_path=f.path,path='D:/é漢字/'+f.path,content_hash=f.content_hash,size_bytes=f.size_bytes) for f in files]
    expected=hashlib.sha256(json.dumps([(r.logical_path,r.path,r.content_hash,r.size_bytes) for r in resources],separators=(',',':')).encode()).hexdigest()
    assert config._inventory_hash(resources)==expected
    scope={'root':'.','include':['é/**/*.py'],'exclude':[],'z':i,'a':i%4}
    assert snapshot._hash(scope)==hashlib.sha256(json.dumps(scope,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    paths=[None,'raw/é.json','raw/漢字.json','raw/a.json']
    sides=[]
    for side in range(2):
        sides.append(NS(metrics=[NS(raw_artifact=rng.choice(paths)) for _ in range(i%5)],checks=[NS(diagnostic_artifact=rng.choice(paths)) for _ in range(i%4)],failures=[NS(raw_artifact=rng.choice(paths)) for _ in range(i%3)],executions=[NS(stdout_artifact=rng.choice(paths[1:]),stderr_artifact=rng.choice(paths[1:])) for _ in range(i%6)]))
    r=NS(baseline=sides[0],candidate=sides[1])
    expected=set()
    for obs in sides:
        expected.update(x.raw_artifact for x in obs.metrics)
        expected.update(x.diagnostic_artifact for x in obs.checks)
        expected.update(x.raw_artifact for x in obs.failures)
        for x in obs.executions: expected.update((x.stdout_artifact,x.stderr_artifact))
    expected.discard(None)
    assert set(report._references(r))==expected
print('200 finite Unicode identity/reference cases passed; exact invalid snapshot diagnostic checked. Not an equivalence proof.')

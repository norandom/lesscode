from pathlib import Path
import datetime
root=Path('D:/Source/lesscode')
p=root/'.runs/capability-01/T3-A/src/lesscode_baseline/rules/evidence.py'
s=p.read_text()
s=s.replace('from lesscode_baseline.report import ArtifactIndex, RunManifest, recover','from lesscode_baseline.report import ArtifactIndex, RunManifest, _references, recover\nfrom lesscode_baseline.config import _inventory_hash')
s=s.replace('from lesscode_baseline.snapshot import matches','from lesscode_baseline.snapshot import _hash as snapshot_hash, matches')
a=s.index('            references = set()',s.index('def _validate_partial_store'))
b=s.index('            if unindexed:',a)
s=s[:a]+'            unindexed = set(_references(report)) - indexed\n'+s[b:]
s=s.replace('    source_bytes = json.dumps([[f.path, f.size_bytes, f.content_hash] for f in snapshot.files],\n                             ensure_ascii=False, separators=(",", ":")).encode()\n    if hashlib.sha256(source_bytes).hexdigest() != snapshot.content_hash:', '    if snapshot_hash([[f.path, f.size_bytes, f.content_hash] for f in snapshot.files]) != snapshot.content_hash:')
a=s.index('    resource_bytes = ',s.index('def _validate_plan_identity'))
b=s.index('        raise baseline.ContractError("plan.evaluator_hash',a)
s=s[:a]+'    if _inventory_hash(prepared.evaluator_resources) != plan.evaluator_hash:\n'+s[b:]
s=s.replace('    scope_hash = hashlib.sha256(json.dumps(plan.profile.scope.to_dict(), ensure_ascii=False,\n                               sort_keys=True, separators=(",", ":")).encode()).hexdigest()', '    scope_hash = snapshot_hash(plan.profile.scope.to_dict())')
p.write_text(s)
e=root/'docs/experiments/capability-guided/run-01/T3-A'
(e/'proposal-1/source/src/lesscode_baseline/rules').mkdir(parents=True,exist_ok=True)
(e/'proposal-1/source/src/lesscode_baseline/rules/evidence.py').write_bytes(p.read_bytes())
(e/'proposal-utc.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat())

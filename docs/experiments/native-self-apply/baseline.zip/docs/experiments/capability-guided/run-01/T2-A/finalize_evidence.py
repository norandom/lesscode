from pathlib import Path
import hashlib, json
from datetime import datetime,timezone
root=Path('D:/Source/lesscode'); ev=root/'docs/experiments/capability-guided/run-01/T2-A'; proposal=ev/'proposal-1'
m=json.loads((proposal/'measurements.json').read_text()); runs=json.loads((proposal/'test-runs.json').read_text()); fault=json.loads((proposal/'fault-comparison.json').read_text())
def fingerprint(directory):
    return {str(p.relative_to(directory)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
base=root/'.runs/capability-01/base'; candidate=root/'.runs/capability-01/T2-A'
source_before=fingerprint(base/'src'); source_after=fingerprint(candidate/'src')
tests_before=fingerprint(base/'tests'); tests_after=fingerprint(candidate/'tests')
changed=[p for p in source_before.keys() | source_after.keys() if source_before.get(p)!=source_after.get(p)]
(proposal/'tree-checks.json').write_text(json.dumps({'source_before':source_before,'source_after':source_after,'tests_before':tests_before,'tests_after':tests_after},indent=2),encoding='utf-8')
now=datetime.now(timezone.utc).isoformat()
result={
 'trial':'T2-A','arm':'LOCAL discovery; no shared inventory','disposition':'equivalent_but_not_useful','adopted':False,
 'reason':'The entire module saves only one physical line and five logical lines after adding two helpers. The shared operation is coherent but too marginal to support substantial compression or justify adoption in this pilot.',
 'proposal_count':1,'production_files_changed_in_isolated_copy':changed,'root_production_adoption':False,
 'baseline_candidate_metrics':{label:{scope:m[label][scope] for scope in ('module','responsibility')} for label in ('baseline','candidate')},'delta':m['delta'],
 'size_gate_passed':all(m['delta']['module'][key]<0 for key in ('physical_lines','radon_LLOC')),
 'tests':{'same_native_modules':['tests.test_report','tests.test_experiment_cli'],'baseline':{'count':39,'skipped':1,'returncode':runs[0]['returncode']},'candidate':{'count':39,'skipped':1,'returncode':runs[1]['returncode']},'all_test_files_unchanged':tests_before==tests_after,'records':'test-runs.json','logs':['baseline-tests.log','candidate-tests.log']},
 'differential':fault,'dependency_check':{'manifest_hashes_equal':m['dependencies_unchanged'],'new_runtime_dependencies':0,'configuration_changes':0,'measurement_tools':m['versions'],'measurement_command':'uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/capability-guided/run-01/T2-A/measure.py'},
 'review':{'kind':'local self-review; coordinator independent review pending','finding':'No changed public API or error message; guards remain at callers. New helpers introduce two function boundaries for negligible physical reduction. Recovery logic left intact because distinct completeness and identity rules do not justify a generic policy layer.'},
 'limitations':['Finite native and differential tests are not an equivalence proof.','Symlink creation unavailable in this Windows session; the same native test skipped in both arms.','No power-loss test, filesystem adversary race test or maintenance-hours measurement.','No SMT extraction attempted.','No production adoption; adopted savings zero.'],
 'accounting':{'production':'one isolated module; every helper included','test_changes':0,'research_apparatus':[p.name for p in ev.glob('*.py')],'token_usage':None,'provider_cost':None},
 'timing':{'dispatch_utc':'2026-11-01T10:36:44+00:00','first_clock_utc':'2026-11-01T10:37:00+00:00','hypothesis_saved_utc':datetime.fromtimestamp((ev/'hypothesis.md').stat().st_mtime,timezone.utc).isoformat(),'proposal_saved_utc':datetime.fromtimestamp((proposal/'complete.diff').stat().st_mtime,timezone.utc).isoformat(),'verification_start_utc':runs[0]['started'],'verification_end_utc':now,'record_complete_utc':now,'phase_method':'Proposal boundaries use file mtimes captured at write; test/probe subprocess phase timings are in their records; final evidence check uses UTC clock. Token telemetry unavailable.'},
 'completion_gate':{'status':'VERIFIED','claim':'One isolated proposal saved and compared with frozen base; selected native tests pass and 36 finite fault outcomes match.','not_claimed':'general equivalence, useful substantial compression, production readiness'}
}
(proposal/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(ev/'result.json').write_text(json.dumps({'trial':'T2-A','disposition':result['disposition'],'adopted':False,'proposal_results':['proposal-1/result.json'],'timing':result['timing']},indent=2),encoding='utf-8')
summary=f'''# T2-A outcome

One proposal was tested; retain the original. The isolated replacement shares the durable exclusive-write and atomic-replace protocol while leaving ownership, diagnostics and lifecycle checks in their original callers.

Whole report.py: {m['baseline']['module']['physical_lines']} -> {m['candidate']['module']['physical_lines']} physical lines; {m['baseline']['module']['radon_LLOC']} -> {m['candidate']['module']['radon_LLOC']} Radon LLOC; {m['baseline']['module']['lizard_NLOC']} -> {m['candidate']['module']['lizard_NLOC']} Lizard NLOC. CCN sum rises by two because two helpers add function baseline units; no new branches. All helpers are included. The reduction passes the positive-size gate but is too small to treat as useful substantial compression.

Baseline and candidate each passed 39 native tests (one identical unavailable symlink test skipped). The 36 external fault scenarios matched in filesystem validation call order, errors, surviving bytes and recovery status. Full source, diff, measurements, unchanged test hashes, commands, timings and logs are in proposal-1. No dependencies or native tests changed. No source outside this arm was edited.

Disposition: equivalent_but_not_useful, based on finite checks and local self-review. Coordinator review remains independent. There was no production adoption, so adopted savings are zero. No second proposal was forced after the modest result. Recovery has distinct required-set and diagnostic contracts; sharing its already-short verification loop would not remove useful implementation.
'''
(ev/'outcome.md').write_text(summary,encoding='utf-8')
print(json.dumps({'changed':changed,'tests_unchanged':tests_before==tests_after,'disposition':result['disposition'],'metrics':{label:{k:m[label]['module'][k] for k in ('physical_lines','radon_LLOC','lizard_NLOC')} for label in ('baseline','candidate')},'complete':now},indent=2))

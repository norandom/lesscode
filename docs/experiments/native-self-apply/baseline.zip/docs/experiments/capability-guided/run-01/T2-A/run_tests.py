from pathlib import Path
import json, os, subprocess, time
from datetime import datetime, timezone
ROOT = Path('D:/Source/lesscode')
EVIDENCE = ROOT / 'docs/experiments/capability-guided/run-01/T2-A/proposal-1'
uv = 'C:/Users/mariu/AppData/Local/Microsoft/WinGet/Packages/astral-sh.uv_Microsoft.Winget.Source_8wekyb3d8bbwe/uv.exe'
results = []
for arm in ('base', 'T2-A'):
    copy = ROOT / '.runs/capability-01' / arm
    env = os.environ | {'PYTHONPATH': str(copy / 'src') + os.pathsep + str(copy)}
    command = [uv, 'run', '--no-project', '--no-python-downloads', '--python', str(ROOT / '.venv-task11/Scripts/python.exe'), 'python', '-m', 'unittest', '-v', 'tests.test_report', 'tests.test_experiment_cli']
    started = datetime.now(timezone.utc).isoformat()
    begin = time.monotonic()
    run = subprocess.run(command, cwd=copy, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    label = 'baseline' if arm == 'base' else 'candidate'
    (EVIDENCE / (label + '-tests.log')).write_text(run.stdout, encoding='utf-8')
    results.append({'label':label, 'command':command, 'cwd':str(copy), 'PYTHONPATH':env['PYTHONPATH'], 'started':started, 'elapsed_seconds':time.monotonic()-begin, 'returncode':run.returncode})
    print(label, run.returncode, run.stdout[-150:])
(EVIDENCE / 'test-runs.json').write_text(json.dumps(results, indent=2), encoding='utf-8')

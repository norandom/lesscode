# T1-A preregistered hypothesis

Discovery began before the first exact recorded clock, 2026-11-01T10:30:18.3289543Z. The earlier interval is unmeasured; no start time is estimated. Proposal was saved at 2026-11-01T10:31:18.1275734Z, so measured discovery/proposal elapsed is a lower bound of 59.80 seconds.
Arm A uses local discovery only; no shared capability inventory or other arms read.

Replace complexity's repeated execute/stderr gate/JSON decoding with the existing duplication worker lifecycle, generalized by diagnostic labels. Retain staging, syntax validation, final evidence assembly and analyzer-specific payload validation as direct code. Keep original is an explicit alternative.

Owned boundary is all of metrics.py, with target family measure_duplication, measure_complexity, measure_sizes, and every helper. Only this module may change. Callers in evaluation.py invoke all three as independent measured phases; their public signatures remain stable. Existing worker already owns command execution, strict stderr rejection, report parsing, and diagnostic artifact selection.

| Member | Shared operation | Required variation |
| --- | --- | --- |
| duplication | staged inputs, worker stdout JSON, stderr failure | multiple commands, syntax/token inventory and CLI report file; specific error prefix; CLI artifact retained |
| complexity | staged inputs, worker stdout JSON, stderr failure | one command, complexity execution/report prefixes; strict payload inventory |
| sizes | staged inputs, worker stdout JSON | stderr is not fatal; successful artifact remains stderr; reports annotate runtime; byte measurement can fail afterward |

A broad shared lifecycle would require policies for distinct artifact selection, exception scope and report sources. It is not proposed. Candidate 1 shares only the existing strict worker between duplication and complexity. Rename private worker/failure for their broader role and add execution/report labels. Preserve command ids, execution order, staging cleanup, raw diagnostics, exception types caught at public boundaries, and persistence-error propagation. Estimate net 5-10 physical and 3-6 LLOC removed across complete module; this may be too marginal to justify adoption.

Verification: unchanged tests.test_metrics and tests.test_evaluation on base and candidate, plus external finite fault comparisons for strict-worker diagnostic text/artifacts and cleanup. No solver model. Dependencies, manifests, locks and tests must not change. Pin research tools lizard 1.17.31 and radon 6.0.1. Budget at most 20 minutes discovery, two proposals, 15 minutes verification each. Source identity, tests hashes, complete metrics and logs will be recorded. No production adoption authorized.


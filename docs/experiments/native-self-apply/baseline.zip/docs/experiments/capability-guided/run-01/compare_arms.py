"""Independent full-module accounting; candidate labels are reviewed separately."""
import ast
import hashlib
import json
from pathlib import Path
import runpy

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
helpers = runpy.run_path(str(HERE / "audit.py"))
measure, inputs = helpers["measure"], helpers["INPUTS"]
base = Path(inputs["snapshot"])
rows = []
for target in ("T1", "T2", "T3"):
    relative = inputs["targets"][target]["path"]
    for arm in ("A", "B"):
        name = target + "-" + arm
        candidate = ROOT / ".runs/capability-01" / name
        if not candidate.exists():
            continue
        changes = []
        for path in (candidate / "src").rglob("*.py"):
            rel = path.relative_to(candidate)
            old = base / rel
            if not old.exists() or old.read_bytes() != path.read_bytes():
                changes.append(rel.as_posix())
        for path in (base / "src").rglob("*.py"):
            rel = path.relative_to(base)
            if not (candidate / rel).exists():
                changes.append(rel.as_posix())
        before, after = ((root / relative).read_text(encoding="utf-8") for root in (base, candidate))
        measurements = {"before": measure(before), "after": measure(after)}
        all_delta = {key: 0 for key in measurements["before"]}
        for rel in changes:
            texts = [(root / rel).read_text(encoding="utf-8") if (root / rel).exists() else "" for root in (base, candidate)]
            old, new = map(measure, texts)
            for key in all_delta:
                all_delta[key] += new[key] - old[key]
        protected = [p.relative_to(base).as_posix() for p in (base / "tests").rglob("*")
                     if p.is_file() and "__pycache__" not in p.parts]
        protected += [p for p in inputs["hashes"] if p.endswith((".toml", ".lock", "package.json", "package-lock.json"))]
        drift = [p for p in protected if not (candidate / p).exists() or (base / p).read_bytes() != (candidate / p).read_bytes()]
        rows.append({"trial": name, "changed_source_files": changes, "module": measurements,
                     "all_changed_source_delta": all_delta, "test_dependency_drift": drift,
                     "candidate_source_sha256": hashlib.sha256((candidate / relative).read_bytes()).hexdigest()})
(HERE / "paired-measurements.json").write_text(json.dumps(rows, indent=2) + "\n")
for row in rows:
    print(row["trial"], row["all_changed_source_delta"], "drift", row["test_dependency_drift"])

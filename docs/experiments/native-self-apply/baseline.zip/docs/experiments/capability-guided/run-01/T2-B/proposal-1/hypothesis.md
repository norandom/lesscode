# T2-B proposal 1 (written before candidate edits)

First recorded UTC: 2026-11-01T10:30:49Z. Discovery began earlier in this turn; its exact start was not instrumented (approximately 10:28 UTC). Token count unavailable. Shared inventory arm; frozen base ../base; owned copy T2-B only. No production adoption.

Assignment: Run independent T2 arm B shared discovery trial on report.RunStore, persist, recover, persist_experiment, recover_experiment and relevant helpers. Investigate publication/identity reuse while keeping contracts distinct; max 20 minutes discovery, at most 2 proposals, 15 minutes verification per proposal. Standard library/internal dependencies only; unchanged tests and safeguards; full source/diff/measurements/logs required. Do not inspect other arms/prior experiments. Common instructions and supplied inventory are retained alongside this file.

## Hypothesis
Replace the repeated exclusive-temp/write/flush/fsync/revalidate/replace implementations in RunStore._atomic and persist_experiment.atomic with one module-private atomic publication operation using CG01-C5 and CG01-C6. Retain run ownership registration after successful publication, separate overwrite policies, exact diagnostic text and lifecycle ordering (CG01-C7/C8). Contract parsing and identity verification continue using CG01-C1/C6 unchanged. Approximately 6-10 physical lines and 6-9 LLOC should disappear including the new helper; estimates only.

| Member | Shared operation | Behavioral distinction retained |
| --- | --- | --- |
| RunStore._atomic | Safe target, exclusive temporary bytes, fsync, safe recheck, replace | Only owned names overwritten; successful publication adds ownership |
| persist_experiment.atomic | Same file publication sequence | Only manifest may overwrite; experiment error text |
| recover / recover_experiment | Hash comparison | Required subset versus exact artifact set; distinct diagnostics and output records |

Recovery identity loops are only three lines each; sharing needs a helper and diagnostic parameters without meaningful deletion. Leave them direct. Raw write_artifact is exclusive final-file creation and registration, not atomic replacement; leave it intact.

Alternative retained: original implementation. No runtime dependencies or manifest/config changes. Complete responsibility measurement includes storage record classes and all source from PersistenceError onward except render_experiment_summary, plus the new helper; whole report.py measured separately. Existing tests remain unchanged. Research scripts measured separately. Baseline/candidate tests: tests.test_report, tests.test_experiment_cli and storage consumer tests where relevant. Add external finite fault-injection comparisons for fsync/replace failures before edits; no solver model for filesystem semantics. Native Windows testing cannot establish all crash/concurrency or platform behavior.

Timing correction after proposal: the approximate 10:28 timestamp above is withdrawn; initial interval was uninstrumented. Use 10:30:49Z as the first exact observation and report elapsed from it only as a lower bound. No claim of full discovery duration is supported.

"""Coordinator measurements and input preservation checks for this pilot."""
import ast
import hashlib
import json
from pathlib import Path
import sys
import lizard
from radon.raw import analyze

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
INPUTS = json.loads((HERE / "inputs.json").read_text())
BASE = Path(INPUTS["snapshot"])


def measure(text):
    functions = lizard.analyze_file.analyze_source_code("input.py", text).function_list
    return {"physical": len(text.splitlines()), "lloc": analyze(text).lloc,
            "ccn": sum(f.cyclomatic_complexity for f in functions),
            "nloc": sum(f.nloc for f in functions)}


def target_text(text, names):
    lines = text.splitlines(True)
    return "\n".join("".join(lines[n.lineno - 1:n.end_lineno]) for n in ast.parse(text).body
                     if getattr(n, "name", None) in names)


def summarize(base):
    result = {}
    for target, info in INPUTS["targets"].items():
        text = (base / info["path"]).read_text(encoding="utf-8")
        result[target] = {"module": measure(text), "selected_members": measure(target_text(text, info["members"]))}
    for label, directory in (("production", "src"), ("tests", "tests")):
        values = [measure(p.read_text(encoding="utf-8")) for p in (base / directory).rglob("*.py")]
        result[label] = {"files": len(values), **{key: sum(v[key] for v in values) for key in values[0]}}
    return result


if len(sys.argv) == 1:
    result = summarize(BASE)
    (HERE / "baseline-measurements.json").write_text(json.dumps(result, indent=2) + "\n")
else:
    changed = []
    for relative, expected in INPUTS["hashes"].items():
        for base in (ROOT, BASE):
            if hashlib.sha256((base / relative).read_bytes()).hexdigest() != expected:
                changed.append(str(base / relative))
    for relative, expected in INPUTS["preserved_previous"].items():
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected:
            changed.append(relative)
    result = {"changed_inputs": changed, "frozen_inputs": len(INPUTS["hashes"]),
              "previous_artifacts": len(INPUTS["preserved_previous"])}
    (HERE / "preservation.json").write_text(json.dumps(result, indent=2) + "\n")
    assert not changed, changed
print(json.dumps(result, indent=2))

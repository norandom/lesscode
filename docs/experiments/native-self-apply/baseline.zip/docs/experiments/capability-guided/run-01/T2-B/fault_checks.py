import json, re, tempfile
from pathlib import Path
from unittest.mock import patch
from lesscode_baseline import report
from tests.test_report import RunPersistenceTests
from tests.test_experiment_cli import ExperimentCLI

results = []
for family in ('run', 'experiment'):
    for operation in ('fsync', 'replace'):
        for position in range(1, 8):
            fixture = RunPersistenceTests() if family == 'run' else ExperimentCLI()
            fixture.setUp()
            try:
                if family == 'run':
                    store = fixture.store()
                    fixture.raw(store)
                    target = fixture.target
                else:
                    fixture.add()
                    target = fixture.out
                original = getattr(report.os, operation)
                count = [0]
                def fault(*args, **kwargs):
                    count[0] += 1
                    if count[0] == position:
                        raise OSError('injected ' + operation)
                    return original(*args, **kwargs)
                error = None
                with patch.object(report.os, operation, fault):
                    try:
                        if family == 'run':
                            store.finalize(fixture.report)
                        else:
                            fixture.run_cli()
                            error = fixture.stderr.getvalue().strip() or None
                    except OSError as exc:
                        error = str(exc)
                recovered = report.recover(target) if family == 'run' else report.recover_experiment(target)
                names = sorted(re.sub(r'\.[0-9a-f]{32}\.tmp$', '.UUID.tmp', p.relative_to(target).as_posix()) for p in target.rglob('*') if p.is_file())
                results.append(dict(family=family, operation=operation, position=position,
                    calls=count[0], state=recovered.state, names=names,
                    error=None if error is None else error.replace(str(target.resolve()), 'TARGET')))
            finally:
                fixture.doCleanups()
print(json.dumps(results, indent=2))

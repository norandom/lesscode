from pathlib import Path
from datetime import datetime, timezone
import hashlib,json
root=Path('D:/Source/lesscode'); e=root/'docs/experiments/capability-guided/run-01/T1-B'
base=root/'.runs/capability-01/base'; copy=root/'.runs/capability-01/T1-B'
changes=[]
for folder in ('src','tests'):
    for p in (base/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.read_bytes()!=(copy/p.relative_to(base)).read_bytes():changes.append(str(p.relative_to(base)))
measure=json.loads((e/'measurements.json').read_text())
end=datetime.now(timezone.utc)
start=datetime.fromtimestamp((e/'baseline-tests.log').stat().st_ctime,timezone.utc)
test_end=datetime.fromtimestamp((e/'baseline-tests.log').stat().st_mtime,timezone.utc)
result={
'id':'T1-B','arm':'shared discovery','inventory':'CG01-v1','capability_ids':['CG01-C1','CG01-C2','CG01-C3','CG01-C4'],
'disposition':'no credible useful deletion hypothesis admitted; original retained','saved_proposals':0,'alternatives_examined':5,'adopted_replacements':0,
'production_changes':changes,'test_changes':measure['test_changes'],'dependency_manifest_changes':measure['dependency_manifest_changes'],
'module_before':measure['before'],'module_after':measure['after'],'physical_line_reduction':0,'lloc_reduction':0,
'baseline_test':{'command':'$env:PYTHONPATH="D:/Source/lesscode/.runs/capability-01/base/src;D:/Source/lesscode/.runs/capability-01/base"; uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python -m unittest tests.test_metrics -v','cwd':str(base),'exit_code':int((e/'baseline-tests.exit.txt').read_text()),'tests':30,'failures':0,'skipped':0,'elapsed_seconds':110.245,'log':'baseline-tests.log'},
'candidate_tests':'not run: no candidate; copied source and tests byte-identical',
'measurement_command':'PYTHONPATH=T1-B/src;T1-B uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/capability-guided/run-01/T1-B/measure.py',
'measurement_exit_code':0,'resolved_module':measure['resolved_module'],
'phase_timing':{'dispatch':'2026-11-01T10:35:43Z','first_clock':'2026-11-01T10:35:58Z','discovery_core_end':start.isoformat(),'baseline_verification_start':start.isoformat(),'baseline_verification_end':test_end.isoformat(),'evidence_finalize':end.isoformat(),'timing_note':'Verification timestamps use retained test log filesystem UTC timestamps. Discovery documentation and measurement overlapped verification; exact separate active CPU/token costs unavailable.'},
'costs':{'tokens':'unavailable','total_wall_seconds_from_dispatch':(end-datetime(2026,11,1,10,35,43,tzinfo=timezone.utc)).total_seconds()},
'limitations':['No candidate implementation or equivalence claim.','Line estimates in hypothesis are preimplementation estimates, not measured replacements.','Finite Windows tests only; no cross-platform claim.','No proof that further useful compression is impossible.','No production adoption authorized or performed.'],
'verification_gate':{'status':'VERIFIED','claim':'No-proposal local trial recorded; unchanged baseline 30 metrics tests passed; source/test hashes and manifest comparison show no changes.'}}
(e/'result.json').write_text(json.dumps(result,indent=2)+'\n')
(e/'complete.diff').write_text('')
print(json.dumps({'changes':changes,'result':str(e/'result.json'),'total_wall_seconds':result['costs']['total_wall_seconds_from_dispatch']},indent=2))

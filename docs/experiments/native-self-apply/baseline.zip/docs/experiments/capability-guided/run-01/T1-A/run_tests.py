from pathlib import Path
import datetime, json, os, subprocess, hashlib, sys, shutil
ROOT = Path(r'D:/Source/lesscode')
EVIDENCE = ROOT/'docs/experiments/capability-guided/run-01/T1-A'
BASE = ROOT/'.runs/capability-01/base'
CANDIDATE = ROOT/'.runs/capability-01/T1-A'
PYTHON = ROOT/'.venv-task11/Scripts/python.exe'
UV = shutil.which('uv.exe')

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(label, root, arguments):
    env = dict(os.environ, PYTHONPATH=str(root/'src') + os.pathsep + str(root))
    command = [UV, 'run', '--no-project', '--no-python-downloads', '--python', str(PYTHON), 'python', *arguments]
    start = now()
    result = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=780)
    (EVIDENCE/(label+'.log')).write_bytes(result.stdout)
    record = dict(command=command,cwd=str(root),PYTHONPATH=env['PYTHONPATH'],start_utc=start,end_utc=now(),returncode=result.returncode)
    (EVIDENCE/(label+'.json')).write_text(json.dumps(record,indent=2))
    print(label, result.returncode, flush=True)
if __name__ == '__main__':
 for label, root in [('baseline',BASE),('candidate',CANDIDATE)]:
    run(label+'-module-path', root, ['-c', 'import lesscode_baseline.metrics as m; import tests.test_metrics as t; print(m.__file__); print(t.__file__)'])
    run(label+'-tests', root, ['-m','unittest','tests.test_metrics','tests.test_evaluation','-v'])


# Shared capability knowledge did not increase verified removal in this pilot

The global discovery pass and all six local sessions ran. Both arms found the
same useful evidence-admission replacement: 12 fewer physical lines and 9 fewer
LLOC, with no new dependency. The shared-inventory arm did not produce additional
verified removal. Its analyzer agent declined a rewrite where the local agent
produced a behavior-changing candidate, which is an observation about restraint,
not evidence of a general causal benefit.

This pilot does not meet the predeclared positive-result criterion: useful
removal on at least two targets in arm B, plus an observed advantage over arm A.
The inventory workflow was exercised, but its compression benefit remains
unestablished. No candidate was applied to production or Facdrone.

![Raw candidate reductions and reviewed dispositions](paired-results.svg)

## Paired results, including unsuccessful attempts

Negative deltas mean less code. These are complete changed-module deltas,
including all new helpers and imports, not selected deleted blocks. All other
production files remain unchanged. Physical lines and Radon LLOC are different
definitions. No byte score is used.

| Responsibility | Arm | Physical delta | LLOC delta | CCN-sum delta | Reviewed outcome |
| --- | --- | ---: | ---: | ---: | --- |
| T1 analyzer measurement | A: local | -3 | -6 | -2 | Rejected: changes actual-input error behavior |
| T1 analyzer measurement | B: shared | 0 | 0 | 0 | Original retained; no useful proposal admitted |
| T2 artifact publication/recovery | A: local | -1 | -5 | +2 | Tested, but marginal; retain original |
| T2 artifact publication/recovery | B: shared | -3 | -7 | -1 | Tested, but marginal; retain original |
| T3 stored-evidence admission | A: local | -12 | -9 | -6 | Modest tested reuse candidate |
| T3 stored-evidence admission | B: shared | -12 | -9 | -6 | Same reuse candidate, differing import order |

T1-B's zero is measured unchanged source, not an invented saving or missing
measurement. New helper functions add base units to summed CCN, so its delta is
not a pure count of removed decisions. The two T3 candidates overlap completely:
unique potential removal is 12 lines / 9 LLOC, not 24 / 18. Actual production
removal is zero because this was an isolated experiment.

The T3 module changes from 423 to 411 physical lines and 326 to 317 LLOC. It
reuses `report._references`, `config._inventory_hash` and `snapshot._hash` while
retaining admission's corruption checks and diagnostic ordering. Review confirmed
that the hash representations match for validated records: ordered resource
tuples retain ASCII encoding; source file triples retain non-ASCII UTF-8; scope
dictionaries retain sorted keys. Private helper imports add coupling that must
remain visible. This is not a measured maintenance-hours improvement.

T2's wrappers preserve caller-specific ownership and lifecycle rules. Counting
the extracted helpers leaves only one or three module lines saved, with new
indirection; both agents and coordinator retain the original. T1-A changes a
relative interpreter path from a raised `ContractError` into unavailable metric
evidence. That concrete counterexample rejects it regardless of native tests.

## What actually ran

The coordinator selected three responsibilities before inspecting the inventory,
using existing structural measurements and manual inspection of repeated work.
Selected member spans initially totalled about 154, 278 and 173 physical lines;
full-module accounting above includes providers/helpers outside those spans.
No fresh automatic duplication census or entropy metric is claimed.

One fresh discovery subagent produced [CG01-v1](inventory.md). Six fresh local
contexts then ran in order T1-A, T2-B, T3-A, T1-B, T2-A, T3-B. The first wave and
second wave overlapped in time. A contexts could inspect the frozen repository
normally but were not supplied the inventory or other arms' results. B contexts
received the inventory. Shared files were technically accessible; isolation was
an instruction/context control, not an OS access boundary. All agents reported
respecting it. Same inherited model settings were used; exact model identifier
and token telemetry were unavailable.

Five proposals were saved across six sessions. No second proposal was forced.
Selection and dependency policy were identical across arms, but agents chose
different targeted tests and explored alternatives independently. This is an
exploratory three-pair pilot, not a randomized or replicated effectiveness study.

Lesscode declares no external runtime dependencies. The global inventory therefore
mostly describes standard-library and internal capabilities, not framework API
substitutions. Analyzer, build and research packages were explicitly excluded as
runtime providers. No manifests, locks, existing tests or dependency imports were
changed to obtain savings. This run cannot establish how much a richer framework
inventory would help a different project.

## Verification and the limits of the claims

| Trial | Retained evidence |
| --- | --- |
| [T1-A](T1-A/result.json) | 46 native tests pass per side, but a real relative-interpreter mismatch rejects the candidate. Passing native tests alone missed this defect. |
| [T1-B](T1-B/result.json) | Original retained; 30 baseline metric tests pass. No candidate to verify. |
| [T2-A](T2-A/proposal-1/result.json) | 39 native tests run per side, one identical Windows symlink skip; 36 fault scenarios match. |
| [T2-B](T2-B/proposal-1/result.json) | Coordinator ran the same 39 core tests per side, one identical skip; 28 fault scenarios match. Supplemental broad suite interrupted; no full-suite claim. |
| [T3-A](T3-A/proposal-1/result.json) | 127 tests run per side, one symlink privilege skip; 200 finite boundary cases and 32 partial-store comparisons match. |
| [T3-B](T3-B/result.json) | 127 tests run per side, one identical skip; 96 same-store missing/corrupt combinations match exact results and diagnostics. |

After both T3 agents finished, the coordinator independently reviewed their
diffs, recomputed complete module deltas and ran A's 200 Unicode/reference checks
against both the original and B's candidate. Both pass. The two candidates have
the same implementation changes apart from import ordering. There are no
disjoint qualifying patches to combine, so no combined multi-patch integration
result is claimed. The existing suites exercise admission with rule evaluation
and storage providers together.

All claims are finite Windows tests and review. No faithful SMT model of these
filesystem/serialization boundaries was extracted; no equivalence proof is
claimed. Unknown behavior remains unknown. Repeated test counts are not
independent samples or a project mutation score.

The first coordinator baseline lacked the repository-relative analyzer toolchain
and failed metric tests. Its [log](baseline-tests.txt) is retained. The same
existing toolchain was exposed through `.tools` junctions in both arms; the
[corrected 30-test run](baseline-metrics-corrected.txt) passes. This was environment
repair, not a test or dependency change. T3-A also retains and excludes its first
incorrect-working-directory run. Agent-session handoff did not preserve terminal
access; completed logs and explicit incomplete statuses, rather than assumed
passes, govern the validation record.

## Costs and preserved populations

Global discovery recorded 132.77 seconds after its first clock, plus an unmeasured
initial reading interval. Charge that cost to B in full. Across three B targets,
the measured portion amortizes to 44.26 seconds per target; this is a lower bound,
not a complete cost estimate. See [discovery metadata](discovery.json).

First-wave initial read intervals were not fully instrumented. Later dispatch
and phase times are recorded per arm. Concurrent tests contended for the same
machine, and native test selections differed, so elapsed-time differences do not
establish an efficiency advantage. Tokens and provider cost remain unavailable.

Production remains 17 Python files, 6,589 physical lines and 5,563 LLOC. Existing
tests/fixtures remain 45 Python files, 7,863 physical lines and 6,402 LLOC. Research
scripts, logs, candidate source copies and snapshots are separate evidence costs;
they are not product savings. [Footprint accounting](footprint.json) records them
separately. The pilot accumulated 1,096 research-script lines; this is explicit
experimental overhead, not additional product functionality or a net code saving.
Disposable working copies live under `.runs/capability-01/`; durable
sources, diffs, hypotheses and results live here.

The [input manifest](inputs.json) records the actual dirty source snapshot and
selection. [Preservation checks](preservation.json) compare frozen source/test/tool
inputs and prior artifacts. Existing unrelated work was not reverted. All earlier
outcome, reader and synthesis results remain separate from this trial.

## What this changes about the next step

Keep the shared-inventory design as an experimental coordination mechanism, not
as an established compression accelerator. This run shows a modest internal reuse
opportunity that either arm can discover. It does not justify an MCP server or
another sequence of local rewrites on these same responsibilities.

The next discriminating specimen should already have a meaningful runtime
framework/library surface. First identify concrete operations that its existing
stack can replace; keep dependencies frozen and preserve the A/B comparison.
This is a proposed next study, not authorization to modify Facdrone. A positive
result must come from removed implementation, not a larger inventory document.

The report follows the existing COBESY framing: let a negative result revise the
hypothesis, separate the tested mechanism from the intervention, and put the next
decision next to its evidence. No rollout or maintainability claim follows from
this small pilot.

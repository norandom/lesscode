# T1-B discovery disposition

No proposal admitted; original retained. This record precedes any source editing, and no source edits will be made. This is a manually selected real family, not a synthetic rejection control. Scope is the three measurement entry points, all their module-local helpers, worker strings and fixed definitions. Whole-module accounting prevents omission of residual support. The copied specimen and tests remain byte-identical.

## Candidate hypothesis examined

Replace repeated staging, inventory creation, execution validation and evidence assembly with existing shared capabilities or one simpler lifecycle, retaining analyzer-specific stderr handling, exception boundaries, diagnostic text, artifact selection, cleanup and payload contracts. Remove repeated scaffolding only if adapters plus shared implementation reduce the complete responsibility usefully.

CG01-C3 already provides verified disposable staging, filtering, byte validation, scope identity retention and cleanup. CG01-C2 already supplies bounded subprocess execution and retained diagnostics. CG01-C4 already supplies exclusive inventory artifacts, execution auditing and duplication JSON workers. CG01-C1 preserves public evidence validation; unvalidated serialization is not an alternative.

## Member matrix

| Member | Shared operations | Required behavior variations |
| --- | --- | --- |
| measure_duplication, metrics.py:91 | Typed input roundtrip, stage_product, inventory, _execute_analyzer | Syntax then tokenizer then CLI; stderr rejected; worker failure attaches stdout/stderr via _DuplicationFailure; CLI success uses fresh report path; broad report exception catch has duplication prefix. |
| measure_complexity, metrics.py:343 | Typed input roundtrip, stage_product, inventory, _execute_analyzer | Single Lizard worker; stderr rejected; execution diagnostic has complexity prefix, malformed JSON and payload errors have complexity report prefix; success artifact is stdout. |
| measure_sizes, metrics.py:504 | Typed input roundtrip, stage_product, inventory, _execute_analyzer | Syntax worker permits successful stderr; default artifact remains stderr; malformed syntax changes artifact to stdout; runtime version appended only after valid report; measurement OSError gets separate reason; three evidence records. |

Locations are specimen locators; full source is the authority.

## Alternatives rejected before implementation

1. A staging/inventory context manager. Each call site still needs staged Failure handling, paths for analyzer-specific verification and its distinct command. Removing three inventory blocks (about nine physical lines) costs approximately nine to thirteen helper lines plus replacement unpacking, with no established physical/LLOC reduction. Existing stage_product is already the substantive lifecycle provider.
2. Reuse _duplication_worker for complexity and sizes. Direct reuse changes exact reason prefixes and successful-stderr policy, loses sizes' success stderr artifact choice, and changes malformed-report exception detail. Parameterizing these behaviors or adding exception translation restores several independent policies. Estimated net removal is zero to roughly six physical lines, with LLOC reduction unestablished; the needed adapters do not support a useful whole-lifecycle reduction hypothesis. This is an estimate, not a measured candidate.
3. A common checked execution helper for duplication CLI, duplication worker and complexity. The repeated core is execution plus stderr read/status check. Duplication CLI failure text omits the command ID whereas the worker includes it; complexity separates execution and report exceptions. A helper plus three caller-specific exception boundaries is approximately break-even (roughly zero to five physical lines removed, LLOC not established). Size does not participate because its stderr behavior differs. The existing _execute_analyzer already shares audit work.
4. A generic evidence/finalization template. Duplication and complexity each construct one differently typed payload; sizes constructs three records and independently determines runtime provenance and value suppression. Callback/state adapters would move the existing policy rather than remove it. No credible positive net estimate was found.
5. Delete input revalidation because stage_product also validates Snapshot. Rejected: entry points validate snapshot before limits; moving validation later changes exception ordering, and a mutation between checks is not equivalent. Validation is not a deletion target without a preserved contract.

No proposed alternative clears a credible useful-deletion threshold without first hiding policies in configuration or callbacks. The original is retained. This finding is local to this responsibility and these bounded alternatives; it does not prove a smaller implementation is impossible. Zero proposals were saved and zero replacements adopted.

## Checks and cost scope

Unchanged tests.test_metrics runs against the frozen baseline with the root analyzer toolchain junction. It covers real analyzers, invalid syntax/encoding, malformed reports, omissions, warnings, limits, staging and cleanup. No integration suite is warranted because no product behavior changed. No new boundary test or SMT model is claimed. Existing finite tests establish only their exercised cases, not equivalence. All tests have recorded hashes. No candidate test run is needed for an unchanged copy and is not claimed.

Research files, logs and metrics are excluded from production measurements. No dependency, manifest, lock, test or fixture edits are permitted. The standalone measurement runner uses research-only pinned Radon 6.0.1 and Lizard 1.17.31 under uv; they are not introduced as runtime dependencies. Full module and the union of all target callable/class definitions are measured separately; no byte score is used.


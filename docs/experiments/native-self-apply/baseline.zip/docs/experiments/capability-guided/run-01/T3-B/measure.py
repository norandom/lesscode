import ast
import difflib
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
from radon.raw import analyze
import lizard

root = Path('D:/Source/lesscode')
evidence = root / 'docs/experiments/capability-guided/run-01/T3-B'
proposal = evidence / 'proposal-1'
relative = Path('src/lesscode_baseline/rules/evidence.py')
base = root / '.runs/capability-01/base'
candidate = root / '.runs/capability-01/T3-B'
(proposal / 'source' / relative.parent).mkdir(parents=True, exist_ok=True)
shutil.copy2(candidate / relative, proposal / 'source' / relative)
before, after = ((directory / relative).read_text(encoding='utf-8') for directory in (base, candidate))
(proposal / 'complete.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='base/'+relative.as_posix(), tofile='candidate/'+relative.as_posix())), encoding='utf-8')
metrics = {}
for label, directory, source in (('before', base, before), ('after', candidate, after)):
    target = source[source.index('def read_evidence('):]
    metrics[label] = {}
    for scope, text in (('whole_module', source), ('admission_responsibility', target)):
        result = lizard.analyze_file.analyze_source_code('evidence.py', text)
        metrics[label][scope] = {'physical_lines': len(text.splitlines()), 'radon_lloc': analyze(text).lloc,
            'lizard_nloc': result.nloc, 'lizard_ccn_sum': sum(f.cyclomatic_complexity for f in result.function_list),
            'functions': [{'name': f.name, 'nloc': f.nloc, 'ccn': f.cyclomatic_complexity} for f in result.function_list]}
    metrics[label]['source_sha256'] = hashlib.sha256((directory/relative).read_bytes()).hexdigest()
metrics['versions'] = {name: importlib.metadata.version(name) for name in ('radon', 'lizard')}
metrics['helper_cost'] = 'No new or changed helper; reuse existing report._references, config._inventory_hash, snapshot._hash. All added imports included in whole-module counts.'
metrics['unchanged_provider_modules'] = {}
for name in ('report', 'config', 'snapshot'):
    rel = Path('src/lesscode_baseline') / (name + '.py')
    content = (base/rel).read_bytes()
    assert content == (candidate/rel).read_bytes()
    source = content.decode('utf-8')
    measured = lizard.analyze_file.analyze_source_code(name+'.py', source)
    metrics['unchanged_provider_modules'][name] = {'physical_lines': len(source.splitlines()),
        'radon_lloc': analyze(source).lloc, 'lizard_nloc': measured.nloc,
        'lizard_ccn_sum': sum(f.cyclomatic_complexity for f in measured.function_list),
        'sha256': hashlib.sha256(content).hexdigest()}
(proposal / 'metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
hashes = {}
for path in base.rglob('*'):
    if path.is_file() and (path.suffix == '.py' and 'tests' in path.relative_to(base).parts or path.name in ('pyproject.toml','uv.lock','package.json','package-lock.json')):
        rel = path.relative_to(base)
        hashes[rel.as_posix()] = {'before': hashlib.sha256(path.read_bytes()).hexdigest(), 'after': hashlib.sha256((candidate/rel).read_bytes()).hexdigest()}
assert all(value['before'] == value['after'] for value in hashes.values())
(proposal / 'unchanged-tests-dependencies.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
print(json.dumps(metrics, indent=2))

from datetime import datetime, timezone
import json
from pathlib import Path
import shutil

root = Path('D:/Source/lesscode')
evidence = root/'docs/experiments/capability-guided/run-01/T3-B'
proposal = evidence/'proposal-1'
logs = proposal/'logs'
logs.mkdir(exist_ok=True)
for path in evidence.glob('*.log'):
    shutil.copy2(path, logs/path.name)
for path in evidence.glob('*.exit'):
    shutil.copy2(path, logs/path.name)
metrics = json.loads((proposal/'metrics.json').read_text())
result = {
    'trial': 'T3-B', 'proposal': 1, 'disposition': 'tested compression candidate; retained for coordinator review; no production adoption',
    'capability_ids': ['CG01-C1','CG01-C6','CG01-C9','CG01-C10'],
    'tests': {name: {'return_code': int((evidence/(name+'.exit')).read_text()), 'log': 'logs/'+name+'.log'} for name in ('baseline-tests','candidate-tests','differential','measurement','candidate-imports','skip-audit')},
    'baseline_tests': {'run':127,'skipped':1,'seconds':171.310},
    'candidate_tests': {'run':127,'skipped':1,'seconds':202.933},
    'skip': 'Symlink creation unavailable on Windows (WinError 1314); separate audit confirms actual jscpd duplication check passed.',
    'differential_cases':96, 'differential_matching':96,
    'whole_module_before': {key:metrics['before']['whole_module'][key] for key in ('physical_lines','radon_lloc','lizard_nloc','lizard_ccn_sum')},
    'whole_module_after': {key:metrics['after']['whole_module'][key] for key in ('physical_lines','radon_lloc','lizard_nloc','lizard_ccn_sum')},
    'test_changes':0, 'new_dependencies':0, 'new_helpers':0, 'adopted_production_reduction':0,
    'limitations':['Finite local tests, not equivalence proof or cross-platform certification.', 'Private internal provider coupling is added; their representations must remain synchronized.', 'All selected suite tests run, one environmental symlink skip retained.', 'No performance/maintenance-effort improvement measured.', 'Only 12 physical lines and 9 LLOC removed: modest reduction, not substantial project compression.'],
    'review': 'Inline source review: validation order and diagnostic strings unchanged. Typed contract paths cannot be empty; _references truth filtering matches original None exclusion on admitted records. Source hash sort_keys is inert for nested lists of primitives; scope and resource serialization match providers. No recapture/probing occurs in imported pure helpers.',
    'verification_gate': 'VERIFIED for recorded local tests and measured reduction only; not FEATURE_GO',
    'token_count':None
}
(proposal/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
(evidence/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
times = {'dispatch_utc':'2026-11-01T10:36:55+00:00',
    'first_observed_local_clock':'2026-11-01T11:37:38.2955154+01:00',
    'hypothesis_saved_utc':datetime.fromtimestamp((evidence/'hypothesis.md').stat().st_mtime,timezone.utc).isoformat(),
    'candidate_edit_complete_utc':datetime.fromtimestamp((root/'.runs/capability-01/T3-B/src/lesscode_baseline/rules/evidence.py').stat().st_mtime,timezone.utc).isoformat(),
    'baseline_test_start_local':'2026-11-01T11:38:33.1556633+01:00',
    'candidate_test_start_local':'2026-11-01T11:39:07.9029441+01:00',
    'phase_notes':'Discovery/proposal completed at candidate edit timestamp. Verification started with baseline tests and overlapped final edit. End timestamps below are shell result-file writes, not inferred subprocess durations.',
    'verification_end_utc':datetime.now(timezone.utc).isoformat(), 'token_count':None}
for name in ('baseline-tests','candidate-tests','differential','measurement','skip-audit'):
    times[name+'_recorded_end_utc']=datetime.fromtimestamp((evidence/(name+'.exit')).stat().st_mtime,timezone.utc).isoformat()
(evidence/'timings.json').write_text(json.dumps(times,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))

import ast, difflib, hashlib, json, os, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone
ROOT = Path('D:/Source/lesscode')
E = ROOT / 'docs/experiments/capability-guided/run-01/T2-B/proposal-1'
BASE = ROOT / '.runs/capability-01/base'
CAND = ROOT / '.runs/capability-01/T2-B'
def now(): return datetime.now(timezone.utc).isoformat()
records = []
uv = ['uv.exe', 'run', '--no-project', '--no-python-downloads', '--python', str(ROOT / '.venv-task11/Scripts/python.exe'), 'python']
tests = ['tests.test_report','tests.test_experiment_cli','tests.test_experiments','tests.test_rule_evidence','tests.test_evaluation','tests.test_cli','tests.test_adverse_evaluation']
for label, root in [('baseline', BASE), ('candidate', CAND)]:
    env = os.environ | {'PYTHONPATH': str(root/'src') + os.pathsep + str(root)}
    commands = [('modules', uv + ['-c', 'import lesscode_baseline.report, tests.test_report; print(lesscode_baseline.report.__file__); print(tests.test_report.__file__)']),
                ('tests', uv + ['-m', 'unittest', '-v', *tests]),
                ('faults', uv + [str(E.parent / 'fault_checks.py')])]
    for kind, cmd in commands:
        start = now()
        result = subprocess.run(cmd, cwd=root, env=env, capture_output=True, text=True)
        (E / (label+'-'+kind+'.stdout')).write_text(result.stdout)
        (E / (label+'-'+kind+'.stderr')).write_text(result.stderr)
        records.append(dict(label=label,kind=kind,command=cmd,cwd=str(root),PYTHONPATH=env['PYTHONPATH'],start_utc=start,end_utc=now(),returncode=result.returncode))
        (E/'commands.json').write_text(json.dumps(records,indent=2))
        print(label,kind,result.returncode,flush=True)
source = 'src/lesscode_baseline/report.py'
a,b = (r/source for r in (BASE,CAND))
out=E/'source'/source
out.parent.mkdir(parents=True,exist_ok=True)
out.write_bytes(b.read_bytes())
(E/'change.diff').write_text(''.join(difflib.unified_diff(a.read_text().splitlines(True), b.read_text().splitlines(True),fromfile='before/'+source,tofile='after/'+source)))
files = {}
for root,label in [(BASE,'baseline'),(CAND,'candidate')]:
    files[label] = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for directory in ('tests','src') for p in (root/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    files[label].update({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ('pyproject.toml',)})
(E/'file-hashes.json').write_text(json.dumps(files,indent=2))
changed=[p for p in files['baseline'] if files['baseline'][p]!=files['candidate'].get(p)]
print('CHANGED', changed)
print('FAULTS_EQUAL', json.loads((E/'baseline-faults.stdout').read_text()) == json.loads((E/'candidate-faults.stdout').read_text()))

from pathlib import Path
import json, os, subprocess, time
from datetime import datetime, timezone
root=Path('D:/Source/lesscode')
evidence=root/'docs/experiments/capability-guided/run-01/T2-A'
uv='C:/Users/mariu/AppData/Local/Microsoft/WinGet/Packages/astral-sh.uv_Microsoft.Winget.Source_8wekyb3d8bbwe/uv.exe'
runs=[]
for label, arm in [('baseline','base'),('candidate','T2-A')]:
    copy=root/'.runs/capability-01'/arm
    command=[uv,'run','--no-project','--no-python-downloads','--python',str(root/'.venv-task11/Scripts/python.exe'),'python',str(evidence/'fault_probe.py')]
    started=datetime.now(timezone.utc).isoformat(); begin=time.monotonic()
    completed=subprocess.run(command,cwd=copy,env=os.environ|{'PYTHONPATH':str(copy/'src')+os.pathsep+str(copy)},capture_output=True,text=True)
    (evidence/'proposal-1'/f'{label}-fault-probe.json').write_text(completed.stdout,encoding='utf-8')
    (evidence/'proposal-1'/f'{label}-fault-probe.log').write_text(completed.stderr,encoding='utf-8')
    runs.append({'label':label,'command':command,'started':started,'elapsed_seconds':time.monotonic()-begin,'returncode':completed.returncode})
    print(label,completed.returncode,completed.stderr[-1000:])
a=json.loads((evidence/'proposal-1/baseline-fault-probe.json').read_text())
b=json.loads((evidence/'proposal-1/candidate-fault-probe.json').read_text())
result={'runs':runs,'module_paths':[a['module_path'],b['module_path']], 'scenario_count':len(a['scenarios']), 'equal':a['scenarios']==b['scenarios']}
(evidence/'proposal-1/fault-comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))

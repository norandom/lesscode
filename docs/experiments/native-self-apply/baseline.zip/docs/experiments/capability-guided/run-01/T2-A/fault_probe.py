"""External finite differential fault probe; never edits product or native tests."""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import hashlib, json, tempfile
from lesscode_baseline import report as r
from lesscode_baseline.contracts import ExperimentManifest
from lesscode_baseline.experiments import aggregate
from tests.test_experiment_contracts import manifest
from tests.test_experiments import evaluated

def scenario(kind, fault, nth):
    events = []
    counts = {'fsync':0, 'replace':0}
    with tempfile.TemporaryDirectory() as temporary:
        target = Path(temporary) / 'output'
        original_replace, original_sync, original_safe = r.os.replace, r.os.fsync, r._safe
        def sync(fd):
            counts['fsync'] += 1
            events.append(['fsync', counts['fsync']])
            if fault == 'fsync' and counts['fsync'] == nth:
                raise OSError('injected fsync failure')
            return original_sync(fd)
        def replace(source, destination):
            counts['replace'] += 1
            events.append(['replace', Path(source).name, Path(destination).name])
            if fault == 'replace' and counts['replace'] == nth:
                raise OSError('injected replace failure')
            return original_replace(source, destination)
        def safe(root, relative):
            events.append(['safe',relative])
            return original_safe(root,relative)
        error = None
        with patch.object(r, '_now', return_value='2026-11-01T00:00:00+00:00'), patch.object(r.uuid, 'uuid4', return_value=SimpleNamespace(hex='fixed')), patch.object(r.os,'fsync',side_effect=sync), patch.object(r.os,'replace',side_effect=replace), patch.object(r,'_safe',side_effect=safe):
            try:
                if kind == 'run':
                    report = evaluated()
                    store = r.RunStore.create(target, report.plan_hash, run_id=report.run_id)
                    store.start()
                    store.write_artifact('raw.log', b'raw\x00bytes')
                    store.finalize(report)
                else:
                    r.persist_experiment(aggregate(ExperimentManifest.from_dict(manifest()),()),target)
            except Exception as exc:
                error = [type(exc).__name__, str(exc).replace(str(target),'<target>')]
        files = {str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.rglob('*')) if p.is_file()}
        state = r.recover(target).state if kind == 'run' else r.recover_experiment(target).state
        return {'kind':kind, 'fault':fault,'nth':nth,'events':events,'error':error,'files':files,'recovery_state':state}
results = [scenario(kind, fault, nth) for kind in ('run','experiment') for fault in ('fsync','replace') for nth in range(1,10)]
print(json.dumps({'module_path':str(Path(r.__file__).resolve()), 'scenarios':results},indent=2))

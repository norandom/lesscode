# Common local-arm instructions

Goal: remove maintained implementation while preserving the complete target
responsibility's observable behavior. A target and arm are assigned separately.
The frozen specimen is `D:/Source/lesscode/.runs/capability-01/base`.

Read specimen AGENTS.md, src/lesscode_baseline/AGENTS.md, core steering and the
target source/callers/tests. You may inspect any specimen code normally. Do not
read other arms, inventory unless explicitly provided, or prior experiment
results. Fresh context isolation is experimental control, not a security boundary.

Dependency policy for BOTH arms: no new external runtime dependency, upgrade,
extra, manifest/lock change or promotion of tooling/research imports into product.
Use supported Python 3.12 standard library and existing internal implementations.
Preserve APIs, diagnostic ordering, safeguards, error and lifecycle semantics.
Do not split functions or hide branches merely to lower complexity. Keep names
and types useful. No arbitrary CCN cap is required for these responsibilities.

Copy the specimen into your assigned `.runs/capability-01/<target>-<arm>` directory
before edits. Ownership is that copy plus your assigned durable evidence directory.
The base's `.tools` junction references the existing root analyzer installation.
When copying, EXCLUDE `.tools` and create the same junction in your copy instead
of duplicating or editing the toolchain. The coordinator's initial metrics-test
attempt lacked this location and failed setup; its log is retained. Both arms
must use the identical existing analyzer toolchain for the corrected runs.
You are not alone: do not revert others, edit root production or another arm, or
change source/test fixtures in the frozen base. No Facdrone access is needed.

Budget: at most two saved proposals, 20 minutes for discovery/proposal work,
15 minutes verification per proposal. No credible deletion hypothesis is a valid
recorded disposition. Record time by phase, with token count unavailable if no
telemetry exists. Do not invent costs or claim subprocess execution without logs.

Before editing, save hypothesis.md naming owned code removed, replacement,
semantic differences and estimated whole physical/LLOC savings. Then save each
proposal separately; never overwrite rejected proposal 1 with proposal 2.

Use local uv.exe, Python `D:/Source/lesscode/.venv-task11/Scripts/python.exe`,
`--no-project --no-python-downloads`; pin measurement tools lizard==1.17.31,
radon==6.0.1 if used. Ensure PYTHONPATH targets the candidate src and candidate
root so tests do not import installed/production package. Record resolved module
paths. Existing tests must remain unchanged. Select appropriate native tests
for the full change, run them on baseline and candidate, retain logs. Add targeted
comparisons/checks outside product where necessary, run against both; distinguish
finite tests from proof. SMT only if a faithful extraction is actually available.

Save candidate changed source files beneath each proposal's `source/`, complete
diff, measurements (physical lines, Radon LLOC, Lizard NLOC/CCN for target and
complete changed modules including new helpers), logs and result.json. Include
before/after, exact tests and return codes, test file hashes, dependency check,
limitations, and disposition. No byte score. Separate production, test changes
(expected zero), and research apparatus. A candidate must reduce both whole-owned
physical lines and LLOC to qualify; all helpers/adapters count. No production
adoption is authorized by this pilot. Return your evidence path and conclusion.

Local tests are provisional evidence; the coordinator will review candidate
scope, compare arms and run suitable independent checks before final reporting.

# Exact agent assignment

Run independent local compression trial T1 arm A (LOCAL discovery, NO shared inventory). Read D:/Source/lesscode/docs/experiments/capability-guided/run-01/task-brief.md and follow exactly. Target: analyzer measurement lifecycle in src/lesscode_baseline/metrics.py: measure_duplication, measure_complexity, measure_sizes plus relevant existing/new helpers. Hypothesis to investigate: repeated staging/execution/diagnostic/evidence assembly may be replaced by existing or simpler shared lifecycle while retaining analyzer-specific behavior. You may reject if no useful complete reduction. Frozen source D:/Source/lesscode/.runs/capability-01/base; own copy D:/Source/lesscode/.runs/capability-01/T1-A and evidence D:/Source/lesscode/docs/experiments/capability-guided/run-01/T1-A. Create dirs. You are not alone; don't modify others or root source. Do not read shared inventory, other arms or previous experiments. Budget max20min proposal, max2 saved proposals, max15min verification each. Read-only source exploration allowed. Follow common uv, same unchanged-tests and dependency rules; exclude .tools when copying and create junction to existing root .tools. Record UTC start/end, hypotheses, every candidate diff/source, complete measurements incl helpers, test logs/result.json. Relevant starting tests tests.test_metrics; additional affected integration as needed. Save exact instructions in your evidence for reproducibility. Return disposition/artifacts. This is an explicitly authorized experiment; no production adoption.

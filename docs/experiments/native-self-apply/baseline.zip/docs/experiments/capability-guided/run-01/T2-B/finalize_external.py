import hashlib,json,shutil
from pathlib import Path
from datetime import datetime, timezone
R=Path('D:/Source/lesscode');E=R/'docs/experiments/capability-guided/run-01/T2-B/proposal-1'
shutil.copyfile(E/'result.json', E/'result-validation-pending.json')
files={}
for arm in ['base','T2-B']:
    root=R/'.runs/capability-01'/arm
    files[arm]={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for directory in ['tests','src'] for p in (root/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
(E/'file-hashes.json').write_text(json.dumps(files,indent=2))
changed=[p for p in files['base'] if files['base'][p]!=files['T2-B'].get(p)]
assert changed==['src\\lesscode_baseline\\report.py'] or changed==['src/lesscode_baseline/report.py']
deps={}
for name in ['pyproject.toml','requirements-tools.lock','tools/package.json','tools/package-lock.json','src/lesscode_baseline/data/requirements-tools.lock','src/lesscode_baseline/data/tools/package-lock.json']:
    deps[name]={arm:hashlib.sha256((R/'.runs/capability-01'/arm/name).read_bytes()).hexdigest() for arm in ['base','T2-B']}
    assert len(set(deps[name].values()))==1
(E/'dependency-check.json').write_text(json.dumps(deps,indent=2))
faults=[json.loads((E.parent/name).read_text(encoding='utf-8-sig')) for name in ['coordinator-base-faults.json','coordinator-T2-B-faults.json']]
assert faults[0]==faults[1] and len(faults[0])==28
for arm in ['base','T2-B']:
    log=(E.parent/('coordinator-'+arm+'-tests.log')).read_text(encoding='utf-8-sig')
    assert 'Ran 39 tests' in log and 'OK (skipped=1)' in log
m=json.loads((E/'measurements.json').read_text());result=json.loads((E/'result.json').read_text())
result.update(disposition='equivalent_but_not_useful', behavior_status='finite core tests and fault comparisons passed; no equivalence proof', tests_pending=None, changed_files=changed,test_changes=0,new_runtime_dependencies=[],dependency_check='dependency-check.json',test_source_hashes='file-hashes.json',core_validation={'source':'coordinator independent execution; return codes supplied in parent message, logs inspected directly','tests_per_side':39,'skipped_per_side':1,'returncodes':[0,0],'modules':['tests.test_report','tests.test_experiment_cli'],'logs':['../coordinator-base-tests.log','../coordinator-T2-B-tests.log']},fault_validation={'cases_per_side':28,'equal':True,'returncodes':[0,0],'logs':['../coordinator-base-faults.json','../coordinator-T2-B-faults.json']},supplemental_validation={'status':'interrupted/incomplete','baseline_only':True,'candidate_not_started':True,'metadata':'interrupted-validation.json','process_command_metadata':'interrupted-processes.json','buffered_output':'unavailable; original subprocess captured in memory, runner terminated before completion'},measurement_command='uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe --with lizard==1.17.31 --with radon==6.0.1 python docs/experiments/capability-guided/run-01/T2-B/measure.py',measurement_returncode=0,research_apparatus={p.name:len(p.read_text().splitlines()) for p in E.parent.glob('*.py')},finalized_utc=datetime.now(timezone.utc).isoformat())
result['limitations']=['Core Windows tests and finite fault injection passed; no full-suite or equivalence proof claim.','Supplemental baseline seven-module suite interrupted; candidate supplemental suite never started; buffered broad output unavailable.','Power loss and hostile concurrency unverified.','Only 3 whole-module physical lines saved; added helper boundary makes usefulness doubtful.','Overwrite boolean evaluated before _safe; ordinary internal str/set callers covered, arbitrary patched objects not modeled.','Initial discovery interval unmeasured, elapsed since first clock lower-bound only.','Target physical totals sum AST node spans, full module includes intervening whitespace.','Private shared publisher couples run and experiment storage; diagnostics and lifecycle wrappers remain distinct.']
(E/'result.json').write_text(json.dumps(result,indent=2))
t=json.loads((E/'phase-times.json').read_text());t.update(verification_start_utc='2026-11-01T10:32:37.001586+00:00',supplemental_interrupted_utc=json.loads((E/'interrupted-validation.json').read_text(encoding='utf-8-sig'))['interrupted_utc'],report_finished_utc=result['finalized_utc'],initial_interval='unmeasured; approximate estimate withdrawn; first-clock elapsed lower bound');(E/'phase-times.json').write_text(json.dumps(t,indent=2))
print(json.dumps({'disposition':result['disposition'],'changed_files':changed,'tests_per_side':39,'fault_cases':28,'supplemental':'interrupted'},indent=2))

# T2-B result

Disposition: equivalent but not useful, on finite tested evidence only. No production adoption.

The candidate shares atomic publication through a private `_publish` operation (CG01-C5/C6). Run ownership updates and experiment overwrite rules remain in their respective wrappers (CG01-C7/C8); recovery identity checks remain direct. The helper introduces coupling between two publication callers and a policy-parameter boundary. This is not enough useful deletion to recommend adoption.

| Scope | Physical before / after | Radon LLOC before / after | Lizard NLOC before / after | Summed function CCN before / after |
| --- | --- | --- | --- | --- |
| Complete report.py | 620 / 617 | 519 / 512 | 550 / 545 | 173 / 172 |
| Complete selected storage nodes, including new helper | 404 / 399 | 381 / 374 | 385 / 380 | 108 / 107 |

Target physical counts sum full AST node spans and exclude separators; whole-module counts include all whitespace and both summary renderers. Full member/function accounting is in measurements.json. Only report.py changed; all test sources, manifests and locks retain their baseline hashes. Research scripts are accounted separately in result.json.

Coordinator independent execution passed the unchanged tests.test_report and tests.test_experiment_cli on both versions: 39 tests per side, one skip per side. Both external fault scripts returned zero and produced identical 28-case records covering fsync and replace failures at positions 1 through 7 for run and experiment publication. These finite checks compare operation counts, recovery state, surviving filenames and normalized diagnostics. Core logs and fault outputs are in the parent evidence directory; coordinator-reported return codes are distinguished from directly inspected log contents.

The optional seven-module baseline suite started at 10:32:38 UTC and remained unfinished. Its original tool session became inaccessible, while the OS process remained live. With coordinator authorization it and its verified descendants were stopped at 10:44:12 UTC, within the original 15-minute verification budget. No candidate broad suite started. Buffered supplemental output was unavailable because the runner captured it in memory until subprocess completion. Process commands and interruption metadata are preserved; no full-suite claim is made.

Discovery's initial interval was not instrumented. The first exact clock is 10:30:49 UTC; the earlier approximate estimate in hypothesis.md is explicitly withdrawn. Phase timestamps are retained in phase-times.json. Token count and maintenance cost are unavailable. No solver or crash/concurrency equivalence proof was attempted. The new overwrite boolean is computed before the safe-path call, unlike the original short-circuit check; ordinary internal string/set callers are covered, arbitrary patched objects are outside these checks.

Verification result: VERIFIED for the narrow core-test and fault-comparison claims, NOT VERIFIED for supplemental regression completion. Retain the original implementation.

from pathlib import Path
import difflib
root = Path('D:/Source/lesscode')
evidence = root / 'docs/experiments/capability-guided/run-01/T2-A'
base = root / '.runs/capability-01/base/src/lesscode_baseline/report.py'
target = root / '.runs/capability-01/T2-A/src/lesscode_baseline/report.py'
original = base.read_text(encoding='utf-8')
source = original
helper = '''def _write_exclusive(path, data):
    with path.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def _replace_artifact(root, relative, target, data):
    temporary = _safe(root, "." + relative + "." + uuid.uuid4().hex + ".tmp")
    # Leave interrupted temporary bytes available for diagnosis.
    _write_exclusive(temporary, data)
    _safe(root, relative)
    os.replace(temporary, target)


'''
source = source.replace('class RunStore:\n', helper + 'class RunStore:\n')
old = '''        temporary = _safe(self.directory, "." + relative + "." + uuid.uuid4().hex + ".tmp")
        # Leave interrupted temporary bytes available for diagnosis.
        with temporary.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        _safe(self.directory, relative)
        os.replace(temporary, target)
'''
assert old in source
source = source.replace(old, '        _replace_artifact(self.directory, relative, target, data)\n')
old = '''            with path.open("xb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
'''
assert old in source
source = source.replace(old, '            _write_exclusive(path, data)\n')
old = '''        temporary = _safe(target, "." + name + "." + uuid.uuid4().hex + ".tmp")
        with temporary.open("xb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        _safe(target, name)
        os.replace(temporary, path)
'''
assert old in source
source = source.replace(old, '        _replace_artifact(target, name, path, data)\n')
target.write_text(source, encoding='utf-8', newline='\n')
proposal = evidence / 'proposal-1'
(proposal / 'source/src/lesscode_baseline').mkdir(parents=True, exist_ok=True)
(proposal / 'source/src/lesscode_baseline/report.py').write_bytes(target.read_bytes())
(proposal / 'complete.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile='a/src/lesscode_baseline/report.py', tofile='b/src/lesscode_baseline/report.py')), encoding='utf-8')
print('physical lines', len(original.splitlines()), len(source.splitlines()))

from pathlib import Path
import datetime, hashlib, json
from run_tests import BASE, CANDIDATE, EVIDENCE
P=EVIDENCE/'proposal-1'
measurements=json.loads((P/'measurements.json').read_text())
checks=json.loads((P/'unchanged-files.json').read_text())
changed=[]
for path in (BASE/'src').rglob('*.py'):
    relative=path.relative_to(BASE)
    if path.read_bytes() != (CANDIDATE/relative).read_bytes(): changed.append(relative.as_posix())
result={
 'trial':'T1-A','arm':'local discovery without shared capability inventory',
 'disposition':'behavior_failure','adopted':False,'saved_proposals':1,
 'capability_kind':'existing internal implementation reuse',
 'hypothesis':'Generalize the existing duplication worker and reuse its execution/stderr/report lifecycle in complexity measurement.',
 'source_boundary':'Complete src/lesscode_baseline/metrics.py including all existing and introduced helpers; source payload strings included in module counts.',
 'changed_production_files':changed,
 'measurement_definitions':{'physical_lines':'len(source_bytes.splitlines())','lloc':'Radon 6.0.1 raw analyze LLOC','nloc_ccn':'Lizard 1.17.31 full file and function analysis'},
 'before':{key:measurements['before'][key] for key in ['physical_lines','radon_lloc','lizard_nloc','sha256']},
 'after':{key:measurements['after'][key] for key in ['physical_lines','radon_lloc','lizard_nloc','sha256']},
 'whole_module_reduction':{'physical_lines':3,'radon_lloc':6,'lizard_nloc':3},
 'test_changes':0,'test_hashes':'proposal-1/unchanged-files.json',
 'unchanged_tests':all(x['before']==x['after'] for x in checks['tests']),
 'unchanged_dependency_controls':all(x['before']==x['after'] for x in checks['dependencies']),
 'new_runtime_dependencies':[],'tooling_dependencies':['lizard==1.17.31','radon==6.0.1'],
 'regression_suites':{'command':'uv.exe run --no-project --no-python-downloads --python D:/Source/lesscode/.venv-task11/Scripts/python.exe python -m unittest tests.test_metrics tests.test_evaluation -v','baseline':{'status':'pending','returncode':None},'candidate':{'status':'pending','returncode':None},'session_id':28433,'runner':'run_tests.py','output_paths':['baseline-tests.log','baseline-tests.json','candidate-tests.log','candidate-tests.json']},
 'probes':{name:json.loads((EVIDENCE/(name+'.json')).read_text()) for name in ['baseline-fault-probe','candidate-fault-probe','baseline-relative-runtime','candidate-relative-runtime','baseline-resolved-module','candidate-resolved-module']},
 'counterexample':{'input':'measure_complexity with interpreter Path("relative-python.exe") and valid staged Python source','baseline':'raises ContractError: $input.argv[0]: expected resolved absolute path','candidate':'returns unavailable evidence: complexity report: $input.argv[0]: expected resolved absolute path','mocked':False},
 'timing':{'first_exact_discovery_clock_utc':'2026-11-01T10:30:18.3289543Z','earlier_discovery_interval':'unmeasured','proposal_saved_utc':'2026-11-01T10:31:18.1275734Z','discovery_proposal_elapsed_lower_bound_seconds':59.7986,'verification_start':'first saved proposal at 10:31:18.1275734Z; native runner launched approximately 10:31:34Z, process timestamp','verification_handoff_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verification_end_utc':None,'token_count':'unavailable'},
 'limitations':['Actual-input counterexample disproves behavior preservation regardless of native-suite outcome.','Native unchanged tests are running at handoff; no pass claim made.','Finite fault probes are supplementary and not exhaustive proof.','Only Windows local execution examined.','No SMT model or proof.','Original exception-scope-preserving rewrite would consume most remaining physical savings; not saved as proposal 2.'],
 'research_apparatus':'Evidence-directory Python scripts, logs and JSON only; excluded from production counts.',
 'verification_claim':'Rejected trial artifacts and real-input behavioral mismatch verified; regression suite completion not yet verified.'
}
(P/'result.json').write_text(json.dumps(result,indent=2))
(EVIDENCE/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'disposition':result['disposition'],'changed_files':changed,'tests_unchanged':result['unchanged_tests'],'dependencies_unchanged':result['unchanged_dependency_controls']}))

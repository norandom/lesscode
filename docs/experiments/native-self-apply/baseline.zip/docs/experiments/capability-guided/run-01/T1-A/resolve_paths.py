from run_tests import run, BASE, CANDIDATE
for label, root in [('baseline', BASE), ('candidate', CANDIDATE)]:
    run(label+'-resolved-module', root, ['-c','import lesscode_baseline.metrics as m; import tests.test_metrics as t; print(m.__file__); print(t.__file__)'])

"""Finite, same-store differential admission check; research apparatus only."""
import importlib.util
import itertools
import json
from pathlib import Path
import tempfile
from lesscode_baseline.rules import evidence as original
from tests.test_rule_evidence import materialize

candidate_path = Path('D:/Source/lesscode/.runs/capability-01/T3-B/src/lesscode_baseline/rules/evidence.py')
spec = importlib.util.spec_from_file_location('lesscode_baseline.rules.evidence_candidate', candidate_path)
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
print('original:', original.__file__)
print('candidate:', candidate.__file__)
count = 0
with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    for absent in itertools.product((False, True), repeat=4):
        for corrupt in (None, 'summary.md', 'plan.json', 'report.json', 'manifest.json', 'artifacts.json'):
            fixture = materialize(root / str(count))
            for name, missing in zip(('manifest.json', 'artifacts.json', 'report.json', 'plan.json'), absent):
                if missing:
                    (fixture['run'] / name).unlink()
            if corrupt:
                (fixture['run'] / corrupt).write_bytes(b'{}')
            before = original.read_evidence(fixture['run'], fixture['policy'])
            after = candidate.read_evidence(fixture['run'], fixture['policy'])
            assert before == after, (absent, corrupt, before, after)
            count += 1
print(json.dumps({'differential_cases': count, 'matching': count}))

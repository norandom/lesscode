"""Public invalid-runtime probe, using the real process execution validator."""
import json, tempfile
from pathlib import Path
from lesscode_baseline import metrics
from lesscode_baseline.contracts import Limits, ScopeRules
from lesscode_baseline.snapshot import capture_scope
with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)/'source'; root.mkdir()
    (root/'a.py').write_text('pass\n')
    snapshot = capture_scope(root, ScopeRules(('**/*',),(),(),(),(),('**/*.py',)))
    try:
        result = metrics.measure_complexity(snapshot, Path('relative-python.exe'), Limits(10,100000), Path(temporary)/'logs')
        observed = {'status':result.status,'reason':result.reason}
    except Exception as exc:
        observed = {'raised':type(exc).__name__,'message':str(exc)}
    print(json.dumps(observed, indent=2))

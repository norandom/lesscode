from pathlib import Path
import itertools,json,shutil,tempfile
from tests.test_rule_evidence import materialize
from lesscode_baseline.rules.evidence import read_evidence
results=[]
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp).resolve()
    fixture=materialize(root/'fixture')
    for mask in range(16):
        dest=root/f'case-{mask}'
        shutil.copytree(fixture['run'],dest)
        for bit,name in enumerate(('manifest.json','artifacts.json','report.json','plan.json')):
            if mask & 1<<bit: (dest/name).unlink()
        for corrupt in (False,True):
            if corrupt: (dest/'summary.md').write_bytes(b'corrupt')
            value=read_evidence(dest,fixture['policy'])
            if hasattr(value,'diagnostics'):
                out={'kind':value.kind,'diagnostics':[d.replace(str(dest),'<RUN>') for d in value.diagnostics]}
            else: out={'bundle':True,'decision':value.report.decision}
            results.append({'missing_mask':mask,'corrupt_summary':corrupt,**out})
print(json.dumps(results,indent=2))

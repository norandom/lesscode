"""Finite public-boundary fault observations; external research support only."""
import json, tempfile
from pathlib import Path
from unittest.mock import patch
from lesscode_baseline import metrics
from lesscode_baseline.contracts import Limits, ScopeRules
from lesscode_baseline.snapshot import capture_scope

observations = []
with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)/'source'
    root.mkdir()
    (root/'a.py').write_text('pass\n')
    snapshot = capture_scope(root, ScopeRules(('**/*',),(),(),(),(),('**/*.py',)))
    for fault in [ValueError('execution failure'), TypeError('execution type'), KeyError('execution key'), UnicodeError('execution encoding'), OSError('persistence failure')]:
        with patch.object(metrics, '_execute_analyzer', side_effect=fault):
            try:
                evidence = metrics.measure_complexity(snapshot, Path('python.exe'), Limits(10,100000), Path(temporary)/'logs')
                observation = {'fault':type(fault).__name__, 'status':evidence.status, 'reason':evidence.reason}
            except Exception as exc:
                observation = {'fault':type(fault).__name__, 'raised':type(exc).__name__, 'message':str(exc)}
        observations.append(observation)
print(json.dumps(observations, indent=2))

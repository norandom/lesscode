from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, importlib.metadata, json
import lizard
from radon.raw import analyze
ROOT = Path('D:/Source/lesscode')
EVIDENCE = ROOT / 'docs/experiments/capability-guided/run-01/T2-A/proposal-1'
OMIT = {'_literal', '_value', '_product_changes', 'render_summary', 'render_experiment_summary'}
def metrics(source, name):
    measured = lizard.analyze_file.analyze_source_code(name, source)
    return {'physical_lines':len(source.splitlines()), 'radon_LLOC':analyze(source).lloc, 'lizard_NLOC':measured.nloc, 'lizard_CCN_sum':sum(f.cyclomatic_complexity for f in measured.function_list), 'lizard_functions':[{'name':f.long_name,'NLOC':f.nloc,'CCN':f.cyclomatic_complexity} for f in measured.function_list]}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
result = {'timestamp':datetime.now(timezone.utc).isoformat(), 'versions':{name:importlib.metadata.version(name) for name in ('lizard','radon')}, 'definitions':{'module':'all report.py lines, including unrelated rendering and imports', 'responsibility':'all report.py top-level classes and functions except rendering/_literal/_value/_product_changes; includes every new helper, storage record and persistence exception; imports counted at module level; AST spans include decorators; inter-definition whitespace excluded identically'}}
for label, arm in [('baseline','base'),('candidate','T2-A')]:
    root = ROOT / '.runs/capability-01' / arm
    path = root / 'src/lesscode_baseline/report.py'
    source = path.read_text(encoding='utf-8')
    lines = source.splitlines(True)
    nodes = [n for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in OMIT]
    parts = [''.join(lines[min([n.lineno]+[d.lineno for d in n.decorator_list])-1:n.end_lineno]) for n in nodes]
    owned = '\n'.join(parts)
    result[label] = {'module_path':str(path), 'module_sha256':sha(path),'module':metrics(source,'report.py'), 'responsibility':metrics(owned,'responsibility.py'), 'test_hashes':{str(p.relative_to(root)):sha(p) for p in sorted((root / 'tests').rglob('*.py'))}, 'dependency_hashes':{name:sha(root/name) for name in ('pyproject.toml','uv.lock') if (root/name).exists()}}
result['delta'] = {scope:{key:result['candidate'][scope][key]-result['baseline'][scope][key] for key in ('physical_lines','radon_LLOC','lizard_NLOC','lizard_CCN_sum')} for scope in ('module','responsibility')}
result['tests_unchanged'] = result['baseline']['test_hashes'] == result['candidate']['test_hashes']
result['dependencies_unchanged'] = result['baseline']['dependency_hashes'] == result['candidate']['dependency_hashes']
(EVIDENCE/'measurements.json').write_text(json.dumps(result,indent=2), encoding='utf-8')
print(json.dumps({k:result[k] for k in ('delta','tests_unchanged','dependencies_unchanged')},indent=2))

from pathlib import Path
import ast, difflib, hashlib, json, importlib.metadata
import lizard
from radon.raw import analyze
ROOT=Path(r'D:/Source/lesscode')
E=ROOT/'docs/experiments/capability-guided/run-01/T1-A'
BASE=ROOT/'.runs/capability-01/base'
CAND=ROOT/'.runs/capability-01/T1-A'

def measured(path):
    raw=path.read_bytes(); source=raw.decode('utf-8'); tree=ast.parse(source)
    info=lizard.analyze_file(str(path))
    functions=[dict(name=f.name,start_line=f.start_line,end_line=f.end_line,nloc=f.nloc,ccn=f.cyclomatic_complexity) for f in info.function_list]
    targets=[]
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
            start=min([node.lineno,*[d.lineno for d in node.decorator_list]])
            text='\n'.join(source.splitlines()[start-1:node.end_lineno])+'\n'
            targets.append(dict(name=node.name,physical_lines=len(text.splitlines()),lloc=analyze(text).lloc))
    return dict(sha256=hashlib.sha256(raw).hexdigest(),physical_lines=len(raw.splitlines()),radon_lloc=analyze(source).lloc,lizard_nloc=info.nloc,lizard_functions=functions,target_members=targets)
proposal=E/'proposal-1'
before=BASE/'src/lesscode_baseline/metrics.py'; after=proposal/'source/src/lesscode_baseline/metrics.py'
report=dict(tools={name:importlib.metadata.version(name) for name in ['lizard','radon']},before=measured(before),after=measured(after))
(proposal/'measurements.json').write_text(json.dumps(report,indent=2))
(proposal/'complete.diff').write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='base/src/lesscode_baseline/metrics.py',tofile='proposal-1/src/lesscode_baseline/metrics.py')))
# Record every test and dependency-control file independently, before and after.
checks={}
for group, files in [('tests',list((BASE/'tests').rglob('*.py'))),('dependencies',[p for p in BASE.rglob('*') if p.is_file() and '.tools' not in p.parts and p.name in ('pyproject.toml','uv.lock','package.json','package-lock.json','requirements.txt')])]:
    entries=[]
    for path in files:
        relative=path.relative_to(BASE)
        candidate=CAND/relative
        digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
        entries.append(dict(path=relative.as_posix(),before=digest(path),after=digest(candidate)))
    checks[group]=entries
(proposal/'unchanged-files.json').write_text(json.dumps(checks,indent=2))
print(json.dumps({version:{key:report[version][key] for key in ['physical_lines','radon_lloc','lizard_nloc']} for version in ['before','after']}))

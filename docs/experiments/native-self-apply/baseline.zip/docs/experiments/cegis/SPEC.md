# Modulo-data code synthesis: bounded functional CEGIS experiment

Status: experimental specification with a runnable prototype, 2026-11-01. The goal is **less code, same behavior**, not mandatory conversion into a kernel/table. This document is self-contained as a technical specification; the linked scripts provide its executable reference. It does not resume the paused rule-engine implementation or introduce an MCP server.

## 1. Objective and decision

Given a small cluster of pure functions with compatible input/output semantics, find scalar parameters for a shared sketch and verify each specialization. Emit a candidate diff preserving the existing callable API. Compare the full shared implementation with simpler independent functions and with doing nothing. Keep only a verified candidate that reduces maintained implementation without obscuring roles or weakening contracts.

**Build the bounded synthesis/verifier experiment first.** Use a deliberately narrow AST translator with explicit rejection. Do not start with a general concolic tracer or repository-wide clustering system. This makes it possible to test whether solved representations save code before investing in discovery infrastructure.

Current implementation: Python `ast` extraction, quantifier-free integer CEGIS, Python code generation and TypeScript `bigint` generation. TypeScript input extraction, floating-point synthesis, arbitrary objects, state tuples and automatic sketch generation are future work, not implemented capabilities.

## 2. Semantic boundary

The prototype accepts only undecorated functions with one argument named `x: int` and return annotation `int`. Supported inputs are exact built-in Python integers; subclasses, `bool`, overloaded operators and arbitrary Python values are outside the domain. The target TypeScript input is `bigint`, not `number`. Mathematical unbounded integer semantics apply, excluding resource exhaustion and introspection of frames, source, globals or function identities.

Supported operations: integer literals, local assignments, addition, subtraction, multiplication by an expression simplifying to an integer constant, unary minus, `>` and `<=`, conditionals and explicit integer returns. Branches must be exhaustive. Calls, mutation, IO, loops, exceptions, division, floats, decorators, defaults and unsupported signatures are rejected. The prototype limits a function to 2,000 AST nodes and 64 extracted paths. No missing semantics may be filled with an arbitrary return value.

Do not relabel a financial float function as an integer function to obtain a proof. The two sampled Facdrone float routines are reported unsupported, and no Facdrone code is changed.

For later frontends, encode numeric semantics before solving:

| Source domain | Required solver interpretation |
| --- | --- |
| Python built-in integer arithmetic | Unbounded `Int`; model division, exceptions and shifts explicitly before admitting them |
| TypeScript `bigint` | Unbounded `Int` for supported operations; account for division/remainder rules and mixed-type errors |
| Fixed-width machine arithmetic | Bit-vectors with explicit width, signedness and overflow semantics |
| Python `float` / TypeScript `number` | IEEE floating point with rounding, NaN, infinities and signed zero; `Real` is not an equivalent replacement |
| Exact rational application domain | `Real` abstraction only with a justified source/output mapping; preserve rational constants exactly |

Stateful extensions must model returned values, state changes, exceptions and observable event order. “Deterministic” alone does not mean “pure.”

## 3. Two representations, no application classes

Use tuples, mappings and pure functions. The implementation defines no classes; Z3's own expression and solver objects are library APIs. A `TypedDict` may be declared with functional syntax in a future typing pass if literal zero class definitions is required. `TypedDict` and `as const` do not by themselves make runtime objects immutable.

**Discovery record:** source identity/hash, ordered argument names and sorts, return sort, AST-node count, branch count, maximum branch nesting, call dependencies and unsupported-feature flags. Preserve argument order: sorting input sorts would lose positional meaning. Branch count is not branch depth or a measure of structural entropy. Similar syntax is only a prefilter, not evidence that sharing is appropriate.

**Symbolic summary:** `(id, ordered_inputs, domain, paths, output, source_hash, semantic_profile)` where each path is `(guard, returned_expression)`. Root-to-leaf guards include all prior decisions. Require:

```text
UNSAT(domain(x) AND NOT OR(path_guards))
UNSAT(domain(x) AND guard_i AND guard_j)  for every i != j
```

The prototype uses domain `True` over `Int`. Unreachable paths are permitted; uncovered paths are not. Only after these checks may the paths be folded into an ITE with an unreachable default. Python uses `z3.prove`, not `z3.Prove`; the implementation uses solver statuses directly so `unknown` is actionable.

**Sketch specification:** named scalar holes with sorts and optional explicit bounds, an allowed operator grammar, an expression and a source emitter. The prototype fixes this grammar to:

```text
K(x; threshold, multiplier, offset)
  = if x > threshold then x * multiplier + offset else x + offset
```

All three parameters are integers. The table contains only scalar tuples, never callbacks, lambdas, source strings to execute, or encoded programs. Parameter count and table size belong to the cost model. Different identifiers receive separate synthesis problems; duplicate and emitter-reserved names are rejected.

The summaries are process-local mappings with Z3 expressions. Durable records use source hashes, numeric model values, statuses and metrics; a general serialized IR would additionally need explicit sort declarations and SMT-LIB expressions. Python `str(model_value)` is not a reliable cross-language code generator for rationals, algebraic numbers or bit-vectors.

## 4. Class-free CEGIS

The reference is [synthesis.py](synthesis.py), exercised by [trial.py](trial.py):

```text
samples := zero plus source integer literals and their immediate neighbors
repeat within iteration, wall-time and per-query budgets:
    synthesize theta satisfying K(sample, theta) = source(sample)
        for all accumulated samples
    if UNSAT: no solution in this sketch
    if UNKNOWN: stop inconclusive, record reason
    freeze every theta to an exact model numeral
    verify domain(x) AND K(x, frozen_theta) != source(x)
    if UNSAT: verified for the encoded domain and source semantics
    if UNKNOWN: stop inconclusive, record reason
    if SAT: obtain concrete x, append it to samples, continue
```

Use separate synthesis and verification solvers. Never read a model after `unknown` or `unsat`. Budget/iteration exhaustion is an inconclusive result, not equivalence and not absence of a representable solution. The prototype has a default 40 iterations, 15 seconds per function and 2 seconds per solver query, capped by remaining time.

Every submitted formula in this prototype is `QF_LIA`: substituting sampled input values makes `x * multiplier` constant-times-hole; freezing the parameters makes it constant-times-input. Arbitrary sketches do not inherit this property. Hole-times-hole products or nonlinear source expressions remain nonlinear. CEGIS does not bypass undecidability generally, and finite samples do not guarantee termination on infinite domains. Quantified polynomial real arithmetic is not categorically undecidable; there is no universal “more than three parameters hangs” rule. See the [Z3 arithmetic guide](https://microsoft.github.io/z3guide/docs/theories/Arithmetic/) and [Programming Z3](https://z3prover.github.io/papers/programmingz3.html).

The zero-only seed control actually reaches the 40-iteration limit on a threshold example. The solver advances the candidate threshold by small counterexamples. Source-literal boundary seeds resolve the six-function fixture in one or two iterations. This is an experimental result for this sketch and solver version, not a runtime guarantee.

Synthesizer `unsat` can identify an incompatible finite example set. An unsat core requires tracked constraints or assumptions and is not an input counterexample. Counterexamples come from a **satisfiable verification query**. Do not automatically add another parameter whenever synthesis fails: evaluate the additional code/data cost, try another bounded sketch, or retain the original.

## 5. Code generation and independent checks

Generate both alternatives:

1. One kernel and an immutable scalar table, with wrappers preserving every original public name and the argument name `x`.
2. Independent simplified functions with solved parameters inlined; eliminate a redundant conditional for the identity specialization.

The Python table uses `MappingProxyType` with immutable tuple rows. The TypeScript table and each named-field row use `Object.freeze`; `readonly` is also used in types. Python's tuple positions are unpacked immediately into `threshold`, `multiplier`, `offset`. No application classes or runtime solver dependency are emitted.

Reparse the emitted Python helper expression and verify it with each solved row against the original summary. Re-extract and independently compare each inline candidate. Execute the generated public wrappers against the originals on seeded values, branch boundaries and integers of magnitude `10**100`. Compile the generated TypeScript with strict checking, then test its `bigint` wrappers against the same exact expected results.

The prototype's solver checks establish equivalence of the encoded Python expressions over all integers; concrete tests additionally exercise code generation and wrappers. The TypeScript emitter is tested and compiled, not formally translated back from TypeScript into SMT. Do not call that a complete TypeScript source-equivalence proof.

## 6. Acceptance and measurements

Keep semantic verification separate from compression:

| Result | Meaning |
| --- | --- |
| `verified` | The verifier returned `unsat` for a fixed candidate under the stated model |
| `no_solution_in_sketch` | Accumulated constraints are unsatisfiable in this sketch |
| `unknown` | A solver could not establish the result |
| `iteration_limit` / `budget_exhausted` | Search stopped without a conclusion |
| unsupported source | Translator cannot faithfully model the function |
| verified but larger | Correct candidate, rejected as compression |

Measure the entire generated module, including imports, parameter table, kernel and API wrappers. Count Python physical lines, UTF-8 bytes, logical lines (tokenizer `NEWLINE` tokens), AST nodes and function count. This logical-line definition is explicit and must not be silently mixed with another analyzer's LLOC. Keep synthesis/test apparatus separate from emitted application source, but disclose its cost. There is no claim that building a solver amortizes itself on this tiny fixture.

A branch-depth ceiling is a sketch preference, not a universal acceptance gate. A table can hide complexity, and a flat expression can be harder to maintain. The prototype finds parameters for a fixed sketch; it does **not** prove global branch minimality, minimal source size, or improved maintenance effort. Prefer the simpler candidate when shared-kernel indirection has no demonstrated benefit. A future maintenance exercise should test changing a common operation versus changing one variant independently.

## 7. Required experiment controls

- Positive fixture: six deliberately verbose, synthetic integer functions with differing thresholds, multipliers, offsets and one redundant nested branch.
- Size-negative fixture: three already-compact functions; sharing must not be reported as improvement.
- Semantic-negative controls: float literal, arbitrary call, implicit `None`, side effect and nonlinear multiplication are rejected by extraction.
- Search-negative controls: incompatible three-region behavior, zero iteration budget, zero time budget and injected verifier `unknown`.
- Numeric counterexample: returning `-0.0` versus adding `0.0` preserves real-number equality but changes the observable sign in Python and JavaScript.
- External specimen: selected Facdrone float functions are read-only rejection examples, not successful synthesis claims.

Hypothesis provides generated observations, not universal equivalence. CrossHair can help explore supported Python paths, but its documentation explicitly warns that absence of a counterexample is not a guarantee. It also runs code, so it requires an appropriate isolated execution boundary. Neither tool automatically “locks” the full semantics of a dirty module. Sources: [Hypothesis](https://hypothesis.readthedocs.io/en/latest/), [CrossHair limitations](https://crosshair.readthedocs.io/en/latest/limitations.html), [Z3 floating-point semantics](https://microsoft.github.io/z3guide/docs/theories/IEEE%20Floats/).

## 8. What to build next, only if the evidence warrants it

First test another real cluster whose operations fit the supported semantics, with a source/coverage census reporting refusals. Then extend one needed semantic operation or add one justified sketch. Keep the original, inline simplification and shared-kernel arms. Only introduce clustering when manual selection becomes the repeated bottleneck; only introduce concolic extraction when a concrete supported case needs it.

Do not force a periodic repository rewrite or branching-depth limit. Trigger a proposal when a repeated implementation has a plausible lower-cost representation. Preserve the reviewable diff, source hashes and original tests. A diff is an output artifact and can represent large deletions perfectly well; synthesis need not bypass Git to work.

## 9. Cursor and Claude Code

The claim that these tools operate only on unified diffs is too strong. Their official documentation describes file editing, code search and command execution. Those capabilities can run an external synthesis experiment already. Public overview documentation does not establish whether any internal synthesis technique is used, or why a particular feature is absent. Sources: [Cursor Agent](https://cursor.com/docs/agent/overview), [How Claude Code works](https://code.claude.com/docs/en/how-claude-code-works).

Our engineering inference is that the difficult integration work is faithful language semantics, trustworthy extraction, sketch selection, bounded solving and deciding whether the result is worth maintaining. The current trial demonstrates the last two problems directly. “Diffs cause additive behavior” is a hypothesis requiring a controlled editing comparison, not an established explanation of vendor design.

## 10. Reproduction

Run from Lesscode's root. Python is always launched locally through uv; no project runtime dependencies change.

```powershell
uv.exe run --no-project --no-python-downloads --python 3.13.16 --with z3-solver==4.15.4.0 python docs/experiments/cegis/trial.py --specimen D:/Source/facdrone
```

Omit `--specimen` on machines without that example checkout. It only reads two function definitions. The run writes candidates, unified diffs, JSON results and disposable test vectors alongside the experiment. The pinned CPython version must already be installed for `--no-python-downloads`; use uv to install it if necessary.

TypeScript tooling is installed locally in an ignored tools directory, separately from the Python environment:

```powershell
npm.cmd install --prefix .tools/cegis --no-save --ignore-scripts typescript@5.9.3
node .tools/cegis/node_modules/typescript/bin/tsc --strict --target ES2020 --module commonjs --outDir .runs/cegis-ts docs/experiments/cegis/bloated_shared.ts docs/experiments/cegis/compact_shared.ts
node docs/experiments/cegis/verify_typescript.cjs .runs/cegis-ts
```

Check each command's exit status before continuing. Native results were obtained on Windows with Node 24.22.1. See [measured results and diffs](README.md), [Python results](results.json) and [TypeScript results](typescript-results.json). Repeating CEGIS can change model choices, counterexample order and timing without changing the verified function. Unused parameters are not guaranteed to be zero; canonicalization is a separate optional objective and must be reverified.

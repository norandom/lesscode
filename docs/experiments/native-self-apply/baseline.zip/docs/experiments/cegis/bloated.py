def standard(x: int) -> int:
    amount = x
    threshold = 100
    if amount > threshold:
        multiplier = 2
        adjusted = amount * multiplier
        fee = 3
        result = adjusted + fee
        return result
    else:
        fee = 3
        result = amount + fee
        return result


def express(x: int) -> int:
    if x <= 250:
        base = x
        surcharge = 10
        total = base + surcharge
        return total
    else:
        base = x * 3
        surcharge = 10
        total = base + surcharge
        return total


def bulk(x: int) -> int:
    value = x
    boundary = 500
    if value > boundary:
        scaled = value * 4
        adjustment = -7
        return scaled + adjustment
    adjustment = -7
    return value + adjustment


def priority(x: int) -> int:
    threshold = 50
    if x > threshold:
        if x > 50:
            scaled = x * 5
            fee = 12
            return scaled + fee
        return x + 12
    base = x
    return base + 12


def economy(x: int) -> int:
    threshold = 200
    fee = -2
    if x > threshold:
        rate = 2
        result = x * rate
        return result + fee
    result = x
    return result + fee


def free(x: int) -> int:
    original = x
    result = original
    return result

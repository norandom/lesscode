const PARAMS = Object.freeze({
  standard: Object.freeze({ threshold: 100n, multiplier: 2n, offset: 3n }),
  express: Object.freeze({ threshold: 250n, multiplier: 3n, offset: 10n }),
  free: Object.freeze({ threshold: 0n, multiplier: 1n, offset: 0n }),
});

function compute(x: bigint, parameters: { readonly threshold: bigint; readonly multiplier: bigint; readonly offset: bigint }): bigint {
  const { threshold, multiplier, offset } = parameters;
  return x > threshold ? x * multiplier + offset : x + offset;
}

export function standard(x: bigint): bigint {
  return compute(x, PARAMS.standard);
}

export function express(x: bigint): bigint {
  return compute(x, PARAMS.express);
}

export function free(x: bigint): bigint {
  return compute(x, PARAMS.free);
}

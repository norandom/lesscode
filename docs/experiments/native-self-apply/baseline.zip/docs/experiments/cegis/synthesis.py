"""Bounded experiment: exact-int AST summaries and a fixed piecewise sketch.

No application execution, classes, automatic edits, or general Python semantics.
"""
import ast
from time import monotonic

import z3


def expression(node, environment):
    if isinstance(node, ast.Name) and node.id in environment:
        return environment[node.id]
    if isinstance(node, ast.Constant) and type(node.value) is int:
        return z3.IntVal(node.value)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -expression(node.operand, environment)
    if isinstance(node, ast.BinOp):
        left, right = expression(node.left, environment), expression(node.right, environment)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult) and (z3.is_int_value(z3.simplify(left)) or z3.is_int_value(z3.simplify(right))):
            return left * right
    if isinstance(node, ast.Compare) and len(node.ops) == 1:
        left, right = expression(node.left, environment), expression(node.comparators[0], environment)
        if isinstance(node.ops[0], ast.Gt):
            return left > right
        if isinstance(node.ops[0], ast.LtE):
            return left <= right
    if isinstance(node, ast.IfExp):
        return z3.If(expression(node.test, environment), expression(node.body, environment), expression(node.orelse, environment))
    raise ValueError(f"unsupported expression: {ast.dump(node, include_attributes=False)}")


def paths(statements, environment, guard):
    if not statements:
        raise ValueError("implicit None return is unsupported")
    first, *rest = statements
    if isinstance(first, ast.Return) and first.value is not None:
        return ((guard, expression(first.value, environment)),)
    if isinstance(first, ast.Assign) and len(first.targets) == 1 and isinstance(first.targets[0], ast.Name):
        return paths(rest, {**environment, first.targets[0].id: expression(first.value, environment)}, guard)
    if isinstance(first, ast.If):
        condition = expression(first.test, environment)
        clauses = (paths(first.body + rest, dict(environment), z3.And(guard, condition))
                   + paths(first.orelse + rest, dict(environment), z3.And(guard, z3.Not(condition))))
        if len(clauses) > 64:
            raise ValueError("path budget exceeded")
        return clauses
    raise ValueError(f"unsupported statement: {type(first).__name__}")


def branch_depth(node):
    return int(isinstance(node, (ast.If, ast.IfExp))) + max((branch_depth(child) for child in ast.iter_child_nodes(node)), default=0)


def check(formula, timeout_ms=2000):
    solver = z3.SolverFor("QF_LIA")
    solver.set(timeout=timeout_ms)
    solver.add(formula)
    status = solver.check()
    return status, solver


def summarize(source):
    tree = ast.parse(source)
    summaries = []
    seen = set()
    for function in tree.body:
        if not isinstance(function, ast.FunctionDef) or function.decorator_list:
            raise ValueError("only undecorated functions are supported")
        arguments = function.args
        if (len(arguments.args) != 1 or arguments.posonlyargs or arguments.kwonlyargs
                or arguments.defaults or arguments.vararg or arguments.kwarg
                or arguments.args[0].arg != "x"
                or not isinstance(arguments.args[0].annotation, ast.Name)
                or arguments.args[0].annotation.id != "int"
                or not isinstance(function.returns, ast.Name) or function.returns.id != "int"):
            raise ValueError("requires one argument x: int and int return")
        if function.name in seen or function.name in {"_compute", "_PARAMS"}:
            raise ValueError("duplicate function identity")
        seen.add(function.name)
        if sum(1 for _ in ast.walk(function)) > 2000:
            raise ValueError("AST budget exceeded")
        x = z3.Int(f"{function.name}_input")
        clauses = paths(function.body, {arguments.args[0].arg: x}, z3.BoolVal(True))
        if any(not z3.is_int(value) for _, value in clauses):
            raise ValueError("non-integer return")
        coverage, _ = check(z3.Not(z3.Or(*(guard for guard, _ in clauses))))
        overlaps = [z3.And(a[0], b[0]) for i, a in enumerate(clauses) for b in clauses[i + 1:]]
        disjoint, _ = check(z3.Or(*overlaps))
        if coverage != z3.unsat or disjoint != z3.unsat:
            raise ValueError("path completeness/disjointness not established")
        output = z3.IntVal(0)  # unreachable: completeness established above
        for guard, value in reversed(clauses):
            output = z3.If(guard, value, output)
        summaries.append({"name": function.name, "input": x, "paths": clauses,
                          "output": z3.simplify(output), "branch_depth": branch_depth(function),
                          "seed_points": tuple(sorted({0, *(n.value + delta for n in ast.walk(function)
                              if isinstance(n, ast.Constant) and type(n.value) is int for delta in (-1, 0, 1))})),
                          "ast_nodes": sum(1 for _ in ast.walk(function))})
    if not summaries:
        raise ValueError("empty cluster")
    return tuple(summaries)


def kernel(x, parameters):
    threshold, multiplier, offset = parameters
    return z3.If(x > threshold, x * multiplier + offset, x + offset)


def synthesize(summary, max_iterations=40, budget_seconds=15, timeout_ms=2000, seed_literals=True):
    x = summary["input"]
    holes = z3.Ints("threshold multiplier offset")
    solver = z3.SolverFor("QF_LIA")
    started = monotonic()
    for point in summary["seed_points"] if seed_literals else (0,):
        solver.add(z3.simplify(z3.substitute(kernel(x, holes) == summary["output"], (x, z3.IntVal(point)))))
    sample = z3.IntVal(0)
    counterexamples = []
    for iteration in range(max_iterations):
        remaining = budget_seconds - (monotonic() - started)
        if remaining <= 0:
            return {"status": "budget_exhausted", "counterexamples": counterexamples}
        solver.set(timeout=max(1, min(timeout_ms, int(remaining * 1000))))
        solver.add(z3.simplify(z3.substitute(kernel(x, holes) == summary["output"], (x, sample))))
        status = solver.check()
        if status == z3.unsat:
            return {"status": "no_solution_in_sketch", "counterexamples": counterexamples}
        if status != z3.sat:
            return {"status": "unknown", "stage": "synthesis", "reason": solver.reason_unknown()}
        model = solver.model()
        values = tuple(model.eval(hole, model_completion=True) for hole in holes)
        remaining = budget_seconds - (monotonic() - started)
        if remaining <= 0:
            return {"status": "budget_exhausted", "counterexamples": counterexamples}
        status, verifier = check(z3.simplify(kernel(x, values) != summary["output"]),
                                 max(1, min(timeout_ms, int(remaining * 1000))))
        if status == z3.unsat:
            return {"status": "verified", "parameters": tuple(value.as_long() for value in values),
                    "iterations": iteration + 1, "counterexamples": counterexamples,
                    "seconds": monotonic() - started}
        if status != z3.sat:
            return {"status": "unknown", "stage": "verification", "reason": verifier.reason_unknown()}
        sample = verifier.model().eval(x, model_completion=True)
        counterexamples.append(sample.as_long())
    return {"status": "iteration_limit", "counterexamples": counterexamples}


def emit_python(table):
    rows = "\n".join(f'    "{name}": {values!r},' for name, values in table.items())
    wrappers = "\n\n".join(f'def {name}(x: int) -> int:\n    return _compute(x, _PARAMS["{name}"])' for name in table)
    return ('from types import MappingProxyType\n\n\n_PARAMS = MappingProxyType({\n' + rows
            + '\n})\n\n\ndef _compute(x: int, parameters: tuple[int, int, int]) -> int:\n'
            + '    threshold, multiplier, offset = parameters\n'
            + '    return x * multiplier + offset if x > threshold else x + offset\n\n\n' + wrappers + '\n')


def emit_typescript(table):
    rows = "\n".join(f'  {name}: Object.freeze({{ threshold: {a}n, multiplier: {b}n, offset: {c}n }}),' for name, (a, b, c) in table.items())
    wrappers = "\n\n".join(f'export function {name}(x: bigint): bigint {{\n  return compute(x, PARAMS.{name});\n}}' for name in table)
    return ('const PARAMS = Object.freeze({\n' + rows + '\n});\n\n'
            + 'function compute(x: bigint, parameters: { readonly threshold: bigint; readonly multiplier: bigint; readonly offset: bigint }): bigint {\n'
            + '  const { threshold, multiplier, offset } = parameters;\n'
            + '  return x > threshold ? x * multiplier + offset : x + offset;\n}\n\n' + wrappers + '\n')


def emit_inline(table):
    functions = []
    for name, (threshold, multiplier, offset) in table.items():
        body = ("x" if offset == 0 else f"x + {offset}") if multiplier == 1 else (
            f"x * {multiplier} + {offset} if x > {threshold} else x + {offset}")
        functions.append(f"def {name}(x: int) -> int:\n    return {body}")
    return "\n\n\n".join(functions) + "\n"

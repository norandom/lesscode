"""Render the recorded experiment; no measurements are inferred from the chart."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
cases = json.loads((root / "results.json").read_text())["cases"]
fig, axes = plt.subplots(1, 2, figsize=(11, 4.8), layout="constrained")
colors = ["#687789", "#257aa0", "#17816b"]
for axis, metric, title in zip(axes, ("physical_lines", "utf8_bytes"),
                               ("Maintained Python source lines", "Maintained Python source bytes")):
    for group, (case, label) in enumerate((("bloated", "Verbose fixture"), ("compact", "Compact control"))):
        for form, (key, name) in enumerate((("before", "Original"), ("shared", "Kernel + table"), ("inline", "Direct expressions"))):
            value = cases[case][key][metric]
            position = group * 4 + form
            axis.bar(position, value, color=colors[form], label=name if group == 0 else None)
            axis.text(position, value, f"{value:,}", ha="center", va="bottom", fontsize=10)
    axis.set_xticks([1, 5], ["Verbose fixture\n6 functions", "Compact control\n3 functions"])
    axis.set_title(title, fontsize=12)
    axis.set_ylim(0, axis.get_ylim()[1] * 1.15)
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="y", alpha=.15)
    axis.set_axisbelow(True)
axes[0].legend(frameon=False, fontsize=9)
fig.suptitle("Equivalent code can still be larger: compare complete alternatives", fontsize=14)
destination = root.parents[1] / "images"
destination.mkdir(exist_ok=True)
for suffix in ("svg", "png"):
    fig.savefig(destination / f"cegis-compression.{suffix}", dpi=180)

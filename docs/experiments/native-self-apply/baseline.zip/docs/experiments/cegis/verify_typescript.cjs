const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");

const build = path.resolve(process.argv[2]);
const results = {};
for (const stem of ["bloated", "compact"]) {
  const candidate = require(path.join(build, `${stem}_shared.js`));
  const vectors = JSON.parse(fs.readFileSync(path.join(__dirname, `${stem}_vectors.json`), "utf8"));
  for (const [name, input, expected] of vectors) {
    assert.equal(candidate[name](BigInt(input)), BigInt(expected));
  }
  results[stem] = { comparisons: vectors.length, mismatches: 0 };
}
const x = -0;
const candidate = x > 0 ? x * 1 + 0 : x + 0;
assert.equal(Object.is(x, -0), true);
assert.equal(Object.is(candidate, -0), false);
const report = { node: process.version, typescript: "5.9.3", strictCompilation: true,
  scope: "Generated bigint output only; no TypeScript input extraction or number equivalence proof",
  results, numberSignedZeroCounterexample: true };
fs.writeFileSync(path.join(__dirname, "typescript-results.json"), JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report, null, 2));

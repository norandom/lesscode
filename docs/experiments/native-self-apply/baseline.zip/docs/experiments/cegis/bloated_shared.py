from types import MappingProxyType


_PARAMS = MappingProxyType({
    "standard": (100, 2, 3),
    "express": (250, 3, 10),
    "bulk": (500, 4, -7),
    "priority": (50, 5, 12),
    "economy": (200, 2, -2),
    "free": (0, 1, 0),
})


def _compute(x: int, parameters: tuple[int, int, int]) -> int:
    threshold, multiplier, offset = parameters
    return x * multiplier + offset if x > threshold else x + offset


def standard(x: int) -> int:
    return _compute(x, _PARAMS["standard"])

def express(x: int) -> int:
    return _compute(x, _PARAMS["express"])

def bulk(x: int) -> int:
    return _compute(x, _PARAMS["bulk"])

def priority(x: int) -> int:
    return _compute(x, _PARAMS["priority"])

def economy(x: int) -> int:
    return _compute(x, _PARAMS["economy"])

def free(x: int) -> int:
    return _compute(x, _PARAMS["free"])

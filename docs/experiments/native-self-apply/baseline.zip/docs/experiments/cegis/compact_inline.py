def standard(x: int) -> int:
    return x * 2 + 3 if x > 100 else x + 3


def express(x: int) -> int:
    return x * 3 + 10 if x > 250 else x + 10


def free(x: int) -> int:
    return x

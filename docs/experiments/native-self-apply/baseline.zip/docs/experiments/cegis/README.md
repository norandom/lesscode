# CEGIS compression experiment

Start with the [measured report and charts](../../reports/code-flow-synthesis.md). The verbose synthetic fixture shrank from 66 to 22 physical Python lines with direct expressions; a shared kernel used 35. The compact negative control grew when forced into the shared representation.

## Inspect and reproduce

- [Technical specification and reproduction commands](SPEC.md)
- [Restricted AST extraction and CEGIS implementation](synthesis.py)
- [Experiment runner and negative controls](trial.py)
- [Original verbose fixture](bloated.py), [direct candidate](bloated_inline.py), [shared candidate](bloated_shared.py)
- [Direct diff](bloated_inline.diff), [shared diff](bloated_shared.diff)
- [Compact control](compact.py), [rejected shared diff](compact_shared.diff)
- [Python measurements, hashes and proof outcomes](results.json)
- [Generated TypeScript example](bloated_shared.ts), [TypeScript validation receipt](typescript-results.json)

Regenerate the chart after running the experiment:

```powershell
uv.exe run --no-project --no-python-downloads --python 3.13.16 --with matplotlib==3.10.7 python docs/experiments/cegis/plot_results.py
```

The supported semantics are exact integers, not Python float or TypeScript number. This is a standalone experiment, not an installed Lesscode capability or an automatic repository rewrite.

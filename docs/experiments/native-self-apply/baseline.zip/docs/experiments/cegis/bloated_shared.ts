const PARAMS = Object.freeze({
  standard: Object.freeze({ threshold: 100n, multiplier: 2n, offset: 3n }),
  express: Object.freeze({ threshold: 250n, multiplier: 3n, offset: 10n }),
  bulk: Object.freeze({ threshold: 500n, multiplier: 4n, offset: -7n }),
  priority: Object.freeze({ threshold: 50n, multiplier: 5n, offset: 12n }),
  economy: Object.freeze({ threshold: 200n, multiplier: 2n, offset: -2n }),
  free: Object.freeze({ threshold: 0n, multiplier: 1n, offset: 0n }),
});

function compute(x: bigint, parameters: { readonly threshold: bigint; readonly multiplier: bigint; readonly offset: bigint }): bigint {
  const { threshold, multiplier, offset } = parameters;
  return x > threshold ? x * multiplier + offset : x + offset;
}

export function standard(x: bigint): bigint {
  return compute(x, PARAMS.standard);
}

export function express(x: bigint): bigint {
  return compute(x, PARAMS.express);
}

export function bulk(x: bigint): bigint {
  return compute(x, PARAMS.bulk);
}

export function priority(x: bigint): bigint {
  return compute(x, PARAMS.priority);
}

export function economy(x: bigint): bigint {
  return compute(x, PARAMS.economy);
}

export function free(x: bigint): bigint {
  return compute(x, PARAMS.free);
}

def standard(x: int) -> int:
    return x * 2 + 3 if x > 100 else x + 3


def express(x: int) -> int:
    return x * 3 + 10 if x > 250 else x + 10


def bulk(x: int) -> int:
    return x * 4 + -7 if x > 500 else x + -7


def priority(x: int) -> int:
    return x * 5 + 12 if x > 50 else x + 12


def economy(x: int) -> int:
    return x * 2 + -2 if x > 200 else x + -2


def free(x: int) -> int:
    return x

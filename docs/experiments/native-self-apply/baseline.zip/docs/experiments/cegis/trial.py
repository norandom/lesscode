"""Run bounded synthesis, challenge emitted code, and retain complete diffs."""
import ast
import argparse
import difflib
import hashlib
import io
import json
import math
from pathlib import Path
import platform
import random
import tokenize
from unittest.mock import patch

import z3

from synthesis import check, emit_inline, emit_python, emit_typescript, expression, summarize, synthesize

ROOT = Path(__file__).resolve().parent


def metrics(source):
    tree = ast.parse(source)
    return {"physical_lines": len(source.splitlines()), "utf8_bytes": len(source.encode()),
            "sha256": hashlib.sha256(source.encode()).hexdigest(),
            "logical_lines": sum(t.type == tokenize.NEWLINE for t in tokenize.generate_tokens(io.StringIO(source).readline)),
            "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "functions": sum(isinstance(n, ast.FunctionDef) for n in ast.walk(tree))}


def verify_generated(summary, shared_source, table):
    tree = ast.parse(shared_source)
    helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_compute")
    row = table[summary["name"]]
    environment = dict(zip(("threshold", "multiplier", "offset"), map(z3.IntVal, row)))
    environment["x"] = summary["input"]
    actual = expression(helper.body[-1].value, environment)
    status, _ = check(actual != summary["output"])
    assert status == z3.unsat, "emitted kernel does not implement the verified expression"


def run_case(stem):
    source = (ROOT / f"{stem}.py").read_text(encoding="utf-8")
    summaries = summarize(source)
    results = {s["name"]: synthesize(s) for s in summaries}
    assert all(r["status"] == "verified" for r in results.values()), results
    table = {name: result["parameters"] for name, result in results.items()}
    shared, inline = emit_python(table), emit_inline(table)
    inline_summaries = {s["name"]: s for s in summarize(inline)}
    for summary in summaries:
        verify_generated(summary, shared, table)
        replacement = inline_summaries[summary["name"]]
        replacement_output = z3.substitute(replacement["output"], (replacement["input"], summary["input"]))
        status, _ = check(replacement_output != summary["output"])
        assert status == z3.unsat
    # Execute only these owned synthetic fixtures and generated candidates.
    original, shared_namespace, inline_namespace = {}, {}, {}
    exec(compile(source, stem, "exec"), original)
    exec(compile(shared, stem + "_shared", "exec"), shared_namespace)
    exec(compile(inline, stem + "_inline", "exec"), inline_namespace)
    rng = random.Random(17)
    samples = {0, 1, -1, 10**100, -(10**100)}
    samples.update(rng.randint(-10000, 10000) for _ in range(1000))
    for threshold, _, _ in table.values():
        samples.update((threshold - 1, threshold, threshold + 1))
    checks = 0
    ts_vectors = []
    for name in table:
        for x in sorted(samples):
            expected = original[name](x)
            assert shared_namespace[name](x) == expected
            assert inline_namespace[name](x) == expected
            checks += 2
            ts_vectors.append([name, str(x), str(expected)])
    for suffix, candidate in (("shared", shared), ("inline", inline)):
        (ROOT / f"{stem}_{suffix}.py").write_text(candidate, encoding="utf-8")
        diff = "".join(difflib.unified_diff(source.splitlines(True), candidate.splitlines(True),
                                         fromfile=f"a/{stem}.py", tofile=f"b/{stem}.py"))
        (ROOT / f"{stem}_{suffix}.diff").write_text(diff, encoding="utf-8")
    (ROOT / f"{stem}_shared.ts").write_text(emit_typescript(table), encoding="utf-8")
    (ROOT / f"{stem}_vectors.json").write_text(json.dumps(ts_vectors), encoding="utf-8")
    before, shared_size, inline_size = map(metrics, (source, shared, inline))
    return {"source_sha256": hashlib.sha256(source.encode()).hexdigest(), "synthesis": results,
            "source_branch_depths": {s["name"]: s["branch_depth"] for s in summaries},
            "before": before, "shared": shared_size, "inline": inline_size,
            "python_concrete_comparisons": checks, "typescript_vectors": len(ts_vectors),
            "shared_smaller_in_lines_and_bytes": shared_size["logical_lines"] < before["logical_lines"] and shared_size["utf8_bytes"] < before["utf8_bytes"],
            "inline_smaller_in_lines_and_bytes": inline_size["logical_lines"] < before["logical_lines"] and inline_size["utf8_bytes"] < before["utf8_bytes"]}


def rejection_cases():
    rejected = []
    for name, source in {
        "float": "def f(x: int) -> int:\n    return x * 0.9\n",
        "call": "def f(x: int) -> int:\n    return abs(x)\n",
        "implicit_none": "def f(x: int) -> int:\n    if x > 0:\n        return x\n",
        "side_effect": "def f(x: int) -> int:\n    print(x)\n    return x\n",
        "nonlinear": "def f(x: int) -> int:\n    return x * x\n",
    }.items():
        try:
            summarize(source)
        except ValueError as error:
            rejected.append({"case": name, "reason": str(error)})
        else:
            raise AssertionError(f"unsupported case accepted: {name}")
    incompatible = summarize("def f(x: int) -> int:\n    if x > 10:\n        return x * 3\n    if x > 0:\n        return x * 2\n    return x\n")[0]
    result = synthesize(incompatible)
    assert result["status"] == "no_solution_in_sketch", result
    limited = synthesize(incompatible, max_iterations=0)
    assert limited["status"] == "iteration_limit"
    budget = synthesize(incompatible, budget_seconds=0)
    assert budget["status"] == "budget_exhausted"
    identity = summarize("def f(x: int) -> int:\n    return x\n")[0]
    with patch("synthesis.check", return_value=(z3.unknown, z3.Solver())):
        unknown = synthesize(identity)
    assert unknown["status"] == "unknown" and unknown["stage"] == "verification"
    # Real equality loses signed zero, observable in both target languages.
    x = -0.0
    original = x
    generated = x * 1.0 + 0.0 if x > 0.0 else x + 0.0
    assert math.copysign(1.0, original) != math.copysign(1.0, generated)
    return {"unsupported": rejected, "incompatible_sketch": result,
            "iteration_limit": limited["status"], "budget_limit": budget["status"],
            "injected_unknown": unknown["status"],
            "float_counterexample": {"input": "-0.0", "original_sign": math.copysign(1, original),
                                     "generated_sign": math.copysign(1, generated)}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--specimen", type=Path)
    arguments = parser.parse_args()
    report = {"python": platform.python_version(), "z3": z3.get_version_string(),
              "domain": "exact built-in Python int; TypeScript bigint target, not number",
              "cases": {stem: run_case(stem) for stem in ("bloated", "compact")},
              "negative_controls": rejection_cases()}
    report["zero_seed_control"] = synthesize(summarize((ROOT / "bloated.py").read_text())[0], seed_literals=False)
    report["apparatus"] = {name: metrics((ROOT / name).read_text(encoding="utf-8"))
                           for name in ("synthesis.py", "trial.py")}
    if arguments.specimen:
        specimen_path = arguments.specimen / "src/facdrone/library/stops/iv_stop.py"
        specimen_source = specimen_path.read_text(encoding="utf-8")
        findings = []
        for node in ast.parse(specimen_source).body:
            if isinstance(node, ast.FunctionDef) and node.name in {"bar_sigma", "stress_multiplier"}:
                try:
                    summarize(ast.get_source_segment(specimen_source, node))
                except ValueError as error:
                    findings.append({"function": node.name, "status": "unsupported", "reason": str(error)})
                else:
                    raise AssertionError("floating-point specimen unexpectedly accepted")
        report["specimen"] = {"path": "src/facdrone/library/stops/iv_stop.py",
                              "sha256": hashlib.sha256(specimen_source.encode()).hexdigest(),
                              "findings": findings, "modified": False}
    (ROOT / "results.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))

# Lesscode self-application: preserve the behavior boundary

The [Lesscode census and real-code CEGIS report](../../reports/lesscode-self-application.md)
records 282 production definitions, explicit prototype exclusions and a solved
decision-table replacement that passes behavior checks but adds source. It
includes charts, raw results, a replayable SMT query and the complete diff.

The [selected Facdrone and Lesscode boundaries](../facdrone/selected-parts.md) explain the measured priorities. This directory keeps experimental replacements separate from production code.

The first trial tests a standard-library substitute for portable path matching. It is **rejected**: 22 original snapshot tests pass; the replacement produces 11 failures and 2 errors. Source and existing tests remain unchanged. See [glob-result.json](glob-result.json) for fingerprints and exact failures.

```powershell
$env:PYTHONPATH=(Resolve-Path src).Path
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/self-apply/glob_trial.py
```

The runner exits successfully only when the original passes, the candidate is rejected, and source/test bytes remain unchanged. A successful experiment exit does not mean the candidate passed. Existing snapshot tests create and clean their own temporary directories. Facdrone is not accessed by this trial.

The next substantial candidate is the full public record conversion boundary. A five-leaf library trial already showed that adding a dependency for a marginal source reduction was not useful. Preserve functionality and tests; do not accept a smaller implementation merely to obtain a positive result.

## Fresh baseline

On 2026-11-01, the existing full suite ran **515 tests in 613.224 seconds, with 11 skipped**, exit code 0, on Windows / CPython 3.12.10. [Raw output](baseline-tests.txt) includes an intentionally failing child command exercised by the tests; the final unittest outcome is `OK (skipped=11)`. This validates the current working tree, including pre-existing rule-evaluation edits; it is not new cross-platform validation or a proof of equivalence. The rejected candidate was applied only inside the separate scoped trial.

```powershell
$env:PYTHONPATH=(Resolve-Path src).Path
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python -m unittest discover -q
```

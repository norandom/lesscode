_DISPOSITIONS = {
    (False, False, 0): 'improved',
    (False, False, 1): 'unchanged',
    (False, False, 2): 'worsened',
    (False, True, 2): 'new_debt',
    (True, False, 0): 'resolved_debt',
    (True, True, 0): 'improved_residual_debt',
    (True, True, 1): 'inherited_debt',
    (True, True, 2): 'worsened_debt',
}


def _debt_disposition(reference, candidate, maximum):
    trend = 0 if candidate < reference else 1 if candidate == reference else 2
    reference_above = maximum is not None and reference > maximum
    candidate_above = maximum is not None and candidate > maximum
    return _DISPOSITIONS[reference_above, candidate_above, trend]

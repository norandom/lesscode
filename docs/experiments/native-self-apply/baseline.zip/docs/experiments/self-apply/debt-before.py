def _debt_disposition(reference, candidate, maximum):
    if maximum is not None and reference > maximum:
        if candidate <= maximum:
            return "resolved_debt"
        if candidate == reference:
            return "inherited_debt"
        return "improved_residual_debt" if candidate < reference else "worsened_debt"
    if maximum is not None and candidate > maximum:
        return "new_debt"
    if candidate == reference:
        return "unchanged"
    return "improved" if candidate < reference else "worsened"

"""Census all production Python definitions; attempt the unchanged prototype."""
import ast
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tokenize

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "docs/experiments/cegis"))
from synthesis import summarize, synthesize


def metrics(source):
    return {"physical_lines": len(source.splitlines()), "utf8_bytes_lf": len(source.encode()),
            "logical_lines": sum(t.type == tokenize.NEWLINE for t in tokenize.generate_tokens(io.StringIO(source).readline))}


def definitions(node, prefix="", context="module"):
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            name = prefix + child.name
            if not isinstance(child, ast.ClassDef):
                yield name, context, child
            yield from definitions(child, name + ".", "method" if isinstance(child, ast.ClassDef) else "nested")
        else:
            yield from definitions(child, prefix, context)


if __name__ == "__main__":
    files, outcomes = {}, []
    for path in sorted((ROOT / "src").rglob("*.py")):
        raw = path.read_bytes()
        source = raw.decode("utf-8-sig").replace("\r\n", "\n")
        relative = path.relative_to(ROOT).as_posix()
        files[relative] = {"sha256_raw": hashlib.sha256(raw).hexdigest(), **metrics(source)}
        for name, context, node in definitions(ast.parse(source)):
            row = {"file": relative, "name": name, "line": node.lineno, "context": context,
                   "span_lines": node.end_lineno - node.lineno + 1}
            if context != "module":
                row.update(status="excluded", reason="method or nested closure context not modeled")
            elif isinstance(node, ast.AsyncFunctionDef):
                row.update(status="excluded", reason="async execution not modeled")
            else:
                try:
                    summary, = summarize(ast.unparse(node))
                except ValueError as error:
                    row.update(status="unsupported", reason=str(error))
                else:
                    row.update(status="supported", synthesis=synthesize(summary))
            outcomes.append(row)
    populations = {}
    groups = {"production": list((ROOT / "src").rglob("*.py")),
              "automated_tests": list((ROOT / "tests").glob("test_*.py")),
              "test_other_and_fixtures": [p for p in (ROOT / "tests").rglob("*.py") if p not in (ROOT / "tests").glob("test_*.py")],
              "experiment_support": list((ROOT / "docs/experiments").rglob("*.py"))}
    for group, paths in groups.items():
        counts = [metrics(p.read_text(encoding="utf-8-sig")) for p in paths]
        populations[group] = {"files": len(paths), **{key: sum(c[key] for c in counts) for key in counts[0]}}
    report = {"revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
              "working_tree": subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True),
              "prototype_sha256": hashlib.sha256((ROOT / "docs/experiments/cegis/synthesis.py").read_bytes()).hexdigest(),
              "definitions": "All src/**/*.py files, including uncommitted bytes. Each lexical function definition counted once; spans overlap for nested functions and must not be summed. Embedded worker source strings are not parsed as separate functions. Tests and experiments are separate populations.",
              "populations": populations, "files": files, "outcomes": outcomes,
              "status_counts": dict(Counter(r["status"] for r in outcomes)),
              "reason_counts": dict(Counter(r.get("reason", "supported") for r in outcomes))}
    assert all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == info["sha256_raw"] for p, info in files.items())
    Path(__file__).with_name("applicability.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"populations": populations, "statuses": report["status_counts"], "reasons": report["reason_counts"]}, indent=2))

"""Fit a decision table to a real pure classifier; keep production untouched."""
import ast
import difflib
import hashlib
import io
import itertools
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import z3
from lesscode_baseline.rules import evaluate

ROOT = Path(__file__).resolve().parent
LABELS = ("resolved_debt", "inherited_debt", "improved_residual_debt", "worsened_debt",
          "new_debt", "unchanged", "improved", "worsened")
reference, candidate, maximum = z3.Reals("reference candidate maximum")
has_maximum = z3.Bool("has_maximum")
SYMBOLS = (reference, candidate, maximum, has_maximum)


def expression(node):
    if isinstance(node, ast.Name):
        return dict(zip(("reference", "candidate", "maximum"), SYMBOLS))[node.id]
    if isinstance(node, ast.Constant) and node.value in LABELS:
        return z3.IntVal(LABELS.index(node.value))
    if isinstance(node, ast.BoolOp) and isinstance(node.op, ast.And):
        return z3.And(*(expression(v) for v in node.values))
    if isinstance(node, ast.Compare) and len(node.ops) == 1:
        if (isinstance(node.ops[0], ast.IsNot) and isinstance(node.left, ast.Name)
                and node.left.id == "maximum" and isinstance(node.comparators[0], ast.Constant)
                and node.comparators[0].value is None):
            return has_maximum
        left, right = expression(node.left), expression(node.comparators[0])
        return {ast.Gt: lambda: left > right, ast.LtE: lambda: left <= right,
                ast.Eq: lambda: left == right, ast.Lt: lambda: left < right}[type(node.ops[0])]()
    if isinstance(node, ast.IfExp):
        return z3.If(expression(node.test), expression(node.body), expression(node.orelse))
    raise ValueError("unsupported expression: " + ast.dump(node))


def returns(statements):
    first, *rest = statements
    if isinstance(first, ast.Return):
        if rest:
            raise ValueError("unreachable statements not modeled")
        return expression(first.value)
    if isinstance(first, ast.If):
        return z3.If(expression(first.test), returns(first.body), returns(first.orelse + rest))
    raise ValueError("unsupported statement: " + type(first).__name__)


def run_tests(function):
    output = io.StringIO()
    suite = unittest.defaultTestLoader.discover("tests", pattern="test_rule_evaluation.py")
    with patch.object(evaluate, "_debt_disposition", function):
        result = unittest.TextTestRunner(stream=output).run(suite)
    return {"run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
            "skipped": len(result.skipped), "log": output.getvalue()}


if __name__ == "__main__":
    module_path = Path(evaluate.__file__)
    raw = module_path.read_bytes()
    source = raw.decode("utf-8")
    test_path = Path("tests/test_rule_evaluation.py")
    test_raw = test_path.read_bytes()
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "_debt_disposition")
    before = ast.get_source_segment(source, node) + "\n"
    original = returns(node.body)
    keys = list(itertools.product((False, True), (False, True), range(3)))
    trend = z3.If(candidate < reference, 0, z3.If(candidate == reference, 1, 2))
    guards = [z3.And(z3.And(has_maximum, reference > maximum) == old,
                     z3.And(has_maximum, candidate > maximum) == new, trend == direction)
              for old, new, direction in keys]
    holes = [z3.Int(f"cell_{i}") for i in range(len(keys))]
    sketch = z3.Sum(*(z3.If(guard, hole, 0) for guard, hole in zip(guards, holes)))
    synth = z3.Solver()
    synth.set(timeout=2000)
    synth.add(*(z3.And(h >= 0, h < len(LABELS)) for h in holes))
    trace = []
    for iteration in range(14):
        status = synth.check()
        if status != z3.sat:
            raise RuntimeError(f"synthesis: {status}; {synth.reason_unknown()}")
        values = [synth.model().eval(h, model_completion=True) for h in holes]
        proposal = z3.substitute(sketch, *zip(holes, values))
        verify = z3.Solver()
        verify.set(timeout=2000)
        verify.add(proposal != original)
        status = verify.check()
        if status == z3.unsat:
            (ROOT / "debt-verification.smt2").write_text(verify.to_smt2(), encoding="utf-8")
            break
        if status != z3.sat:
            raise RuntimeError(f"verification: {status}; {verify.reason_unknown()}")
        point = [verify.model().eval(s, model_completion=True) for s in SYMBOLS]
        substitutions = list(zip(SYMBOLS, point))
        synth.add(z3.substitute(sketch, *substitutions) == z3.substitute(original, *substitutions))
        trace.append([str(v) for v in point])
    else:
        raise RuntimeError("CEGIS iteration budget exhausted")
    rows = []
    for key, guard, value in zip(keys, guards, values):
        reachable = z3.Solver()
        reachable.set(timeout=2000)
        reachable.add(guard)
        status = reachable.check()
        if status == z3.sat:
            rows.append((key, LABELS[value.as_long()]))
        elif status != z3.unsat:
            raise RuntimeError("reachability unknown")
    after = "_DISPOSITIONS = {\n" + "".join(f"    {key!r}: {label!r},\n" for key, label in rows) + "}\n\n\n"
    after += '''def _debt_disposition(reference, candidate, maximum):
    trend = 0 if candidate < reference else 1 if candidate == reference else 2
    reference_above = maximum is not None and reference > maximum
    candidate_above = maximum is not None and candidate > maximum
    return _DISPOSITIONS[reference_above, candidate_above, trend]
'''
    namespace = {}
    exec(compile(after, "generated_debt.py", "exec"), namespace)
    replacement = namespace["_debt_disposition"]
    numbers = (-10**100, -2, -1, -0.0, 0, 0.5, 1, 2, 10**100)
    comparisons = 0
    for a, b, limit in itertools.product(numbers, numbers, (None, *numbers)):
        assert evaluate._debt_disposition(a, b, limit) == replacement(a, b, limit)
        comparisons += 1
    baseline_tests = run_tests(evaluate._debt_disposition)
    candidate_tests = run_tests(replacement)
    assert not any(r[k] for r in (baseline_tests, candidate_tests) for k in ("failures", "errors"))
    assert module_path.read_bytes() == raw
    assert test_path.read_bytes() == test_raw
    (ROOT / "debt-before.py").write_text(before, encoding="utf-8")
    (ROOT / "debt-after.py").write_text(after, encoding="utf-8")
    (ROOT / "debt.diff").write_text("".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="original", tofile="table_candidate")), encoding="utf-8")
    report = {"module_sha256": hashlib.sha256(raw).hexdigest(), "python": sys.version,
              "test_sha256": hashlib.sha256(test_raw).hexdigest(),
              "before_sha256_lf": hashlib.sha256(before.encode()).hexdigest(),
              "after_sha256_lf": hashlib.sha256(after.encode()).hexdigest(),
              "z3": z3.get_version_string(), "scope": "manually selected existing pure classifier; ordered finite built-in numbers and optional maximum",
              "proof": "unsat for original AST expression vs solved symbolic table over Real order plus optional maximum flag; emitted Python has differential and existing-test evidence",
              "iterations": iteration + 1, "counterexamples": trace, "reachable_cells": len(rows),
              "concrete_comparisons": comparisons, "mismatches": 0,
              "before": {"physical_lines": len(before.splitlines()), "bytes": len(before.encode())},
              "after_including_table": {"physical_lines": len(after.splitlines()), "bytes": len(after.encode())},
              "baseline_tests": baseline_tests, "candidate_tests": candidate_tests,
              "decision": "retain original: table adds maintained source and indirect numeric trend encoding",
              "product_modified": False}
    (ROOT / "debt-result.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k not in ("baseline_tests", "candidate_tests", "counterexamples")}, indent=2))

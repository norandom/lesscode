"""Test a tempting standard-library replacement against existing scope tests."""
import ast
from fnmatch import fnmatchcase
import hashlib
import io
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from lesscode_baseline import snapshot


def native_matches(path: str, pattern: str) -> bool:
    return fnmatchcase(path, pattern)


def run_tests(replacement=None):
    suite = unittest.defaultTestLoader.discover("tests", pattern="test_snapshot.py")
    output = io.StringIO()
    with patch.object(snapshot, "matches", replacement or snapshot.matches):
        result = unittest.TextTestRunner(stream=output, verbosity=1).run(suite)
    return {"tests_run": result.testsRun, "failures": len(result.failures),
            "errors": len(result.errors), "skipped": len(result.skipped), "log": output.getvalue()}


if __name__ == "__main__":
    source_path = Path(snapshot.__file__)
    raw = source_path.read_bytes()
    test_path = Path("tests/test_snapshot.py")
    test_bytes = test_path.read_bytes()
    source = raw.decode("utf-8")
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == "matches")
    baseline = run_tests()
    candidate = run_tests(native_matches)
    examples = [("main.py", "**/*.py"), ("src/main.py", "*.py"), ("src/a.py", "src/**/?.py")]
    report = {"decision": "reject candidate; retain production implementation",
              "source_sha256": hashlib.sha256(raw).hexdigest(),
              "test_sha256": hashlib.sha256(test_bytes).hexdigest(),
              "baseline_function_lines": node.end_lineno - node.lineno + 1,
              "candidate_function_lines": 2,
              "baseline": baseline, "candidate": candidate,
              "counterexamples": [{"path": path, "pattern": pattern, "original": snapshot.matches(path, pattern),
                                   "candidate": native_matches(path, pattern)} for path, pattern in examples],
              "source_unchanged": source_path.read_bytes() == raw,
              "tests_unchanged": test_path.read_bytes() == test_bytes}
    assert baseline["failures"] == baseline["errors"] == 0, baseline
    assert candidate["failures"] > 0 and report["source_unchanged"] and report["tests_unchanged"], candidate
    Path(__file__).with_name("glob-result.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print({key: value for key, value in report.items() if key not in ("baseline", "candidate")})

"""Plot measured applicability and complete replacement cost, not a quality score."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
census = json.loads((root / "applicability.json").read_text())
trial = json.loads((root / "debt-result.json").read_text())
fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), layout="constrained")
values = [census["status_counts"].get(k, 0) for k in ("supported", "unsupported", "excluded")]
axes[0].barh(["Accepted by current interface", "Module functions unsupported", "Methods / nested: excluded"], values,
             color=["#17816b", "#687789", "#b8c0ca"])
for i, value in enumerate(values):
    axes[0].text(value + 2, i, str(value), va="center")
axes[0].set_xlim(0, max(values) * 1.25)
axes[0].set_title("Unchanged pricing prototype: 282 definitions")
axes[0].set_xlabel("Function definitions; not compressibility")
axes[0].invert_yaxis()
lines = [trial[k]["physical_lines"] for k in ("before", "after_including_table")]
axes[1].bar(["Original classifier", "Solved table + lookup"], lines, color=["#687789", "#b16a36"])
for i, value in enumerate(lines):
    axes[1].text(i, value + .3, str(value), ha="center")
axes[1].set_ylim(0, max(lines) * 1.25)
axes[1].set_ylabel("Physical Python lines")
axes[1].set_title("Real-code trial: verified model, larger source")
for axis in axes:
    axis.spines[["top", "right"]].set_visible(False)
destination = root.parents[1] / "images"
for suffix in ("svg", "png"):
    fig.savefig(destination / f"lesscode-synthesis-statistics.{suffix}", dpi=180)

"""Same native checks and fixed generated boundary corpus for each arm."""
import contextlib
import itertools
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
arm, mode = sys.argv[1:3]
work = ROOT / ".runs/npu-backends-01" / arm
sys.path.insert(0, str(work / "src"))
os.chdir(work)
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
if mode == "tests":
    import pytest
    with (HERE / arm / "tests.log").open("w", encoding="utf-8") as log:
        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
            code = pytest.main(["-q", "--import-mode=importlib", "-p", "no:cacheprovider",
                "--junitxml=" + str(HERE / arm / "tests.xml"), "tests/embedding/providers/test_cpu.py",
                "tests/embedding/providers/test_vitisai.py", "tests/embedding/providers/test_base.py",
                "tests/embedding/test_service.py", "tests/embedding/test_postprocess.py"])
    (HERE / arm / "test-exit.json").write_text(json.dumps(dict(exit_code=int(code))))
    print(arm, "tests", code)
    raise SystemExit(code)

import numpy as np
from npu_rag.embedding.providers.cpu import CpuBackend
from npu_rag.embedding.providers.vitisai import VitisAIBackend
from npu_rag.embedding.profiles import ModelProfile
profile = ModelProfile("test/reference-model", 3, 4, 8, 1, "mean", False, "{content}", "{content}", False)
outcomes = []
shapes = ((1, 4), (1, 3), (2, 4), (4,))
dtypes = (np.int64, np.int32, np.float32)
for backend, left, right, output_case in itertools.product((CpuBackend, VitisAIBackend),
        tuple(itertools.product(shapes, dtypes)), tuple(itertools.product(shapes, dtypes)), range(11)):
    token_ids = np.ones(left[0], dtype=left[1])
    attention_mask = np.zeros(right[0], dtype=right[1])
    original_ids, original_mask = token_ids.copy(), attention_mask.copy()
    tensor = np.arange(12, dtype=np.float32).reshape(1, 4, 3)
    outputs = ([tensor], [], [tensor, tensor], [None], [1], [tensor.astype(np.float64)],
               [tensor.reshape(1, 3, 4)], [tensor.reshape(4, 3)], [np.zeros((1, 4, 0), np.float32)])
    calls = []

    class Session:
        def run(self, names, feed):
            calls.append(dict(names=names, keys=list(feed), ids_identity=feed["input_ids"] is token_ids,
                              mask_identity=feed["attention_mask"] is attention_mask))
            if output_case >= 9:
                raise (RuntimeError if output_case == 9 else ValueError)("fixed session failure")
            return outputs[output_case]

    instance = backend.__new__(backend)
    instance._profile, instance._shape, instance._session = profile, (1, 4), Session()
    try:
        result = instance.run(token_ids, attention_mask)
        observed = dict(returned=True, identity=result is outputs[output_case][0],
                        dtype=str(result.dtype), shape=list(result.shape), values=result.tolist())
    except Exception as error:
        observed = dict(returned=False, type=type(error).__name__, message=str(error),
                        provider=getattr(error, "provider", None), model_id=getattr(error, "model_id", None),
                        stage=getattr(error, "stage", None), suppressed=error.__suppress_context__,
                        cause=type(error.__cause__).__name__ if error.__cause__ else None)
    observed.update(calls=calls, inputs_unchanged=bool(np.array_equal(token_ids, original_ids)
                                                     and np.array_equal(attention_mask, original_mask)))
    outcomes.append(observed)
(HERE / arm / "outcomes.json").write_text(json.dumps(outcomes, indent=2) + "\n")
print(arm, "cases", len(outcomes))

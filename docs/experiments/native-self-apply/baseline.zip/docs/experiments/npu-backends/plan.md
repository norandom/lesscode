# NPU01: shared execution across active CPU/NPU providers

Recorded before candidate construction. Manual selection of one real capability:
validate and execute an already-created backend session over a batch, returning
its original token tensor or the same diagnostic exception. The ATS trial is
the preceding positive example, not a reduction target for this one.

## Replacement hypothesis and boundary

Share the repeated input-check, session-invocation and output-check algorithm
using a typed ordinary Python function and explicit diagnostic text arguments.
Keep both backend classes, public run signatures, provider-specific constructors,
session factories, precision choices, graph selection, partition verification,
fallback policy and error construction. No inheritance relation between CPU/NPU,
new package dependency, model download or real hardware run is needed.

Count both existing run/check/output/error methods, all changed imports, the
entire new shared module and new diagnostic arguments. Also measure both complete
provider modules plus the new module. Moving branches into helpers cannot improve
the scope decision. Record functions, aggregate decisions, LLOC, physical lines,
AST nodes and type/diagnostic overhead separately where useful.

Exact diagnostic strings, provider/model/stage attributes, exception suppression,
input-check order, session call count and original output/input object identity
remain part of the differential boundary. Private `_check` and `_only_tensor`
extension seams are not a promised external API; no inspected tests call them.
All existing public behavior remains. Document this exclusion explicitly.

## Frozen verification and budget

Copy source and selected unchanged tests to isolated Lesscode workspaces. Use
the existing local NPU project's Python through uv without syncing its environment.
Run original CPU/NPU fake-session tests and base/service/postprocess tests before
candidate construction. No live model/provider tests or arbitrary commands.

Before candidate construction, record outcomes for a fixed generated tensor
corpus: input shape/dtype conflicts, output count/type/dtype/shape conflicts and
session exceptions. Compare exception class/message/metadata, session feed
identity, call order, output identity and nonmutation. Re-run the same existing
tests on the candidate. Type-check changed modules under the existing strict
policy; report any baseline environmental/type limitations.

Existing static safety tests inspect individual provider modules. Supplement
them by inspecting/testing the new shared module so moving code cannot escape
their intent. A deliberate accepting-wrong-dtype variant must be detected.
No SMT model or inference-speed claim is made.

One candidate and at most one counterexample-driven corrective revision. Preserve
all attempts. A reduction is useful only if both physical and logical code fall,
with clear typed interfaces and intact safeguards. Record outcome even if modest.
Keep research scripts, copied tests and source archives separate. Neither specimen
repository is changed or committed; previous experimental evidence stays frozen.

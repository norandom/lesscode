# NPU01: scoped compression also works on this active backend family

One shared execution/check operation replaces repeated CPU/NPU implementations,
reducing the complete capability from 171 to 101 physical lines and 68 to 47
LLOC. All 3,168 frozen generated cases match; both versions pass the same 339
existing tests. This is a second positive scope-based result after ATS01, on
active code with provider safeguards and useful types retained.

The candidate is isolated in Lesscode. No source, test or dependency was changed
in `npu_rag_from_folder`, and there is no upstream adoption or hardware-performance
claim. The [plan](plan.md) preceded candidate construction.

![Complete execution and validation capability](scope-chart.png)

## The scope includes both adapters and all shared support

The capability starts with an already-created backend and its input batch, and
ends with the session's original output tensor or a diagnostic exception. It
contains both `run`, `_check`, `_only_tensor` and `_failed` implementations before
the rewrite. Afterward it contains both run adapters/error constructors, the
entire new typed shared module and both new imports. Diagnostic strings count.

```mermaid
flowchart LR
    C[CPU-specific construction and provider checks] --> CR[CPU run adapter]
    N[NPU-specific construction and partition checks] --> NR[NPU run adapter]
    CR --> S[Shared input checks, session call and output checks]
    NR --> S
    D[Provider-specific diagnostics and error construction] --> S
    S --> O[Original tensor identity or matching exception]
```

Neither provider inherits from the other. Both call the ordinary typed
`checked_run` function, supplying their session method, error constructor and
diagnostic wording. Constructors, session factories, graph selection, precision
choices, provider properties, partition verification and fallback policy are
unchanged by AST comparison. No generic provider framework was added.

## Whole-replacement measurements

| Measure | Original | Candidate | Change |
| --- | ---: | ---: | ---: |
| Capability physical lines | 171 | 101 | -70 (-40.9%) |
| Capability Radon LLOC | 68 | 47 | -21 (-30.9%) |
| Aggregate AST decision points | 16 | 8 | -8 (50%) |
| Summed Lizard CCN | 24 | 14 | -10 |
| Capability AST nodes | 889 | 682 | -207 |
| Functions, including nested check helper | 8 | 6 | -2 |
| Whole provider modules plus shared module: physical lines | 799 | 729 | -70 |
| Whole provider modules plus shared module: LLOC | 290 | 269 | -21 |

Physical scope counts sum actual owned source spans and new support, excluding
blank separators introduced solely to assemble an analysis fixture. The first
accounting pass counted those separators as 178/106; its
[original record](accounting-with-separators.json) remains available. The corrected
171/101 counts agree with the full-module saving. Logical and structural metrics
are unchanged by that correction.

The new shared interface has ten named parameters, including four diagnostic-text
arguments. That is an integration cost, included in the counts. The maximum
internal path to error construction grows from two call edges to three through
the shared function and nested input check. Fewer functions alone is not the
reason this candidate qualifies: the duplicated decision sequence is removed,
and the complete modules shrink. Physical savings include removed repeated
explanatory comments; the LLOC and decision reductions establish more than that.

## Same behavior on the recorded boundary

| Check | Original | Candidate | Deliberate dtype-check omission |
| --- | --- | --- | --- |
| Generated cases | 3,168 recorded | 3,168 match | 572 mismatches |
| Existing native tests | 339 passed | 339 passed | Not run |
| Strict type check, selected modules | Passed on retry, 2 files | Passed, 3 files | Not run |

The generated corpus crosses both backends, twelve input shape/dtype variants
for each input, and eleven output/session outcomes: `2 × 12 × 12 × 11 = 3,168`.
It checks exact exception class/message, provider/model/stage metadata, cause
suppression, session call count and feed identity, input nonmutation and output
identity. It calls the real run methods on prepared test instances; it does not
exercise constructors. Those are exercised by the unchanged native tests.

The five unchanged suites cover CPU, NPU, provider resolution, service and
postprocessing. They use injected sessions and synthetic ONNX graphs rather
than live models. No tests were weakened or deleted. Both baseline and candidate
had zero failures, errors or skips. Their elapsed times are test observations,
not inference benchmarks.

The deliberate mutant omits input-dtype rejection. It changes 572 outcomes,
including cases where a session is incorrectly called before a failure. This
checks one relevant safeguard, not a mutation score. The corpus collector exits
zero for collection; the separate accounting step verifies that the candidate
matches and the mutant differs.

Existing static safety tests inspect the individual provider modules. The
accounting script additionally inspects shared code for precision-changing,
pooling, normalization and logging calls. The generated checks verify returned
object identity and input nonmutation. This supplements the existing checks;
an AST call-name screen alone is not a security proof.

Mypy 2.3.1 used the copied strict project configuration with imported modules
followed silently. This is a selected-module check, not a full project type audit.
The first baseline process exited -536870911 with an empty log and an unknown
cause. A separate retry passed. Both attempts are retained; no source changed
between them. Candidate typing passed on its first run.

## What remains outside the claim

This is finite behavioral evidence, not universal equivalence or SMT proof.
Live CPU/NPU numerical behavior and hardware activity were not remeasured. The
candidate forwards the same arrays to the injected session without casts or
postprocessing; native hardware validation would still be needed before upstream
adoption.

The private `_check` and `_only_tensor` methods are removed. No inspected caller
or test relies on overriding them; private downstream subclass hooks are outside
this trial's contract. Public run signatures and provider interfaces remain.
The callable and diagnostic arguments are bound before entering the shared
function; arbitrary session properties or mutated profile objects with observable
attribute-access side effects are not covered by these fixtures.

The different diagnostics remain explicit strings, so the common function has
several parameters. That is preferable here to hiding behavior in a strategy
table or creating a CPU/NPU inheritance relationship. This is an inline design
assessment, not an independent review or a measured maintenance-time improvement.

## Decision and relation to ATS01

This is a useful tested candidate on the scoped boundary: 70 fewer physical lines,
21 fewer logical lines and half the aggregate decisions. It supports transferring
the shared-responsibility mechanism from a bilingual renderer to an active typed
backend family. It does not establish a general reduction percentage for NPU RAG
or for arbitrary AI-generated projects.

There is one real family, one candidate and one deliberately broken control.
Upstream adoption is zero. Research scripts add 253 physical Python lines;
candidate/source/test copies and charts are separate evidence. The product adds
no runtime dependencies. All 545 frozen input files, including the ATS evidence,
remained unchanged. See the [two-trial synthesis](../../reports/capability-compression.md).

## Evidence and reproduction

- [Results](result.json), [execution receipt](execution.json), [frozen inputs](frozen.json),
  [SVG chart](scope-chart.svg).
- Original: [CPU](original/cpu.py.txt), [NPU](original/vitisai.py.txt),
  [native test log](original/tests.log), [XML](original/tests.xml), [types](original/types.log).
- Candidate: [CPU diff](candidate/cpu.diff), [NPU diff](candidate/vitisai.diff),
  [complete shared module](checked_run.py), [native tests](candidate/tests.log),
  [XML](candidate/tests.xml), [types](candidate/types.log).
- [Baseline outcomes](original/outcomes.json), [candidate outcomes](candidate/outcomes.json),
  [mutant outcomes](mutant/outcomes.json), [mutant source](mutant/checked_run.py.txt).
- [First type-check receipt](original/types-attempt1-exit.json) and
  [empty diagnostic log](original/types-attempt1.log).

The scripts use `.runs/npu-backends-01/{original,candidate,mutant}` as isolated
workspaces. `prepare.py` freezes selected public source/tests/manifests and refuses
an existing workspace; `build.py` refuses existing candidate artifacts. Preserve
the run before reproducing it. The source revision and runtime versions are in
`execution.json`. No environment synchronization or Windows Store Python is used.

```powershell
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/npu-backends/prepare.py
uv.exe run --no-project --no-python-downloads --python ../npu_rag_from_folder/.venv/Scripts/python.exe python docs/experiments/npu-backends/run.py original tests
uv.exe run --no-project --no-python-downloads --python ../npu_rag_from_folder/.venv/Scripts/python.exe python docs/experiments/npu-backends/run.py original corpus
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/npu-backends/build.py
```

Then run `candidate tests`, `candidate corpus` and `mutant corpus` with the same
runner. `account.py` uses uv with Radon 6.0.1, Lizard 1.17.31 and Matplotlib 3.11.2.
Type checks run in each isolated workspace with `MYPYPATH=src`, invoking local
Python through uv and `python -m mypy --follow-imports=silent --no-incremental`
on the two provider modules and, for the candidate, `checked_run.py`.

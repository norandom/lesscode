"""Compare the frozen boundary and account for every replacement component."""
import ast
import hashlib
import importlib.metadata
import json
from pathlib import Path
import textwrap
import xml.etree.ElementTree as ET

import lizard
from radon.raw import analyze
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2] / ".runs/npu-backends-01"
baseline = json.loads((HERE / "original/outcomes.json").read_text())
comparisons = {}
for arm in ("candidate", "mutant"):
    outputs = json.loads((HERE / arm / "outcomes.json").read_text())
    assert len(outputs) == len(baseline)
    differing = [i for i, (old, new) in enumerate(zip(baseline, outputs)) if old != new]
    comparisons[arm] = dict(cases=len(outputs), mismatches=len(differing),
        witnesses=[dict(case=i, original=baseline[i], candidate=outputs[i]) for i in differing[:3]])


def metrics(source):
    nodes = list(ast.walk(ast.parse(source)))
    return dict(physical=len(source.splitlines()), lloc=analyze(source).lloc, ast_nodes=len(nodes),
        functions=sum(isinstance(n, ast.FunctionDef) for n in nodes),
        decisions=sum(isinstance(n, (ast.If, ast.IfExp, ast.For, ast.While, ast.ExceptHandler))
                      + (len(n.values)-1 if isinstance(n, ast.BoolOp) else 0)
                      + (1+len(n.ifs) if isinstance(n, ast.comprehension) else 0) for n in nodes),
        ccn_sum=sum(f.cyclomatic_complexity for f in lizard.analyze_file.analyze_source_code("scope.py", source).function_list))


measurements = {}
trees = {}
selected = {"run", "_check", "_only_tensor", "_failed"}
for arm in ("original", "candidate"):
    directory = WORK / arm / "src/npu_rag/embedding/providers"
    pieces, sources = [], []
    for name, class_name in (("cpu", "CpuBackend"), ("vitisai", "VitisAIBackend")):
        source = (directory / (name + ".py")).read_text()
        sources.append(source)
        cls = next(n for n in ast.parse(source).body if isinstance(n, ast.ClassDef) and n.name == class_name)
        trees[arm, name] = cls
        lines = source.splitlines(True)
        pieces += [textwrap.dedent("".join(lines[n.lineno-1:n.end_lineno])) for n in cls.body
                   if isinstance(n, ast.FunctionDef) and n.name in selected]
    if arm == "candidate":
        shared = (directory / "checked_run.py").read_text()
        sources.append(shared)
        pieces.extend([shared, "from npu_rag.embedding.providers.checked_run import checked_run\n" * 2])
    scope = "\n".join(pieces)
    (HERE / arm / "scope.py.txt").write_text(scope)
    scope_metrics = metrics(scope)
    scope_metrics["physical"] = sum(len(piece.splitlines()) for piece in pieces)
    measurements[arm] = dict(scope=scope_metrics, assembly_separator_lines=len(pieces)-1,
                            modules={key: sum(metrics(s)[key] for s in sources)
                                                          for key in metrics(scope)})
for name in ("cpu", "vitisai"):
    retained = lambda arm: [ast.dump(n) for n in trees[arm, name].body
                            if getattr(n, "name", None) not in {"run", "_check", "_only_tensor"}]
    assert retained("original") == retained("candidate")
shared_tree = ast.parse(shared)
calls = [ast.unparse(n.func) for n in ast.walk(shared_tree) if isinstance(n, ast.Call)]
unsafe = [name for name in calls if name.endswith(("astype", "SessionOptions", "add_session_config_entry"))
          or any(part in name for part in ("quantiz", "np.mean", "np.sum", "np.linalg", "print", "logging"))]
assert not unsafe
tests = {}
for arm in ("original", "candidate"):
    suite = ET.parse(HERE / arm / "tests.xml").getroot().find("testsuite")
    tests[arm] = suite.attrib
frozen = json.loads((HERE / "frozen.json").read_text())
changed = [path for path, value in frozen.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest() != value]
research = {p.name: len(p.read_text().splitlines()) for p in HERE.glob("*.py") if p.name != "checked_run.py"}
result = dict(comparisons=comparisons, measurements=measurements, tests=tests,
    unchanged_outside_run_and_checks=True, shared_forbidden_calls=unsafe,
    frozen_inputs=len(frozen), changed_inputs=changed, research_lines=research,
    versions={name: importlib.metadata.version(name) for name in ("lizard", "radon", "matplotlib")})
(HERE / "result.json").write_text(json.dumps(result, indent=2) + "\n")
fig, axes = plt.subplots(1, 3, figsize=(10, 3.5))
for axis, key, label in zip(axes, ("physical", "lloc", "decisions"), ("Physical lines", "Radon LLOC", "AST decision points")):
    values = [measurements[arm]["scope"][key] for arm in ("original", "candidate")]
    bars = axis.bar(["Original", "Candidate"], values, color=["#64748b", "#087e8b"])
    axis.bar_label(bars, padding=3)
    axis.set_ylim(0, max(values)*1.2)
    axis.set_title(label)
    axis.spines[["top", "right"]].set_visible(False)
fig.suptitle("NPU01: complete execution/check family, including shared module")
fig.tight_layout(rect=(0, 0, 1, .93))
fig.savefig(HERE / "scope-chart.png", dpi=150)
fig.savefig(HERE / "scope-chart.svg")
print(json.dumps(dict(measurements=measurements, comparisons={k: v["mismatches"] for k, v in comparisons.items()},
                     tests=tests, changed_inputs=changed, research_lines=research)))
assert not changed and comparisons["candidate"]["mismatches"] == 0 and comparisons["mutant"]["mismatches"] > 0

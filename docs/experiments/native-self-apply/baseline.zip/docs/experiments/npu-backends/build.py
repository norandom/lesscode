"""One candidate from frozen provider sources; preserve messages as literal data."""
import ast
import difflib
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2] / ".runs/npu-backends-01"
assert not (HERE / "candidate/cpu.py.txt").exists()
for name, cls_name in (("cpu", "CpuBackend"), ("vitisai", "VitisAIBackend")):
    source = (HERE / "original" / (name + ".py.txt")).read_text(encoding="utf-8")
    cls = next(n for n in ast.parse(source).body if isinstance(n, ast.ClassDef) and n.name == cls_name)
    methods = {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}
    # Extract literal diagnostics from the original joined strings, not a translation.
    checks = [n for n in ast.walk(methods["_check"]) if isinstance(n, ast.JoinedStr)]
    output = [n for n in ast.walk(methods["_only_tensor"]) if isinstance(n, ast.JoinedStr)]
    shape_note = checks[0].values[-1].value.lstrip()
    dtype_note = checks[1].values[-1].value.removeprefix(", but ")
    output_note = output[2].values[-1].value.removeprefix(", not ")
    # Wrapping long diagnostic strings preserves both content and readable source.
    def quoted(value):
        import textwrap
        parts = textwrap.wrap(value, 82, break_long_words=False, break_on_hyphens=False,
                              replace_whitespace=False, drop_whitespace=False)
        return "\n".join("                " + repr(part) for part in parts)
    run = f'''    def run(
        self, token_ids: npt.NDArray[np.int64], attention_mask: npt.NDArray[np.int64],
    ) -> npt.NDArray[np.float32]:
        """Validate and execute one batch through the provider-neutral operation."""
        return checked_run(
            token_ids, attention_mask, shape=self._shape, profile_name=self._profile.name,
            session_run=self._session.run, failure=self._failed,
            execution_note=(f"running {{self._profile.name}}{" on the NPU" if name == "vitisai" else ""} over a batch of "
                            f"{{self._shape[0]}} x {{self._shape[1]}} failed: "),
            shape_note=(
{quoted(shape_note)}),
            input_dtype_note=(
{quoted(dtype_note)}),
            output_dtype_note=(
{quoted(output_note)}),
        )
'''
    lines = source.splitlines(True)
    for method in sorted((methods[n] for n in ("run", "_check", "_only_tensor")), key=lambda n: -n.lineno):
        lines[method.lineno-1:method.end_lineno] = [run if method.name == "run" else ""]
    candidate = "".join(lines).replace("from npu_rag.embedding.errors import", 
        "from npu_rag.embedding.providers.checked_run import checked_run\nfrom npu_rag.embedding.errors import", 1)
    (HERE / "candidate" / (name + ".py.txt")).write_text(candidate, encoding="utf-8")
    (HERE / "candidate" / (name + ".diff")).write_text("".join(difflib.unified_diff(
        source.splitlines(True), candidate.splitlines(True), fromfile=name + ".py", tofile="candidate/" + name + ".py")), encoding="utf-8")
    for arm in ("candidate", "mutant"):
        (WORK / arm / "src/npu_rag/embedding/providers" / (name + ".py")).write_text(candidate, encoding="utf-8")
for arm in ("candidate", "mutant"):
    shared = (HERE / "checked_run.py").read_text()
    if arm == "mutant":
        shared = shared.replace("if array.dtype != np.int64:", "if False:")
    (WORK / arm / "src/npu_rag/embedding/providers/checked_run.py").write_text(shared)
    (HERE / arm / "checked_run.py.txt").write_text(shared)

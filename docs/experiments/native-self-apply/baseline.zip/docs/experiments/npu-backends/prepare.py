"""Freeze public code and create isolated workspaces, never copy private data."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
UPSTREAM = ROOT.parent / "npu_rag_from_folder"
WORK = ROOT / ".runs/npu-backends-01"
assert not WORK.exists() and not (HERE / "frozen.json").exists()
tests = ["embedding/providers/test_cpu.py", "embedding/providers/test_vitisai.py",
         "embedding/providers/test_base.py", "embedding/test_service.py", "embedding/test_postprocess.py"]
paths = list((UPSTREAM / "src").rglob("*.py")) + [UPSTREAM / "tests" / p for p in tests]
paths += [UPSTREAM / "pyproject.toml", UPSTREAM / "uv.lock"]
protected = paths + [p for folder in ("src", "tests", "docs/experiments")
    for p in (ROOT / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts and HERE not in p.parents]
(HERE / "frozen.json").write_text(json.dumps({str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                                             for p in protected}, indent=2) + "\n")
for arm in ("original", "candidate", "mutant"):
    for path in paths:
        target = WORK / arm / path.relative_to(UPSTREAM)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    (HERE / arm).mkdir()
for name in ("cpu", "vitisai"):
    shutil.copyfile(UPSTREAM / f"src/npu_rag/embedding/providers/{name}.py", HERE / "original" / f"{name}.py.txt")
print(json.dumps(dict(frozen=len(protected), copied_files_per_arm=len(paths))))

# Less code after modularization: an empirical Facdrone roadmap

> Scope correction, owner clarification 2026-11-01: Facdrone is an empirical
> example case, not the key deliverable. Local code experiments and
> behavior-preserving refactoring trials may test general Lesscode hypotheses;
> do not commit or push changes upstream to Facdrone from this work for now.
> The application-specific agenda in this guide and
> [solution review 1](solution-review.md) is superseded. The objective is a
> reusable solution for less code with the same behavior, supported by measured
> examples; see [authoritative product memory](../../../.kiro/steering/product.md).

Prepared 2026-11-01. This is a research guide and proposed experiment sequence, not an approved Facdrone implementation spec or a claim that its code can safely be deleted. Facdrone was inspected read-only at `d49f48bd13c4e3da8a219d5bf73a974a9f982999`. No trading, database workload, application tests or deployments were run. Findings below distinguish inspected code, historical reports and hypotheses.

The objective is **less bespoke implementation for the same reliable capabilities, with a smaller amount of context needed to change them correctly**. Modularity protects the ability to work locally. Compression removes responsibilities, representations and mechanisms that need not be custom code. Both matter; neither substitutes for behavioral verification.

## What Facdrone already teaches us

The modularization was a useful prerequisite. The split requirements describe a core that transitively pulled 40 of 41 CLI modules, 69 of 106 reporting modules and 48 of 73 factor modules. The core-units closing report records sixteen units in an acyclic order, eight mutual pairs removed, declared read surfaces and a fan-out ceiling. These are historical measurements from the linked files, not gates rerun for this guide.

The code also exposes why another round of splitting alone will not deliver Lesscode's goal:

| Evidence inspected | What it establishes | Research consequence |
| --- | --- | --- |
| `facdrone-split/requirements.md` aims to move roughly 48k source code lines out of the core | The initial target was separation of independently changing responsibilities | Count all maintained packages, including extracted first-party packages, before claiming net compression |
| `facdrone-core-units/plan-complex-routines-2026-10-24.md` proposes five helpers for `ols_residual_step9`, dropping its strict complexity from 20 to 8 while adding 31 code lines to the unit; those helpers are present in current `combine_steps.py` | Per-routine complexity can improve while implementation grows | Measure the entire responsibility, helper count and comprehension effort; do not optimize a single function's score |
| That plan reports 20,002 bit-identical cases for the extraction, but 6,803 changed solved cases from replacing division by multiplication by a reciprocal | Mathematical equivalence is insufficient for this numerical contract | Preserve operation order and established precision contracts; treat numerical substitutions as separate experiments |
| That plan explicitly says T1/T1b omit evidence and trace order | An unchanged trading digest covers only part of behavior | Add the existing evidence/trace contract tests to a candidate's validation inventory |
| `shells/config/overlay.py` already delegates validation to Pydantic, then uses AST inspection, bytecode positions and frame tracking to attribute root validation errors | An installed library alone has not eliminated the supporting machinery | Investigate whether the representation of validation failures can remove the need for inference |
| `facdrone_reporting/library/render_model.py` shares display decisions across workbook and dashboard, including rounding, sign and missing/refused state | Some structure prevents an observed class of inconsistency | Preserve that responsibility; investigate duplicate adapters around it rather than discarding its types |
| `shells/config/parameters.py` explicitly exports a focused public surface to avoid importing four modules or a broader initializer | A forwarding module may reduce consumer context | Require a demonstrated benefit before removing an apparently ceremonial layer |
| `.kiro/breadth.toml` distinguishes active, parked, superseded and completed fronts; `definition-of-done.md` records a historical 2-of-26 live-fetch capability gap despite green tests | Completeness and current authority cannot be inferred from test volume or checked tasks | Preserve an executable capability inventory and reconcile superseded instructions before rewriting |

There is a concrete context-drift example: current `structure.md` still describes dash reading one core module, while the split closing report and `pyproject.toml` contract state that dash imports nothing from the core. This warrants reconciliation before a dash task. It does not establish that every old spec is wrong, or that the newest prose automatically wins.

## Current size, with populations separated

The [raw census](census.json) records the clean tracked working tree, its revision and a content fingerprint. These are **physical Python lines including blanks, comments and docstrings**, not LLOC, executable code lines, complexity or maintenance effort.

| Path-defined population | Files | Physical lines |
| --- | ---: | ---: |
| Core production (`src/`) | 400 | 71,233 |
| Package production | 321 | 81,659 |
| **Combined production** | **721** | **152,892** |
| Tests, including helpers within test directories | 951 | 154,528 |
| Separately identified test support | 60 | 6,072 |
| Scripts | 73 | 19,025 |
| Other tracked Python | 68 | 7,934 |

Package production includes reporting (42,296), research (10,102), client (9,584), dash (8,769), kernel (6,604), and smaller wire, observability and factor packages. Research is maintained application functionality here, not test overhead. Scripts and other Python remain visible rather than disappearing from accounting. External `facdrone-data` source is not in this checkout census; it must be added at its pinned revision for a system-wide before/after claim. Moving code into that dependency cannot count as removal.

Classification is path-based: embedded test helpers are not perfectly separable, generated files are not independently identified, and non-Python fixtures, configuration, documentation and source in dependencies are excluded. No separate fixture Python population was identified by the script's explicit path rules; that does not mean the repository has no fixtures. The census is a starting inventory, not an assessment of unnecessary code.

Reproduce from Lesscode in PowerShell (the script imports no Facdrone code):

```powershell
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/facdrone/census.py D:/Source/facdrone
```

On another machine, substitute an explicit available Python interpreter through uv. The census uses only the standard library. Its own script is experiment support, outside the production population.

## Map responsibility before choosing a rewrite

Start with Facdrone's existing `scripts/module_map.py`, `scripts/core_units.py`, `scripts/check_split_edges.py`, import-linter contracts and breadth ledger. Do not build a competing architecture database. The module map supports output without rewriting the ledger; inspect and use that read-only mode in the project's compatible Python environment.

The following is a responsibility overview, not a complete or freshly computed import graph:

```mermaid
flowchart TD
    Config[Configuration and composition] --> Decision[Typed decision stages]
    Data[Point-in-time data and factor inputs] --> Decision
    Decision --> Math[Quantitative library]
    Live[Serving and daemon] --> Decision
    Sim[Simulation] --> Decision
    Live --> Evidence[Evidence and published records]
    Sim --> Evidence
    Evidence --> Reports[Reporting calculations and render model]
    Reports --> Views[Dashboard and workbook adapters]
    Research[Research and admitted candidates] -. reviewed admission .-> Data
```

For each trial, trace one observable capability end to end: input, typed representations, policy decisions, side effects, persisted evidence and consumer output. Record a short table alongside the experiment:

| Field | What to record |
| --- | --- |
| Capability and owner | The user-visible result and the module that owns its rules |
| Current authority | Applicable approved requirement/amendment, public contract and executable checks; explicitly excluded superseded material |
| Implementations | Every place that decides the same policy, not every similar-looking expression |
| Representations | Each type/schema and conversion, with the boundary it protects |
| Existing capability | Exact installed library/framework API and version, plus any semantic mismatch |
| Removal hypothesis | Named machinery expected to disappear, including downstream adapters |
| Context needed | Files, symbols and authoritative documents needed to explain and safely change the capability |
| Preservation checks | Valid/invalid inputs, errors, order, numeric behavior, persistence, causality and real entry-point wiring |

Keep a useful semantic type when it prevents confusing units, currencies, timestamps, states or availability. Compression should remove repeated representations and inference machinery, not replace meaningful names with positional tuples, `Any`, unchecked dictionaries or casts.

## Roadmap: evidence gates rather than infrastructure milestones

These are proposed research steps. They do not authorize changes to Facdrone's caps, specifications, financial behavior or deployment.

| Stage | Work | Exit evidence |
| --- | --- | --- |
| 0. Establish the experiment boundary | Pin checkout, dependency lock, applicable requirements, tests and metric definitions. Reconcile instruction conflicts affecting the selected responsibility. Name missing dependencies/checks. | One reproducible baseline and a capability-to-check list; unresolved required behavior blocks candidate acceptance |
| 1. Rank three responsibilities | Use the existing map, inspect callers and test coverage, inspect recent semantic changes after excluding mechanical moves. Estimate removable machinery and integration cost. | Three bounded hypotheses, plus at least one deliberate retain-as-is control; no claimed savings yet |
| 2. Run the first replacement | Start with configuration error attribution below. Compare the full original responsibility with one proposed representation, including all changed validators and adapters. | Before/after diff, differential cases, typing, existing checks, net production delta and explicit adoption/rejection |
| 3. Replicate across different responsibilities | Trial reporting adaptation and one tightly scoped framework-backed operation. Keep numerical code as a high-risk control until these work. | At least three completed trial reports, including failed/marginal trials; repeatable benefit rather than a single favorable example |
| 4. Test maintainability | Perform equivalent bounded maintenance tasks on original and successful candidate snapshots, with fresh agent sessions and a human review exercise. | Correctness, context, effort and change-spread comparisons; shorter code must not win by making changes harder |
| 5. Derive prevention rules | Turn only demonstrated recurring improvements into concise agent instructions and deterministic checks where possible. | A rule predicts a useful action on a held-out module without losing required behavior |
| 6. Decide what Lesscode should automate | Reuse the existing comparison CLI where compatible. Automate only repeated expensive steps supported by these trials. | A concrete need for a skill, analyzer adapter or MCP operation, justified by observed work saved |

Three trials are a pilot, not statistical proof. If the first trial fails, retain the result and move to the next hypothesis. Do not spend weeks building a general replacement engine to make one candidate work.

## First experiment: explicit configuration error attribution

**Observed:** `ParameterOverlay.resolve` uses Pydantic's `TypeAdapter`, maintains provenance and stable operator-facing errors. For root failures, `_root_validation_parameter_names` invokes a dataclass's `__post_init__` on a probe. `_ParameterReadProbe` records frame/code offsets; further helpers inspect source and failed guards to identify supplied parameter names.

**Hypothesis:** explicit field constraints and structured cross-field error attribution can preserve this capability while eliminating some source/bytecode inference. This is a representation trial, not a proposal to install another validation framework.

1. Inventory the supported parameter records and their `__post_init__` guards. Separate single-field constraints, cross-field rules, unsupported introspection cases and externally supplied parameter classes.
2. Capture the accepted/rejected inputs, resolved values, provenance, issue paths, issue codes, ordering and contractual wording. Include omitted defaults, baseline overrides, unknown keys, coercion, multiple bad fields, cross-field failures, unavailable source and nested validation. Determine whether replaying validators can have side effects and preserve the required observable behavior.
3. Prototype one coherent error representation using already installed capabilities. Include the migration of validators in the candidate cost; a shorter overlay that adds more annotation/adaptation code everywhere else is not a win.
4. Run original/candidate differential checks over real parameter types and generated cases. Preserve baseline validity checks and public diagnostics. Retain direct-construction invariants if callers depend on them.
5. Count the whole change: overlay, affected records, bindings, helpers, tests, schema/configuration and any new dependency burden. Identify which introspection functions are now truly unnecessary.
6. Reject adoption if equivalent attribution requires more custom machinery, relevant public behavior is uncertain, or the maintenance exercise is worse. If a different diagnostic contract is needed, classify that as a separate product change requiring review, never a behavior-preserving compression.

This could be substantial, marginal or impossible under the existing contract. The inspection establishes a promising mechanism to investigate, not a demonstrated saving.

## Next experiments and an intentional control

| Trial | Candidate scope and hypothesis | Required preservation evidence |
| --- | --- | --- |
| Reporting adaptation | Trace one metric from declaration/calculation through `render_model.py`, `render_build.py` and `xlsx_renderer.py` to both outputs. Test whether repeated label/format/availability decisions can come solely from the existing shared model. | Golden output, Decimal rounding, rounded sign, missing/refused distinction, schema-key chart references, workbook cell types and actual rendering entry points |
| Framework-backed support | Inspect one repeated persistence or resource-lifetime operation in the shells. Compare it with the pinned SQLAlchemy transaction or standard context-manager capability already available. Select only after verifying concrete duplication. | Transaction/rollback boundary, ordering, idempotency, retries, exception translation, cleanup and real database integration; do not conflate similar-looking operations with identical policy |
| Quantitative control | Retain `ols_residual_step9` as an example where guards and arithmetic order are purposeful. Compare comprehension of the current helper decomposition with its historical form before considering another rewrite. | Existing bitwise grid and boundary cases, caller behavior, evidence/trace checks and affected decision probes; no unapproved tolerance or golden recapture |

The shared render model and the parameter public surface are also retain-as-is controls. A good method must explain why a structure earns its cost, not flag all layers as excess.

## How to measure the middle ground

Use a small dashboard of separate observations. Do not collapse them into a weighted simplicity score or assert that a percentage LOC reduction is the same percentage maintenance saving.

| Dimension | Measurement | Interpretation |
| --- | --- | --- |
| Required behavior | Preserved capability/check inventory; differential failures; native entry-point results; explicit unavailable checks | First acceptance condition; tests passing is bounded evidence, not a proof |
| Maintained implementation | Production physical lines and a separately defined LLOC measure, bytes, configuration, first-party packages and adapters | Net reduction across the responsibility and consumers; no credit for moving code out of the measured root |
| Test investment | Test/fixture/support changes and runtime, separately | No target to reduce finance tests; add missing semantic checks when warranted |
| Structural burden | Policy copies, conversion steps, forwarding layers, public symbols and independently meaningful types | Manual, documented counts first; fewer is useful only if responsibilities and invariants survive |
| Local reasoning | Files/symbols/documents consulted, amount of material read, mistaken authority selections, time to identify the owner and invariant | Observed per task, not inferred from file size or token count alone |
| Change amplification | Files, modules and policy locations changed for a bounded requirement | Compare equivalent work; incidental reformatting and moves reported separately |
| Agent reliability | Correct completion, regressions, repair iterations, tool calls, elapsed time and token use when available | Count failures and timeouts, not only successful attempts |
| Human maintenance | Time to explain the path, locate a seeded defect and review a bounded change; confidence checked against correctness | Small structured exercises; no unsupported claim of universal human superiority |
| Dependency cost | New runtime/transitive dependencies, configuration, API assumptions and integration code | Using a library transfers some maintenance; it does not make it vanish |

Use open-source tools as instruments: the existing pinned Lizard/jscpd pair for comparable complexity/clone observations; [Ruff](https://docs.astral.sh/ruff/rules/) for specific idiom candidates; [import-linter](https://import-linter.readthedocs.io/en/stable/) for import contracts; [Hypothesis](https://hypothesis.readthedocs.io/en/latest/) for generated boundary and differential cases. None detects an entire redundant responsibility automatically. Preserve each analyzer's definition and version; do not compare McCabe variants as if identical. Facdrone's historical Understand figures are context, not a required commercial dependency for replication.

### A small controlled maintenance study

For each successful candidate, freeze original and candidate snapshots and predefine equivalent exercises: explain a configuration rejection, add a supported constraint with the same diagnostics, or trace an existing report metric into both surfaces. Keep feature scope and checks constant.

Compare ordinary agent instructions with responsibility-first instructions on those snapshots. This yields four conditions: original/plain, original/guided, simplified/plain, simplified/guided. It separates the value of shorter implementation from better context instructions. Use the same model/version, tool permissions, task budget and available dependency environment. Start with three independent fresh sessions per condition on one bounded task; report every outcome and the spread rather than a significance claim. Expand only if the cost is justified.

Do not hand simplified arms richer documentation unnoticed: either keep supplied context equal or report documentation as an additional intervention. Do not let the rewriting session grade its own maintenance result. Fix checks before evaluation and include failure/timeout cases. Human comparisons need matched tasks or counterbalanced order because the person learns from the first version. Keep domain expertise and task familiarity visible in the report.

Accept a simplification only when required checks pass, bespoke implementation actually falls across the full scope, and the evidence does not show a material loss of changeability or clarity. Define materiality for that task before results. Reject unknown required behavior rather than quietly marking its check optional. Improvements in navigation without reduction remain useful modularity results, reported separately from compression.

## Keep agent context coherent as the system grows

An agent should not need to reconcile the entire development history to edit one module. Use the existing Kiro documents to supply a bounded current view:

1. Identify the capability owner and authoritative approved decision, including any later amendment. Record replaced decisions as superseded with pointers; retain history for incident explanation.
2. Check applicable instructions against current import contracts, public APIs and relevant tests. If they disagree, state the conflict and resolve its authority before dependent edits. Neither passing tests nor a newer date alone settles product intent.
3. Give the working agent a concise task packet: responsibility, inputs/outputs, invariants, permitted dependency surfaces, required checks and explicit non-goals. Link history for retrieval instead of copying it all into every context.
4. After a change, update the canonical owner document and relevant map. Avoid a new status file that competes with the ledger/spec. Measure retrieval mistakes before investing in automated context generation.

Candidate agent rules to validate experimentally:

> Before adding custom support code, identify the required behavior and check the standard library, installed framework and existing repository implementation. State the semantic gap that still requires custom code.
>
> A new abstraction must own an actual policy or protect a meaningful boundary. A new representation must justify its conversion. Prefer role-revealing typed fields and explicit functions over positional data or speculative class hierarchies.
>
> When replacing a mechanism, name the old implementation and support code that will disappear. Keep all callers and first-party packages in the accounting. Preserve the tests and contracts that constrain it.

These are proposed instructions, not new Facdrone policy. Python can express variation with functions, dataclasses and existing validators; TypeScript can use typed functions, discriminated unions and framework-native schemas. Verify each library/runtime mismatch in its own language. Later [Knip](https://knip.dev/overview/getting-started) can support TypeScript unused-code discovery, with real entry points and framework conventions configured. Do not extrapolate a Python result into a TypeScript effectiveness claim. Java is outside this pilot.

## Trial receipt and the next concrete action

Each experiment needs one short receipt, not a new subsystem:

```text
Revision / lock / measured file population:
Capability and current authoritative requirement:
Mechanism being replaced and existing capability taking over:
Behavior observations fixed before editing:
Before / after production, configuration, tests and dependencies:
Policy copies, conversions and context required before / after:
Commands, actual exit codes, differential cases and missing checks:
Maintenance exercise outcome, including failures:
Decision: adopt / reject / insufficient evidence
What this result does and does not generalize to:
```

**Next action:** conduct the read-only inventory of configuration validators and their diagnostic contracts, then propose one complete replacement experiment with the actual file set and checks. No new MCP server, general graph database, plugin skeleton or additional metrics framework is needed to answer that question. Lesscode's next implementation should follow demonstrated repetition in these experiments.

## Local evidence index

Paths below are relative to the inspected Facdrone checkout (`D:/Source/facdrone`); the files are not copied into Lesscode. Historical quantitative claims above are attributed to those reports, not independently rerun. The local inspection and census contain project-specific details and are prepared for local review; this work does not publish them.

- `.kiro/specs/facdrone-split/requirements.md`: initial breadth, dependency directions and split targets.
- `.kiro/specs/facdrone-split/reports/step-7-extraction.md`: release outcomes, deferred extraction and final dash boundary.
- `.kiro/specs/facdrone-core-units/closing-report-2026-10-29.md`: cycles, sixteen units and verification limits.
- `.kiro/specs/facdrone-core-units/plan-complex-routines-2026-10-24.md`: decomposition cost, numerical differences and probe omissions.
- `.kiro/specs/facdrone-config-and-reporting-consolidation/requirements.md`: policy/configuration identity, historical reachability and reporting drift motivation.
- `.kiro/breadth.toml`, `.kiro/steering/structure.md`, `causality.md`, `definition-of-done.md` and `agents.md` in the same steering directory: front status, boundaries, no-lookahead rules and verification/operating constraints.
- `scripts/module_map.py`, `core_units.py`, `check_split_edges.py`, `size_gate.py` in the same scripts directory, plus `pyproject.toml`: existing architecture measurement and dependency declarations.
- `src/facdrone/shells/config/overlay.py`, `parameters.py` in the same directory: error attribution and focused public surface.
- `src/facdrone/pipelines/factors/combine_steps.py`: current numerical helper decomposition.
- `packages/facdrone-reporting/facdrone_reporting/library/render_model.py`: shared typed presentation semantics.
- [Census implementation](census.py) and [raw result](census.json): current tracked Python footprint and scope definition.

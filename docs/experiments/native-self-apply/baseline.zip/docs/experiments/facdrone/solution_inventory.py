"""Static responsibility inventory; does not import the inspected application."""
import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
names = subprocess.check_output(["git", "-C", str(root), "ls-files", "-z", "--", "*.py"]).decode().split("\0")
files = {}
classes = {}
bindings = []
for name in filter(None, names):
    path = Path(name)
    if not (name.startswith("src/") or (name.startswith("packages/") and "tests" not in path.parts)):
        continue
    source = (root / name).read_text(encoding="utf-8-sig")
    tree = ast.parse(source)
    files[name] = {"physical_lines": len(source.splitlines()),
                   "ast_statements": sum(isinstance(n, ast.stmt) for n in ast.walk(tree)),
                   "sha256": hashlib.sha256((root / name).read_bytes()).hexdigest()}
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            validators = [n for n in node.body if isinstance(n, ast.FunctionDef) and n.name == "__post_init__"]
            classes.setdefault(node.name, []).append({"path": name, "line": node.lineno,
                "physical_lines": node.end_lineno - min([node.lineno] + [d.lineno for d in node.decorator_list]) + 1,
                "annotated_fields": [n.target.id for n in node.body if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)],
                "validators": [{"line": f.lineno, "physical_lines": f.end_lineno - f.lineno + 1,
                    "raises": sum(isinstance(n, ast.Raise) for n in ast.walk(f)),
                    "asserts": sum(isinstance(n, ast.Assert) for n in ast.walk(f))} for f in validators]})
        if isinstance(node, ast.Call) and ast.unparse(node.func) in {"ParameterGroupBinding", "ParameterGroupBinding.from_block"}:
            parameter = next((kw.value for kw in node.keywords if kw.arg == "parameter_type"), None)
            if parameter is None and len(node.args) > 1:
                parameter = node.args[1]
            bindings.append({"path": name, "line": node.lineno,
                "type_expression": ast.unparse(parameter) if parameter else "UNRESOLVED"})

scopes = {
    "configuration": [n for n in files if n.startswith("src/facdrone/shells/config/")],
    "pod_resolution": [n for n in files if n.startswith("src/facdrone/shells/pods/")],
    "stored_configuration_reader": ["src/facdrone/shells/wiring/run_config.py"],
    "report_rendering_sample": ["packages/facdrone-reporting/facdrone_reporting/" + n for n in
        ["library/render_model.py", "shells/render_build.py", "shells/xlsx_renderer.py"]],
}
result = {"revision": subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"]).decode().strip(),
    "definition": "Static tracked source inventory. AST statements include definitions/imports/docstring statements; not LLOC. Binding expressions are not a runtime completeness proof.",
    "scopes": {key: {"files": {n: files[n] for n in paths},
        "physical_lines": sum(files[n]["physical_lines"] for n in paths),
        "ast_statements": sum(files[n]["ast_statements"] for n in paths)} for key, paths in scopes.items()},
    "binding_sites": bindings,
    "bound_type_definitions": {name: classes.get(name, []) for name in sorted({b["type_expression"] for b in bindings})}}
result["regime_reference_surface"] = []
for name in files:
    source = (root / name).read_text(encoding="utf-8-sig")
    hits = [{"line": number, "text": line.strip()} for number, line in enumerate(source.splitlines(), 1)
            if "RegimeParameters" in line or "REGIME_PARAMETER_BINDING" in line]
    if hits:
        result["regime_reference_surface"].append({"path": name, "hits": hits})
print(json.dumps(result, indent=2))

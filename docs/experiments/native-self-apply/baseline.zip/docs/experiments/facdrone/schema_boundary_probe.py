"""Exercise the actual exact-key check with synthetic shapes, not financial data."""
import ast
import hashlib
import json
import subprocess
import sys
from collections.abc import Mapping
from dataclasses import fields, make_dataclass
from pathlib import Path
from typing import ClassVar

root = Path(sys.argv[1]).resolve()
reader_path = root / "src/facdrone/shells/wiring/run_config.py"
pod_path = root / "src/facdrone/shells/pods/resolve.py"
reader = ast.parse(reader_path.read_text(encoding="utf-8"))
pod = next(n for n in ast.parse(pod_path.read_text(encoding="utf-8")).body
           if isinstance(n, ast.ClassDef) and n.name == "ResolvedPod")
field_names = [n.target.id for n in pod.body
               if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name)]
key_expression = next(n.value for n in reader.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == "_POD_PARAMETER_KEYS" for t in n.targets))
selected = [n for n in reader.body if isinstance(n, (ast.ClassDef, ast.FunctionDef))
            and n.name in {"InvalidRunConfigPayload", "_require_exact_keys"}]
namespace = {"Mapping": Mapping, "ClassVar": ClassVar}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(reader_path), "exec"), namespace)


def keys(names):
    shape = make_dataclass("ResolvedPodShape", [(name, object) for name in names])
    return eval(compile(ast.Expression(key_expression), str(reader_path), "eval"),
                {"ResolvedPod": shape, "fields": fields})


def outcome(payload, expected):
    try:
        namespace["_require_exact_keys"](payload, expected, "parameters")
        return "accepted"
    except namespace["InvalidRunConfigPayload"] as error:
        return {"field": error.field_name, "detail": error.detail}


original_keys = keys(field_names)
runtime_without_regime = keys([name for name in field_names if name != "regime"])
# A frozen historical schema is independent of the new runtime shape.
# This is a shape-only model, not an implemented persisted-schema codec.
historical_schema_keys = tuple(original_keys)
historical_payload = dict.fromkeys(original_keys)
cases = {
    "baseline_historical_shape": outcome(historical_payload, original_keys),
    "runtime_field_deleted_coupled_reader": outcome(historical_payload, runtime_without_regime),
    "runtime_field_deleted_frozen_historical_schema": outcome(historical_payload, historical_schema_keys),
    "frozen_schema_unknown_key": outcome({**historical_payload, "unexpected": None}, historical_schema_keys),
    "frozen_schema_missing_key": outcome({k: v for k, v in historical_payload.items() if k != "regime"}, historical_schema_keys),
}
assert cases["baseline_historical_shape"] == "accepted"
assert cases["runtime_field_deleted_coupled_reader"] == {"field": "parameters.regime", "detail": "field is not recognised"}
assert cases["runtime_field_deleted_frozen_historical_schema"] == "accepted"
assert cases["frozen_schema_unknown_key"] == {"field": "parameters.unexpected", "detail": "field is not recognised"}
assert cases["frozen_schema_missing_key"] == {"field": "parameters.regime", "detail": "field is missing"}
print(json.dumps({
    "revision": subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"]).decode().strip(),
    "source_sha256": {str(p.relative_to(root)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (reader_path, pod_path)},
    "scope": "Actual key derivation and exact-key check extracted from source. Synthetic dataclass field shapes and null-valued payload. No type/value/digest/provenance validation, real stored record, application import or trading check.",
    "original_keys": original_keys,
    "cases": cases,
    "assertions_passed": 5,
    "production_code_removed": 0,
}, indent=2))

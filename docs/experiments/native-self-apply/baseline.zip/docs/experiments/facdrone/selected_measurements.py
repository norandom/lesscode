"""Measure a disclosed manual sample without importing or modifying Facdrone."""
import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tokenize

FACDRONE = {
    "canonical serialization": [
        "packages/facdrone-kernel/facdrone_kernel/canonical.py",
        "packages/facdrone-reporting/facdrone_reporting/library/serialization.py",
        "packages/facdrone-kernel/tests/test_canonical.py",
        "packages/facdrone-kernel/tests/test_canonical_serialization.py"],
    "explicit registry control": ["src/facdrone/pipeline_registry.py",
                                  "tests/unit/test_pipeline_registry.py"],
    "stateful dispatch control": ["src/facdrone/shells/cli/pod_dispatch.py",
                                  "tests/unit/test_cli_pod_dispatch.py"],
    "typed units control": ["packages/facdrone-kernel/facdrone_kernel/domain/units.py",
                            "packages/facdrone-kernel/tests/test_units.py"],
}
LESSCODE = {
    "public record boundary": ["src/lesscode_baseline/contracts.py", "tests/test_contracts.py",
                               "tests/test_plan_contracts.py", "tests/test_optional_contracts.py",
                               "tests/test_experiment_contracts.py"],
    "artifact boundary": ["src/lesscode_baseline/report.py", "tests/test_report.py"],
    "portable source scope": ["src/lesscode_baseline/snapshot.py", "tests/test_snapshot.py"],
}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8-sig").replace("\r\n", "\n")
    tree = ast.parse(source)
    functions = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    return {"sha256_raw": hashlib.sha256(raw).hexdigest(), "physical_lines": len(source.splitlines()),
            "logical_lines": sum(t.type == tokenize.NEWLINE for t in tokenize.generate_tokens(io.StringIO(source).readline)),
            "ast_nodes": sum(1 for _ in ast.walk(tree)), "functions_including_methods": len(functions),
            "from_dict_lines": sum(n.end_lineno - n.lineno + 1 for n in functions if n.name == "from_dict")}


def inventory(root, groups):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()
    return {"revision": git("rev-parse", "HEAD"), "working_tree_status": git("status", "--porcelain"),
            "groups": {label: {name: {"population": "tests" if "tests" in Path(name).parts else "production",
                                      **measure(root / name)} for name in paths} for label, paths in groups.items()}}


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[3]
    specimen = Path(sys.argv[1]).resolve()
    report = {"selection": "Manual contrasting sample; not representative, not a reduction estimate",
              "definitions": "Physical lines include blanks/comments; logical lines are tokenizer NEWLINE tokens; from_dict spans exclude decorators. Test files are selected witnesses, not coverage claims.",
              "facdrone": inventory(specimen, FACDRONE), "lesscode": inventory(root, LESSCODE)}
    destination = Path(__file__).with_name("selected-measurements.json")
    destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(destination)

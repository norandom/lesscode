# Solution review 1: why retired behavior still requires current code

> Superseded agenda, owner clarification 2026-11-01: the application-specific
> schema/regime replacement proposed here is not Lesscode's deliverable.
> Facdrone is an empirical example case. Local behavior-preserving code trials
> are allowed when they test a general Lesscode hypothesis; do not commit or
> push changes upstream to Facdrone from this work for now. This document retains
> historical observations, not the current research or implementation agenda.
> See [authoritative product memory](../../../.kiro/steering/product.md).

2026-11-01, Facdrone revision `d49f48bd13c4e3da8a219d5bf73a974a9f982999`.

**Finding:** part of Facdrone's implementation survives because historical configuration evidence is validated against the current execution model. Removing a retired runtime field changes the accepted historical schema. That couples past and present and makes apparently simple retirements affect configuration, composition, persistence and reporting together.

This is a demonstrated local coupling, not a diagnosis of the entire codebase. The proposed solution is to separate ownership of historical evidence from current execution, then remove redundant live propagation where the complete behavior inventory permits it. It is not yet a demonstrated net code reduction. **Production code removed in this investigation: zero.**

## Measured scope

The [static inventory](solution-inventory.json) records file hashes and definitions; [its script](solution_inventory.py) imports no application modules. Physical lines include comments, docstrings and blanks. AST statements include definitions, imports and docstring statements and are not LLOC.

| Inspected population | Files | Physical lines | AST statements |
| --- | ---: | ---: | ---: |
| Configuration package | 10 | 2,762 | 1,191 |
| Pod definitions and resolution | 12 | 2,462 | 932 |
| Stored configuration reader | 1 | 559 | 288 |
| **Combined configuration/pod/reader footprint** | **23** | **5,783** | **2,411** |
| Reporting rendering sample, separately | 3 | 1,443 | 556 |

The reporting sample is `render_model.py`, `render_build.py`, and `xlsx_renderer.py`; it is not the complete reporting responsibility. Neither table identifies removable lines. The configuration footprint excludes additional wiring, callers, tests and external types; a rewrite's accounting must include every affected file, even outside these roots.

Static binding expressions resolve to 14 named parameter types with 83 directly annotated fields. Seven have a `__post_init__` method. This is a source census, not proof that all runtime binding paths were discovered, or that all fields are active decision inputs. Nested types and dynamic construction need separate tracing.

## The problem stated independently of the implementation

The system needs to:

1. Resolve a current strategy and global risk authority into typed, valid decision inputs, preserving defaults, declared overrides and provenance.
2. Reject malformed or inconsistent inputs with useful, stable diagnostics; no invalid supplied value silently becomes a default.
3. Record enough evidence to explain and reproduce what a run used, preserving identity and linkage to its global risk record.
4. Read and present historical runs even when the current decision algorithm changes.
5. Maintain the same current decision outputs, safeguards, reporting semantics and supported public contracts during a code-only simplification.

These capabilities do not inherently require the current decision object to remain structurally identical to every supported historical snapshot. That identity is an implementation choice. However, public fields, accepted configuration inputs and replay semantics are real contracts until their owners explicitly decide otherwise.

## Evidence of unnecessary coupling

In `src/facdrone/shells/wiring/run_config.py`:

```python
_POD_PARAMETER_KEYS = tuple(
    field.name
    for field in fields(ResolvedPod)
    if field.name not in {"identity", "provenance", "futures"}
)
_POD_FIELD_SCHEMAS = get_type_hints(ResolvedPod)
```

The reader uses these to validate persisted configuration. Thus both required field names and field types follow today's runtime dataclass.

The source documents the resulting retention explicitly:

- `engine/stages/regime.py`: the regime arithmetic and its producer were deleted; `RegimeParameters` stays as the stored-run schema block.
- `facdrone_kernel/control_stack.py`: the twelve-step calculator is deleted, but `ActiveControlPolicy` remains because removing a `ResolvedPod` field invalidates stored configurations. Additional record shapes remain for reporting projections.
- `library/ledger/parameters.py`: `max_share_per_name` is superseded by the state mechanism table but remains for stored configurations.
- `pods/resolve.py`: safety parameters are marked superseded yet retained as schema fields.

For the regime example, direct references to its type or binding occur in six production source files. The current resolver still binds, records provenance for, freezes and projects that configuration. This is evidence of propagation cost, not proof that its public behavior is dispensable. Other uses of the word “regime,” such as live market-state reporting, are different concepts and are not deletion candidates on name similarity.

### Executable boundary probe

The [probe](schema_boundary_probe.py) executes the original key-derivation expression and exact-key validation function extracted from source. It supplies synthetic dataclass shapes and null-valued payloads. It does not load the application or validate financial values.

| Condition | Observed result |
| --- | --- |
| Existing shape and existing reader keys | Accepted by the exact-key check |
| Same historical shape after removing `regime` from the runtime-derived keys | Rejected: `parameters.regime`, field is not recognised |
| Same historical shape with historical keys held independently of runtime fields | Accepted by the exact-key check |
| Independent historical keys, unknown extra field | Rejected |
| Independent historical keys, missing historical field | Rejected |

All five assertions passed; [raw results](schema-boundary-result.json) include source hashes. This establishes the coupling and demonstrates that separating keys need not weaken exact-key checks. It establishes **nothing yet** about type validation, real persisted records, content digests, provenance, migrations, current decisions or production integration. It is deliberately not reported as a passing refactor.

## Compare solutions before writing another layer

| Alternative | Expected effect | Decision at this stage |
| --- | --- | --- |
| Split the existing resolver/reader into more modules | Smaller files; same historical/runtime dependency and mostly the same code | Does not address this cause |
| Adopt another schema library wholesale | Could replace some parsing, but deriving historical contracts from live types still couples them | No justification; Pydantic is already present |
| Freeze historical schema ownership and narrow current execution inputs | May permit deletion of obsolete current propagation while retaining historical reading | First architectural experiment |
| Remove old records, fields or reporting requirements | Smaller source by reducing supported behavior | Outside a feature-preserving experiment |

The first experiment should use the existing stored-run reader as the historical boundary. Avoid a new service, generic migration framework or duplicate registry. Establish the supported historical schema explicitly there, with exact validation and identity rules intact. Keep meaningful unit types and constraints.

Then trace one retired block, initially `regime`, from accepted input through current runtime, persisted output and reporting. If it has no decision effect, determine whether its information can remain solely in the existing evidence/configuration boundary while the internal decision input stops carrying it. Preserve the current external shape through existing boundary code where required; count that code. Do not infer that a preserved snapshot may be replayed through today's engine as if it had the same historical semantics.

**Critical tradeoff:** retaining historical schemas can initially add code. If the change merely creates `HistoricalPod`, `CurrentPod` and a forest of mappers, it has failed the Lesscode objective. Adopt it only when obsolete live definitions, construction, freezing, correspondence, overrides and projections disappear in aggregate, with the compatibility implementation included. A smaller runtime with a larger maintained system is a locality improvement, not compression.

The ledger-core specification offers a useful design precedent: replace a sequential collection of mechanisms with an explicit conserved quantity and owner. But that project also changed financial behavior. It is evidence for reconsidering the model, **not** evidence that those deletions were behavior-preserving or that their historical savings can be claimed for this experiment.

## Candidate patch boundary and acceptance experiment

Work on one closed responsibility rather than choosing a line-reduction percentage in advance.

| Step | Concrete deliverable | Acceptance question |
| --- | --- | --- |
| A. Trace contract reach | Map current configuration inputs, public `ResolvedPod` consumers, stored records, digest calculation, replay and report consumers for the regime block | Is the block decision-inert, and which externally observable behaviors still require it? |
| B. Freeze observations | Use existing `test_run_config_payload.py`, `test_run_config_inspection.py`, pod-resolution and parameter-overlay tests; add real anonymized historical/current examples and malformed variants as needed | Can old records, new records, exact errors, provenance and identities be compared before editing? |
| C. Separate schema ownership | Prototype the historical reader independent of current dataclass shape, using its existing validation mechanisms | Does a harmless internal runtime-shape change leave supported historical observations unchanged? |
| D. Remove propagation | Eliminate the regime block from internal decision flow wherever the trace proves it unnecessary; keep public boundaries functional | Which entire mechanisms disappear, and what compatibility code is added? |
| E. Challenge behavior | Run typing, native unit/contract/integration tiers, applicable decision and causality probes, evidence/trace checks and actual persistence/report entry points | Are all required observations preserved, with unavailable checks explicitly blocking adoption? |
| F. Challenge maintainability | Fresh agent explains one historical field and makes one bounded current change; human reviews the same responsibility | Did the change reduce the context and distinct policy locations needed, without shifting confusion into adapters? |

This is an experiment proposal, not approval to revise Facdrone's public schema, recapture goldens or relax its caps. Existing project operating rules remain applicable. No production work or database access occurred during this investigation.

### The deletion ledger

Every candidate report must enumerate removed and added responsibilities with file-level diffs. Compute:

```text
net maintained production reduction
  = all removed production implementation
  - all added production implementation, including compatibility and adapters
```

Report configuration/schema changes separately, plus all test/support changes. Keep the same population and metric definition before and after. Count extracted first-party packages; do not hide additions in a dependency, generated source or a new service. For third-party delegation, report package/version and integration obligations separately.

Track these concrete mechanisms for this experiment: binding registration, current parameter construction, override/provenance handling, freezing, projection, snapshot validation and consumer conversion. A mechanism merely moved to another file remains present. A shared mechanism retained for other blocks is not a deletion attributable to this trial.

Do not estimate savings from the 5,783-line scope. Establish them from the complete candidate patch. If net reduction is zero or negative, reject the compression claim even if the architecture becomes cleaner. If necessary history/public contracts prevent removal, retain them and move to a different responsibility.

## Secondary candidate: validation diagnostics

`overlay.py` is 516 physical lines and 248 AST statements. It uses Pydantic validation plus source/bytecode inference to attribute failed root guards. The measured type inventory gives this investigation a finite initial set, rather than an imagined generic problem.

An explicit error representation may replace inference, but migrating a guard to field constraints can change direct dataclass construction, coercion, error ordering and attribution. Chained comparisons also short-circuit: reporting every syntactic field is not equivalent to reporting the fields actually read before failure. Existing tests explicitly distinguish unrelated valid fields and earlier successful guards. Removing these diagnostics to obtain a shorter overlay would lose behavior.

Review this as a smaller independent experiment. Count all migrated validators and preserve the generic extension contract if it is required. Do not let this attractive local rewrite replace the larger schema-ownership investigation. The open-source [executing project](https://github.com/alexmojaki/executing) also offers frame-to-AST lookup as a possible delegation alternative, but no candidate using it was built or tested here; it does not by itself resolve the underlying historical/runtime coupling.

## What this derives for Lesscode

The useful review unit is a **capability plus its representations and compatibility obligations**. Complexity scanners alone cannot distinguish essential history from an obsolete concept propagated through the live model.

A candidate agent instruction, to validate on a successful replacement before general adoption:

> Before extending a representation, identify who consumes it now, who consumes it historically, and which contract makes each field necessary. Search for one authoritative owner. Propose what implementation can disappear when that ownership is corrected; include all compatibility costs and preserve observable behavior.

The experiment has now moved beyond “write shorter functions”: there is a measured scope, an executable demonstration of the obstruction, a proposed solution and a falsifiable deletion criterion. Actual net savings, full behavior preservation and maintenance improvement remain to be demonstrated by the candidate patch. No MCP or additional platform implementation is needed to establish those results.

## Reproduction and provenance

From Lesscode, with uv and an explicit installed interpreter:

```powershell
uv.exe run --no-project --no-python-downloads --python 3.13.16 python docs/experiments/facdrone/solution_inventory.py D:/Source/facdrone
uv.exe run --no-project --no-python-downloads --python 3.13.16 python docs/experiments/facdrone/schema_boundary_probe.py D:/Source/facdrone
```

Both scripts use only the standard library. The inventory reads source; the probe executes only the extracted exception, key expression and key check. Test apparatus is separate from production code. The [original roadmap](README.md) contains the wider research protocol and the initial census. Raw results are local research artifacts, not a published external benchmark.

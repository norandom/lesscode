"""Read tracked Python text only; never import or execute the inspected project."""

import hashlib
import json
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

root = Path(sys.argv[1]).resolve()


def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args]).decode("utf-8")


def population(path):
    parts = path.parts
    if "fixtures" in parts or "goldens" in parts:
        return "fixtures_python"
    if "tests" in parts or path.name.startswith("test_") or path.name == "conftest.py":
        return "tests_python"
    if "facdrone-testing" in parts or "testing" in parts:
        return "test_support_python"
    if parts[0] == "src":
        return "production_core_python"
    if parts[0] == "packages" and len(parts) > 2 and parts[2].startswith("facdrone_"):
        return "production_packages_python"
    if parts[0] == "scripts":
        return "scripts_python"
    return "other_python"


groups = defaultdict(lambda: {"files": 0, "physical_lines": 0, "utf8_bytes_lf": 0})
packages = defaultdict(lambda: {"files": 0, "physical_lines": 0})
digest = hashlib.sha256()
for name in sorted(git("ls-files", "-z", "--", "*.py").split("\0")):
    if not name:
        continue
    path = Path(name)
    raw = (root / path).read_bytes()
    content = raw.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
    lines = len(content.splitlines())
    group = population(path)
    groups[group]["files"] += 1
    groups[group]["physical_lines"] += lines
    groups[group]["utf8_bytes_lf"] += len(content.encode("utf-8"))
    digest.update(name.encode("utf-8") + b"\0" + hashlib.sha256(raw).digest())
    if group == "production_packages_python":
        packages[path.parts[1]]["files"] += 1
        packages[path.parts[1]]["physical_lines"] += lines

print(json.dumps({
    "revision": git("rev-parse", "HEAD").strip(),
    "tracked_changes": git("status", "--porcelain", "--untracked-files=no").splitlines(),
    "tracked_python_sha256": digest.hexdigest(),
    "definition": "Tracked working-tree Python only; physical lines include blanks/comments/docstrings. Path-based categories, not semantic feature classification. No external package source, non-Python fixtures or untracked files.",
    "populations": dict(sorted(groups.items())),
    "production_packages": dict(sorted(packages.items())),
}, indent=2))

# Selected code boundaries and the first Lesscode self-application

2026-11-01. Facdrone is read-only in this pass. These are manually selected contrasting examples, not a representative benchmark or a proposal to redesign the application. The reusable question is whether less custom implementation can preserve the same behavior and useful types.

## Selected Facdrone parts

| Boundary | Production physical lines | Selected test physical lines | Why inspect it? |
| --- | ---: | ---: | --- |
| Kernel canonical serialization plus reporting facade | 446 | 102 | Compare generic traversal, scalar policies and typed reconstruction with Lesscode's explicit readers. |
| Explicit pipeline registry | 26 | 29 | Compact negative control: a named map already expresses dispatch directly. |
| CLI pod dispatch | 88 | 131 | Stateful control: per-run authority, fresh configuration and optional caching constrain simplification. |
| Kernel unit types | 39 | 57 | Typed negative control: names encode roles and units; removing them would not establish a useful compression. |

Exact source paths, raw hashes, revision and per-file AST/logical-line measurements are in [selected-measurements.json](selected-measurements.json). [selected_measurements.py](selected_measurements.py) reads text only. Physical lines include comments, docstrings and blanks; test counts cover selected witness files, not the entire related test population or a coverage guarantee. No Facdrone code or tests were executed or edited.

Canonical serialization is the first substantial comparison boundary. Its ordered rules distinguish enums from integers, datetimes from dates, identity-only fields from full payloads, decimal tokens and floating-point identity rounding. The reporting facade delegates to the kernel. Those are observed policies to preserve, not reasons to import finance-specific semantics into Lesscode. The presence of a table is not itself evidence of compression; count its handlers and callers too.

These boundaries deliberately extend beyond the integer CEGIS fixture: dynamic typed objects, external constructors, stateful closures and floating-point units do not fit that prototype's supported source subset. Use it as an archetype for proposing and checking alternatives, not as the mandatory engine for these examples. An existing library or a direct idiom can be the better candidate; behavioral tests and explicit semantics remain the admission boundary.

The registry already uses explicit composition and reuses the smoke pipeline as the default. The dispatcher explicitly creates fresh configuration/authority per independent run and only caches runners under a supplied shared scope. Turning this into a single lookup would discard lifecycle behavior. Unit names and the checked fraction constructor communicate constraints with little machinery. Keep these controls in the sample so a future compressor must demonstrate when to leave code alone.

## Applying the same lens to Lesscode

| Boundary | Production physical lines | Selected test physical lines | First finding |
| --- | ---: | ---: | --- |
| `contracts.py` | 1,376 | 803 | 524 lines belong to `from_dict` methods, excluding decorators. Conversion is a substantial footprint, but includes real validation. |
| `report.py` | 620 | 347 | Persistence, recovery, escaping and rendering share a file; storage integrity must survive any extraction or replacement. |
| `snapshot.py` | 300 | 343 | Portable scope and safe copying are real features, not disposable support code. |

This prioritizes the **whole record conversion boundary** for the next substantial replacement trial. It does not establish that 524 lines can be deleted. The earlier [five-record library trial](../leaf-contracts/README.md) saved only four lines before full API/diagnostic compatibility and was correctly not adopted. A broader candidate must count its complete configuration, adapters, validation and dependency burden and beat that result; do not merely expand that trial's percentage to the whole module.

Compare the current typed records with one concrete alternative at a time. Keep serialization bytes, tuple/list normalization, direct-constructor revalidation, duplicate/unknown-field rejection, error paths, version checks and cross-record invariants in the behavioral boundary. Retain role-revealing field names and public APIs. Do not replace explicit code with an opaque mini-framework solely to improve LOC.

## First self-application result: tests reject a false saving

A deliberately simple candidate replaced Lesscode's recursive whole-path matcher with the standard-library `fnmatchcase`. The candidate would reduce the function from 13 physical lines to 2, before counting removable imports. It was tested through an in-memory patch against the existing snapshot tests; the production file was never overwritten.

| Implementation | Existing tests run | Failures | Errors |
| --- | ---: | ---: | ---: |
| Original | 22 | 0 | 0 |
| Standard-library substitution | 22 | 11 | 2 |

`fnmatchcase('main.py', '**/*.py')` fails to include a root-level Python file, while `fnmatchcase('src/main.py', '*.py')` matches across a separator. Both conflict with Lesscode's declared scope semantics. Downstream failures include omitted copied files. **Reject this candidate.** The reduced code is less useful because it changes the project being evaluated.

The [trial and reproduction instructions](../self-apply/README.md) retain the [raw results](../self-apply/glob-result.json), exact failure output, source/test fingerprints and counterexamples. This is a negative control, not the main compression opportunity, and not evidence that standard-library replacements generally fail.

## Test impact and the next decision

No existing product test was removed, weakened or rewritten. No new permanent product test is needed for the rejected matcher: the existing suite already catches its defects. Experimental drivers and receipts are separate research support. Product reduction in this pass is **zero**; we have identified a larger target and eliminated a misleading shortcut.

The fresh full Lesscode baseline also completed: **515 tests run, 11 skipped**, exit code 0, on Windows with CPython 3.12.10. The [baseline receipt](../self-apply/baseline-tests.txt) records the outcome. Skipped tests are not counted as verified behavior, and no cross-platform result is inferred from this run.

For an accepted replacement, first run the existing tests against the original. Add only missing behavioral checks before rewriting; establish that they exercise the intended invariant, ideally by demonstrating a counterexample or injected defect. Then run the identical checks against the candidate. Report production source, test source and experiment support separately. If tests depend on private implementation details, identify that dependency explicitly instead of silently deleting assertions to accommodate the rewrite.

The next substantial self-application should compare complete record conversion alternatives against these fixed boundaries. Accept only after behavior evidence and whole-replacement size justify the change; assess readability and navigation separately. A useful rejection is preferable to cutting features or safeguards. This pass does not amend Kiro specifications or deliver an upstream Facdrone refactor.

Reproduce the read-only measurements from Lesscode's root:

```powershell
uv.exe run --no-project --no-python-downloads --python .venv-task11/Scripts/python.exe python docs/experiments/facdrone/selected_measurements.py D:/Source/facdrone
```

Use an installed Python 3.12 interpreter via uv if that local environment path is unavailable.
